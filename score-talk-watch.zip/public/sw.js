/* Sideline service worker — wakes on a push and shows the fan's alerts. */

const TOKEN_CACHE = "sideline-push";
const TOKEN_URL = "/__sideline-push-token";

async function readToken() {
  try {
    const cache = await caches.open(TOKEN_CACHE);
    const hit = await cache.match(TOKEN_URL);
    return hit ? (await hit.text()).trim() : "";
  } catch {
    return "";
  }
}

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("push", (event) => {
  event.waitUntil(
    (async () => {
      const token = await readToken();
      if (!token) return;
      const res = await fetch(`/api/public/push/pending?token=${encodeURIComponent(token)}`, {
        cache: "no-store",
      }).catch(() => null);
      if (!res || !res.ok) return;
      const payload = await res.json().catch(() => null);
      const alerts = Array.isArray(payload?.alerts) ? payload.alerts : [];
      for (const alert of alerts) {
        await self.registration.showNotification(alert.title || "Sideline", {
          body: alert.body || "",
          tag: alert.id,
          icon: "/icon-192.png",
          badge: "/icon-192.png",
          data: { url: alert.url || "/" },
        });
      }
    })(),
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    (async () => {
      const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of all) {
        if ("focus" in client) {
          await client.focus();
          if ("navigate" in client) await client.navigate(target);
          return;
        }
      }
      await self.clients.openWindow(target);
    })(),
  );
});
