export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      alert_preferences: {
        Row: {
          breaking_news: boolean
          created_at: string
          email: string
          final_score: boolean
          game_start: boolean
          leagues: string[]
          predictions_updates: boolean
          premium_interest: boolean
          quiet_enabled: boolean
          quiet_end: number
          quiet_start: number
          score_updates: boolean
          tz_offset: number
          updated_at: string
          user_id: string
          weekly_recap: boolean
        }
        Insert: {
          breaking_news?: boolean
          created_at?: string
          email: string
          final_score?: boolean
          game_start?: boolean
          leagues?: string[]
          predictions_updates?: boolean
          premium_interest?: boolean
          quiet_enabled?: boolean
          quiet_end?: number
          quiet_start?: number
          score_updates?: boolean
          tz_offset?: number
          updated_at?: string
          user_id: string
          weekly_recap?: boolean
        }
        Update: {
          breaking_news?: boolean
          created_at?: string
          email?: string
          final_score?: boolean
          game_start?: boolean
          leagues?: string[]
          predictions_updates?: boolean
          premium_interest?: boolean
          quiet_enabled?: boolean
          quiet_end?: number
          quiet_start?: number
          score_updates?: boolean
          tz_offset?: number
          updated_at?: string
          user_id?: string
          weekly_recap?: boolean
        }
        Relationships: []
      }
      community_posts: {
        Row: {
          body: string
          created_at: string
          game_id: string
          id: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          game_id: string
          id?: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          game_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "community_posts_profile_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      crew_members: {
        Row: {
          created_at: string
          crew_id: string
          display_name: string
          invited_by: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          crew_id: string
          display_name?: string
          invited_by?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          crew_id?: string
          display_name?: string
          invited_by?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crew_members_crew_id_fkey"
            columns: ["crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
        ]
      }
      crew_messages: {
        Row: {
          author_name: string
          body: string
          created_at: string
          crew_id: string
          id: string
          user_id: string
        }
        Insert: {
          author_name: string
          body: string
          created_at?: string
          crew_id: string
          id?: string
          user_id: string
        }
        Update: {
          author_name?: string
          body?: string
          created_at?: string
          crew_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "crew_messages_crew_id_fkey"
            columns: ["crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
        ]
      }
      crews: {
        Row: {
          created_at: string
          id: string
          invite_code: string
          name: string
          owner_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          invite_code?: string
          name: string
          owner_id: string
        }
        Update: {
          created_at?: string
          id?: string
          invite_code?: string
          name?: string
          owner_id?: string
        }
        Relationships: []
      }
      daily_debates: {
        Row: {
          context: string
          created_at: string
          debate_date: string
          id: string
          league: string | null
          link: string | null
          question: string
          side_a: string
          side_b: string
          source: string
          suggested_by: string | null
        }
        Insert: {
          context?: string
          created_at?: string
          debate_date: string
          id?: string
          league?: string | null
          link?: string | null
          question: string
          side_a: string
          side_b: string
          source?: string
          suggested_by?: string | null
        }
        Update: {
          context?: string
          created_at?: string
          debate_date?: string
          id?: string
          league?: string | null
          link?: string | null
          question?: string
          side_a?: string
          side_b?: string
          source?: string
          suggested_by?: string | null
        }
        Relationships: []
      }
      debate_votes: {
        Row: {
          created_at: string
          debate_id: string
          side: string
          user_id: string
        }
        Insert: {
          created_at?: string
          debate_id: string
          side: string
          user_id: string
        }
        Update: {
          created_at?: string
          debate_id?: string
          side?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "debate_votes_debate_id_fkey"
            columns: ["debate_id"]
            isOneToOne: false
            referencedRelation: "daily_debates"
            referencedColumns: ["id"]
          },
        ]
      }
      deep_dives: {
        Row: {
          body: string
          created_at: string
          id: string
          sources: Json
          suggestion_id: string | null
          title: string
          week: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          sources?: Json
          suggestion_id?: string | null
          title: string
          week: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          sources?: Json
          suggestion_id?: string | null
          title?: string
          week?: string
        }
        Relationships: [
          {
            foreignKeyName: "deep_dives_suggestion_id_fkey"
            columns: ["suggestion_id"]
            isOneToOne: false
            referencedRelation: "topic_suggestions"
            referencedColumns: ["id"]
          },
        ]
      }
      fan_badges: {
        Row: {
          badge: string
          earned_at: string
          user_id: string
        }
        Insert: {
          badge: string
          earned_at?: string
          user_id: string
        }
        Update: {
          badge?: string
          earned_at?: string
          user_id?: string
        }
        Relationships: []
      }
      fan_post_comments: {
        Row: {
          author_name: string
          body: string
          created_at: string
          hidden: boolean
          id: string
          post_id: string
          user_id: string
        }
        Insert: {
          author_name?: string
          body: string
          created_at?: string
          hidden?: boolean
          id?: string
          post_id: string
          user_id: string
        }
        Update: {
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fan_post_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "fan_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      fan_post_likes: {
        Row: {
          created_at: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fan_post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "fan_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      fan_posts: {
        Row: {
          author_name: string
          caption: string
          category: string
          created_at: string
          hidden: boolean
          id: string
          image_path: string
          league: string | null
          team: string | null
          user_id: string
        }
        Insert: {
          author_name?: string
          caption: string
          category?: string
          created_at?: string
          hidden?: boolean
          id?: string
          image_path: string
          league?: string | null
          team?: string | null
          user_id: string
        }
        Update: {
          author_name?: string
          caption?: string
          category?: string
          created_at?: string
          hidden?: boolean
          id?: string
          image_path?: string
          league?: string | null
          team?: string | null
          user_id?: string
        }
        Relationships: []
      }
      fan_streaks: {
        Row: {
          created_at: string
          current_days: number
          last_active: string | null
          longest_days: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_days?: number
          last_active?: string | null
          longest_days?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_days?: number
          last_active?: string | null
          longest_days?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      fan_venues: {
        Row: {
          address: string
          city: string
          created_at: string
          hidden: boolean
          id: string
          league: string | null
          name: string
          notes: string
          team: string
          user_id: string
        }
        Insert: {
          address: string
          city: string
          created_at?: string
          hidden?: boolean
          id?: string
          league?: string | null
          name: string
          notes?: string
          team: string
          user_id: string
        }
        Update: {
          address?: string
          city?: string
          created_at?: string
          hidden?: boolean
          id?: string
          league?: string | null
          name?: string
          notes?: string
          team?: string
          user_id?: string
        }
        Relationships: []
      }
      fantasy_leagues: {
        Row: {
          commissioner_id: string
          created_at: string
          draft_order: string[]
          draft_turn: number
          id: string
          invite_code: string
          name: string
          roster_size: number
          sport: string
          status: string
        }
        Insert: {
          commissioner_id: string
          created_at?: string
          draft_order?: string[]
          draft_turn?: number
          id?: string
          invite_code: string
          name: string
          roster_size?: number
          sport: string
          status?: string
        }
        Update: {
          commissioner_id?: string
          created_at?: string
          draft_order?: string[]
          draft_turn?: number
          id?: string
          invite_code?: string
          name?: string
          roster_size?: number
          sport?: string
          status?: string
        }
        Relationships: []
      }
      fantasy_members: {
        Row: {
          created_at: string
          id: string
          league_id: string
          team_name: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          league_id: string
          team_name: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          league_id?: string
          team_name?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fantasy_members_league_id_fkey"
            columns: ["league_id"]
            isOneToOne: false
            referencedRelation: "fantasy_leagues"
            referencedColumns: ["id"]
          },
        ]
      }
      fantasy_messages: {
        Row: {
          body: string
          created_at: string
          id: string
          league_id: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          league_id: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          league_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fantasy_messages_league_id_fkey"
            columns: ["league_id"]
            isOneToOne: false
            referencedRelation: "fantasy_leagues"
            referencedColumns: ["id"]
          },
        ]
      }
      fantasy_picks: {
        Row: {
          dropped: boolean
          id: string
          league_id: string
          member_id: string
          picked_at: string
          player_id: string
          player_name: string
          position: string
          round: number
          team_name: string
        }
        Insert: {
          dropped?: boolean
          id?: string
          league_id: string
          member_id: string
          picked_at?: string
          player_id: string
          player_name: string
          position?: string
          round?: number
          team_name?: string
        }
        Update: {
          dropped?: boolean
          id?: string
          league_id?: string
          member_id?: string
          picked_at?: string
          player_id?: string
          player_name?: string
          position?: string
          round?: number
          team_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "fantasy_picks_league_id_fkey"
            columns: ["league_id"]
            isOneToOne: false
            referencedRelation: "fantasy_leagues"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fantasy_picks_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "fantasy_members"
            referencedColumns: ["id"]
          },
        ]
      }
      followed_teams: {
        Row: {
          created_at: string
          league: string
          logo: string | null
          name: string
          team_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          league: string
          logo?: string | null
          name: string
          team_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          league?: string
          logo?: string | null
          name?: string
          team_id?: string
          user_id?: string
        }
        Relationships: []
      }
      game_alert_state: {
        Row: {
          game_id: string
          score: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          game_id: string
          score?: string
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          game_id?: string
          score?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      game_moods: {
        Row: {
          game_id: string
          mood: string
          updated_at: string
          user_id: string
        }
        Insert: {
          game_id: string
          mood: string
          updated_at?: string
          user_id: string
        }
        Update: {
          game_id?: string
          mood?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      game_reactions: {
        Row: {
          created_at: string
          emoji: string
          game_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          game_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          game_id?: string
          user_id?: string
        }
        Relationships: []
      }
      game_stories: {
        Row: {
          body: string
          created_at: string
          game_id: string
          league: string
        }
        Insert: {
          body: string
          created_at?: string
          game_id: string
          league: string
        }
        Update: {
          body?: string
          created_at?: string
          game_id?: string
          league?: string
        }
        Relationships: []
      }
      hub_views: {
        Row: {
          created_at: string
          id: string
          label: string
          path: string
        }
        Insert: {
          created_at?: string
          id?: string
          label: string
          path: string
        }
        Update: {
          created_at?: string
          id?: string
          label?: string
          path?: string
        }
        Relationships: []
      }
      issue_pulse: {
        Row: {
          created_at: string
          stance: string
          subject_id: string
          subject_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          stance: string
          subject_id: string
          subject_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          stance?: string
          subject_id?: string
          subject_type?: string
          user_id?: string
        }
        Relationships: []
      }
      newsletter_config: {
        Row: {
          key: string
          value: string
        }
        Insert: {
          key: string
          value: string
        }
        Update: {
          key?: string
          value?: string
        }
        Relationships: []
      }
      newsletter_signup_attempts: {
        Row: {
          created_at: string
          id: string
          ip_hash: string
        }
        Insert: {
          created_at?: string
          id?: string
          ip_hash: string
        }
        Update: {
          created_at?: string
          id?: string
          ip_hash?: string
        }
        Relationships: []
      }
      newsletter_subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          leagues: string[]
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          leagues?: string[]
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          leagues?: string[]
        }
        Relationships: []
      }
      poll_votes: {
        Row: {
          created_at: string
          option_id: string
          poll_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          option_id: string
          poll_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          option_id?: string
          poll_id?: string
          user_id?: string
        }
        Relationships: []
      }
      post_likes: {
        Row: {
          created_at: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_likes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "community_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      prediction_chat: {
        Row: {
          body: string
          created_at: string
          id: string
          league: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          league: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          league?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "prediction_chat_profile_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      predictions: {
        Row: {
          correct: boolean | null
          created_at: string
          game_id: string
          game_label: string
          id: string
          kickoff: string | null
          league: string
          pick: string
          resolved: boolean
          user_id: string
        }
        Insert: {
          correct?: boolean | null
          created_at?: string
          game_id: string
          game_label: string
          id?: string
          kickoff?: string | null
          league: string
          pick: string
          resolved?: boolean
          user_id: string
        }
        Update: {
          correct?: boolean | null
          created_at?: string
          game_id?: string
          game_label?: string
          id?: string
          kickoff?: string | null
          league?: string
          pick?: string
          resolved?: boolean
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          favorite_team: string | null
          id: string
        }
        Insert: {
          created_at?: string
          display_name: string
          favorite_team?: string | null
          id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          favorite_team?: string | null
          id?: string
        }
        Relationships: []
      }
      provider_cache: {
        Row: {
          body: Json
          cache_key: string
          fetched_at: string
        }
        Insert: {
          body: Json
          cache_key: string
          fetched_at?: string
        }
        Update: {
          body?: Json
          cache_key?: string
          fetched_at?: string
        }
        Relationships: []
      }
      push_alerts: {
        Row: {
          body: string
          created_at: string
          delivered: boolean
          id: string
          title: string
          url: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          delivered?: boolean
          id?: string
          title: string
          url?: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          delivered?: boolean
          id?: string
          title?: string
          url?: string
          user_id?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          created_at: string
          endpoint: string
          id: string
          token: string
          user_id: string
        }
        Insert: {
          created_at?: string
          endpoint: string
          id?: string
          token: string
          user_id: string
        }
        Update: {
          created_at?: string
          endpoint?: string
          id?: string
          token?: string
          user_id?: string
        }
        Relationships: []
      }
      rumor_votes: {
        Row: {
          believe: boolean
          created_at: string
          post_id: string
          user_id: string
        }
        Insert: {
          believe: boolean
          created_at?: string
          post_id: string
          user_id: string
        }
        Update: {
          believe?: boolean
          created_at?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "rumor_votes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      space_follows: {
        Row: {
          created_at: string
          followee_id: string
          follower_id: string
        }
        Insert: {
          created_at?: string
          followee_id: string
          follower_id: string
        }
        Update: {
          created_at?: string
          followee_id?: string
          follower_id?: string
        }
        Relationships: []
      }
      space_members: {
        Row: {
          created_at: string
          space_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          space_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          space_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_members_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      space_notifications: {
        Row: {
          actor_name: string
          body: string
          created_at: string
          id: string
          kind: string
          post_id: string | null
          read: boolean
          user_id: string
        }
        Insert: {
          actor_name?: string
          body?: string
          created_at?: string
          id?: string
          kind: string
          post_id?: string | null
          read?: boolean
          user_id: string
        }
        Update: {
          actor_name?: string
          body?: string
          created_at?: string
          id?: string
          kind?: string
          post_id?: string | null
          read?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_notifications_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      space_poll_options: {
        Row: {
          created_at: string
          id: string
          label: string
          position: number
          post_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          label: string
          position?: number
          post_id: string
        }
        Update: {
          created_at?: string
          id?: string
          label?: string
          position?: number
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_poll_options_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      space_poll_votes: {
        Row: {
          created_at: string
          option_id: string
          post_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          option_id: string
          post_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          option_id?: string
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_poll_votes_option_id_fkey"
            columns: ["option_id"]
            isOneToOne: false
            referencedRelation: "space_poll_options"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "space_poll_votes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      space_posts: {
        Row: {
          author_name: string
          body: string
          created_at: string
          hidden: boolean
          id: string
          image_path: string | null
          kind: string
          pinned: boolean
          space_id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          image_path?: string | null
          kind?: string
          pinned?: boolean
          space_id: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          image_path?: string | null
          kind?: string
          pinned?: boolean
          space_id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_posts_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      space_replies: {
        Row: {
          author_name: string
          body: string
          created_at: string
          hidden: boolean
          id: string
          parent_id: string | null
          post_id: string
          user_id: string
        }
        Insert: {
          author_name?: string
          body: string
          created_at?: string
          hidden?: boolean
          id?: string
          parent_id?: string | null
          post_id: string
          user_id: string
        }
        Update: {
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          parent_id?: string | null
          post_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_replies_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "space_replies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "space_replies_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      space_reports: {
        Row: {
          created_at: string
          id: string
          post_id: string | null
          reason: string
          reply_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id?: string | null
          reason?: string
          reply_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string | null
          reason?: string
          reply_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_reports_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "space_reports_reply_id_fkey"
            columns: ["reply_id"]
            isOneToOne: false
            referencedRelation: "space_replies"
            referencedColumns: ["id"]
          },
        ]
      }
      space_votes: {
        Row: {
          created_at: string
          id: string
          post_id: string | null
          reply_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          post_id?: string | null
          reply_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          post_id?: string | null
          reply_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_votes_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "space_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "space_votes_reply_id_fkey"
            columns: ["reply_id"]
            isOneToOne: false
            referencedRelation: "space_replies"
            referencedColumns: ["id"]
          },
        ]
      }
      spaces: {
        Row: {
          active: boolean
          created_at: string
          created_by: string | null
          description: string
          id: string
          image: string | null
          kind: string
          league: string | null
          name: string
          slug: string
          status: string
          team_id: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          description?: string
          id?: string
          image?: string | null
          kind?: string
          league?: string | null
          name: string
          slug: string
          status?: string
          team_id?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          created_by?: string | null
          description?: string
          id?: string
          image?: string | null
          kind?: string
          league?: string | null
          name?: string
          slug?: string
          status?: string
          team_id?: string | null
        }
        Relationships: []
      }
      topic_suggestions: {
        Row: {
          answer: string | null
          author_name: string
          body: string
          created_at: string
          hidden: boolean
          id: string
          kind: string
          pinned: boolean
          status: string
          target: string | null
          title: string
          user_id: string
        }
        Insert: {
          answer?: string | null
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          kind: string
          pinned?: boolean
          status?: string
          target?: string | null
          title: string
          user_id: string
        }
        Update: {
          answer?: string | null
          author_name?: string
          body?: string
          created_at?: string
          hidden?: boolean
          id?: string
          kind?: string
          pinned?: boolean
          status?: string
          target?: string | null
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      topic_votes: {
        Row: {
          created_at: string
          suggestion_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          suggestion_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          suggestion_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "topic_votes_suggestion_id_fkey"
            columns: ["suggestion_id"]
            isOneToOne: false
            referencedRelation: "topic_suggestions"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      watch_parties: {
        Row: {
          address: string
          created_at: string
          created_by: string
          crew_id: string
          game_label: string
          id: string
          starts_at: string
          title: string
          venue: string
        }
        Insert: {
          address?: string
          created_at?: string
          created_by: string
          crew_id: string
          game_label?: string
          id?: string
          starts_at: string
          title: string
          venue: string
        }
        Update: {
          address?: string
          created_at?: string
          created_by?: string
          crew_id?: string
          game_label?: string
          id?: string
          starts_at?: string
          title?: string
          venue?: string
        }
        Relationships: [
          {
            foreignKeyName: "watch_parties_crew_id_fkey"
            columns: ["crew_id"]
            isOneToOne: false
            referencedRelation: "crews"
            referencedColumns: ["id"]
          },
        ]
      }
      watch_party_rsvps: {
        Row: {
          created_at: string
          display_name: string
          party_id: string
          status: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name: string
          party_id: string
          status: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          party_id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "watch_party_rsvps_party_id_fkey"
            columns: ["party_id"]
            isOneToOne: false
            referencedRelation: "watch_parties"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      crew_pick_standings: {
        Args: { _crew: string; _days?: number }
        Returns: {
          correct: number
          display_name: string
          pending: number
          resolved: number
          user_id: string
        }[]
      }
      crew_preview: {
        Args: { _code: string }
        Returns: {
          members: number
          name: string
        }[]
      }
      debate_vote_counts: {
        Args: never
        Returns: {
          debate_id: string
          side: string
          total: number
        }[]
      }
      diehard_leaderboard: {
        Args: { _days?: number; _team?: string }
        Returns: {
          correct_picks: number
          display_name: string
          points: number
          posts: number
          thread_posts: number
          upvotes: number
          user_id: string
        }[]
      }
      fan_post_like_counts: {
        Args: never
        Returns: {
          likes: number
          post_id: string
        }[]
      }
      fan_standing: {
        Args: { _user: string }
        Returns: {
          badges: string[]
          current_days: number
          longest_days: number
        }[]
      }
      game_mood_counts: {
        Args: { _game: string }
        Returns: {
          mood: string
          total: number
        }[]
      }
      game_reaction_counts: {
        Args: never
        Returns: {
          emoji: string
          game_id: string
          total: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_crew_member: {
        Args: { _crew: string; _user: string }
        Returns: boolean
      }
      is_fantasy_member: {
        Args: { _league: string; _user: string }
        Returns: boolean
      }
      issue_pulse_counts: {
        Args: { _id: string; _type: string }
        Returns: {
          stance: string
          total: number
        }[]
      }
      join_crew: {
        Args: { _code: string; _inviter?: string; _name: string }
        Returns: string
      }
      poll_vote_counts: {
        Args: never
        Returns: {
          option_id: string
          poll_id: string
          total: number
        }[]
      }
      post_like_counts: {
        Args: never
        Returns: {
          likes: number
          post_id: string
        }[]
      }
      record_fan_activity: { Args: never; Returns: undefined }
      refresh_fan_badges: { Args: never; Returns: undefined }
      rumor_vote_counts: {
        Args: { _post: string }
        Returns: {
          believe: boolean
          total: number
        }[]
      }
      space_follower_counts: {
        Args: never
        Returns: {
          followee_id: string
          total: number
        }[]
      }
      space_member_counts: {
        Args: never
        Returns: {
          space_id: string
          total: number
        }[]
      }
      space_poll_option_counts: {
        Args: { _post: string }
        Returns: {
          option_id: string
          total: number
        }[]
      }
      space_vote_counts: {
        Args: never
        Returns: {
          post_id: string
          reply_id: string
          total: number
        }[]
      }
      topic_vote_counts: {
        Args: never
        Returns: {
          suggestion_id: string
          total: number
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
    },
  },
} as const
