import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mlb/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mlb/news",
      title: "MLB News — Latest Headlines & Injuries — Sideline",
      description: "The latest MLB news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("mlb"),
    }),
  component: () => <SportNewsSection league="mlb" />,
});
