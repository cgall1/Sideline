import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-hockey/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-hockey/news",
      title: "College Hockey News — Latest Headlines & Injuries — Sideline",
      description: "The latest College Hockey news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("chk"),
    }),
  component: () => <SportNewsSection league="chk" />,
});
