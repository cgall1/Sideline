import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { displayNameOf, useAuth } from "@/hooks/useAuth";
import { publicCounts } from "@/lib/public-counts.functions";

export const Route = createFileRoute("/join/$code")({
  validateSearch: (s: Record<string, unknown>): { from?: string | undefined } => ({
    from: typeof s["from"] === "string" && /^[0-9a-f-]{36}$/.test(s["from"] as string) ? (s["from"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "You're Invited to a Crew — Sideline" },
      { name: "description", content: "A friend invited you to their private fan crew on Sideline. Join to chat, argue and follow the games together." },
      { property: "og:title", content: "You're invited to a crew on Sideline" },
      { property: "og:description", content: "Join your friends' private fan group on Sideline." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: JoinPage,
});

function JoinPage() {
  const { code } = Route.useParams();
  const { from } = Route.useSearch();
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: preview, isLoading } = useQuery({
    queryKey: ["crew-preview", code],
    queryFn: async () => {
      const res = await publicCounts({ data: { fn: "crew_preview", args: { _code: code.slice(0, 40) } } });
      const row = res.data?.[0];
      return row ? { name: String(row.name), members: Number(row.members) } : null;
    },
  });

  async function join() {
    if (!user) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("join_crew", { _code: code, _name: displayNameOf(user), ...(from ? { _inviter: from } : {}) });
    if (error || !data) {
      setBusy(false);
      return setErr("Couldn't join this crew. The link may have expired.");
    }
    navigate({ to: "/crews/$crewId", params: { crewId: data as string } });
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16 text-center">
      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading invite…</p>
      ) : !preview ? (
        <p className="text-sm">This invite link isn't valid. <Link to="/crews" className="text-primary underline">Start your own crew</Link></p>
      ) : (
        <>
          <p className="text-xs font-semibold uppercase tracking-widest text-primary">You're invited</p>
          <h1 className="scoreboard mt-2 text-3xl font-bold uppercase tracking-wide">{preview.name}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{preview.members} {preview.members === 1 ? "fan" : "fans"} already inside</p>
          {!loading && !user ? (
            <Link to="/auth" search={{ next: `/join/${code}${from ? `?from=${from}` : ""}` }} className="mt-6 inline-block rounded-md bg-primary px-5 py-2 text-sm font-bold text-primary-foreground">
              Sign in to join
            </Link>
          ) : (
            <button onClick={join} disabled={busy || !user} className="mt-6 rounded-md bg-primary px-5 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50">
              Join the crew
            </button>
          )}
          {err && <p className="mt-3 text-sm text-destructive">{err}</p>}
        </>
      )}
    </div>
  );
}
