import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import { leagueLeadersQueryOptions } from "@/lib/feed";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/leaders/$league")({
  loader: async ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    await context.queryClient.ensureQueryData(leagueLeadersQueryOptions(league.id as LeagueId));
    return { name: league.name, short: league.short };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Stat leaders unavailable — Sideline" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.short} Stat Leaders — Best Players by Position — Sideline`;
    const description = `Live ${loaderData.name} statistical leaders — the top five players in every major category this season, with links to each player's profile.`;
    return pageHead({ path: `/leaders/${params.league}`, title, description });
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-5xl px-4 py-16">
      These stat leaders are unavailable right now: {error.message}
    </div>
  ),
  component: LeagueLeaders,
});

function LeagueLeaders() {
  const { league } = Route.useParams();
  const { short, name } = Route.useLoaderData();
  const { data } = useSuspenseQuery(leagueLeadersQueryOptions(league as LeagueId));

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link
        to="/leaders"
        className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ← All stat leaders
      </Link>

      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">
        {short} stat leaders
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        The best {name} players this season by category and position — tap a name for their full
        profile, career stats and fan thread.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link
          to="/power-rankings/$league"
          params={{ league }}
          className="text-primary underline"
        >
          Power rankings
        </Link>
        <Link to="/rosters/$league" params={{ league }} className="text-primary underline">
          Rosters
        </Link>
        <Link to="/injuries/$league" params={{ league }} className="text-primary underline">
          Injuries
        </Link>
      </div>

      {!data.length ? (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No season stats published yet — leaders appear once games are played.
        </p>
      ) : (
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {data.map((cat) => (
            <section key={cat.name} className="rounded-md border border-border bg-card p-4">
              <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
                {cat.name}
              </h2>
              <ol className="mt-3 space-y-2">
                {cat.entries.map((entry, i) => (
                  <li key={entry.playerId} className="flex items-baseline justify-between gap-3">
                    <span className="flex items-baseline gap-2">
                      <span className="scoreboard w-4 text-xs tabular-nums text-muted-foreground">
                        {i + 1}
                      </span>
                      <Link
                        to="/players/$league/$playerId"
                        params={{ league, playerId: entry.playerId }}
                        className="text-sm font-semibold hover:text-primary"
                      >
                        {entry.name}
                      </Link>
                      {entry.position && (
                        <span className="text-xs uppercase text-muted-foreground">
                          {entry.position}
                        </span>
                      )}
                    </span>
                    <span className="scoreboard text-sm font-bold tabular-nums">{entry.value}</span>
                  </li>
                ))}
              </ol>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
