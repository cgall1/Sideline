import { Link } from "@tanstack/react-router";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { useTrackHubVisit } from "@/lib/visits";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-football`;
const TITLE = "College Football Season Calendar — Live Scores, Standings & Highlights — Sideline";
const DESCRIPTION =
  "The full college football season calendar: every game date, kickoff time and stadium, plus live scores, AP-style standings and a highlight video for each matchup.";

const SEASON_MONTHS = [8, 9, 10, 11, 12, 1];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/college-football/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("cfb"));
    context.queryClient.ensureQueryData(standingsQueryOptions("cfb"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("cfb", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "College Football Season Calendar",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              {
                "@type": "ListItem",
                position: 3,
                name: "College Football Season Calendar",
                item: PAGE_URL,
              },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The college football hub is unavailable right now: {error.message}
    </div>
  ),
  component: CollegeFootballPage,
});

function CollegeFootballPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/college-football/" });
  useTrackHubVisit("/college-football", "College Football Hub");

  return (
    <>
    <CollegeHub
      league="cfb"
      month={month}
      heading="College Football Season Calendar"
      intro="Every Saturday of the college football season in one place: live scores as they happen, national standings, the full month-by-month calendar with venues and TV, and a highlight reel for each matchup."
      seasonMonths={SEASON_MONTHS}
      onMonth={(next) => navigate({ search: { month: next } })}
    />
      <div className="mx-auto max-w-7xl px-4 pb-12 flex flex-wrap gap-4 text-sm">
        <Link to="/college-football-chat" className="font-semibold text-primary underline">
          College football chat
        </Link>
        <Link to="/college-football-predictions" className="font-semibold text-primary underline">
          Predictions
        </Link>
        <Link to="/college-football-rankings" className="font-semibold text-primary underline">
          Rankings
        </Link>
        <Link to="/college-football-results" className="font-semibold text-primary underline">
          Season results
        </Link>
        <Link to="/college-football-trivia" className="font-semibold text-primary underline">
          Trivia
        </Link>
        <Link to="/media/college-football-highlights" className="font-semibold text-primary underline">
          Highlight videos
        </Link>
        <Link to="/transfer-portal-tracker" className="font-semibold text-primary underline">
          Transfer portal tracker
        </Link>

      </div>
    </>
  );
}
