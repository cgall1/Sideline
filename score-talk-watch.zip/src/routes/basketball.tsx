import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/basketball")({
  component: BasketballSection,
});

const tab =
  "scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground";

function BasketballSection() {
  return (
    <>
      <nav
        aria-label="Basketball sections"
        className="border-b border-border bg-card/60 backdrop-blur"
      >
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            Basketball
          </span>
          <Link
            to="/basketball"
            activeOptions={{ exact: true }}
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            Home
          </Link>
          <Link
            to="/basketball/news"
            search={{ league: "nba" }}
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            News
          </Link>
          <Link
            to="/basketball/scores"
            search={{ league: "nba" }}
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            Scores
          </Link>
          <Link
            to="/basketball/standings"
            search={{ league: "nba" }}
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            Standings
          </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
