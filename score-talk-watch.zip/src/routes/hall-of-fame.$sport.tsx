import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { HALL_OF_FAME } from "@/data/legacy";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/hall-of-fame/$sport")({
  loader: ({ params }) => {
    const sport = HALL_OF_FAME.find((s) => s.slug === params.sport);
    if (!sport) throw notFound();
    return { sport };
  },
  head: ({ loaderData, params }) => {
    if (!loaderData) {
      return { meta: [{ title: "Hall of fame not found — Sideline" }, { name: "robots", content: "noindex" }] };
    }
    const s = loaderData.sport;
    return pageHead({
      path: `/hall-of-fame/${params.sport}`,
      title: `${s.name} Hall of Fame — All-Time Greats and Enshrinees — Sideline`,
      description: `${s.name} hall of fame: ${s.hall}. ${s.blurb}`,
      type: "article",
    });
  },
  component: HallSport,
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">Not found</h1>
      <Link to="/hall-of-fame" className="mt-4 inline-block underline">
        Back to the hall of fame
      </Link>
    </div>
  ),
});

function HallSport() {
  const { sport } = Route.useLoaderData();
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <Link to="/hall-of-fame" className="text-sm text-muted-foreground underline">
        All halls of fame
      </Link>
      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">
        {sport.name} hall of fame
      </h1>
      <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{sport.hall}</p>
      <p className="mt-3 text-muted-foreground">{sport.blurb}</p>

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {sport.members.map((m) => (
          <div key={m.name} className="rounded-md border border-border bg-card p-4">
            <h2 className="text-lg font-bold">{m.name}</h2>
            <p className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">{m.era}</p>
            <p className="mt-2 text-sm text-muted-foreground">{m.note}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap gap-2 text-sm">
        <Link to="/history" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Sports history
        </Link>
        <Link to="/championships" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Championship history
        </Link>
        <Link to="/records" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Franchise records
        </Link>
      </div>
    </div>
  );
}
