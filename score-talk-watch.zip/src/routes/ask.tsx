import { createFileRoute, Link } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Conversation,
  ConversationContent,
  ConversationEmptyState,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Tool, ToolHeader, ToolContent, ToolInput, ToolOutput } from "@/components/ai-elements/tool";

const SITE = "https://score-talk-watch.lovable.app";

export const Route = createFileRoute("/ask")({
  component: AskPage,
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Ask Sideline — AI sports assistant for scores, teams and picks" },
      {
        name: "description",
        content:
          "Ask Sideline anything about live scores, league tables, rosters, trades and the prediction game. Answers come straight from Sideline's own live sports data.",
      },
      { property: "og:title", content: "Ask Sideline — AI sports assistant" },
      {
        property: "og:description",
        content:
          "Live scores, tables, rosters and picks — answered from Sideline's own data.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: `${SITE}/ask` },
      { property: "og:image", content: `${SITE}/og-cover.jpg` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: `${SITE}/og-cover.jpg` },
    ],
    links: [{ rel: "canonical", href: `${SITE}/ask` }],
  }),
});

const SUGGESTIONS = [
  "What NFL games are live right now?",
  "Who leads the NBA standings?",
  "Show me the Boston Bruins roster and latest moves",
  "How are Sideline fans doing in the prediction game?",
];

function AskPage() {
  const [input, setInput] = useState("");
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { messages, sendMessage, status, stop, error } = useChat({
    transport: new DefaultChatTransport({
      api: "/api/chat",
      // The assistant runs on Sideline's account, so only signed-in fans may use it.
      headers: async () => {
        const { data } = await supabase.auth.getSession();
        const token = data.session?.access_token;
        return token ? { Authorization: `Bearer ${token}` } : {};
      },
    }),
  });

  useEffect(() => {
    let active = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (active) setSignedIn(Boolean(data.session));
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setSignedIn(Boolean(session));
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (status === "ready") textareaRef.current?.focus();
  }, [status]);

  const send = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || signedIn === false) return;
    void sendMessage({ text: trimmed });
    setInput("");
  };

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-4 py-8">
      <header className="space-y-2">
        <p className="scoreboard text-[11px] font-bold uppercase tracking-widest text-primary">
          Sideline assistant
        </p>
        <h1 className="font-display text-3xl font-bold tracking-tight md:text-4xl">
          Ask about any team, player or pick
        </h1>
        <p className="text-sm text-muted-foreground">
          Answers come from Sideline&apos;s own live scores, league tables, rosters, headlines and
          prediction board — not from guesswork.
        </p>
      </header>

      {signedIn === false ? (
        <div className="rounded-lg border border-border bg-card p-4 text-sm">
          <p className="font-semibold">Sign in to ask Sideline</p>
          <p className="mt-1 text-muted-foreground">
            The assistant is for Sideline fans with an account.{" "}
            <Link to="/auth" className="text-primary underline">
              Sign in or create a free account
            </Link>
            .
          </p>
        </div>
      ) : null}

      <div className="flex h-[60vh] flex-col overflow-hidden rounded-lg border border-border bg-card">
        <Conversation className="flex-1">
          <ConversationContent>
            {messages.length === 0 ? (
              <ConversationEmptyState
                title="Kick things off"
                description="Pick a question or type your own."
              >
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => send(s)}
                      className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary hover:text-foreground"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </ConversationEmptyState>
            ) : null}

            {messages.map((message) => (
              <Message key={message.id} from={message.role}>
                <MessageContent>
                  {message.parts.map((part, index) => {
                    if (part.type === "text") {
                      return (
                        <MessageResponse key={index}>{part.text}</MessageResponse>
                      );
                    }
                    if (part.type.startsWith("tool-")) {
                      const toolPart = part as never as {
                        type: string;
                        state: "input-streaming" | "input-available" | "output-available" | "output-error";
                        input?: unknown;
                        output?: unknown;
                        errorText?: string;
                      };
                      return (
                        <Tool key={index} defaultOpen={false}>
                          <ToolHeader type={toolPart.type as never} state={toolPart.state} />
                          <ToolContent>
                            <ToolInput input={toolPart.input} />
                            <ToolOutput
                              output={toolPart.output as never}
                              errorText={toolPart.errorText}
                            />
                          </ToolContent>
                        </Tool>
                      );
                    }
                    return null;
                  })}
                </MessageContent>
              </Message>
            ))}

            {status === "submitted" ? <Shimmer>Checking Sideline data...</Shimmer> : null}
            {error ? (
              <p className="text-sm text-destructive">
                Something went wrong reaching the assistant. Try again in a moment.
              </p>
            ) : null}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>

        <div className="border-t border-border p-3">
          <PromptInput
            onSubmit={(_message, event) => {
              event.preventDefault();
              send(input);
            }}
          >
            <PromptInputTextarea
              ref={textareaRef}
              autoFocus
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about a game, a team, a player or your picks..."
            />
            <PromptInputFooter className="justify-end">
              <PromptInputSubmit status={status} onClick={status === "streaming" ? () => void stop() : undefined} />
            </PromptInputFooter>
          </PromptInput>
        </div>
      </div>

      <p className="text-xs text-muted-foreground">
        Sideline&apos;s prediction game is for fun — no betting, no money. The assistant will not
        give gambling advice.
      </p>
    </div>
  );
}
