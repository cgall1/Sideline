import { createFileRoute } from "@tanstack/react-router";
import { CricketStandingsSection } from "@/components/sport/CricketSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/cricket/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/cricket/standings",
      title: "Cricket Standings — Live Points Tables — Sideline",
      description:
        "Points tables for the cricket tournaments running right now, re-checking the results feed every 15 seconds so finished matches land in the table immediately.",
    }),
  component: () => <CricketStandingsSection />,
});
