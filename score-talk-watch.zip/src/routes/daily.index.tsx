import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ensureDailyDebates } from "@/lib/daily.functions";
import { debatesQueryOptions } from "@/lib/daily";
import { DebateCard } from "@/components/DailyDebate";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";

const TITLE = "The Daily Debate — One Argument Every Day — Sideline";
const DESCRIPTION =
  "A new sports argument every single day, game or no game: rivalries, dynasties, all-time greats and the moments that changed sport. Pick a side and see how fans split.";

export const Route = createFileRoute("/daily/")({
  staticData: { sitemap: true },
  loader: () => ensureDailyDebates(),
  head: () => pageHead({ path: "/daily", title: TITLE, description: DESCRIPTION }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-3xl px-4 py-16">
      The debate is unavailable right now: {error.message}
    </div>
  ),
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-16">No debate for that day.</div>
  ),
  component: DailyIndex,
});

function DailyIndex() {
  const { user } = useAuth();
  const { data: debates = [], isLoading } = useQuery(debatesQueryOptions(user?.id ?? null));
  const [today, ...earlier] = debates;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">The daily debate</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        One argument a day, whether anyone is playing or not. Pick your side, come back tomorrow for
        a new one.
      </p>

      <div className="mt-8">
        {isLoading && <p className="text-sm text-muted-foreground">Loading today's debate…</p>}
        {today && <DebateCard debate={today} />}
      </div>

      {earlier.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Earlier debates</h2>
          <div className="mt-4 grid gap-4">
            {earlier.map((d) => (
              <DebateCard key={d.id} debate={d} compact />
            ))}
          </div>
        </section>
      )}

      <div className="mt-10 flex flex-wrap gap-2 text-sm">
        <Link to="/community" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Fan community
        </Link>
        <Link to="/throwback" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Throwback threads
        </Link>
        <Link to="/offseason" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Off-season desk
        </Link>
      </div>
    </div>
  );
}
