import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/college-basketball")({
  component: CBBSection,
});

function CBBSection() {
  return (
    <>
      <nav
        aria-label="College Basketball sections"
        className="border-b border-border bg-card/60 backdrop-blur"
      >
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            College Basketball
          </span>
        <Link
          to="/college-basketball"
          activeOptions={{ exact: true }}
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Home
        </Link>
        <Link
          to="/college-basketball/news"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          News
        </Link>
        <Link
          to="/college-basketball/scores"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Scores
        </Link>
        <Link
          to="/college-basketball/standings"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Standings
        </Link>
        <Link
          to="/college-basketball/schedule"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Schedule
        </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
