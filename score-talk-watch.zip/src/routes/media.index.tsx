import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, type LeagueId, type MediaKind } from "@/data/sports";
import { articlesQueryOptions } from "@/lib/feed";
import { LeagueBadge, LeagueFilter } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";

const LEAGUE_IDS = LEAGUES.map((l) => l.id) as string[];
const KINDS: (MediaKind | "all")[] = ["all", "news", "analysis", "video"];

export const Route = createFileRoute("/media/")({
  staticData: { sitemap: true },
  validateSearch: (
    search: Partial<{ league: LeagueId | "all"; kind: MediaKind | "all" }>,
  ): Partial<{ league: LeagueId | "all"; kind: MediaKind | "all" }> => {
    const rawLeague = typeof search.league === "string" ? search.league : "all";
    const rawKind = typeof search.kind === "string" ? search.kind : "all";
    return {
      league: (LEAGUE_IDS.includes(rawLeague) ? rawLeague : "all") as LeagueId | "all",
      kind: (KINDS.includes(rawKind as MediaKind) ? rawKind : "all") as MediaKind | "all",
    };
  },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(articlesQueryOptions());
  },
  head: () => ({
    meta: [
      { title: "News, Analysis & Video Highlights — Sideline" },
      {
        name: "description",
        content:
          "Reporting, tactical analysis and video highlights from across the NFL, NBA, NHL, MLB, MLS and world soccer.",
      },
      { property: "og:title", content: "News, Analysis & Video Highlights — Sideline" },
      {
        property: "og:description",
        content: "The editorial desk: breaking news, deep analysis and the week's best highlights.",
      },
      { property: "og:url", content: "https://score-talk-watch.lovable.app/media" },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
    ],
    links: [
      { rel: "canonical", href: "https://score-talk-watch.lovable.app/media" },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      Stories are unavailable: {error.message}
    </div>
  ),
  component: Media,
});

function Media() {
  const { league = "all", kind = "all" } = Route.useSearch();
  const navigate = useNavigate({ from: "/media" });
  const { data: articles } = useSuspenseQuery(articlesQueryOptions());

  const filtered = articles.filter(
    (a) => (league === "all" || a.league === league) && (kind === "all" || a.kind === kind),
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Sports News, Analysis &amp; Highlights</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        News, analysis and video highlights from every league we cover.
      </p>

      <div className="mt-4 space-y-3">
        <LeagueFilter
          value={league}
          onChange={(next) => navigate({ search: (prev) => ({ ...prev, league: next }) })}
        />
        <div className="flex flex-wrap gap-1.5">
          {KINDS.map((k) => (
            <button
              key={k}
              onClick={() => navigate({ search: (prev) => ({ ...prev, kind: k }) })}
              className={cn(
                "rounded-sm border px-3 py-1 text-xs font-semibold uppercase tracking-widest transition-colors",
                k === kind
                  ? "border-foreground bg-foreground text-background"
                  : "border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {k === "all" ? "Everything" : k}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <Link
          to="/media/nfl-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ NFL Highlights — every touchdown & top play
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/college-hockey-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ College Hockey Highlights — NCAA goals & recaps
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/nba-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ NBA Highlights — every dunk & top play
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/nhl-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ NHL Highlights — every goal & top play
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/college-football-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ College Football Highlights — every Saturday
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/mlb-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ MLB Highlights — every home run & top play
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/mls-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ MLS Highlights — every goal & match recap
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/premier-league-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ Premier League Highlights — every goal
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/laliga-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ LaLiga Highlights — goals & match recaps
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/bundesliga-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ Bundesliga Highlights — goals & top plays
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/serie-a-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ Serie A Highlights — goals & match recaps
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/ligue-1-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ Ligue 1 Highlights — goals & top plays
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>
        <Link
          to="/media/champions-league-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ▶ Champions League Highlights — every European night
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Watch now
          </span>
        </Link>


      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((a) => (
          <Link
            key={a.slug}
            to="/media/$slug"
            params={{ slug: a.slug }}
            className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <LeagueBadge league={a.league} />
                <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  {a.kind}
                </span>
              </div>
              {a.duration && (
                <span className="scoreboard rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-bold">
                  ▶ {a.duration}
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold leading-snug">{a.title}</h2>
            <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{a.dek}</p>
            <p className="mt-3 text-xs text-muted-foreground">
              {a.author} · {a.published}
            </p>
          </Link>
        ))}
        {!filtered.length && (
          <p className="text-muted-foreground">Nothing published under those filters yet.</p>
        )}
      </div>
    </div>
  );
}
