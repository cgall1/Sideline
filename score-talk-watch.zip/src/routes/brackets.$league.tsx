import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import { standingsQueryOptions } from "@/lib/feed";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/brackets/$league")({
  loader: async ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    await context.queryClient.ensureQueryData(standingsQueryOptions(league.id as LeagueId));
    return { name: league.name, short: league.short };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Bracket unavailable — Sideline" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.short} Playoff Bracket & Seeding Picture — Sideline`;
    const description = `Current ${loaderData.name} playoff seeds and projected first-round matchups, updated from live standings as results come in.`;
    return pageHead({ path: `/brackets/${params.league}`, title, description });
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-5xl px-4 py-16">
      This bracket is unavailable right now: {error.message}
    </div>
  ),
  component: LeagueBracket,
});

function LeagueBracket() {
  const { league } = Route.useParams();
  const { short, name } = Route.useLoaderData();
  const { data } = useSuspenseQuery(standingsQueryOptions(league as LeagueId));

  const seeds = data.rows.slice(0, 8);
  const pairs = seeds.length >= 4
    ? Array.from({ length: Math.floor(seeds.length / 2) }, (_, i) => ({
        high: seeds[i]!,
        low: seeds[seeds.length - 1 - i]!,
        highSeed: i + 1,
        lowSeed: seeds.length - i,
      }))
    : [];

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link
        to="/brackets"
        className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ← All brackets
      </Link>

      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">
        {short} playoff bracket
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        If the {name} postseason started today — current seeds from the live table and the
        first-round matchups they produce.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/standings" search={{ league: league as LeagueId }} className="text-primary underline">
          Full standings
        </Link>
        <Link to="/power-rankings/$league" params={{ league }} className="text-primary underline">
          Power rankings
        </Link>
        <Link to="/leaders/$league" params={{ league }} className="text-primary underline">
          Stat leaders
        </Link>
      </div>

      {!seeds.length ? (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No standings published yet — the bracket fills in once the season starts.
        </p>
      ) : (
        <>
          <section className="mt-8">
            <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
              Projected first round
            </h2>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              {pairs.map((p) => (
                <div key={p.highSeed} className="rounded-md border border-border bg-card p-4">
                  <p className="text-sm font-semibold">
                    <span className="scoreboard text-muted-foreground">{p.highSeed}.</span>{" "}
                    {p.high.team}
                  </p>
                  <p className="my-1 text-xs uppercase tracking-widest text-muted-foreground">vs</p>
                  <p className="text-sm font-semibold">
                    <span className="scoreboard text-muted-foreground">{p.lowSeed}.</span>{" "}
                    {p.low.team}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="mt-8 overflow-hidden rounded-md border border-border bg-card">
            <table className="w-full text-sm">
              <thead>
                <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                  <th className="px-4 py-2 text-left font-semibold">Seed</th>
                  <th className="px-2 py-2 text-left font-semibold">Team</th>
                  <th className="px-2 py-2 text-right font-semibold">Record</th>
                  <th className="px-4 py-2 text-right font-semibold">Streak</th>
                </tr>
              </thead>
              <tbody>
                {seeds.map((row, i) => (
                  <tr key={row.team} className="border-b border-border/60 last:border-0">
                    <td className="scoreboard px-4 py-2 tabular-nums text-muted-foreground">
                      {i + 1}
                    </td>
                    <td className="px-2 py-2 font-semibold">{row.team}</td>
                    <td className="scoreboard px-2 py-2 text-right tabular-nums">
                      {row.w}-{row.l}
                    </td>
                    <td className="scoreboard px-4 py-2 text-right">{row.streak || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </>
      )}
    </div>
  );
}
