import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CHAMPIONSHIPS } from "@/data/legacy";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/championships/$league")({
  loader: ({ params }) => {
    const league = CHAMPIONSHIPS.find((c) => c.slug === params.league);
    if (!league) throw notFound();
    return { league };
  },
  head: ({ loaderData, params }) => {
    if (!loaderData) {
      return { meta: [{ title: "Championships not found — Sideline" }, { name: "robots", content: "noindex" }] };
    }
    const c = loaderData.league;
    return pageHead({
      path: `/championships/${params.league}`,
      title: `${c.name} Champions — Every Title Winner and Most Championships — Sideline`,
      description: `${c.name} championship history: the ${c.trophy}, the franchises with the most titles and every recent champion.`,
      type: "article",
    });
  },
  component: ChampionshipPage,
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">Not found</h1>
      <Link to="/championships" className="mt-4 inline-block underline">
        Back to championship history
      </Link>
    </div>
  ),
});

function ChampionshipPage() {
  const { league } = Route.useLoaderData();
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <Link to="/championships" className="text-sm text-muted-foreground underline">
        All championships
      </Link>
      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">
        {league.name} champions
      </h1>
      <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{league.trophy}</p>
      <p className="mt-3 text-muted-foreground">{league.blurb}</p>

      <h2 className="scoreboard mt-8 text-xl font-bold uppercase tracking-wide">Most titles</h2>
      <div className="mt-3 overflow-hidden rounded-md border border-border">
        <table className="w-full text-sm">
          <tbody>
            {league.mostTitles.map((t, i) => (
              <tr key={t.team} className={i % 2 ? "bg-card" : "bg-surface-2"}>
                <td className="px-4 py-2 font-semibold">{t.team}</td>
                <td className="scoreboard px-4 py-2 text-right font-bold tabular-nums">{t.titles}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 className="scoreboard mt-8 text-xl font-bold uppercase tracking-wide">Recent champions</h2>
      <ul className="mt-3 space-y-3">
        {league.recent.map((r) => (
          <li key={r.year} className="rounded-md border border-border bg-card p-4">
            <span className="scoreboard mr-3 font-bold text-primary">{r.year}</span>
            <span className="font-semibold">{r.champion}</span>
            <p className="mt-1 text-sm text-muted-foreground">{r.note}</p>
          </li>
        ))}
      </ul>

      <div className="mt-8 flex flex-wrap gap-2 text-sm">
        <Link to="/standings" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          This season&apos;s standings
        </Link>
        <Link to="/hall-of-fame" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Hall of fame
        </Link>
        <Link to="/rivalries" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Rivalries
        </Link>
      </div>
    </div>
  );
}
