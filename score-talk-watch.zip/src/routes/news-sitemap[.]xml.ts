import { createFileRoute } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";

const BASE_URL = "https://score-talk-watch.lovable.app";

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Google News sitemaps only accept URLs published in the last two days. */
function recentDays(count: number): string[] {
  const now = Date.now();
  return Array.from({ length: count }, (_, i) =>
    new Date(now - i * 86_400_000).toISOString().slice(0, 10),
  );
}

export const Route = createFileRoute("/news-sitemap.xml")({
  staticData: { sitemap: false },
  server: {
    handlers: {
      GET: () => {
        const days = recentDays(2);
        const urls = days.flatMap((day) =>
          LEAGUES.map((league) => {
            const loc = `${BASE_URL}/news/${league.id}/${day}`;
            const title = `${league.name} News & Scores — ${day}`;
            return [
              "  <url>",
              `    <loc>${escapeXml(loc)}</loc>`,
              "    <news:news>",
              "      <news:publication>",
              "        <news:name>Sideline</news:name>",
              "        <news:language>en</news:language>",
              "      </news:publication>",
              `      <news:publication_date>${day}</news:publication_date>`,
              `      <news:title>${escapeXml(title)}</news:title>`,
              "    </news:news>",
              "  </url>",
            ].join("\n");
          }),
        );

        const xml = [
          '<?xml version="1.0" encoding="UTF-8"?>',
          '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">',
          ...urls,
          "</urlset>",
        ].join("\n");

        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=900" },
        });
      },
    },
  },
});
