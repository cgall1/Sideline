import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/ncaa-volleyball`;
const TITLE =
  "NCAA Volleyball Scores, Standings & Schedule — College Volleyball Hub — Sideline";
const DESCRIPTION =
  "Live NCAA women's volleyball scores, national rankings and a month-by-month schedule with first-serve times, arenas and TV — plus team rosters, news and match threads for every match.";

const SEASON_MONTHS = [8, 9, 10, 11, 12];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/ncaa-volleyball")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("vball"));
    context.queryClient.ensureQueryData(standingsQueryOptions("vball"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("vball", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NCAA Volleyball Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "NCAA Volleyball Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NCAA volleyball hub is unavailable right now: {error.message}
    </div>
  ),
  component: VolleyballPage,
});

function VolleyballPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/ncaa-volleyball" });
  useTrackHubVisit("/ncaa-volleyball", "NCAA Volleyball Hub");

  return (
    <>
      <CollegeHub
        league="vball"
        month={month}
        heading="NCAA Volleyball Scores & Rankings"
        intro="Live NCAA women's volleyball scores, the national rankings, and a month-by-month schedule with first-serve times, arenas and TV — with a match thread beside every match."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball live scores
        </Link>
        <Link to="/results" search={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball season results
        </Link>
        <Link to="/directory/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          Every NCAA volleyball team
        </Link>
        <Link to="/rosters/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball rosters
        </Link>
        <Link to="/news" search={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball news
        </Link>
        <Link to="/standings" search={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball standings
        </Link>
        <Link to="/team-stats/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball advanced team stats
        </Link>
        <Link to="/compare/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          Compare NCAA volleyball players
        </Link>
        <Link to="/leaders/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball stat leaders
        </Link>
        <Link to="/recap/$league" params={{ league: "vball" }} className="font-semibold text-primary underline">
          NCAA volleyball weekly recap
        </Link>
        <a href="/rss/vball.xml" className="font-semibold text-primary underline">
          NCAA volleyball news feed (RSS)
        </a>
        <Link to="/community" className="font-semibold text-primary underline">
          NCAA volleyball fan chat
        </Link>
      </div>
    </>
  );
}
