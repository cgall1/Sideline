import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { triviaByLeague } from "@/data/trivia";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-basketball-trivia`;
const TITLE = "College Basketball Trivia — NCAA Hoops Questions & Answers — Sideline";
const DESCRIPTION =
  "College basketball trivia: March Madness, NCAA tournament records, legendary coaches and rivalry questions with the answer and the story behind each one.";

const QUESTIONS = triviaByLeague("cbb");

export const Route = createFileRoute("/college-basketball-trivia")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Quiz",
          name: "College Basketball Trivia",
          url: PAGE_URL,
          about: { "@type": "Thing", name: "College basketball" },
          hasPart: QUESTIONS.map((q) => ({
            "@type": "Question",
            eduQuestionType: "Flashcard",
            name: q.question,
            acceptedAnswer: { "@type": "Answer", text: `${q.answer}. ${q.detail}` },
          })),
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: SITE },
            { "@type": "ListItem", position: 2, name: "News", item: `${SITE}/news` },
            { "@type": "ListItem", position: 3, name: "College Basketball Trivia", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  component: CbbTrivia,
});

function CbbTrivia() {
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const allShown = QUESTIONS.every((q) => revealed[q.id]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        College basketball trivia
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        {QUESTIONS.length} NCAA men&apos;s basketball questions — March Madness, tournament records,
        coaches and rivalries. Guess first, then reveal the answer.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <button
          onClick={() =>
            setRevealed(allShown ? {} : Object.fromEntries(QUESTIONS.map((q) => [q.id, true])))
          }
          className="scoreboard rounded-sm border border-border px-3 py-1.5 text-muted-foreground transition-colors hover:text-foreground"
        >
          {allShown ? "Hide all answers" : "Reveal all answers"}
        </button>
        <Link to="/college-basketball" className="self-center text-primary underline">
          Hub &amp; calendar
        </Link>
        <Link to="/college-basketball-chat" className="self-center text-primary underline">
          Fan chat
        </Link>
        <Link to="/trivia" className="self-center text-primary underline">
          All sports trivia
        </Link>
      </div>

      <ol className="mt-6 space-y-3">
        {QUESTIONS.map((q, i) => {
          const open = Boolean(revealed[q.id]);
          return (
            <li key={q.id} className="rounded-md border border-border bg-card p-4">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">
                NCAAM · {q.difficulty}
              </p>
              <h2 className="mt-2 text-lg font-bold leading-snug">
                {i + 1}. {q.question}
              </h2>
              <button
                onClick={() => setRevealed((prev) => ({ ...prev, [q.id]: !open }))}
                aria-expanded={open}
                className="scoreboard mt-3 rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
              >
                {open ? "Hide answer" : "Show answer"}
              </button>
              {open && (
                <div className="mt-3 border-l-2 border-primary pl-3">
                  <p className="scoreboard text-lg font-bold uppercase tracking-wide text-primary">
                    {q.answer}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{q.detail}</p>
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
