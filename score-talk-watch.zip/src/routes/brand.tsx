import { createFileRoute, Link } from "@tanstack/react-router";
import { pageHead } from "@/lib/seo";
import logo from "@/assets/league-logo.png";

const TITLE = "Sideline Brand Kit — Logo, Colors, Handles";
const DESCRIPTION =
  "The Sideline brand in one place: the S mark, the violet-pink-cyan palette, typography, social handles and the branded email addresses.";

export const Route = createFileRoute("/brand")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/brand", title: TITLE, description: DESCRIPTION }),
  component: BrandPage,
});

const PALETTE = [
  { name: "Electric Violet", hex: "#7C3AED", use: "Primary — buttons, links, the S ribbon" },
  { name: "Hot Magenta", hex: "#EE5FA2", use: "Accent — highlights, gradients" },
  { name: "Cyan Glow", hex: "#7DD3FC", use: "Secondary accent — sweeps, charts" },
  { name: "Live Red", hex: "#F43F5E", use: "Live markers only" },
  { name: "Off White", hex: "#F6F7FB", use: "Light background" },
  { name: "Deep Navy", hex: "#17123A", use: "Dark background" },
];

const HANDLES = [
  { platform: "X / Twitter", handle: "@sidelinehq" },
  { platform: "Instagram", handle: "@sideline.hq" },
  { platform: "TikTok", handle: "@sidelinehq" },
  { platform: "YouTube", handle: "@sidelinehq" },
  { platform: "Threads", handle: "@sideline.hq" },
  { platform: "Bluesky", handle: "@sidelinehq" },
];

const EMAILS = [
  { address: "hello@", use: "General contact, shown in the footer" },
  { address: "picks@", use: "Weekly recap and pick newsletter sender" },
  { address: "press@", use: "Media and partnership requests" },
  { address: "support@", use: "Account and app help" },
];

function BrandPage() {
  return (
    <main className="mx-auto w-full max-w-4xl px-4 py-10">
      <header className="flex flex-col items-start gap-6 sm:flex-row sm:items-center">
        <img
          src={logo}
          alt="Sideline S logo"
          width={816}
          height={816}
          className="h-24 w-24 shrink-0"
        />
        <div>
          <h1 className="scoreboard text-3xl font-black uppercase tracking-wide">Sideline brand kit</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            One S, one palette, one voice — everything Sideline puts its name on.
          </p>
        </div>
      </header>

      <section className="mt-10">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">The mark</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          The ribbon S runs violet into magenta with a cyan sweep and a red live dot. It is the
          browser tab icon, the home-screen icon, the splash screen and the app store icon. Keep
          clear space of at least half the S height on every side, and never recolor or stretch it.
        </p>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <div className="flex items-center justify-center rounded-md border border-border bg-background p-6">
            <img src={logo} alt="S mark on light" width={816} height={816} loading="lazy" className="h-20 w-20" />
          </div>
          <div className="flex items-center justify-center rounded-md border border-border bg-foreground p-6">
            <img src={logo} alt="S mark on dark" width={816} height={816} loading="lazy" className="h-20 w-20" />
          </div>
          <div
            className="flex items-center justify-center rounded-md border border-border p-6"
            style={{ background: "linear-gradient(135deg,#7C3AED,#EE5FA2)" }}
          >
            <img src={logo} alt="S mark on gradient" width={816} height={816} loading="lazy" className="h-20 w-20" />
          </div>
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Colors</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {PALETTE.map((c) => (
            <div key={c.hex} className="flex items-center gap-4 rounded-md border border-border p-3">
              <span
                className="h-12 w-12 shrink-0 rounded-md border border-border"
                style={{ backgroundColor: c.hex }}
              />
              <div className="min-w-0">
                <p className="font-semibold">{c.name}</p>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{c.hex}</p>
                <p className="mt-1 text-xs text-muted-foreground">{c.use}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Social handles</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Sideline uses one handle style across every platform, so the name reads the same wherever
          fans find us.
        </p>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {HANDLES.map((h) => (
            <div
              key={h.platform}
              className="flex items-center justify-between rounded-md border border-border px-4 py-3"
            >
              <span className="text-sm text-muted-foreground">{h.platform}</span>
              <span className="font-semibold">{h.handle}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Email addresses</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Sideline mail follows one pattern, so every message from us is recognisable at a glance.
        </p>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {EMAILS.map((e) => (
            <div key={e.address} className="rounded-md border border-border px-4 py-3">
              <p className="font-semibold">
                {e.address}
                <span className="text-muted-foreground">sideline.app</span>
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{e.use}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10 rounded-md border border-border bg-card p-5">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Voice</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Short, confident, fan-first. Scores before opinions. Never hype a result we cannot show.
          Headlines in uppercase, body copy plain and readable.
        </p>
        <Link to="/league" className="mt-4 inline-block text-sm font-semibold text-primary underline">
          See the brand applied to the league site →
        </Link>
      </section>
    </main>
  );
}
