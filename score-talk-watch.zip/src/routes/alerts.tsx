import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { LEAGUES } from "@/data/sports";
import { useAuth } from "@/hooks/useAuth";
import { useFavorites } from "@/lib/favorites";
import { alertPrefsQueryOptions, EMPTY_PREFS, saveAlertPrefs, type AlertPrefs } from "@/lib/alerts";
import { pageHead } from "@/lib/seo";
import { PushToggle } from "@/components/PushToggle";
import { NewsletterSignup } from "@/components/NewsletterSignup";

const TITLE = "Email Alerts — Scores & Breaking News for Your Teams — Sideline";
const DESCRIPTION =
  "Choose email alerts for your favourite teams: game start reminders, final scores, breaking news and predictions game results, league by league.";

const TOGGLES: Array<{ key: keyof AlertPrefs; label: string; hint: string }> = [
  { key: "gameStart", label: "Game start", hint: "A heads-up when one of your teams kicks off." },
  { key: "finalScore", label: "Final score", hint: "The result as soon as the game goes final." },
  { key: "breakingNews", label: "Breaking news", hint: "Trades, signings and injury news." },
  {
    key: "predictionsUpdates",
    label: "Predictions game",
    hint: "How your picks scored and where you sit on the leaderboard.",
  },
  {
    key: "scoreUpdates",
    label: "Score updates",
    hint: "A buzz on your phone every time the score changes in a game you follow.",
  },
  {
    key: "weeklyRecap",
    label: "Weekly recap",
    hint: "A link to your leagues' weekly recap pages each Monday.",
  },
];

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const hourLabel = (h: number) => `${String(h).padStart(2, "0")}:00`;

export const Route = createFileRoute("/alerts")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/alerts", title: TITLE, description: DESCRIPTION }),
  component: AlertsPage,
});

function AlertsPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { favorites } = useFavorites();
  const { data: stored } = useQuery(alertPrefsQueryOptions(user?.id ?? null));
  const [prefs, setPrefs] = useState<AlertPrefs>(EMPTY_PREFS);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (stored) setPrefs(stored);
    else if (user?.email) setPrefs((p) => ({ ...p, email: p.email || user.email! }));
  }, [stored, user]);

  async function save() {
    if (!user) return;
    await saveAlertPrefs(user.id, { ...prefs, tzOffset: -new Date().getTimezoneOffset() });
    await queryClient.invalidateQueries({ queryKey: ["alert-prefs"] });
    setSaved(true);
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Email alerts</h1>
      <p className="mt-2 text-muted-foreground">
        Pick what lands in your inbox: game start reminders, final scores, breaking news and how
        your predictions picks scored — for the teams and leagues you follow.
      </p>

      <div className="mt-6">
        <PushToggle />
      </div>

      {!user ? (
        <p className="mt-6 rounded-md border border-border bg-card p-4 text-sm">
          <Link to="/auth" search={{ next: "/alerts" }} className="font-semibold text-primary">
            Sign in
          </Link>{" "}
          to set up your alerts.
        </p>
      ) : (
        <div className="mt-6 space-y-6">
          <div className="rounded-md border border-border bg-card p-4">
            <label className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
              Send alerts to
            </label>
            <input
              type="email"
              value={prefs.email}
              onChange={(e) => {
                setPrefs({ ...prefs, email: e.target.value });
                setSaved(false);
              }}
              placeholder="you@example.com"
              className="mt-2 w-full rounded-sm border border-border bg-background px-3 py-2 text-sm"
            />
          </div>

          <div className="rounded-md border border-border bg-card p-4">
            <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
              What to send
            </h2>
            <ul className="mt-3 space-y-3">
              {TOGGLES.map((t) => (
                <li key={t.key as string} className="flex items-start gap-3">
                  <input
                    id={t.key as string}
                    type="checkbox"
                    checked={Boolean(prefs[t.key])}
                    onChange={(e) => {
                      setPrefs({ ...prefs, [t.key]: e.target.checked });
                      setSaved(false);
                    }}
                    className="mt-1"
                  />
                  <label htmlFor={t.key as string} className="text-sm">
                    <span className="font-semibold">{t.label}</span>
                    <span className="block text-muted-foreground">{t.hint}</span>
                  </label>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-md border border-border bg-card p-4">
            <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
              Leagues
            </h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {LEAGUES.map((l) => {
                const on = prefs.leagues.includes(l.id);
                return (
                  <button
                    key={l.id}
                    onClick={() => {
                      setPrefs({
                        ...prefs,
                        leagues: on
                          ? prefs.leagues.filter((x) => x !== l.id)
                          : [...prefs.leagues, l.id],
                      });
                      setSaved(false);
                    }}
                    className={`rounded-sm border px-3 py-1 text-xs font-semibold uppercase tracking-widest transition-colors ${
                      on ? "border-primary bg-primary/10 text-primary" : "border-border"
                    }`}
                  >
                    {l.short}
                  </button>
                );
              })}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              {favorites.length
                ? `Your starred teams (${favorites.map((f) => f.name).join(", ")}) are always included.`
                : "Star teams on any team page to get alerts just for them."}
            </p>
          </div>

          <div className="rounded-md border border-border bg-card p-4">
            <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
              Quiet hours
            </h2>
            <label className="mt-3 flex items-start gap-3 text-sm">
              <input
                type="checkbox"
                checked={prefs.quietEnabled}
                onChange={(e) => {
                  setPrefs({
                    ...prefs,
                    quietEnabled: e.target.checked,
                    tzOffset: -new Date().getTimezoneOffset(),
                  });
                  setSaved(false);
                }}
                className="mt-1"
              />
              <span>
                <span className="font-semibold">Hold alerts overnight</span>
                <span className="block text-muted-foreground">
                  Late finals stay silent and wait for the morning.
                </span>
              </span>
            </label>
            {prefs.quietEnabled && (
              <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
                <label className="flex items-center gap-2">
                  From
                  <select
                    value={prefs.quietStart}
                    onChange={(e) => {
                      setPrefs({ ...prefs, quietStart: Number(e.target.value) });
                      setSaved(false);
                    }}
                    className="rounded-sm border border-border bg-background px-2 py-1"
                  >
                    {HOURS.map((h) => (
                      <option key={h} value={h}>{hourLabel(h)}</option>
                    ))}
                  </select>
                </label>
                <label className="flex items-center gap-2">
                  until
                  <select
                    value={prefs.quietEnd}
                    onChange={(e) => {
                      setPrefs({ ...prefs, quietEnd: Number(e.target.value) });
                      setSaved(false);
                    }}
                    className="rounded-sm border border-border bg-background px-2 py-1"
                  >
                    {HOURS.map((h) => (
                      <option key={h} value={h}>{hourLabel(h)}</option>
                    ))}
                  </select>
                </label>
                <span className="text-xs text-muted-foreground">your local time</span>
              </div>
            )}
            <p className="mt-3 text-xs text-muted-foreground">
              Every alert opens straight into the match centre for that game.
            </p>
          </div>

          <button
            onClick={() => void save()}
            className="rounded-sm bg-primary px-5 py-2 text-sm font-bold uppercase tracking-widest text-primary-foreground"
          >
            {saved ? "Preferences saved" : "Save preferences"}
          </button>

          <p className="text-xs text-muted-foreground">
            Your choices are stored now. Sending starts once the site's own sender domain is
            verified — until then nothing is emailed out.
          </p>
        </div>
      )}

      <div className="mt-8">
        <NewsletterSignup />
      </div>
    </div>
  );
}
