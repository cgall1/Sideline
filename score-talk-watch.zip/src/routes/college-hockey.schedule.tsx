import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-hockey/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-hockey/schedule",
      title: "College Hockey Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete College Hockey schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("chk"),
    }),
  component: () => <SportScheduleSection league="chk" />,
});
