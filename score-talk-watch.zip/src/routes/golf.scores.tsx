import { createFileRoute } from "@tanstack/react-router";
import { IndividualScoresSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/golf/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/golf/scores",
      title: "Golf Tournaments — Live Results & Schedule — Sideline",
      description: "Live Golf results and the full schedule of upcoming tournaments with dates, venues and finishing positions.",
    }),
  component: () => <IndividualScoresSection sport="golf" />,
});
