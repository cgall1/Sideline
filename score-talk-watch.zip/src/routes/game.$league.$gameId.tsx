import { GameStory } from "@/components/GameStory";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import { gamesQueryOptions, leagueOddsQueryOptions } from "@/lib/feed";
import { leagueOgImage, pageHead } from "@/lib/seo";
import { GameThread } from "@/components/GameThread";
import { GamePoll } from "@/components/GamePoll";
import { GameDetail } from "@/components/GameDetail";
import { PickLockIn } from "@/components/PickLockIn";
import { MatchHub } from "@/components/MatchHub";
import { WhyItMatters } from "@/components/WhyItMatters";
import { FanPulse } from "@/components/FanPulse";
import { FanMood } from "@/components/FanMood";
import { WatchMode, useDelayedGame, useWatchDelay } from "@/components/WatchMode";

export const Route = createFileRoute("/game/$league/$gameId")({
  loader: async ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    const games = await context.queryClient.ensureQueryData(
      gamesQueryOptions(league.id as LeagueId),
    );
    const game = games.find((g) => g.id === params.gameId);
    if (!game) throw notFound();
    return { game };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Game thread unavailable — Sideline" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const g = loaderData.game;
    const info = leagueById(g.league);
    const short = info?.short ?? "";
    const title = `${g.away.name} vs ${g.home.name} — Live Score & Match Thread — Sideline`;
    const description = `Live ${short} coverage of ${g.away.name} at ${g.home.name} — score, clock, venue, fan poll and a real-time match thread on Sideline.`;
    const path = `/game/${params.league}/${params.gameId}`;
    const url = `https://score-talk-watch.lovable.app${path}`;
    const head = pageHead({
      path,
      title,
      description,
      type: "article",
      image: leagueOgImage(g.league),
    });

    const statusMap: Record<string, string> = {
      live: "https://schema.org/EventScheduled",
      final: "https://schema.org/EventScheduled",
      scheduled: "https://schema.org/EventScheduled",
    };

    return {
      ...head,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SportsEvent",
            name: `${g.away.name} at ${g.home.name}`,
            description,
            url,
            startDate: g.startISO ?? undefined,
            eventStatus: statusMap[g.status] ?? "https://schema.org/EventScheduled",
            eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
            sport: info?.sport ?? short,
            location: g.venue
              ? { "@type": "Place", name: g.venue, address: g.venue }
              : undefined,
            homeTeam: { "@type": "SportsTeam", name: g.home.name },
            awayTeam: { "@type": "SportsTeam", name: g.away.name },
            competitor: [
              { "@type": "SportsTeam", name: g.home.name },
              { "@type": "SportsTeam", name: g.away.name },
            ],
            ...(g.status === "final" || g.status === "live"
              ? {
                  subjectOf: {
                    "@type": "CreativeWork",
                    name: `${g.away.abbr} ${g.awayScore} — ${g.home.abbr} ${g.homeScore}`,
                  },
                }
              : {}),
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              {
                "@type": "ListItem",
                position: 1,
                name: "Sideline",
                item: "https://score-talk-watch.lovable.app/",
              },
              {
                "@type": "ListItem",
                position: 2,
                name: "Scores",
                item: "https://score-talk-watch.lovable.app/scores",
              },
              {
                "@type": "ListItem",
                position: 3,
                name: `${info?.short ?? "League"} scoreboard`,
                item: `https://score-talk-watch.lovable.app/scores?league=${params.league}`,
              },
              {
                "@type": "ListItem",
                position: 4,
                name: `${g.away.name} at ${g.home.name}`,
                item: url,
              },
            ],
          }),
        },
      ],
    };
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-5xl px-4 py-16">
      This match thread is unavailable right now: {error.message}
    </div>
  ),
  notFoundComponent: () => (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">Game not found</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        This game is no longer on the board.{" "}
        <Link to="/scores" search={{ league: "all" }} className="text-primary underline">
          Back to live scores
        </Link>
        .
      </p>
    </div>
  ),
  component: GamePage,
});

function GamePage() {
  const { league, gameId } = Route.useParams();
  const { game: initial } = Route.useLoaderData();
  const leagueId = league as LeagueId;
  const { data: games } = useQuery(gamesQueryOptions(leagueId));
  const liveGame = games?.find((g) => g.id === gameId) ?? initial;
  const [delay, setDelay] = useWatchDelay();
  const game = useDelayedGame(liveGame, liveGame.status === "live" ? delay : 0);
  const { data: odds } = useQuery(leagueOddsQueryOptions(leagueId));
  const line = odds?.find((o) => o.id === gameId);
  const path = `/game/${league}/${gameId}`;
  const leagueName = leagueById(league)?.name ?? "League";

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link
        to="/scores"
        search={{ league: leagueId }}
        className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ← {leagueName} scores
      </Link>

      <header className="mt-4 rounded-md border border-border bg-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">
            {game.away.name} at {game.home.name}
          </h1>
          {game.status !== "scheduled" && (
            <span className="scoreboard text-3xl font-bold tabular-nums">
              {game.awayScore}–{game.homeScore}
            </span>
          )}
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          {game.venue} ·{" "}
          {game.status === "live" ? game.clock : game.status === "final" ? "Final" : game.startLabel}
          {game.broadcasters.length > 0 && ` · ${game.broadcasters.join(", ")}`}
        </p>
        {game.headline && <p className="mt-2 text-sm">{game.headline}</p>}
      </header>

      {line && (
        <section className="mt-4 rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Win probability
          </h2>
          <ul className="mt-3 space-y-2">
            {line.teams.map((t) => (
              <li key={t.abbreviation || t.name}>
                <div className="flex justify-between text-sm font-semibold">
                  <span>{t.name}</span>
                  <span className="scoreboard tabular-nums">{t.winProbability}%</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-sm bg-surface-2">
                  <div className="h-full bg-primary" style={{ width: `${t.winProbability}%` }} />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-muted-foreground">
            {[line.spread && `Spread ${line.spread}`, line.overUnder && `Total ${line.overUnder}`]
              .filter(Boolean)
              .join(" · ")}
            {line.provider && ` · ${line.provider}`} · informational only.
          </p>
        </section>
      )}

      {liveGame.status !== "final" && (
        <WatchMode gameId={game.id} live={liveGame.status === "live"} delay={delay} onDelay={setDelay} />
      )}

      <PickLockIn game={game} signInNext={path} />

      <div className="mt-4">
        <FanMood gameId={game.id} live={game.status === "live"} signInNext={path} />
      </div>

      <div className="mt-4">
        <GamePoll
          gameId={game.id}
          home={game.home.name}
          away={game.away.name}
          signInNext={path}
        />
      </div>

      <GameStory league={leagueId} gameId={game.id} final={game.status === "final"} />

      <WhyItMatters league={leagueId} game={game} />

      <div className="mt-4">
        <FanPulse type="game" id={game.id} question={`Is this game a turning point for ${game.home.name} or ${game.away.name}?`} />
      </div>

      <GameDetail league={leagueId} gameId={game.id} />

      <MatchHub league={leagueId} game={game} />

      <section className="mt-4">
        <GameThread gameId={game.id} signInNext={path} heading="Match thread" delaySec={liveGame.status === "live" ? delay : 0} />
      </section>

      <div className="mt-6 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/scores" search={{ league: leagueId }} className="text-primary underline">
          All scores
        </Link>
        <Link to="/standings" search={{ league: leagueId }} className="text-primary underline">
          Standings
        </Link>
        <Link to="/odds" search={{ league: leagueId }} className="text-primary underline">
          Win probabilities
        </Link>
        <Link to="/predictions" className="text-primary underline">
          Predictions game
        </Link>
      </div>
    </div>
  );
}
