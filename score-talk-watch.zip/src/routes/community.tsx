import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { POLLS, REACTIONS } from "@/data/sports";
import { gamesQueryOptions } from "@/lib/feed";
import {
  castVote,
  createPost,
  deletePost,
  pollVotesQueryOptions,
  reactionsQueryOptions,
  relativeTime,
  setReaction,
  threadPostsQueryOptions,
  toggleLike,
} from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";
import { LeagueBadge } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";
import { GamePoll } from "@/components/GamePoll";
import {
  feedQueryOptions,
  sortPosts,
  spacesQueryOptions,
  toggleVote,
  type SortMode,
} from "@/lib/spaces";
import { PostCard } from "@/components/spaces/PostCard";
import { PostComposer } from "@/components/spaces/PostComposer";
import { TodaysDebate } from "@/components/DailyDebate";
import { WeeklyAwards } from "@/components/WeeklyAwards";

const SITE = "https://score-talk-watch.lovable.app";

export const Route = createFileRoute("/community")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<{ game: string }>): { game?: string | undefined } =>
    typeof search.game === "string" ? { game: search.game } : {},
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("all"));
  },
  head: () => ({
    meta: [
      { title: "Fan Community — Game Threads, Reactions & Polls — Sideline" },
      {
        name: "description",
        content:
          "Join live game threads, drop instant reactions and vote in fan polls across every league we cover.",
      },
      { property: "og:title", content: "Fan Community — Game Threads & Polls" },
      {
        property: "og:description",
        content: "Live discussion, fan reactions and interactive polls for every big game.",
      },
      { property: "og:url", content: `${SITE}/community` },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
    ],
    links: [{ rel: "canonical", href: `${SITE}/community` }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Sideline Fan Community",
          url: `${SITE}/community`,
          description:
            "Live game threads, fan reactions and interactive polls for the NFL, NBA, NHL, MLB, MLS and international soccer.",
          mainEntity: {
            "@type": "DiscussionForumPosting",
            headline: "Sideline live game threads",
            text: "Fan discussion for every live and completed game across six leagues.",
            url: `${SITE}/community`,
            author: { "@type": "Organization", name: "Sideline" },
          },
        }),
      },
    ],
  }),

  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The community is unavailable: {error.message}
    </div>
  ),
  component: Community,
});

function SignInPrompt({ what }: { what: string }) {
  return (
    <p className="text-xs text-muted-foreground">
      <Link to="/auth" search={{ next: "/community" }} className="font-semibold text-primary underline">
        Sign in
      </Link>{" "}
      to {what}.
    </p>
  );
}

function Community() {
  const { game } = Route.useSearch();
  const navigate = useNavigate({ from: "/community" });
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const userId = user?.id ?? null;

  const { data: games } = useSuspenseQuery(gamesQueryOptions("all"));
  const { data: posts } = useSuspenseQuery(threadPostsQueryOptions(userId));
  const { data: reactionData } = useSuspenseQuery(reactionsQueryOptions(userId));
  const { data: voteData } = useSuspenseQuery(pollVotesQueryOptions(userId));

  const { data: spaces } = useSuspenseQuery(spacesQueryOptions(userId));
  const { data: fanPosts } = useSuspenseQuery(feedQueryOptions(userId));

  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [sort, setSort] = useState<SortMode>("hot");

  // Fans see their own communities first; everyone else sees what's hot everywhere.
  const mySpaceIds = new Set(spaces.filter((s) => s.joined).map((s) => s.id));
  const mineFirst = mySpaceIds.size
    ? fanPosts.filter((p) => mySpaceIds.has(p.spaceId))
    : fanPosts;
  const feed = sortPosts(mineFirst.length ? mineFirst : fanPosts, sort).slice(0, 20);
  const topFans = Object.entries(
    fanPosts.reduce<Record<string, { name: string; score: number }>>((acc, p) => {
      const entry = acc[p.userId] ?? { name: p.author, score: 0 };
      entry.score += p.votes + p.replies + 1;
      acc[p.userId] = entry;
      return acc;
    }, {}),
  )
    .sort((a, b) => b[1].score - a[1].score)
    .slice(0, 5);

  // Live first, then finals, then upcoming tip-offs — every league gets a thread.
  const threadOrder = { live: 0, final: 1, scheduled: 2 } as const;
  const perLeague: Record<string, number> = {};
  const threadGames = [...games]
    .sort((a, b) => threadOrder[a.status] - threadOrder[b.status])
    // Cap each league so busy slates never crowd out another league's threads.
    .filter((g) => {
      const seen = perLeague[g.league] ?? 0;
      if (seen >= 6) return false;
      perLeague[g.league] = seen + 1;
      return true;
    });
  const activeId = game && threadGames.some((g) => g.id === game) ? game : threadGames[0]?.id;
  const active = threadGames.find((g) => g.id === activeId);
  // Oldest first so the thread reads like a live chat.
  const threadPosts = posts.filter((p) => p.gameId === activeId).slice().reverse();

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["community"] });

  // Live chat: push new messages, likes and reactions to everyone instantly.
  const [liveChat, setLiveChat] = useState(false);
  useEffect(() => {
    const channel = supabase
      .channel("community-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "community_posts" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "post_likes" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "game_reactions" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .subscribe((status) => setLiveChat(status === "SUBSCRIBED"));
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient]);

  // Keep the newest message in view as the conversation grows.
  const endRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [threadPosts.length, activeId]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !activeId || !userId || busy) return;
    setBusy(true);
    try {
      await createPost(userId, activeId, text);
      setDraft("");
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  const myReaction = activeId ? reactionData.mine[activeId] : undefined;
  const reactionTotals = (activeId && reactionData.totals[activeId]) || {};

  async function react(emoji: string) {
    if (!userId || !activeId) return;
    await setReaction(activeId, userId, myReaction === emoji ? null : emoji);
    await refresh();
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        Sports Fan Community &amp; Game Threads
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Live game threads, instant reactions and fan polls.{" "}
        {!userId && "Sign in to join the conversation."}
      </p>
      <Link
        to="/fan-gallery"
        className="mt-4 inline-flex items-center gap-2 rounded-md border border-primary/50 bg-primary/10 px-4 py-2 text-sm font-semibold hover:border-primary"
      >
        🎨 Fan Gallery — share your team art, gear and favourite moments
      </Link>

      <div className="mt-6">
        <TodaysDebate />
      </div>

      <div className="mt-6">
        <WeeklyAwards />
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[2fr_1fr]">
        <section>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              {mySpaceIds.size ? "Your communities" : "Hot across Sideline"}
            </h2>
            <div className="flex gap-2">
              {(["hot", "new", "top"] as SortMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setSort(m)}
                  className={cn(
                    "scoreboard rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-widest",
                    sort === m ? "border-primary bg-primary/15 text-primary" : "border-border",
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <PostComposer spaces={spaces} signInNext="/community" />
          </div>

          <div className="mt-4 space-y-3">
            {feed.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                canVote={!!userId}
                onVote={async () => {
                  if (!userId) return;
                  await toggleVote({ postId: p.id }, userId, p.votedByMe);
                  await queryClient.invalidateQueries({ queryKey: ["spaces"] });
                }}
              />
            ))}
            {!feed.length && (
              <p className="text-sm text-muted-foreground">
                No fan posts yet — start the first conversation above.
              </p>
            )}
          </div>
        </section>

        <aside className="space-y-6">
          <div className="rounded-md border border-border bg-card p-4">
            <h3 className="scoreboard mb-2 text-sm font-bold uppercase tracking-widest">
              {mySpaceIds.size ? "Your spaces" : "Popular spaces"}
            </h3>
            <ul className="space-y-1.5 text-sm">
              {(mySpaceIds.size ? spaces.filter((s) => s.joined) : spaces)
                .slice(0, 8)
                .map((s) => (
                  <li key={s.id}>
                    <Link
                      to="/s/$slug"
                      params={{ slug: s.slug }}
                      className="font-semibold hover:text-primary hover:underline"
                    >
                      {s.name}
                    </Link>{" "}
                    <span className="text-xs text-muted-foreground">{s.members} fans</span>
                  </li>
                ))}
            </ul>
            <Link
              to="/spaces"
              className="mt-3 inline-block text-xs font-semibold text-primary hover:underline"
            >
              Browse all fan spaces →
            </Link>
          </div>

          <div className="rounded-md border border-border bg-card p-4">
            <h3 className="scoreboard mb-2 text-sm font-bold uppercase tracking-widest">
              Top fans
            </h3>
            <ul className="space-y-1.5 text-sm">
              {topFans.map(([id, fan]) => (
                <li key={id}>
                  <Link
                    to="/fan/$fanId"
                    params={{ fanId: id }}
                    className="font-semibold hover:text-primary hover:underline"
                  >
                    {fan.name}
                  </Link>
                </li>
              ))}
              {!topFans.length && (
                <li className="text-xs text-muted-foreground">Nobody has posted yet.</li>
              )}
            </ul>
          </div>
        </aside>
      </div>

      <h2 className="scoreboard mt-12 text-2xl font-bold uppercase tracking-wide">
        Live game threads
      </h2>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_2fr_1fr]">
        <aside>
          <h2 className="scoreboard mb-3 text-xl font-bold uppercase tracking-wide">Threads</h2>
          <ul className="space-y-2">
            {threadGames.map((g) => (
              <li key={g.id}>
                <button
                  onClick={() => navigate({ search: { game: g.id } })}
                  className={cn(
                    "w-full rounded-md border p-3 text-left transition-colors",
                    g.id === activeId
                      ? "border-primary bg-surface"
                      : "border-border bg-card hover:border-primary/40",
                  )}
                >
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <LeagueBadge league={g.league} />
                    {g.status === "live" ? (
                      <span className="live-dot scoreboard text-xs font-bold uppercase text-live">
                        {g.clock}
                      </span>
                    ) : (
                      <span className="scoreboard text-xs uppercase text-muted-foreground">
                        {g.status === "final" ? "Final" : g.startLabel}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold">
                    {g.status === "scheduled"
                      ? `${g.away.abbr} @ ${g.home.abbr}`
                      : `${g.away.abbr} ${g.awayScore} — ${g.homeScore} ${g.home.abbr}`}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {posts.filter((p) => p.gameId === g.id).length} posts
                  </p>
                </button>
              </li>
            ))}
            {!threadGames.length && (
              <li className="text-sm text-muted-foreground">No games in play right now.</li>
            )}
          </ul>
        </aside>

        <section>
          {active ? (
            <>
              <div className="rounded-md border border-border bg-card p-4">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
                    {active.away.name} at {active.home.name}
                  </h2>
                  <span className="scoreboard text-2xl font-bold tabular-nums">
                    {active.awayScore}–{active.homeScore}
                  </span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {active.venue} · {active.status === "live" ? active.clock : "Final"}
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  {REACTIONS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => react(emoji)}
                      disabled={!userId}
                      aria-pressed={myReaction === emoji}
                      className={cn(
                        "rounded-full border px-3 py-1.5 text-sm font-semibold transition-colors",
                        myReaction === emoji
                          ? "border-primary bg-primary/15 text-foreground"
                          : "border-border hover:border-primary/50",
                        !userId && "opacity-60",
                      )}
                    >
                      <span aria-hidden className="mr-1.5 text-base">
                        {emoji}
                      </span>
                      <span className="scoreboard tabular-nums">{reactionTotals[emoji] ?? 0}</span>
                    </button>
                  ))}
                </div>
                {!userId && <div className="mt-2"><SignInPrompt what="react" /></div>}
              </div>

              <GamePoll
                gameId={active.id}
                home={active.home.name}
                away={active.away.name}
                signInNext="/community"
              />


              <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
                <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-2.5">
                  <h3 className="scoreboard text-sm font-bold uppercase tracking-widest">
                    Live chat
                  </h3>
                  <span
                    className={cn(
                      "scoreboard text-xs font-bold uppercase tracking-widest",
                      liveChat ? "live-dot text-live" : "text-muted-foreground",
                    )}
                  >
                    {liveChat ? "Live" : "Connecting…"}
                  </span>
                </div>

                <ul className="max-h-[28rem] space-y-3 overflow-y-auto p-4">
                  {threadPosts.map((p) => (
                    <li key={p.id} className="rounded-md border border-border bg-surface p-3.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold">
                          {p.author}{" "}
                          <span className="scoreboard ml-1 rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-semibold">
                            {p.team}
                          </span>
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {relativeTime(p.createdAt)}
                        </span>
                      </div>
                      <p className="mt-1.5 text-sm">{p.body}</p>
                      <div className="mt-2 flex items-center gap-3">
                        <button
                          onClick={async () => {
                            if (!userId) return;
                            await toggleLike(p.id, userId, p.likedByMe);
                            await refresh();
                          }}
                          disabled={!userId}
                          aria-pressed={p.likedByMe}
                          className={cn(
                            "text-xs font-semibold",
                            p.likedByMe
                              ? "text-primary"
                              : "text-muted-foreground hover:text-foreground",
                          )}
                        >
                          ♥ {p.likes}
                        </button>
                        {userId === p.userId && (
                          <button
                            onClick={async () => {
                              await deletePost(p.id);
                              await refresh();
                            }}
                            className="text-xs text-muted-foreground hover:text-foreground"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </li>
                  ))}
                  {!threadPosts.length && (
                    <li className="text-sm text-muted-foreground">
                      No messages yet — be the first to say something.
                    </li>
                  )}
                  <div ref={endRef} />
                </ul>

                {userId ? (
                  <form onSubmit={submit} className="flex gap-2 border-t border-border p-3">
                    <label htmlFor="post" className="sr-only">
                      Add to the live chat
                    </label>
                    <input
                      id="post"
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      maxLength={500}
                      placeholder="Say something about this game…"
                      className="flex-1 rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
                    />
                    <button
                      type="submit"
                      disabled={busy}
                      className="scoreboard rounded-sm bg-primary px-4 py-2 text-sm font-bold uppercase tracking-widest text-primary-foreground disabled:opacity-60"
                    >
                      {busy ? "Sending…" : "Send"}
                    </button>
                  </form>
                ) : (
                  <div className="border-t border-border p-4">
                    <SignInPrompt what="join the live chat" />
                  </div>
                )}
              </div>
            </>
          ) : (
            <p className="text-muted-foreground">No active game threads right now.</p>
          )}
        </section>

        <aside>
          <h2 className="scoreboard mb-3 text-xl font-bold uppercase tracking-wide">Fan polls</h2>
          <div className="space-y-4">
            {POLLS.map((poll) => {
              const choice = voteData.mine[poll.id];
              const tallies = voteData.totals[poll.id] ?? {};
              const totals = poll.options.map((o) => tallies[o.id] ?? 0);
              const sum = totals.reduce((a, b) => a + b, 0);
              return (
                <div key={poll.id} className="rounded-md border border-border bg-card p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <LeagueBadge league={poll.league} />
                  </div>
                  <p className="font-semibold">{poll.question}</p>
                  <ul className="mt-3 space-y-2">
                    {poll.options.map((o, i) => {
                      const pct = sum ? Math.round(((totals[i] ?? 0) / sum) * 100) : 0;
                      return (
                        <li key={o.id}>
                          <button
                            onClick={async () => {
                              if (!userId) return;
                              await castVote(poll.id, userId, o.id);
                              await refresh();
                            }}
                            disabled={!userId}
                            className={cn(
                              "relative w-full overflow-hidden rounded-sm border px-3 py-2 text-left text-sm transition-colors",
                              choice === o.id ? "border-primary" : "border-border",
                              userId && "hover:border-primary/60",
                            )}
                          >
                            {choice && (
                              <span
                                aria-hidden
                                className="absolute inset-y-0 left-0 bg-primary/20"
                                style={{ width: `${pct}%` }}
                              />
                            )}
                            <span className="relative flex justify-between gap-2">
                              <span className="font-semibold">{o.label}</span>
                              {choice && <span className="scoreboard tabular-nums">{pct}%</span>}
                            </span>
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                  <p className="mt-2 text-xs text-muted-foreground">
                    {choice
                      ? `${sum.toLocaleString("en-US")} vote${sum === 1 ? "" : "s"}`
                      : userId
                        ? "Tap an option to vote"
                        : "Sign in to vote"}
                  </p>
                </div>
              );
            })}
          </div>
        </aside>
      </div>
    </div>
  );
}
