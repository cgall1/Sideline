import { useMemo, useState } from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import {
  directoryQueryOptions,
  playerProfileQueryOptions,
  teamRosterQueryOptions,
} from "@/lib/feed";
import type { DirectoryTeam } from "@/lib/directory.functions";
import type { PlayerProfile } from "@/lib/players.functions";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/compare/$league")({
  loader: async ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    await context.queryClient.ensureQueryData(directoryQueryOptions(league.id as LeagueId));
    return { name: league.name, short: league.short };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Player comparison unavailable — Sideline" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.short} Player Comparison — Compare Any Two Players — Sideline`;
    const description = `Compare any two ${loaderData.name} players side by side — bio, measurables, season averages and full season-by-season stats, straight from live league data.`;
    return pageHead({ path: `/compare/${params.league}`, title, description });
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-6xl px-4 py-16">
      The comparison tool is unavailable right now: {error.message}
    </div>
  ),
  component: ComparePage,
});

function usePlayerPicker(league: LeagueId, teams: DirectoryTeam[], initialTeam: string) {
  const [teamId, setTeamId] = useState(initialTeam);
  const [playerId, setPlayerId] = useState("");
  const roster = useQuery(teamRosterQueryOptions(league, teamId));
  const profile = useQuery(playerProfileQueryOptions(league, playerId));
  return { teamId, setTeamId, playerId, setPlayerId, roster, profile, teams };
}

function PickerCard({
  label,
  picker,
}: {
  label: string;
  picker: ReturnType<typeof usePlayerPicker>;
}) {
  const players = picker.roster.data?.players ?? [];
  return (
    <div className="rounded-md border border-border bg-card p-4">
      <p className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
        {label}
      </p>
      <label className="mt-3 block text-xs uppercase tracking-widest text-muted-foreground">
        Team
        <select
          value={picker.teamId}
          onChange={(e) => {
            picker.setTeamId(e.target.value);
            picker.setPlayerId("");
          }}
          className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
        >
          {picker.teams.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name}
            </option>
          ))}
        </select>
      </label>
      <label className="mt-3 block text-xs uppercase tracking-widest text-muted-foreground">
        Player
        <select
          value={picker.playerId}
          onChange={(e) => picker.setPlayerId(e.target.value)}
          className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
        >
          <option value="">
            {picker.roster.isLoading
              ? "Loading roster…"
              : players.length
                ? "Choose a player"
                : "No roster published"}
          </option>
          {players.map((p) => (
            <option key={p.id} value={p.id}>
              {p.jersey} {p.name} — {p.position}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}

function ProfileColumn({ profile, league }: { profile: PlayerProfile | null; league: string }) {
  if (!profile) {
    return (
      <div className="rounded-md border border-dashed border-border p-6 text-sm text-muted-foreground">
        Choose a player above to load their stats.
      </div>
    );
  }
  return (
    <div className="rounded-md border border-border bg-card p-4">
      <h3 className="scoreboard text-xl font-bold uppercase tracking-wide">{profile.name}</h3>
      <p className="text-sm text-muted-foreground">
        {profile.jersey} · {profile.position} · {profile.team}
      </p>
      <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <Row label="Height" value={profile.height} />
        <Row label="Weight" value={profile.weight} />
        <Row label="Age" value={profile.age} />
        <Row label="Experience" value={profile.experience} />
      </dl>
      {profile.summary.length > 0 && (
        <div className="mt-4">
          <p className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Season averages
          </p>
          <dl className="mt-2 grid grid-cols-2 gap-2 text-sm">
            {profile.summary.map((s) => (
              <Row key={s.label} label={s.label} value={s.value} />
            ))}
          </dl>
        </div>
      )}
      {profile.categories.slice(0, 1).map((cat) => (
        <div key={cat.name} className="mt-4 overflow-x-auto">
          <p className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
            {cat.name}
          </p>
          <table className="mt-2 w-full text-xs">
            <thead className="text-muted-foreground">
              <tr>
                <th className="py-1 text-left">Season</th>
                {cat.labels.slice(0, 6).map((l, li) => (
                  <th key={`${l}-${li}`} className="py-1 text-right">
                    {l}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {cat.rows.slice(0, 6).map((r, ri) => (
                <tr key={`${r.season}-${ri}`} className="border-t border-border">
                  <td className="py-1">{r.season}</td>
                  {r.values.slice(0, 6).map((v, vi) => (
                    <td key={vi} className="py-1 text-right">
                      {v}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
      <Link
        to="/players/$league/$playerId"
        params={{ league, playerId: profile.id }}
        className="mt-4 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
      >
        Full profile &amp; fan thread →
      </Link>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-border/60 py-1">
      <dt className="text-xs uppercase tracking-widest text-muted-foreground">{label}</dt>
      <dd className="font-semibold">{value}</dd>
    </div>
  );
}

function ComparePage() {
  const { league } = Route.useParams();
  const { short, name } = Route.useLoaderData();
  const leagueId = league as LeagueId;
  const { data: directory } = useSuspenseQuery(directoryQueryOptions(leagueId));

  const teams = useMemo(
    () =>
      directory.groups
        .flatMap((g) => g.divisions.flatMap((d) => d.teams))
        .sort((a, b) => a.name.localeCompare(b.name)),
    [directory],
  );

  const left = usePlayerPicker(leagueId, teams, teams[0]?.id ?? "");
  const right = usePlayerPicker(leagueId, teams, teams[1]?.id ?? teams[0]?.id ?? "");

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Link
        to="/compare"
        className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ← All leagues
      </Link>

      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">
        {short} player comparison
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Pick two {name} players from any teams and compare their measurables, season averages and
        season-by-season stats side by side.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/team-stats/$league" params={{ league }} className="text-primary underline">
          Advanced team stats
        </Link>
        <Link to="/leaders/$league" params={{ league }} className="text-primary underline">
          Stat leaders
        </Link>
        <Link to="/rosters/$league" params={{ league }} className="text-primary underline">
          Rosters
        </Link>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <PickerCard label="Player one" picker={left} />
        <PickerCard label="Player two" picker={right} />
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <ProfileColumn profile={left.profile.data ?? null} league={league} />
        <ProfileColumn profile={right.profile.data ?? null} league={league} />
      </div>
    </div>
  );
}
