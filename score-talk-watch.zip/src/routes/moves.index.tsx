import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Trade & Free Agency Tracker — Every League — Sideline";
const DESCRIPTION =
  "Live trade deadline and free agency tracker for the NFL, NBA, WNBA, NHL, MLB, MLS and college sports — every reported trade, signing, transfer and roster move as it lands.";

export const Route = createFileRoute("/moves/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/moves", title: TITLE, description: DESCRIPTION }),
  component: MovesIndex,
});

function MovesIndex() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        Trade &amp; free agency tracker
      </h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Every reported trade, signing, transfer and roster move, league by league, refreshed as the
        news breaks.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/moves/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{league.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {league.short} trades, signings and roster moves
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
