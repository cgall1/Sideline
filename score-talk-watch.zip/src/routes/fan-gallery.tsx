import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth, displayNameOf } from "@/hooks/useAuth";
import {
  FAN_CATEGORIES,
  addFanComment,
  categoryLabel,
  deleteFanComment,
  deleteFanPost,
  fanCommentsQueryOptions,
  fanPostsQueryOptions,
  toggleFanLike,
  uploadFanPost,
} from "@/lib/fan-gallery";
import { relativeTime } from "@/lib/community";
import { cn } from "@/lib/utils";

const SITE = "https://score-talk-watch.lovable.app";

export const Route = createFileRoute("/fan-gallery")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Fan Gallery — Share Your Team Art, Gear & Moments — Sideline" },
      {
        name: "description",
        content:
          "A fan-made gallery: share your paintings, drawings, matchday photos, jersey collections and favourite team moments with the Sideline community.",
      },
      { property: "og:title", content: "Fan Gallery — Team Art, Gear & Moments" },
      {
        property: "og:description",
        content: "Post your team art, gear and favourite moments, and cheer on other fans' work.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:url", content: `${SITE}/fan-gallery` },
      { property: "og:image", content: `${SITE}/og-cover.jpg` },
      { name: "twitter:image", content: `${SITE}/og-cover.jpg` },
    ],
    links: [{ rel: "canonical", href: `${SITE}/fan-gallery` }],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The fan gallery is unavailable: {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="mx-auto max-w-7xl px-4 py-16">Page not found.</div>,
  component: FanGallery,
});

const MAX_MB = 10;

function FanGallery() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const authorName = displayNameOf(user);

  const { data: posts = [], isLoading } = useQuery(fanPostsQueryOptions(userId));
  const { data: comments = [] } = useQuery(fanCommentsQueryOptions());

  const [filter, setFilter] = useState<string>("all");
  const [file, setFile] = useState<File | null>(null);
  const [caption, setCaption] = useState("");
  const [category, setCategory] = useState<string>("art");
  const [team, setTeam] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [commentDraft, setCommentDraft] = useState<Record<string, string>>({});

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["fan-gallery"] });
  const shown = filter === "all" ? posts : posts.filter((p) => p.category === filter);

  async function share(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!userId || !file || !caption.trim() || busy) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      setError(`Images need to be under ${MAX_MB}MB.`);
      return;
    }
    setBusy(true);
    try {
      await uploadFanPost({
        userId,
        authorName,
        file,
        caption: caption.trim().slice(0, 500),
        category,
        team: team.trim().slice(0, 60),
        league: null,
      });
      setFile(null);
      setCaption("");
      setTeam("");
      await refresh();
    } catch (err) {
      console.error("fan gallery upload failed", err);
      setError("That didn't upload — please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Fan Gallery</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Your space to show your team pride — paintings, drawings, magazine cut-outs, jerseys, tickets,
        stadium shots and the moments you'll never forget. Post yours, cheer on other fans.{" "}
        <Link to="/community" className="font-semibold text-primary underline">
          Back to the game threads
        </Link>
        .
      </p>

      {userId ? (
        <form
          onSubmit={share}
          className="mt-6 grid gap-3 rounded-md border border-border bg-card p-4 sm:grid-cols-2"
        >
          <div className="sm:col-span-2">
            <label htmlFor="fan-file" className="scoreboard text-xs font-bold uppercase tracking-widest">
              Your picture
            </label>
            <input
              id="fan-file"
              type="file"
              accept="image/*"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              className="mt-1 block w-full text-sm file:mr-3 file:rounded-sm file:border-0 file:bg-primary file:px-3 file:py-2 file:text-sm file:font-bold file:text-primary-foreground"
            />
          </div>
          <div>
            <label htmlFor="fan-cat" className="scoreboard text-xs font-bold uppercase tracking-widest">
              What is it?
            </label>
            <select
              id="fan-cat"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1 w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
            >
              {FAN_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="fan-team" className="scoreboard text-xs font-bold uppercase tracking-widest">
              Team (optional)
            </label>
            <input
              id="fan-team"
              value={team}
              onChange={(e) => setTeam(e.target.value)}
              placeholder="e.g. Lakers"
              className="mt-1 w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
            />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="fan-cap" className="scoreboard text-xs font-bold uppercase tracking-widest">
              Tell the story
            </label>
            <textarea
              id="fan-cap"
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              rows={2}
              maxLength={500}
              placeholder="Painted this the night we won the title…"
              className="mt-1 w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
            />
          </div>
          {error && <p className="sm:col-span-2 text-sm text-live">{error}</p>}
          <div className="sm:col-span-2">
            <button
              type="submit"
              disabled={busy || !file || !caption.trim()}
              className="scoreboard rounded-sm bg-primary px-5 py-2 text-sm font-bold uppercase tracking-widest text-primary-foreground disabled:opacity-60"
            >
              {busy ? "Sharing…" : "Share with the community"}
            </button>
          </div>
        </form>
      ) : (
        <p className="mt-6 rounded-md border border-border bg-card p-4 text-sm text-muted-foreground">
          <Link to="/auth" search={{ next: "/fan-gallery" }} className="font-semibold text-primary underline">
            Sign in
          </Link>{" "}
          to share your own art, gear and moments. Browsing is open to everyone.
        </p>
      )}

      <div className="mt-6 flex flex-wrap gap-2">
        {[{ id: "all", label: "Everything" }, ...FAN_CATEGORIES].map((c) => (
          <button
            key={c.id}
            onClick={() => setFilter(c.id)}
            aria-pressed={filter === c.id}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm font-semibold transition-colors",
              filter === c.id ? "border-primary bg-primary/15" : "border-border hover:border-primary/50",
            )}
          >
            {c.label}
          </button>
        ))}
      </div>

      {isLoading && <p className="mt-8 text-sm text-muted-foreground">Loading the gallery…</p>}

      {!isLoading && !shown.length && (
        <p className="mt-8 rounded-md border border-border bg-card p-8 text-center text-sm text-muted-foreground">
          Nothing here yet — be the first fan to share something.
        </p>
      )}

      <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((post) => {
          const postComments = comments.filter((c) => c.postId === post.id);
          return (
            <article key={post.id} className="overflow-hidden rounded-md border border-border bg-card">
              {post.imageUrl && (
                <img
                  src={post.imageUrl}
                  alt={post.caption}
                  loading="lazy"
                  className="aspect-[4/3] w-full bg-surface object-cover"
                />
              )}
              <div className="p-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="scoreboard rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-semibold uppercase">
                    {categoryLabel(post.category)}
                  </span>
                  {post.team && <span className="text-xs text-muted-foreground">{post.team}</span>}
                </div>
                <p className="mt-2 text-sm">{post.caption}</p>
                <p className="mt-2 text-xs text-muted-foreground">
                  {post.author} · {relativeTime(post.createdAt)}
                </p>

                <div className="mt-3 flex items-center gap-4 text-xs">
                  <button
                    type="button"
                    disabled={!userId}
                    aria-pressed={post.likedByMe}
                    onClick={async () => {
                      if (!userId) return;
                      await toggleFanLike(post.id, userId, post.likedByMe);
                      await refresh();
                    }}
                    className={cn(
                      "font-semibold uppercase tracking-widest disabled:opacity-50",
                      post.likedByMe ? "text-primary" : "text-muted-foreground hover:text-foreground",
                    )}
                  >
                    ♥ {post.likes}
                  </button>
                  {post.userId === userId && (
                    <button
                      type="button"
                      onClick={async () => {
                        await deleteFanPost(post.id);
                        await refresh();
                      }}
                      className="font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
                    >
                      Delete
                    </button>
                  )}
                </div>

                {postComments.length > 0 && (
                  <ul className="mt-3 space-y-2 border-t border-border pt-3">
                    {postComments.map((c) => (
                      <li key={c.id} className="text-xs">
                        <span className="font-semibold">{c.author}</span>{" "}
                        <span className="text-muted-foreground">{c.body}</span>
                        {c.userId === userId && (
                          <button
                            type="button"
                            onClick={async () => {
                              await deleteFanComment(c.id);
                              await refresh();
                            }}
                            className="ml-2 text-muted-foreground hover:text-foreground"
                          >
                            ×
                          </button>
                        )}
                      </li>
                    ))}
                  </ul>
                )}

                {userId && (
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const body = (commentDraft[post.id] ?? "").trim();
                      if (!body) return;
                      await addFanComment(post.id, userId, authorName, body.slice(0, 300));
                      setCommentDraft((d) => ({ ...d, [post.id]: "" }));
                      await refresh();
                    }}
                    className="mt-3 flex gap-2"
                  >
                    <input
                      value={commentDraft[post.id] ?? ""}
                      onChange={(e) =>
                        setCommentDraft((d) => ({ ...d, [post.id]: e.target.value }))
                      }
                      placeholder="Say something nice…"
                      aria-label="Add a comment"
                      maxLength={300}
                      className="flex-1 rounded-sm border border-input bg-surface px-2.5 py-1.5 text-xs outline-none focus:border-primary"
                    />
                    <button
                      type="submit"
                      className="scoreboard rounded-sm bg-surface-2 px-3 py-1.5 text-xs font-bold uppercase tracking-widest"
                    >
                      Post
                    </button>
                  </form>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
