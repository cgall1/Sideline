import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, type Article } from "@/data/sports";
import { articlesQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import { VideoReel } from "@/components/VideoReel";

const BASE_URL = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${BASE_URL}/media/mls-highlights`;

const mlsVideoSlugs = ARTICLES.filter((a) => a.league === "mls" && a.kind === "video").map(
  (a) => a.slug,
);

export const Route = createFileRoute("/media/mls-highlights")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(articlesQueryOptions());
  },
  head: () => ({
    meta: [
      { title: "MLS Highlights — Goals, Top Plays & Match Recaps — Sideline" },
      {
        name: "description",
        content:
          "Watch the latest MLS highlights: every goal, top plays and full match recaps from Major League Soccer, updated all season.",
      },
      { property: "og:title", content: "MLS Highlights — Goals, Top Plays & Match Recaps — Sideline" },
      {
        property: "og:description",
        content: "Every goal, top plays and full match recaps from Major League Soccer.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "MLS Highlights",
          description:
            "Watch the latest MLS highlights: every goal, top plays and full match recaps from Major League Soccer, updated all season.",
          url: PAGE_URL,
          hasPart: mlsVideoSlugs.map((slug) => ({
            "@type": "Article",
            headline: ARTICLES.find((a) => a.slug === slug)?.title,
            url: `${BASE_URL}/media/${slug}`,
          })),
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Media", item: `${BASE_URL}/media` },
            { "@type": "ListItem", position: 2, name: "MLS Highlights", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      MLS highlights are unavailable: {error.message}
    </div>
  ),
  component: MlsHighlights,
});

function MlsHighlights() {
  const { data: articles } = useSuspenseQuery(articlesQueryOptions());
  const videos = articles.filter((a) => a.league === "mls" && a.kind === "video");
  const more = articles.filter((a) => a.league === "mls" && a.kind !== "video");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <Link to="/media" className="hover:text-foreground">
          Media
        </Link>{" "}
        / MLS Highlights
      </p>
      <h1 className="scoreboard mt-1 text-4xl font-bold uppercase tracking-wide">
        MLS Highlights
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every goal, the week's best saves, and full match recaps from Major League Soccer — updated all season.
      </p>

      <VideoReel league="mls" heading="MLS highlight reel" intro="Goals, saves and matchday recaps straight from the MLS official video channel." />

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((a: Article) => (
          <Link
            key={a.slug}
            to="/media/$slug"
            params={{ slug: a.slug }}
            className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <LeagueBadge league={a.league} />
                <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  {a.kind}
                </span>
              </div>
              {a.duration && (
                <span className="scoreboard rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-bold">
                  ▶ {a.duration}
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold leading-snug">{a.title}</h2>
            <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{a.dek}</p>
            <p className="mt-3 text-xs text-muted-foreground">
              {a.author} · {a.published}
            </p>
          </Link>
        ))}
        {!videos.length && (
          <p className="text-muted-foreground">No MLS highlight packages published yet.</p>
        )}
      </div>

      {more.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            More from the MLS desk
          </h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {more.map((a) => (
              <Link
                key={a.slug}
                to="/media/$slug"
                params={{ slug: a.slug }}
                className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
              >
                <div className="mb-2 flex items-center gap-2">
                  <LeagueBadge league={a.league} />
                  <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    {a.kind}
                  </span>
                </div>
                <h3 className="text-lg font-bold leading-snug">{a.title}</h3>
                <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{a.dek}</p>
                <p className="mt-3 text-xs text-muted-foreground">
                  {a.author} · {a.published}
                </p>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
