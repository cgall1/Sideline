import { createFileRoute } from "@tanstack/react-router";
import { SportHub } from "@/components/SportHub";
import { sportById } from "@/lib/individual-sports.functions";
import { pageHead } from "@/lib/seo";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";

const TITLE = "Boxing Results, Fight Schedules & Highlights — Sideline";
const DESCRIPTION = "Boxing headlines from the wire, official highlight clips, fight trivia and ringside fan chat, all in one hub.";

export const Route = createFileRoute("/boxing/")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(sportEventsQueryOptions("boxing"));
    context.queryClient.ensureQueryData(sportNewsQueryOptions("boxing"));
  },
  head: () => pageHead({ path: "/boxing", title: TITLE, description: DESCRIPTION }),
  component: BoxingPage,
});

function BoxingPage() {
  const sport = sportById("boxing")!;
  return <SportHub sport={sport} />;
}
