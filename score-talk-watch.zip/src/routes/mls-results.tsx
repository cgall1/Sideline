import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { seasonResultsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/mls-results`;
const TITLE = "MLS Results — Wins, Losses, Points & Streaks — Sideline";
const DESCRIPTION =
  "Full MLS season results: every club's wins, losses, points, goals for and against and current streak, updated from the live league feed.";

export const Route = createFileRoute("/mls-results")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(seasonResultsQueryOptions("mls"));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "MLS Results",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "MLS Results", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      MLS results are unavailable right now: {error.message}
    </div>
  ),
  component: MlsResults,
});

function MlsResults() {
  const { data } = useSuspenseQuery(seasonResultsQueryOptions("mls"));
  const hasPoints = data.groups.some((g) => g.rows.some((r) => r.points !== null));

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        MLS results
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every MLS team&apos;s season record — wins, losses, win percentage,
        points and streaks — straight from the live league feed
        {data.season ? ` (${data.season} season)` : ""}.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/mls" className="text-primary underline">
          Hub &amp; calendar
        </Link>
        <Link to="/mls-chat" className="text-primary underline">
          Fan chat
        </Link>
        <Link to="/standings" search={{ league: "mls" }} className="text-primary underline">
          Standings
        </Link>
        <Link to="/results" search={{ league: "mls" }} className="text-primary underline">
          All league results
        </Link>
      </div>

      {!data.groups.length && (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No results published yet this season. Check the{" "}
          <Link to="/mls-chat" className="font-semibold text-primary underline">
            fan chat
          </Link>{" "}
          instead.
        </p>
      )}

      <div className="mt-8 space-y-8">
        {data.groups.map((group) => (
          <section
            key={group.name}
            className="overflow-hidden rounded-md border border-border bg-card"
          >
            <h2 className="scoreboard border-b border-border px-4 py-3 text-xl font-bold uppercase tracking-wide">
              {group.name}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-sm">
                <thead>
                  <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                    <th className="px-4 py-2 text-left font-semibold">Team</th>
                    <th className="px-2 py-2 text-right font-semibold">GP</th>
                    <th className="px-2 py-2 text-right font-semibold">W</th>
                    <th className="px-2 py-2 text-right font-semibold">L</th>
                    <th className="px-2 py-2 text-right font-semibold">Pct</th>
                    {hasPoints && <th className="px-2 py-2 text-right font-semibold">Pts</th>}
                    <th className="px-2 py-2 text-right font-semibold">PF</th>
                    <th className="px-2 py-2 text-right font-semibold">PA</th>
                    <th className="px-4 py-2 text-right font-semibold">Streak</th>
                  </tr>
                </thead>
                <tbody>
                  {group.rows.map((row) => (
                    <tr key={row.team} className="border-b border-border/60 last:border-0">
                      <td className="px-4 py-2 font-semibold">{row.team}</td>
                      <td className="px-2 py-2 text-right tabular-nums">{row.gp}</td>
                      <td className="px-2 py-2 text-right tabular-nums">{row.w}</td>
                      <td className="px-2 py-2 text-right tabular-nums">{row.l}</td>
                      <td className="px-2 py-2 text-right tabular-nums">{row.pct}</td>
                      {hasPoints && (
                        <td className="px-2 py-2 text-right tabular-nums">{row.points ?? "—"}</td>
                      )}
                      <td className="px-2 py-2 text-right tabular-nums">{row.pointsFor ?? "—"}</td>
                      <td className="px-2 py-2 text-right tabular-nums">
                        {row.pointsAgainst ?? "—"}
                      </td>
                      <td className="px-4 py-2 text-right text-muted-foreground">
                        {row.streak ?? "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
