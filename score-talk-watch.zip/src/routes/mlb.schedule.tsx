import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mlb/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mlb/schedule",
      title: "MLB Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete MLB schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("mlb"),
    }),
  component: () => <SportScheduleSection league="mlb" />,
});
