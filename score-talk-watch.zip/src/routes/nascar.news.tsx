import { createFileRoute } from "@tanstack/react-router";
import { IndividualNewsSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nascar/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nascar/news",
      title: "NASCAR News — Latest Headlines & Results — Sideline",
      description: "The latest NASCAR news on Sideline: headlines, results reports and roster updates, refreshed from the live sports wire.",
    }),
  component: () => <IndividualNewsSection sport="nascar" />,
});
