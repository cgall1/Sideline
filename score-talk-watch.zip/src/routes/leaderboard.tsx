import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LEAGUES } from "@/data/sports";
import { useAuth } from "@/hooks/useAuth";
import { predictionBoardQueryOptions } from "@/lib/predictions";
import { pageHead } from "@/lib/seo";

const TITLE = "Predictions Leaderboard — Top Fans by Record — Sideline";
const DESCRIPTION =
  "The Sideline predictions leaderboard: every fan's record, accuracy and best league, across the NFL, NBA, NHL, MLB, MLS and college sports.";

export const Route = createFileRoute("/leaderboard")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/leaderboard", title: TITLE, description: DESCRIPTION }),
  component: LeaderboardPage,
});

function LeaderboardPage() {
  const { user } = useAuth();
  const { data: board } = useQuery(predictionBoardQueryOptions());

  const overall = board?.overall ?? [];
  const resolvedCount = board?.resolved ?? 0;

  const byLeague = LEAGUES.map((l) => ({
    league: l,
    board: board?.byLeague[l.id] ?? [],
  })).filter((row) => row.board.length > 0);

  const streaks = (board?.streaks ?? []).slice(0, 10);
  const mine = overall.find((e) => e.userId === user?.id);
  const myRank = mine ? overall.indexOf(mine) + 1 : null;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        Predictions leaderboard
      </h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Every fan's record from the Sideline predictions game — correct picks first, then accuracy.
        {resolvedCount > 0 && ` ${resolvedCount} picks scored so far.`}
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/predictions" className="text-primary underline">
          Make your picks
        </Link>
        <Link to="/my-picks" className="text-primary underline">
          My results
        </Link>
        <Link to="/predictions-chat" className="text-primary underline">
          Fans-only picks chat
        </Link>
        <Link to="/alerts" className="text-primary underline">
          Get result alerts
        </Link>

      </div>

      {mine && (
        <p className="mt-6 rounded-md border border-primary/40 bg-primary/10 p-4 text-sm">
          You're <strong>#{myRank}</strong> — {mine.correct} correct from {mine.picks} picks (
          {mine.accuracy}% accuracy).
        </p>
      )}

      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Overall</h2>
        <div className="mt-3 overflow-x-auto rounded-md border border-border bg-card">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-widest text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-4 py-2 text-left">#</th>
                <th className="px-4 py-2 text-left">Fan</th>
                <th className="px-4 py-2 text-right">Picks</th>
                <th className="px-4 py-2 text-right">Correct</th>
                <th className="px-4 py-2 text-right">Accuracy</th>
              </tr>
            </thead>
            <tbody>
              {overall.map((entry, i) => (
                <tr
                  key={entry.userId}
                  className={`border-b border-border/60 last:border-0 ${
                    entry.userId === user?.id ? "bg-primary/5" : ""
                  }`}
                >
                  <td className="scoreboard px-4 py-2 tabular-nums">{i + 1}</td>
                  <td className="px-4 py-2 font-semibold">{entry.name}</td>
                  <td className="scoreboard px-4 py-2 text-right tabular-nums">{entry.picks}</td>
                  <td className="scoreboard px-4 py-2 text-right tabular-nums">{entry.correct}</td>
                  <td className="scoreboard px-4 py-2 text-right tabular-nums">
                    {entry.accuracy}%
                  </td>
                </tr>
              ))}
              {!overall.length && (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-muted-foreground">
                    No picks yet — be the first on the board.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {streaks.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Hot streaks</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Fans on the longest runs of correct picks right now.
          </p>
          <ol className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {streaks.map((entry, i) => (
              <li
                key={entry.userId}
                className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-2 text-sm"
              >
                <span className="font-semibold">
                  {i + 1}. {entry.name}
                </span>
                <span className="scoreboard tabular-nums text-muted-foreground">
                  {entry.current} now · best {entry.best}
                </span>
              </li>
            ))}
          </ol>
        </section>
      )}

      {byLeague.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">League boards</h2>
          <div className="mt-3 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {byLeague.map(({ league, board }) => (
              <div key={league.id} className="rounded-md border border-border bg-card p-4">
                <h3 className="scoreboard text-lg font-bold uppercase tracking-wide">
                  {league.short}
                </h3>
                <ol className="mt-2 space-y-1 text-sm">
                  {board.map((entry, i) => (
                    <li key={entry.userId} className="flex justify-between gap-3">
                      <span>
                        {i + 1}. {entry.name}
                      </span>
                      <span className="scoreboard tabular-nums text-muted-foreground">
                        {entry.correct}/{entry.picks}
                      </span>
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
