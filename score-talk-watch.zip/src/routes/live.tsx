import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, leagueById, type Game } from "@/data/sports";
import { gamesQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/live`;
const TITLE = "Live Game Feed — Scores, Clocks & Highlights — Sideline";
const DESCRIPTION =
  "Every game in one live feed: real-time scores, game clocks and a highlight video for each matchup across the NFL, NBA, NHL, MLB, MLS, college football and international soccer.";

const VIDEOS = ARTICLES.filter((a) => a.kind === "video");

/** Pick a stable highlight reel for a game: same league first, otherwise rotate. */
function reelFor(game: Game, index: number) {
  const sameLeague = VIDEOS.filter((v) => v.league === game.league);
  const pool = sameLeague.length ? sameLeague : VIDEOS;
  return pool.length ? pool[index % pool.length] : undefined;
}

export const Route = createFileRoute("/live")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("all"));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      {
        property: "og:description",
        content: "Live scores, game clocks and a highlight reel for every game on the board.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Sideline", item: SITE },
            { "@type": "ListItem", position: 2, name: "Live Game Feed", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The live feed is unavailable: {error.message}
    </div>
  ),
  component: LiveFeed,
});

function LiveFeed() {
  const {
    data: games,
    dataUpdatedAt,
    refetch,
    isFetching,
  } = useSuspenseQuery(gamesQueryOptions("all"));
  const [liveOnly, setLiveOnly] = useState(false);
  const [updatedLabel, setUpdatedLabel] = useState("");

  // Format on the client only — the server has no way to know the reader's clock.
  useEffect(() => {
    setUpdatedLabel(
      new Date(dataUpdatedAt).toLocaleTimeString(undefined, {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }),
    );
  }, [dataUpdatedAt]);

  const liveCount = games.filter((g) => g.status === "live").length;
  const shown = liveOnly ? games.filter((g) => g.status === "live") : games;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Live game feed</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Every game on the board with its score, clock and a highlight reel — refreshed
            automatically every 30 seconds. {liveCount} game{liveCount === 1 ? "" : "s"} in progress
            right now.
          </p>
        </div>
        <Link
          to="/highlights"
          className="scoreboard rounded-sm border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Game calendar
        </Link>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3 rounded-md border border-border bg-card px-4 py-3">
        <button
          type="button"
          onClick={() => void refetch()}
          disabled={isFetching}
          className="scoreboard rounded-sm border border-primary bg-primary px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-primary-foreground transition-opacity disabled:opacity-60"
        >
          {isFetching ? "Refreshing…" : "Refresh now"}
        </button>
        <button
          type="button"
          onClick={() => setLiveOnly((v) => !v)}
          aria-pressed={liveOnly}
          className={cn(
            "scoreboard rounded-sm border px-3 py-1.5 text-xs font-bold uppercase tracking-widest transition-colors",
            liveOnly
              ? "border-live bg-live text-primary-foreground"
              : "border-border text-muted-foreground hover:text-foreground",
          )}
        >
          Live only
        </button>
        <span className="text-xs text-muted-foreground" aria-live="polite">
          {updatedLabel ? `Updated ${updatedLabel}` : "Updating…"}
        </span>
      </div>

      <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((g, i) => {
          const reel = reelFor(g, i);
          return (
            <li key={g.id} className="flex flex-col rounded-md border border-border bg-card p-4">
              <div className="mb-2 flex items-center justify-between gap-2">
                <LeagueBadge league={g.league} />
                <span
                  className={cn(
                    "scoreboard text-xs font-bold uppercase",
                    g.status === "live" ? "live-dot text-live" : "text-muted-foreground",
                  )}
                >
                  {g.status === "scheduled" ? g.startLabel : g.clock}
                </span>
              </div>
              <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                <span>{g.away.name}</span>
                <span className="scoreboard text-lg tabular-nums">{g.awayScore}</span>
              </p>
              <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                <span>{g.home.name}</span>
                <span className="scoreboard text-lg tabular-nums">{g.homeScore}</span>
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                {g.venue}
                {g.broadcasters.length ? ` · ${g.broadcasters.join(", ")}` : ""}
              </p>
              {reel && (
                <Link
                  to="/media/$slug"
                  params={{ slug: reel.slug }}
                  className="mt-3 block rounded-sm border border-border bg-surface-2 p-2.5 transition-colors hover:border-primary/50"
                >
                  <span className="scoreboard text-[0.7rem] uppercase tracking-widest text-muted-foreground">
                    ▶ Highlights · {leagueById(reel.league)?.short} · {reel.duration ?? reel.readTime}
                  </span>
                  <p className="mt-0.5 text-xs font-semibold">{reel.title}</p>
                </Link>
              )}
            </li>
          );
        })}
      </ul>

      {!shown.length && (
        <p className="mt-8 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          {liveOnly ? "No games are in progress right now." : "No games on the board right now."}{" "} Check the{" "}
          <Link to="/highlights" className="underline">
            game calendar
          </Link>{" "}
          for upcoming fixtures.
        </p>
      )}
    </div>
  );
}
