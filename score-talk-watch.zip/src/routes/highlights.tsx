import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, leagueById } from "@/data/sports";
import { fetchGamesByDate } from "@/lib/live-sports.functions";
import { LeagueBadge } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/highlights`;

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function isoOffset(base: string, days: number) {
  const d = new Date(`${base}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function dayLabel(iso: string) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${iso}T12:00:00Z`));
}

const dayGamesQueryOptions = (date: string) =>
  queryOptions({
    queryKey: ["games-by-date", date],
    queryFn: () => fetchGamesByDate({ data: { date } }),
    staleTime: 60_000,
    refetchInterval: 60_000,
  });

export const Route = createFileRoute("/highlights")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<{ date: string }>): Partial<{ date: string }> =>
    typeof search.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(search.date)
      ? { date: search.date }
      : {},
  loaderDeps: ({ search: { date } }) => ({ date: date ?? todayISO() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(dayGamesQueryOptions(deps.date));
  },
  head: () => ({
    meta: [
      { title: "Daily Highlights & Game Calendar — Every League — Sideline" },
      {
        name: "description",
        content:
          "A day-by-day highlights feed and game calendar: browse past results and upcoming fixtures across the NFL, NBA, NHL, MLB, MLS and international soccer.",
      },
      { property: "og:title", content: "Daily Highlights & Game Calendar — Sideline" },
      {
        property: "og:description",
        content: "Pick any day to see final scores, live games, upcoming fixtures and highlight videos.",
      },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Sideline", item: SITE },
            { "@type": "ListItem", position: 2, name: "Daily Highlights", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The highlights feed is unavailable: {error.message}
    </div>
  ),
  component: Highlights,
});

function Highlights() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/highlights" });
  const today = todayISO();
  const date = search.date ?? today;
  const { data } = useSuspenseQuery(dayGamesQueryOptions(date));

  const days = Array.from({ length: 15 }, (_, i) => isoOffset(today, i - 7));
  const finals = data.games.filter((g) => g.status === "final");
  const live = data.games.filter((g) => g.status === "live");
  const upcoming = data.games.filter((g) => g.status === "scheduled");
  const videos = ARTICLES.filter((a) => a.kind === "video").slice(0, 6);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        Daily Highlights &amp; Game Calendar
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Pick a day to see finals, games in progress and what is coming up next across all six
        leagues — plus the highlight reels worth your time.
      </p>

      <div
        className="mt-6 flex gap-2 overflow-x-auto pb-2"
        role="group"
        aria-label="Choose a date"
      >
        {days.map((d) => (
          <button
            key={d}
            onClick={() => navigate({ search: { date: d } })}
            aria-current={d === date ? "date" : undefined}
            className={cn(
              "scoreboard shrink-0 rounded-sm border px-3 py-2 text-xs font-semibold uppercase tracking-widest transition-colors",
              d === date
                ? "border-primary bg-primary/15 text-foreground"
                : "border-border text-muted-foreground hover:border-primary/50 hover:text-foreground",
            )}
          >
            {d === today ? "Today" : dayLabel(d)}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-8">
          {[
            { label: "Live now", games: live },
            { label: "Final", games: finals },
            { label: "Upcoming", games: upcoming },
          ]
            .filter((section) => section.games.length > 0)
            .map((section) => (
              <section key={section.label}>
                <h2 className="scoreboard mb-3 text-xl font-bold uppercase tracking-wide">
                  {section.label}
                </h2>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {section.games.map((g) => (
                    <li key={g.id} className="rounded-md border border-border bg-card p-4">
                      <div className="mb-2 flex items-center justify-between gap-2">
                        <LeagueBadge league={g.league} />
                        <span
                          className={cn(
                            "scoreboard text-xs font-bold uppercase",
                            g.status === "live" ? "live-dot text-live" : "text-muted-foreground",
                          )}
                        >
                          {g.status === "scheduled" ? g.startLabel : g.clock}
                        </span>
                      </div>
                      <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                        <span>{g.away.name}</span>
                        <span className="scoreboard text-lg tabular-nums">{g.awayScore}</span>
                      </p>
                      <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                        <span>{g.home.name}</span>
                        <span className="scoreboard text-lg tabular-nums">{g.homeScore}</span>
                      </p>
                      <p className="mt-2 text-xs text-muted-foreground">
                        {g.venue}
                        {g.broadcasters.length ? ` · ${g.broadcasters.join(", ")}` : ""}
                      </p>
                    </li>
                  ))}
                </ul>
              </section>
            ))}

          {!data.games.length && (
            <p className="rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
              No games scheduled on {dayLabel(date)}. Try another day on the calendar above.
            </p>
          )}
        </div>

        <aside className="space-y-4">
          <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">Highlight reels</h2>
          <ul className="space-y-3">
            {videos.map((a) => (
              <li key={a.slug}>
                <Link
                  to="/media/$slug"
                  params={{ slug: a.slug }}
                  className="block rounded-md border border-border bg-card p-3.5 transition-colors hover:border-primary/50"
                >
                  <span className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
                    ▶ {leagueById(a.league)?.short} · {a.duration ?? a.readTime}
                  </span>
                  <p className="mt-1 text-sm font-semibold">{a.title}</p>
                </Link>
              </li>
            ))}
          </ul>
          <div className="rounded-md border border-border bg-card p-4 text-sm">
            <p className="font-semibold">League highlight hubs</p>
            <ul className="mt-2 space-y-1.5 text-muted-foreground">
              <li>
                <Link to="/media/nfl-highlights" className="hover:text-foreground">
                  NFL highlights
                </Link>
              </li>
              <li>
                <Link to="/media/nba-highlights" className="hover:text-foreground">
                  NBA highlights
                </Link>
              </li>
              <li>
                <Link to="/media/nhl-highlights" className="hover:text-foreground">
                  NHL highlights
                </Link>
              </li>
              <li>
                <Link to="/media/college-football-highlights" className="hover:text-foreground">
                  College football highlights
                </Link>
              </li>
              <li>
                <Link to="/live" className="hover:text-foreground">
                  Live game feed
                </Link>
              </li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
