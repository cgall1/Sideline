import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";
import { dropFantasyPlayer, getFantasyLeague, startFantasyDraft } from "@/lib/fantasy.functions";
import { fetchFantasyScoreboard, fetchFantasyWeek } from "@/lib/fantasy-scoring.functions";
import { useState } from "react";
import { FantasyChat } from "@/components/FantasyChat";

export const Route = createFileRoute("/fantasy/$leagueId/")({
  head: ({ params }) =>
    pageHead({
      path: `/fantasy/${params.leagueId}`,
      title: "Your Fantasy League Home — Teams, Rosters & Draft — Sideline",
      description:
        "Your private Sideline fantasy league: every team in the league, their drafted rosters, the invite code and the live snake draft.",
      noindex: true,
    }),
  component: FantasyLeaguePage,
});

function FantasyLeaguePage() {
  const { leagueId } = useParams({ from: "/fantasy/$leagueId/" });
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: league, error } = useQuery({
    queryKey: ["fantasy", "league", leagueId],
    queryFn: () => getFantasyLeague({ data: { leagueId } }),
    enabled: !!user,
    refetchInterval: 10_000,
  });

  const { data: scores } = useQuery({
    queryKey: ["fantasy", "scores", leagueId],
    queryFn: () => fetchFantasyScoreboard({ data: { leagueId } }),
    enabled: !!user,
    staleTime: 60_000,
    refetchInterval: 120_000,
  });

  const startDraft = useMutation({
    mutationFn: () => startFantasyDraft({ data: { leagueId } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["fantasy", "league", leagueId] }),
  });

  const drop = useMutation({
    mutationFn: (pickId: string) => dropFantasyPlayer({ data: { pickId } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["fantasy", "league", leagueId] }),
  });

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-muted-foreground">
          Fantasy leagues are for signed-in fans.{" "}
          <Link to="/auth" className="font-semibold text-primary underline">
            Sign in
          </Link>
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-muted-foreground">{error.message}</p>
        <Link to="/fantasy" className="mt-2 inline-block text-primary underline">
          Back to fantasy
        </Link>
      </div>
    );
  }

  if (!league) {
    return <div className="mx-auto max-w-3xl px-4 py-16 text-center text-muted-foreground">Loading…</div>;
  }

  const isCommissioner = league.commissionerId === user.id;
  const myMember = league.members.find((m) => m.userId === user.id);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Link to="/fantasy" className="text-xs font-semibold uppercase tracking-widest text-primary underline">
        ← Fantasy
      </Link>
      <div className="mt-2 flex flex-wrap items-center gap-3">
        <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">{league.name}</h1>
        <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent-foreground">
          {league.status === "open" ? "Open" : league.status === "drafting" ? "Draft live" : "Draft complete"}
        </span>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Share invite code <span className="font-mono font-bold text-foreground">{league.inviteCode}</span> with
        friends · {league.members.length} teams · {league.rosterSize} players each
      </p>

      <div className="mt-4 flex flex-wrap gap-3">
        {isCommissioner && league.status === "open" && (
          <button
            onClick={() => startDraft.mutate()}
            disabled={startDraft.isPending}
            className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
          >
            {startDraft.isPending ? "Starting…" : "Start the draft"}
          </button>
        )}
        {startDraft.error && <p className="self-center text-sm text-destructive">{startDraft.error.message}</p>}
        {league.status !== "open" && (
          <Link
            to="/fantasy/$leagueId/draft"
            params={{ leagueId }}
            className="rounded-md bg-secondary px-4 py-2 text-sm font-semibold text-secondary-foreground"
          >
            {league.status === "drafting" ? "Enter the draft room" : "Draft recap"}
          </Link>
        )}
      </div>

      {scores?.supported && (
        <section className="mt-8">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Standings</h2>
            <p className="text-xs uppercase tracking-widest text-muted-foreground">
              Real points from the last {scores.matchesCounted} games
            </p>
          </div>
          <div className="mt-3 overflow-hidden rounded-lg border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase tracking-widest text-muted-foreground">
                <tr>
                  <th className="p-2 text-left">#</th>
                  <th className="p-2 text-left">Team</th>
                  <th className="p-2 text-right">Played</th>
                  <th className="p-2 text-right">Points</th>
                </tr>
              </thead>
              <tbody>
                {scores.teams.map((t) => (
                  <tr
                    key={t.memberId}
                    className={`border-t border-border ${t.isMe ? "bg-primary/10" : ""}`}
                  >
                    <td className="p-2 tabular-nums">{t.rank}</td>
                    <td className="p-2">
                      <span className="font-semibold">{t.teamName}</span>{" "}
                      <span className="text-xs text-muted-foreground">{t.ownerName}</span>
                      {t.players.some((p) => p.followed) && (
                        <span className="ml-2 rounded bg-accent px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent-foreground">
                          Your teams
                        </span>
                      )}
                    </td>
                    <td className="p-2 text-right tabular-nums">
                      {t.players.reduce((s, p) => s + p.appearances, 0)}
                    </td>
                    <td className="scoreboard p-2 text-right font-bold tabular-nums">{t.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            {scores.rules
              .map((r) => `${r.label} ${r.points > 0 ? "+" : ""}${r.points}`)
              .join(" · ")}
          </p>
        </section>
      )}

      <WeekSection leagueId={leagueId} />


      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {league.members.map((m) => {
          const picks = league.picks.filter((p) => p.memberId === m.id && !p.dropped);
          const teamScore = scores?.teams.find((t) => t.memberId === m.id);
          return (
            <div key={m.id} className="rounded-lg border border-border bg-card p-4">
              <div className="flex items-baseline justify-between">
                <h2 className="font-bold">{m.teamName}</h2>
                <span className="text-xs text-muted-foreground">
                  {m.ownerName}
                  {teamScore ? ` · ${teamScore.points} pts` : ""}
                </span>
              </div>
              {picks.length === 0 ? (
                <p className="mt-2 text-xs text-muted-foreground">No players yet</p>
              ) : (
                <ul className="mt-2 space-y-1">
                  {picks.map((p) => (
                    <li key={p.id} className="flex items-center justify-between text-sm">
                      <span>
                        <span className="font-medium">{p.playerName}</span>{" "}
                        <span className="text-xs text-muted-foreground">
                          {p.position} · {p.teamName} · Rd {p.round}
                          {(() => {
                            const ps = teamScore?.players.find((x) => x.playerId === p.playerId);
                            if (!ps) return "";
                            return ` · ${ps.points} pts${ps.statLine ? ` · ${ps.statLine}` : ""}`;
                          })()}
                        </span>
                      </span>
                      {myMember?.id === m.id && (
                        <button
                          onClick={() => drop.mutate(p.id)}
                          className="text-xs text-destructive underline"
                        >
                          Drop
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>

      {myMember && (
        <FantasyChat
          leagueId={leagueId}
          userId={user.id}
          names={Object.fromEntries(league.members.map((m) => [m.userId, m.ownerName]))}
        />
      )}
    </div>
  );
}

/** One week of head-to-head matchups plus the commissioner's write-up. */
function WeekSection({ leagueId }: { leagueId: string }) {
  const [offset, setOffset] = useState(0);
  const { data: week, isFetching } = useQuery({
    queryKey: ["fantasy", "week", leagueId, offset],
    queryFn: () => fetchFantasyWeek({ data: { leagueId, weekOffset: offset } }),
    staleTime: 60_000,
  });

  if (!week?.supported) return null;

  return (
    <section className="mt-8">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
          Head to head · {week.weekLabel}
        </h2>
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest">
          <button
            onClick={() => setOffset((o) => o + 1)}
            className="rounded-md border border-border px-3 py-1"
          >
            ← Earlier week
          </button>
          <button
            onClick={() => setOffset((o) => Math.max(0, o - 1))}
            disabled={offset === 0}
            className="rounded-md border border-border px-3 py-1 disabled:opacity-40"
          >
            Later week →
          </button>
        </div>
      </div>
      <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">
        {isFetching ? "Working out the week…" : `${week.gamesCounted} games counted this week`}
      </p>

      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {week.matchups.map((m) => (
          <div key={m.home.memberId} className="rounded-lg border border-border bg-card p-4">
            {!m.away ? (
              <p className="text-sm">
                <span className="font-bold">{m.home.teamName}</span> has a bye this week ·{" "}
                <span className="scoreboard font-bold">{m.home.points}</span> pts
              </p>
            ) : (
              <>
                {[m.home, m.away].map((t, i) => {
                  const won =
                    (i === 0 && m.winner === "home") || (i === 1 && m.winner === "away");
                  return (
                    <div key={t.memberId} className="flex items-baseline justify-between py-1">
                      <span className={`text-sm ${won ? "font-bold" : ""}`}>
                        {t.teamName}
                        {t.isMe && (
                          <span className="ml-2 rounded bg-primary/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-primary">
                            You
                          </span>
                        )}
                        {t.top && (
                          <span className="ml-2 text-xs text-muted-foreground">
                            top: {t.top.playerName} ({t.top.points})
                          </span>
                        )}
                      </span>
                      <span className="scoreboard font-bold tabular-nums">{t.points}</span>
                    </div>
                  );
                })}
                {m.winner === "tie" && (
                  <p className="mt-1 text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
                    Tied
                  </p>
                )}
              </>
            )}
          </div>
        ))}
      </div>

      {week.recap.length > 0 && (
        <div className="mt-4 rounded-lg border border-border bg-muted/30 p-4">
          <h3 className="scoreboard text-sm font-bold uppercase tracking-widest">
            Commissioner's recap
          </h3>
          <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
            {week.recap.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
