import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { seasonResultsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-basketball-rankings`;
const TITLE = "College Basketball Rankings — Records, Games Left & Projected Finish — Sideline";
const DESCRIPTION =
  "College basketball rankings from the live NCAA feed: every team's record, win percentage, games left in the regular season and a projected final record.";

/** Regular-season games a Division I team typically plays. */
const SEASON_GAMES = 31;

interface RankRow {
  team: string;
  w: number;
  l: number;
  gp: number;
  pct: number;
  left: number;
  projW: number;
  projL: number;
  streak: string | null;
}

export const Route = createFileRoute("/college-basketball-rankings")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(seasonResultsQueryOptions("cbb"));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "College Basketball Rankings",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              { "@type": "ListItem", position: 2, name: "Standings", item: `${SITE}/standings` },
              {
                "@type": "ListItem",
                position: 3,
                name: "College Basketball Rankings",
                item: PAGE_URL,
              },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      College basketball rankings are unavailable right now: {error.message}
    </div>
  ),
  component: CbbRankings,
});

function CbbRankings() {
  const { data } = useSuspenseQuery(seasonResultsQueryOptions("cbb"));

  const rows: RankRow[] = data.groups
    .flatMap((group) => group.rows)
    .map((row) => {
      const gp = row.gp || row.w + row.l;
      const pct = gp > 0 ? row.w / gp : 0;
      const left = Math.max(0, SEASON_GAMES - gp);
      const projW = Math.round(row.w + left * pct);
      return {
        team: row.team,
        w: row.w,
        l: row.l,
        gp,
        pct,
        left,
        projW,
        projL: SEASON_GAMES - projW,
        streak: row.streak,
      };
    })
    .sort((a, b) => b.pct - a.pct || b.w - a.w);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        College basketball rankings
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every NCAA men&apos;s basketball team ranked by win percentage from the live league feed,
        with games left in a {SEASON_GAMES}-game regular season and a projected final record if each
        team keeps its current pace.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/standings" search={{ league: "cbb" }} className="text-primary underline">
          Standings
        </Link>
        <Link to="/college-basketball" className="text-primary underline">
          Hub &amp; calendar
        </Link>
        <Link to="/college-basketball-live" className="text-primary underline">
          Live scores
        </Link>
        <Link to="/college-basketball-results" className="text-primary underline">
          Full results
        </Link>
      </div>

      {!rows.length && (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No records published yet this season. Check the{" "}
          <Link to="/college-basketball-live" className="font-semibold text-primary underline">
            live scores
          </Link>{" "}
          instead.
        </p>
      )}

      {rows.length > 0 && (
        <div className="mt-8 overflow-hidden rounded-md border border-border bg-card">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead>
                <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                  <th className="px-4 py-2 text-left font-semibold">#</th>
                  <th className="px-2 py-2 text-left font-semibold">Team</th>
                  <th className="px-2 py-2 text-right font-semibold">W</th>
                  <th className="px-2 py-2 text-right font-semibold">L</th>
                  <th className="px-2 py-2 text-right font-semibold">Pct</th>
                  <th className="px-2 py-2 text-right font-semibold">Games left</th>
                  <th className="px-2 py-2 text-right font-semibold">Projected</th>
                  <th className="px-4 py-2 text-right font-semibold">Streak</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={row.team} className="border-b border-border/60 last:border-0">
                    <td className="scoreboard px-4 py-2 tabular-nums text-muted-foreground">
                      {i + 1}
                    </td>
                    <td className="px-2 py-2 font-semibold">{row.team}</td>
                    <td className="px-2 py-2 text-right tabular-nums">{row.w}</td>
                    <td className="px-2 py-2 text-right tabular-nums">{row.l}</td>
                    <td className="scoreboard px-2 py-2 text-right font-bold tabular-nums">
                      {row.pct.toFixed(3).replace(/^0/, "")}
                    </td>
                    <td className="px-2 py-2 text-right tabular-nums text-muted-foreground">
                      {row.left}
                    </td>
                    <td className="scoreboard px-2 py-2 text-right font-bold tabular-nums text-primary">
                      {row.projW}-{row.projL}
                    </td>
                    <td className="px-4 py-2 text-right text-muted-foreground">
                      {row.streak ?? "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
