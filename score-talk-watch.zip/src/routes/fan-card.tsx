import { createFileRoute, Link } from "@tanstack/react-router";
import { useTopVoices } from "@/components/TopVoiceBadge";
import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { fanStandingQueryOptions } from "@/lib/daily";
import { predictionsQueryOptions } from "@/lib/predictions";
import { useFavorites } from "@/lib/favorites";
import { Button } from "@/components/ui/button";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/fan-card")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      title: "Make your fan card — Sideline",
      description: "Turn your prediction record, fan streak or hottest take into a shareable card in your team's colors.",
      path: "/fan-card",
    }),
  component: FanCardPage,
});

type Kind = "called" | "streak" | "take";

function cssColor(name: string, fallback: string) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  if (!v) return fallback;
  return v.startsWith("#") || v.includes("(") ? v : `oklch(${v})`;
}

function wrap(ctx: CanvasRenderingContext2D, text: string, max: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    const test = line ? `${line} ${w}` : w;
    if (ctx.measureText(test).width > max && line) {
      lines.push(line);
      line = w;
    } else line = test;
  }
  if (line) lines.push(line);
  return lines.slice(0, 6);
}

function FanCardPage() {
  const { user } = useAuth();
  const { favorites } = useFavorites();
  const [kind, setKind] = useState<Kind>("called");
  const [take, setTake] = useState("");
  const canvas = useRef<HTMLCanvasElement>(null);
  const standing = useQuery({ ...fanStandingQueryOptions(user?.id ?? ""), enabled: Boolean(user) });
  const preds = useQuery({ ...predictionsQueryOptions(user?.id), enabled: Boolean(user) });

  const name = (user?.user_metadata?.['display_name'] as string | undefined) ?? user?.email?.split("@")[0] ?? "A Sideline fan";
  const team = favorites[0]?.name ?? "";
  const topVoices = useTopVoices();
  const isTopVoice = Boolean(user && topVoices.has(user.id));
  const resolved = (preds.data ?? []).filter((p) => p.resolved && p.userId === user?.id);
  const right = resolved.filter((p) => p.correct);
  const lastWin = right[0];

  const headline =
    kind === "called"
      ? "I called it"
      : kind === "streak"
        ? `${standing.data?.currentDays ?? 0}-day streak`
        : "Hot take";
  const body =
    kind === "called"
      ? lastWin
        ? `${lastWin.gameLabel} — picked ${lastWin.pick}. ${right.length} of ${resolved.length} picks right.`
        : "No graded picks yet — lock one in on any game page."
      : kind === "streak"
        ? `Longest run: ${standing.data?.longestDays ?? 0} days. ${standing.data?.badges.length ?? 0} badges earned on Sideline.`
        : take || "Type your take below…";

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    const brand = cssColor("--brand", cssColor("--primary", "#ff5a5f"));
    const partner = cssColor("--brand-2", cssColor("--accent", "#06b6d4"));
    const bg = cssColor("--foreground", "#0b1024");
    const fg = cssColor("--background", "#ffffff");
    const g = ctx.createLinearGradient(0, 0, 1080, 1080);
    g.addColorStop(0, brand);
    g.addColorStop(1, partner);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, 1080, 1080);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1080, 24);
    ctx.fillRect(0, 1056, 1080, 24);
    ctx.fillStyle = brand;
    ctx.font = "bold 36px system-ui, sans-serif";
    ctx.fillText(isTopVoice ? "SIDELINE · TOP VOICE" : "SIDELINE", 80, 130);
    ctx.fillStyle = fg;
    ctx.font = "900 120px system-ui, sans-serif";
    wrap(ctx, headline.toUpperCase(), 920).forEach((l, i) => ctx.fillText(l, 80, 330 + i * 125));
    ctx.font = "500 48px system-ui, sans-serif";
    wrap(ctx, body, 920).forEach((l, i) => ctx.fillText(l, 80, 600 + i * 64));
    ctx.fillStyle = brand;
    ctx.font = "bold 40px system-ui, sans-serif";
    ctx.fillText(`@${name}${team ? ` · ${team}` : ""}`, 80, 980);
  }, [headline, body, name, team, isTopVoice]);

  const blob = () => new Promise<Blob | null>((r) => canvas.current?.toBlob(r, "image/png"));
  const download = async () => {
    const b = await blob();
    if (!b) return;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(b);
    a.download = "sideline-fan-card.png";
    a.click();
  };
  const share = async () => {
    const b = await blob();
    if (!b) return;
    const file = new File([b], "sideline-fan-card.png", { type: "image/png" });
    if (navigator.canShare?.({ files: [file] })) {
      await navigator.share({ files: [file], text: "My Sideline fan card", url: "https://score-talk-watch.lovable.app" }).catch(() => {});
    } else void download();
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <p className="text-[10px] font-bold uppercase tracking-widest text-primary">Fan cards</p>
      <h1 className="mt-1 text-3xl font-black">Make your fan card</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Styled in your colors — pick a club's colors on <Link to="/my-teams" className="text-primary underline">My Teams</Link>. Post it anywhere.
      </p>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <canvas ref={canvas} width={1080} height={1080} className="w-full rounded-lg border border-border" aria-label="Your fan card preview" />
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {(["called", "streak", "take"] as Kind[]).map((k) => (
              <Button key={k} size="sm" variant={kind === k ? "default" : "outline"} onClick={() => setKind(k)}>
                {k === "called" ? "I called it" : k === "streak" ? "My streak" : "Hot take"}
              </Button>
            ))}
          </div>
          {kind === "take" && (
            <textarea value={take} maxLength={160} onChange={(e) => setTake(e.target.value)} placeholder="Your hottest take (160 characters)" className="h-28 w-full rounded-md border border-input bg-background p-3 text-sm" />
          )}
          {!user && kind !== "take" && (
            <p className="text-xs text-muted-foreground">
              <Link to="/auth" className="text-primary underline">Sign in</Link> to put your real record and streak on the card.
            </p>
          )}
          <div className="flex gap-2">
            <Button onClick={share}>Share</Button>
            <Button variant="outline" onClick={download}>Download</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
