import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Player Comparison Tool — Compare Any Two Players — Sideline";
const DESCRIPTION =
  "Compare any two players side by side in every league we cover, including the NWSL, NCAA softball and NCAA volleyball — bio, measurables and season-by-season stats.";

export const Route = createFileRoute("/compare/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/compare", title: TITLE, description: DESCRIPTION }),
  component: CompareIndex,
});

function CompareIndex() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Compare players</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Pick a league, pick two players from any teams, and see their bio, measurables and season
        stats side by side.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/compare/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{league.short}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{league.name}</p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-primary">
              Compare players →
            </p>
          </Link>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/team-stats" className="text-primary underline">
          Advanced team stats
        </Link>
        <Link to="/leaders" className="text-primary underline">
          Stat leaders
        </Link>
        <Link to="/rosters" className="text-primary underline">
          Team rosters
        </Link>
      </div>
    </div>
  );
}
