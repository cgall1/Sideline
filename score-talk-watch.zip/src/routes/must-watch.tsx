import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { gamesQueryOptions } from "@/lib/feed";
import { ScoreCard } from "@/components/ScoreCard";
import { leagueById, type Game } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Must-Watch Games Today — Best Matchups Across Every Sport — Sideline";
const DESCRIPTION =
  "The best games on today across the NFL, NBA, NHL, MLB, MLS, world soccer and college sports — ranked by what is live, close and worth your night.";

export const Route = createFileRoute("/must-watch")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/must-watch", title: TITLE, description: DESCRIPTION }),
  component: MustWatch,
});

function score(game: Game) {
  let value = 0;
  if (game.status === "live") {
    value += 100;
    const margin = Math.abs(game.homeScore - game.awayScore);
    value += Math.max(0, 40 - margin * 4);
  } else if (game.status === "scheduled") {
    value += 60;
  } else {
    value += 10;
  }
  if (game.broadcasters.length) value += 10;
  const wins = (record: string) => Number(record.split("-")[0] ?? 0);
  value += Math.min(20, (wins(game.home.record) + wins(game.away.record)) / 2);
  return value;
}

function MustWatch() {
  const games = useQuery(gamesQueryOptions("all"));
  const ranked = [...(games.data ?? [])].sort((a, b) => score(b) - score(a)).slice(0, 12);
  const top = ranked[0];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Must-watch today</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Every sport, one list. Live games first, then the closest matchups and the biggest names on
        television tonight.
      </p>

      <div className="mt-4 flex flex-wrap gap-2 text-sm">
        <Link to="/scores" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          All scores
        </Link>
        <Link to="/odds" search={{ league: "nfl" as const }} className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Win probabilities
        </Link>
        <Link to="/predictions" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Make your picks
        </Link>
      </div>

      {games.isLoading && <p className="mt-8 text-muted-foreground">Loading today&apos;s slate…</p>}

      {top && (
        <div className="mt-8 rounded-md border border-primary/50 bg-card p-5">
          <p className="scoreboard text-xs uppercase tracking-widest text-primary">Game of the day</p>
          <h2 className="mt-1 text-2xl font-bold">
            {top.away.name} at {top.home.name}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {leagueById(top.league)?.short} · {top.venue}
            {top.broadcasters.length ? ` · ${top.broadcasters.join(", ")}` : ""}
          </p>
          <p className="mt-2 text-sm">{top.headline}</p>
        </div>
      )}

      <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {ranked.map((game) => (
          <ScoreCard key={game.id} game={game} />
        ))}
      </div>

      {!games.isLoading && ranked.length === 0 && (
        <p className="mt-8 text-muted-foreground">
          No games on the board right now. Check the <Link to="/calendar" className="underline">calendar</Link> for
          what is coming up.
        </p>
      )}
    </div>
  );
}
