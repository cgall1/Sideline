import { createFileRoute, Link, useParams } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";
import { fetchFantasyPlayerPool, getFantasyLeague, makeDraftPick, memberOnClock } from "@/lib/fantasy.functions";

export const Route = createFileRoute("/fantasy/$leagueId/draft")({
  head: ({ params }) =>
    pageHead({
      path: `/fantasy/${params.leagueId}/draft`,
      title: "Live Snake Draft Room — Pick Real Players — Sideline",
      description:
        "The live draft room for your fantasy league: see who is on the clock, search real NFL, NBA, NHL, MLB and soccer players and make your pick.",
      noindex: true,
    }),
  component: DraftRoom,
});

function DraftRoom() {
  const { leagueId } = useParams({ from: "/fantasy/$leagueId/draft" });
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");

  const { data: league } = useQuery({
    queryKey: ["fantasy", "league", leagueId],
    queryFn: () => getFantasyLeague({ data: { leagueId } }),
    enabled: !!user,
    refetchInterval: 5_000,
  });

  const { data: pool = [], isLoading: poolLoading } = useQuery({
    queryKey: ["fantasy", "pool", league?.sport],
    queryFn: () => fetchFantasyPlayerPool({ data: { sport: league!.sport as never } }),
    enabled: !!league,
    staleTime: 30 * 60_000,
  });

  const pick = useMutation({
    mutationFn: (player: { id: string; name: string; position: string; teamName: string }) =>
      makeDraftPick({ data: { leagueId, player } }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["fantasy", "league", leagueId] }),
  });

  if (!user || !league) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center text-muted-foreground">
        {!user ? (
          <>
            Sign in to enter the draft room.{" "}
            <Link to="/auth" className="font-semibold text-primary underline">
              Sign in
            </Link>
          </>
        ) : (
          "Loading the draft room…"
        )}
      </div>
    );
  }

  if (league.status === "open") {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-muted-foreground">The commissioner hasn't started the draft yet.</p>
        <Link to="/fantasy/$leagueId" params={{ leagueId }} className="mt-2 inline-block text-primary underline">
          Back to the league
        </Link>
      </div>
    );
  }

  const onClockId = league.status === "drafting" ? memberOnClock(league.draftOrder, league.draftTurn) : null;
  const onClock = league.members.find((m) => m.id === onClockId);
  const myMember = league.members.find((m) => m.userId === user.id);
  const myTurn = !!myMember && onClockId === myMember.id && league.status === "drafting";
  const taken = new Set(league.picks.filter((p) => !p.dropped).map((p) => p.playerId));
  const totalPicks = league.draftOrder.length * league.rosterSize;
  const round = Math.floor(league.draftTurn / Math.max(league.draftOrder.length, 1)) + 1;

  const q = search.trim().toLowerCase();
  const available = pool
    .filter((p) => !taken.has(p.id))
    .filter((p) => !q || p.name.toLowerCase().includes(q) || p.teamName.toLowerCase().includes(q))
    .slice(0, 60);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <Link
        to="/fantasy/$leagueId"
        params={{ leagueId }}
        className="text-xs font-semibold uppercase tracking-widest text-primary underline"
      >
        ← {league.name}
      </Link>

      <div className="mt-2 flex flex-wrap items-center gap-3">
        <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">Draft room</h1>
        {league.status === "drafting" ? (
          <span className="rounded-full bg-destructive px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-destructive-foreground">
            Live · Round {round}
          </span>
        ) : (
          <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent-foreground">
            Draft complete
          </span>
        )}
      </div>

      {league.status === "drafting" && (
        <p className="mt-2 text-sm">
          On the clock:{" "}
          <span className="font-bold text-primary">{onClock?.teamName ?? "…"}</span>{" "}
          <span className="text-muted-foreground">
            (pick {league.draftTurn + 1} of {totalPicks})
          </span>
          {myTurn && (
            <span className="ml-2 rounded bg-primary px-2 py-0.5 text-xs font-bold text-primary-foreground">
              Your pick!
            </span>
          )}
        </p>
      )}
      {pick.error && <p className="mt-2 text-sm text-destructive">{pick.error.message}</p>}

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search players or teams…"
            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          />
          {poolLoading ? (
            <p className="mt-4 text-sm text-muted-foreground">Loading real rosters…</p>
          ) : (
            <ul className="mt-3 divide-y divide-border rounded-lg border border-border bg-card">
              {available.map((p) => (
                <li key={p.id} className="flex items-center justify-between px-3 py-2 text-sm">
                  <span>
                    <span className="font-medium">{p.name}</span>{" "}
                    <span className="text-xs text-muted-foreground">
                      {p.position} · {p.teamName}
                    </span>
                  </span>
                  {myTurn && (
                    <button
                      onClick={() => pick.mutate(p)}
                      disabled={pick.isPending}
                      className="rounded bg-primary px-2 py-1 text-xs font-bold text-primary-foreground disabled:opacity-50"
                    >
                      Draft
                    </button>
                  )}
                </li>
              ))}
              {available.length === 0 && (
                <li className="px-3 py-4 text-sm text-muted-foreground">No players match that search.</li>
              )}
            </ul>
          )}
        </div>

        <div>
          <h2 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Draft board</h2>
          <ul className="mt-2 space-y-1">
            {league.picks
              .filter((p) => !p.dropped)
              .slice()
              .reverse()
              .map((p) => {
                const team = league.members.find((m) => m.id === p.memberId);
                return (
                  <li key={p.id} className="rounded border border-border bg-card px-3 py-1.5 text-xs">
                    <span className="font-semibold">{p.playerName}</span>{" "}
                    <span className="text-muted-foreground">
                      {p.position} · {p.teamName} → {team?.teamName} (Rd {p.round})
                    </span>
                  </li>
                );
              })}
            {league.picks.filter((p) => !p.dropped).length === 0 && (
              <li className="text-sm text-muted-foreground">No picks yet.</li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
