import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/mlb`;
const TITLE = "MLB Scores, Standings & Schedule — Baseball Hub — Sideline";
const DESCRIPTION =
  "Live MLB scores, full league standings and the complete baseball schedule with first-pitch times, ballparks and TV — plus a highlight reel for every game.";

const SEASON_MONTHS = [3, 4, 5, 6, 7, 8, 9, 10];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/mlb/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("mlb"));
    context.queryClient.ensureQueryData(standingsQueryOptions("mlb"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("mlb", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/mlb.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/mlb.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "MLB Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "MLB Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The MLB hub is unavailable right now: {error.message}
    </div>
  ),
  component: MlbPage,
});

function MlbPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/mlb/" });
  useTrackHubVisit("/mlb", "MLB Hub");

  return (
    <>
      <CollegeHub
        league="mlb"
        month={month}
        heading="MLB Scores & Standings"
        intro="Live MLB scores, the full American and National League table, and a month-by-month schedule with first-pitch times, ballparks and TV — with a highlight reel beside every game."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "mlb" }} className="font-semibold text-primary underline">
          MLB live scores
        </Link>
        <Link to="/results" search={{ league: "mlb" }} className="font-semibold text-primary underline">
          MLB season results
        </Link>
        <Link to="/directory/$league" params={{ league: "mlb" }} className="font-semibold text-primary underline">
          Every MLB team
        </Link>
        <Link to="/mlb-chat" className="font-semibold text-primary underline">
          MLB fan chat
        </Link>
        <Link to="/mlb-rankings" className="font-semibold text-primary underline">
          MLB rankings
        </Link>
        <Link to="/mlb-trivia" className="font-semibold text-primary underline">
          MLB trivia
        </Link>
        <Link to="/media/mlb-highlights" className="font-semibold text-primary underline">
          MLB highlight videos
        </Link>
      </div>
    </>
  );
}
