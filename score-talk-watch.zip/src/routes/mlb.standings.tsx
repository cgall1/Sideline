import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mlb/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mlb/standings",
      title: "MLB Standings — Full Table — Sideline",
      description: "The full MLB standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("mlb"),
    }),
  component: () => <SportStandingsSection league="mlb" />,
});
