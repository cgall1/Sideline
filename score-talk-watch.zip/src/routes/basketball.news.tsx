import { createFileRoute } from "@tanstack/react-router";
import { BasketballNews, basketballLeague } from "@/components/sport/BasketballSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/basketball/news")({
  staticData: { sitemap: true },
  validateSearch: (search: Record<string, unknown>) => ({
    league: basketballLeague(search['league']),
  }),
  head: () =>
    pageHead({
      path: "/basketball/news",
      title: "Basketball News — NBA, WNBA & College Headlines — Sideline",
      description:
        "Basketball news on Sideline: trades, injuries, roster moves and game reports from the NBA, WNBA and college game.",
    }),
  component: BasketballNewsPage,
});

function BasketballNewsPage() {
  const { league } = Route.useSearch();
  return <BasketballNews league={league} />;
}
