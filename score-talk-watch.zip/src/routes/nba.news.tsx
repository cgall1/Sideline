import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nba/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nba/news",
      title: "NBA News — Latest Headlines & Injuries — Sideline",
      description: "The latest NBA news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("nba"),
    }),
  component: () => <SportNewsSection league="nba" />,
});
