import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { REACTIONS } from "@/data/sports";
import { gamesQueryOptions, standingsQueryOptions } from "@/lib/feed";
import {
  createPost,
  deletePost,
  reactionsQueryOptions,
  relativeTime,
  setReaction,
  threadPostsQueryOptions,
  toggleLike,
} from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";
import { useTrackHubVisit } from "@/lib/visits";
import { cn } from "@/lib/utils";
import { GamePoll } from "@/components/GamePoll";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/nba-chat`;
const TITLE = "NBA Chat — Live Basketball Game Threads & Scores — Sideline";
const DESCRIPTION =
  "A live NBA chat hub: real-time basketball game threads with live scores and quarters, division standings and highlight reels for every matchup.";

export const Route = createFileRoute("/nba-chat")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<{ game: string }>): { game?: string | undefined } =>
    typeof search.game === "string" ? { game: search.game } : {},
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("nba"));
    context.queryClient.ensureQueryData(standingsQueryOptions("nba"));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NBA Chat",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          mainEntity: {
            "@type": "DiscussionForumPosting",
            headline: "Sideline NBA game threads",
            text: "Live fan discussion for every NBA game.",
            url: PAGE_URL,
            author: { "@type": "Organization", name: "Sideline" },
          },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              { "@type": "ListItem", position: 2, name: "Sports Directory", item: `${SITE}/directory` },
              { "@type": "ListItem", position: 3, name: "NBA Chat", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NBA chat is unavailable right now: {error.message}
    </div>
  ),
  component: NBAChat,
});

function SignInPrompt({ what }: { what: string }) {
  return (
    <p className="text-xs text-muted-foreground">
      <Link
        to="/auth"
        search={{ next: "/nba-chat" }}
        className="font-semibold text-primary underline"
      >
        Sign in
      </Link>{" "}
      to {what}.
    </p>
  );
}

function NBAChat() {
  const { game } = Route.useSearch();
  const navigate = useNavigate({ from: "/nba-chat" });
  const queryClient = useQueryClient();
  const { user } = useAuth();
  useTrackHubVisit("/nba-chat", "NBA Chat");
  const userId = user?.id ?? null;

  const { data: games } = useSuspenseQuery(gamesQueryOptions("nba"));
  const { data: standings } = useSuspenseQuery(standingsQueryOptions("nba"));
  const { data: posts } = useSuspenseQuery(threadPostsQueryOptions(userId));
  const { data: reactionData } = useSuspenseQuery(reactionsQueryOptions(userId));

  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);

  const order = { live: 0, final: 1, scheduled: 2 } as const;
  const threadGames = [...games].sort((a, b) => order[a.status] - order[b.status]).slice(0, 20);
  const activeId = game && threadGames.some((g) => g.id === game) ? game : threadGames[0]?.id;
  const active = threadGames.find((g) => g.id === activeId);
  const threadPosts = posts.filter((p) => p.gameId === activeId).slice().reverse();

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["community"] });

  const [liveChat, setLiveChat] = useState(false);
  useEffect(() => {
    const channel = supabase
      .channel("nba-chat-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "community_posts" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "post_likes" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "game_reactions" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .subscribe((status) => setLiveChat(status === "SUBSCRIBED"));
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient]);

  const endRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [threadPosts.length, activeId]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !activeId || !userId || busy) return;
    setBusy(true);
    try {
      await createPost(userId, activeId, text);
      setDraft("");
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  const myReaction = activeId ? reactionData.mine[activeId] : undefined;
  const reactionTotals = (activeId && reactionData.totals[activeId]) || {};

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        NBA chat
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Live NBA game threads with live scores and quarters, the conference tables and a
        highlights calendar. {!userId && "Sign in to join the conversation."}
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/nba" className="text-primary underline">
          Highlights calendar
        </Link>
        <Link to="/scores" search={{ league: "nba" }} className="text-primary underline">
          Live scores
        </Link>
        <Link to="/standings" search={{ league: "nba" }} className="text-primary underline">
          Standings
        </Link>
        <Link to="/visitors" className="text-primary underline">
          Popular hubs
        </Link>
      </div>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_2fr_1fr]">
        <aside>
          <h2 className="scoreboard mb-3 text-xl font-bold uppercase tracking-wide">Game threads</h2>
          <ul className="space-y-2">
            {threadGames.map((g) => (
              <li key={g.id}>
                <button
                  onClick={() => navigate({ search: { game: g.id } })}
                  className={cn(
                    "w-full rounded-md border p-3 text-left transition-colors",
                    g.id === activeId
                      ? "border-primary bg-surface"
                      : "border-border bg-card hover:border-primary/40",
                  )}
                >
                  <div className="mb-1 flex items-center justify-between gap-2">
                    <span className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
                      NBA
                    </span>
                    {g.status === "live" ? (
                      <span className="live-dot scoreboard text-xs font-bold uppercase text-live">
                        {g.clock}
                      </span>
                    ) : (
                      <span className="scoreboard text-xs uppercase text-muted-foreground">
                        {g.status === "final" ? "Final" : g.startLabel}
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold">
                    {g.status === "scheduled"
                      ? `${g.away.abbr} @ ${g.home.abbr}`
                      : `${g.away.abbr} ${g.awayScore} — ${g.homeScore} ${g.home.abbr}`}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {posts.filter((p) => p.gameId === g.id).length} posts
                  </p>
                </button>
              </li>
            ))}
            {!threadGames.length && (
              <li className="text-sm text-muted-foreground">
                No NBA games on the board right now.
              </li>
            )}
          </ul>
        </aside>

        <section>
          {active ? (
            <>
              <div className="rounded-md border border-border bg-card p-4">
                <div className="flex items-center justify-between gap-3">
                  <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
                    {active.away.name} at {active.home.name}
                  </h2>
                  {active.status !== "scheduled" && (
                    <span className="scoreboard text-2xl font-bold tabular-nums">
                      {active.awayScore}–{active.homeScore}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  {active.venue} ·{" "}
                  {active.status === "live"
                    ? active.clock
                    : active.status === "final"
                      ? "Final"
                      : active.startLabel}
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  {REACTIONS.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={async () => {
                        if (!userId || !activeId) return;
                        await setReaction(activeId, userId, myReaction === emoji ? null : emoji);
                        await refresh();
                      }}
                      disabled={!userId}
                      aria-pressed={myReaction === emoji}
                      className={cn(
                        "rounded-full border px-3 py-1.5 text-sm font-semibold transition-colors",
                        myReaction === emoji
                          ? "border-primary bg-primary/15 text-foreground"
                          : "border-border hover:border-primary/50",
                        !userId && "opacity-60",
                      )}
                    >
                      <span aria-hidden className="mr-1.5 text-base">
                        {emoji}
                      </span>
                      <span className="scoreboard tabular-nums">{reactionTotals[emoji] ?? 0}</span>
                    </button>
                  ))}
                </div>
                {!userId && (
                  <div className="mt-2">
                    <SignInPrompt what="react" />
                  </div>
                )}
              </div>

              <GamePoll
                gameId={active.id}
                home={active.home.name}
                away={active.away.name}
                signInNext="/nba-chat"
              />

              <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
                <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-2.5">
                  <h3 className="scoreboard text-sm font-bold uppercase tracking-widest">
                    Live chat
                  </h3>
                  <span
                    className={cn(
                      "scoreboard text-xs font-bold uppercase tracking-widest",
                      liveChat ? "live-dot text-live" : "text-muted-foreground",
                    )}
                  >
                    {liveChat ? "Live" : "Connecting…"}
                  </span>
                </div>

                <ul className="max-h-[28rem] space-y-3 overflow-y-auto p-4">
                  {threadPosts.map((p) => (
                    <li key={p.id} className="rounded-md border border-border bg-surface p-3.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold">
                          {p.author}{" "}
                          <span className="scoreboard ml-1 rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-semibold">
                            {p.team}
                          </span>
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {relativeTime(p.createdAt)}
                        </span>
                      </div>
                      <p className="mt-1.5 text-sm">{p.body}</p>
                      <div className="mt-2 flex items-center gap-3">
                        <button
                          onClick={async () => {
                            if (!userId) return;
                            await toggleLike(p.id, userId, p.likedByMe);
                            await refresh();
                          }}
                          disabled={!userId}
                          aria-pressed={p.likedByMe}
                          className={cn(
                            "text-xs font-semibold",
                            p.likedByMe
                              ? "text-primary"
                              : "text-muted-foreground hover:text-foreground",
                          )}
                        >
                          ♥ {p.likes}
                        </button>
                        {userId === p.userId && (
                          <button
                            onClick={async () => {
                              await deletePost(p.id);
                              await refresh();
                            }}
                            className="text-xs text-muted-foreground hover:text-foreground"
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </li>
                  ))}
                  {!threadPosts.length && (
                    <li className="text-sm text-muted-foreground">
                      No messages yet — be the first to say something.
                    </li>
                  )}
                  <div ref={endRef} />
                </ul>

                {userId ? (
                  <form onSubmit={submit} className="flex gap-2 border-t border-border p-3">
                    <label htmlFor="nba-post" className="sr-only">
                      Add to the live chat
                    </label>
                    <input
                      id="nba-post"
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      maxLength={500}
                      placeholder="Say something about this game…"
                      className="flex-1 rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
                    />
                    <button
                      type="submit"
                      disabled={busy}
                      className="scoreboard rounded-sm bg-primary px-4 py-2 text-sm font-bold uppercase tracking-widest text-primary-foreground disabled:opacity-60"
                    >
                      {busy ? "Sending…" : "Send"}
                    </button>
                  </form>
                ) : (
                  <div className="border-t border-border p-4">
                    <SignInPrompt what="join the live chat" />
                  </div>
                )}
              </div>
            </>
          ) : (
            <p className="text-muted-foreground">
              No NBA threads right now — check the{" "}
              <Link to="/nba" className="font-semibold text-primary underline">
                season calendar
              </Link>{" "}
              for the next tip-off.
            </p>
          )}
        </section>

        <aside>
          <h2 className="scoreboard mb-3 text-xl font-bold uppercase tracking-wide">
            {standings.group}
          </h2>
          <ul className="space-y-2">
            {standings.rows.slice(0, 15).map((row, i) => (
              <li
                key={row.team}
                className="flex items-center justify-between gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm"
              >
                <span className="truncate font-semibold">
                  <span className="scoreboard mr-2 text-muted-foreground">{i + 1}</span>
                  {row.team}
                </span>
                <span className="scoreboard tabular-nums text-muted-foreground">
                  {row.w}-{row.l}
                </span>
              </li>
            ))}
            {!standings.rows.length && (
              <li className="text-sm text-muted-foreground">Standings load once games are played.</li>
            )}
          </ul>
          <Link
            to="/standings"
            search={{ league: "nba" }}
            className="mt-3 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
          >
            Full standings →
          </Link>
        </aside>
      </div>
    </div>
  );
}
