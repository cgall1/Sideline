import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { useTrackHubVisit } from "@/lib/visits";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-basketball`;
const TITLE = "College Basketball Hub — Live Scores, Standings & Highlights — Sideline";
const DESCRIPTION =
  "College basketball in one hub: live scores, national standings, the full season calendar with tip-off times and arenas, and a highlights reel for every matchup.";

const SEASON_MONTHS = [11, 12, 1, 2, 3, 4];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/college-basketball/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("cbb"));
    context.queryClient.ensureQueryData(standingsQueryOptions("cbb"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("cbb", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "College Basketball Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              {
                "@type": "ListItem",
                position: 3,
                name: "College Basketball Hub",
                item: PAGE_URL,
              },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The college basketball hub is unavailable right now: {error.message}
    </div>
  ),
  component: CollegeBasketballPage,
});

function CollegeBasketballPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/college-basketball/" });
  useTrackHubVisit("/college-basketball", "College Basketball Hub");

  return (
    <>
      <CollegeHub
        league="cbb"
        month={month}
        heading="College Basketball Hub"
        intro="Live college basketball scores, national standings and a month-by-month calendar with tip-off times, arenas and TV — plus a highlight reel beside every matchup."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto max-w-7xl px-4 pb-12 text-sm">
        <Link to="/transfer-portal-tracker" className="font-semibold text-primary underline">
          Transfer portal tracker
        </Link>
      </div>
    </>
  );
}

