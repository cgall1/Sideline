import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/nba")({
  component: NBASection,
});

function NBASection() {
  return (
    <>
      <nav
        aria-label="NBA sections"
        className="border-b border-border bg-card/60 backdrop-blur"
      >
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            NBA
          </span>
        <Link
          to="/nba"
          activeOptions={{ exact: true }}
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Home
        </Link>
        <Link
          to="/nba/news"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          News
        </Link>
        <Link
          to="/nba/scores"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Scores
        </Link>
        <Link
          to="/nba/standings"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Standings
        </Link>
        <Link
          to="/nba/schedule"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Schedule
        </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
