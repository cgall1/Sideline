import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SportHub } from "@/components/SportHub";
import { sportById } from "@/lib/individual-sports.functions";
import { pageHead } from "@/lib/seo";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";
import { f1StandingsQueryOptions, type F1StandingRow } from "@/lib/f1.functions";

const TITLE = "F1 Standings, Schedule & Race Results — Formula 1 Hub — Sideline";
const DESCRIPTION =
  "Live Formula 1 standings for drivers and constructors, the full grand prix schedule, race results, F1 news, highlights, trivia and fan chat.";

export const Route = createFileRoute("/f1/")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(sportEventsQueryOptions("f1"));
    context.queryClient.ensureQueryData(sportNewsQueryOptions("f1"));
    context.queryClient.ensureQueryData(f1StandingsQueryOptions());
  },
  head: () => pageHead({ path: "/f1", title: TITLE, description: DESCRIPTION }),
  component: F1Page,
});

function StandingsTable({
  heading,
  rows,
  subjectLabel,
}: {
  heading: string;
  rows: F1StandingRow[];
  subjectLabel: string;
}) {
  return (
    <div className="rounded-md border border-border bg-card">
      <h3 className="scoreboard border-b border-border px-4 py-3 text-lg font-bold uppercase tracking-wide">
        {heading}
      </h3>
      {rows.length === 0 ? (
        <p className="p-4 text-sm text-muted-foreground">
          Standings appear here as soon as the championship feed updates.
        </p>
      ) : (
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-2 font-medium">#</th>
              <th className="px-4 py-2 font-medium">{subjectLabel}</th>
              <th className="px-4 py-2 text-right font-medium">Wins</th>
              <th className="px-4 py-2 text-right font-medium">Pts</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id} className="border-t border-border">
                <td className="scoreboard px-4 py-2 text-muted-foreground">{row.rank}</td>
                <td className="px-4 py-2">
                  <span className="font-semibold text-foreground">{row.name}</span>
                  {row.detail && (
                    <span className="block text-xs text-muted-foreground">{row.detail}</span>
                  )}
                </td>
                <td className="scoreboard px-4 py-2 text-right text-muted-foreground">{row.wins}</td>
                <td className="scoreboard px-4 py-2 text-right font-semibold">{row.points}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function F1Standings() {
  const { data, isLoading } = useQuery(f1StandingsQueryOptions());

  return (
    <section className="mx-auto max-w-7xl px-4">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
        Championship standings{data?.season ? ` — ${data.season}` : ""}
      </h2>
      {isLoading && <p className="mt-2 text-sm text-muted-foreground">Loading standings…</p>}
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <StandingsTable heading="Drivers" rows={data?.drivers ?? []} subjectLabel="Driver" />
        <StandingsTable
          heading="Constructors"
          rows={data?.constructors ?? []}
          subjectLabel="Constructor"
        />
      </div>
    </section>
  );
}

function F1Page() {
  const sport = sportById("f1")!;
  return (
    <>
      <SportHub sport={sport} />
      <div className="pb-12">
        <F1Standings />
      </div>
    </>
  );
}
