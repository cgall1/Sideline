import { createFileRoute } from "@tanstack/react-router";
import { CricketNewsSection } from "@/components/sport/CricketSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/cricket/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/cricket/news",
      title: "Cricket News — Squads, Injuries & Match Reports — Sideline",
      description:
        "The latest cricket news on Sideline: squad announcements, injury updates, tour previews and match reports from the active international and franchise series.",
    }),
  component: () => <CricketNewsSection />,
});
