import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/boxing")({
  component: BOXINGSection,
});

function BOXINGSection() {
  return (
    <>
      <nav aria-label="Boxing sections" className="border-b border-border bg-card/60 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            Boxing
          </span>
        <Link
          to="/boxing"
          activeOptions={{ exact: true }}
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Home
        </Link>
        <Link
          to="/boxing/news"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          News
        </Link>
        <Link
          to="/boxing/scores"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Fights
        </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
