import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mls/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mls/standings",
      title: "MLS Standings — Full Table — Sideline",
      description: "The full MLS standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("mls"),
    }),
  component: () => <SportStandingsSection league="mls" />,
});
