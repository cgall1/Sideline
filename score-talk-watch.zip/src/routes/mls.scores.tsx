import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mls/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mls/scores",
      title: "MLS Scores — Live & Final — Sideline",
      description: "Live MLS scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("mls"),
    }),
  component: () => <SportScoresSection league="mls" />,
});
