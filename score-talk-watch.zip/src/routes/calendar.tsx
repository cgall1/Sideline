import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, LEAGUES, type LeagueId } from "@/data/sports";
import { monthScheduleQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import type { ScheduleGame } from "@/lib/schedule.functions";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/calendar`;
const TITLE = "Season Schedule Calendar — Dates, Venues & Highlights — Sideline";
const DESCRIPTION =
  "The full season schedule for the NFL, NBA, NHL, MLB, MLS, college football and international soccer: every game date, kickoff time, stadium and a highlight video for each matchup.";

const LEAGUE_IDS = LEAGUES.map((l) => l.id) as string[];
const VIDEOS = ARTICLES.filter((a) => a.kind === "video");

function thisMonth(): string {
  return new Date().toISOString().slice(0, 7);
}

function shiftMonth(month: string, delta: number): string {
  const [y, m] = month.split("-").map(Number);
  const date = new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1 + delta, 1));
  return date.toISOString().slice(0, 7);
}

function monthLabel(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1, 1)));
}

function dayLabel(day: string): string {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${day}T12:00:00Z`));
}

function timeLabel(iso: string): string {
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(
    new Date(iso),
  );
}

function reelFor(game: ScheduleGame, index: number) {
  const sameLeague = VIDEOS.filter((v) => v.league === game.league);
  const pool = sameLeague.length > 0 ? sameLeague : VIDEOS;
  return pool[index % pool.length];
}

interface CalendarSearch {
  league: LeagueId;
  month: string;
}

export const Route = createFileRoute("/calendar")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<CalendarSearch>): Partial<CalendarSearch> => {
    const rawLeague = typeof search.league === "string" ? search.league : "nfl";
    const rawMonth = typeof search.month === "string" ? search.month : "";
    return {
      league: (LEAGUE_IDS.includes(rawLeague) ? rawLeague : "nfl") as LeagueId,
      month: /^\d{4}-\d{2}$/.test(rawMonth) ? rawMonth : thisMonth(),
    };
  },
  loaderDeps: ({ search }) => ({
    league: search.league ?? "nfl",
    month: search.month ?? thisMonth(),
  }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(monthScheduleQueryOptions(deps.league, deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Season Schedule Calendar",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              { "@type": "ListItem", position: 2, name: "Sports Directory", item: `${SITE}/directory` },
              { "@type": "ListItem", position: 3, name: "Season Schedule Calendar", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The schedule is unavailable right now: {error.message}
    </div>
  ),
  component: CalendarPage,
});

function CalendarPage() {
  const { league = "nfl", month = thisMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/calendar" });
  const { data } = useSuspenseQuery(monthScheduleQueryOptions(league, month));

  const days = [...new Set(data.games.map((g) => g.day))].sort();
  const leagueName = LEAGUES.find((l) => l.id === league)?.name ?? "League";

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        {leagueName} Season Schedule
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every fixture month by month with dates, start times, stadiums and a highlight reel for each
        matchup. Switch leagues or months below.
      </p>

      <div className="mt-5 flex flex-wrap gap-2">
        {LEAGUES.map((l) => (
          <button
            key={l.id}
            type="button"
            onClick={() => navigate({ search: { league: l.id, month } })}
            aria-pressed={l.id === league}
            className={`scoreboard rounded-sm border px-3 py-1 text-xs font-bold uppercase tracking-widest transition-colors ${
              l.id === league
                ? "border-primary bg-primary/15 text-foreground"
                : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {l.short}
          </button>
        ))}
      </div>

      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          onClick={() => navigate({ search: { league, month: shiftMonth(month, -1) } })}
          className="rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          ← {monthLabel(shiftMonth(month, -1))}
        </button>
        <span className="scoreboard text-lg font-bold uppercase tracking-wide">
          {monthLabel(month)}
        </span>
        <button
          type="button"
          onClick={() => navigate({ search: { league, month: shiftMonth(month, 1) } })}
          className="rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          {monthLabel(shiftMonth(month, 1))} →
        </button>
      </div>

      {days.length === 0 && (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No {leagueName} games scheduled in {monthLabel(month)}. Try another month or league.
        </p>
      )}

      {days.map((day) => (
        <section key={day} className="mt-8">
          <h2 className="scoreboard text-xl font-bold uppercase tracking-wide text-muted-foreground">
            {dayLabel(day)}
          </h2>
          <ul className="mt-3 grid gap-3 lg:grid-cols-2">
            {data.games
              .filter((g) => g.day === day)
              .map((game, index) => {
                const reel = reelFor(game, index);
                return (
                  <li
                    key={game.id}
                    className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
                  >
                    <div className="flex items-center gap-2">
                      <LeagueBadge league={game.league} />
                      <span className="text-xs uppercase tracking-widest text-muted-foreground">
                        {game.status === "scheduled" ? timeLabel(game.date) : game.statusLabel}
                      </span>
                    </div>
                    <p className="scoreboard mt-2 text-lg font-bold uppercase tracking-wide">
                      {game.away} at {game.home}
                      {game.status !== "scheduled" && game.homeScore !== null && (
                        <span className="ml-2 text-primary">
                          {game.awayScore}–{game.homeScore}
                        </span>
                      )}
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {game.venue}
                      {game.city ? ` · ${game.city}` : ""}
                      {game.broadcast ? ` · ${game.broadcast}` : ""}
                    </p>
                    {reel && (
                      <Link
                        to="/media/$slug"
                        params={{ slug: reel.slug }}
                        className="mt-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-primary"
                      >
                        ▶ Highlight reel: {reel.title}
                      </Link>
                    )}
                  </li>
                );
              })}
          </ul>
        </section>
      ))}

      <div className="mt-10 flex flex-wrap gap-3 text-sm">
        <Link to="/directory" className="font-semibold text-primary underline">
          Sports directory
        </Link>
        <Link to="/directory/venues" className="font-semibold text-primary underline">
          Cities &amp; stadiums
        </Link>
        <Link to="/highlights" className="font-semibold text-primary underline">
          Daily highlights
        </Link>
        <Link to="/scores" className="font-semibold text-primary underline">
          Live scores
        </Link>
        <Link to="/college-basketball-live" className="font-semibold text-primary underline">
          College basketball live feed
        </Link>
      </div>
    </div>
  );
}
