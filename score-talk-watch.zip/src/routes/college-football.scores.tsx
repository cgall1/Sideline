import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-football/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-football/scores",
      title: "College Football Scores — Live & Final — Sideline",
      description: "Live College Football scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("cfb"),
    }),
  component: () => <SportScoresSection league="cfb" />,
});
