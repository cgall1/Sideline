import { createFileRoute, Link } from "@tanstack/react-router";
import { CHAMPIONSHIPS } from "@/data/legacy";
import { pageHead } from "@/lib/seo";

const TITLE = "Championship History — Super Bowl, World Series, Stanley Cup and More — Sideline";
const DESCRIPTION =
  "Every league's championship history in one place: trophies, most titles by franchise and recent champions across the NFL, NBA, MLB, NHL, MLS, world soccer and college sports.";

export const Route = createFileRoute("/championships/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/championships", title: TITLE, description: DESCRIPTION }),
  component: ChampionshipsIndex,
});

function ChampionshipsIndex() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Championship history</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Who has won the most, and who lifted the trophy last — for every league we cover.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {CHAMPIONSHIPS.map((c) => (
          <Link
            key={c.slug}
            to="/championships/$league"
            params={{ league: c.slug }}
            className="rounded-md border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{c.name}</h2>
            <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{c.trophy}</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Latest: {c.recent[0]?.champion} ({c.recent[0]?.year})
            </p>
          </Link>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap gap-2 text-sm">
        <Link to="/hall-of-fame" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Hall of fame
        </Link>
        <Link to="/rivalries" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Rivalries
        </Link>
        <Link to="/records" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Franchise records
        </Link>
      </div>
    </div>
  );
}
