import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, type Article } from "@/data/sports";
import { articlesQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import { VideoReel } from "@/components/VideoReel";

const BASE_URL = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${BASE_URL}/media/nhl-highlights`;

const nhlVideoSlugs = ARTICLES.filter((a) => a.league === "nhl" && a.kind === "video").map(
  (a) => a.slug,
);

export const Route = createFileRoute("/media/nhl-highlights")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(articlesQueryOptions());
  },
  head: () => ({
    meta: [
      { title: "NHL Highlights — Latest Videos, Scores & Top Plays — Sideline" },
      {
        name: "description",
        content:
          "Watch the latest NHL highlights: every goal, top 10 plays, and full game recaps from around the league, updated all season.",
      },
      { property: "og:title", content: "NHL Highlights — Latest Videos, Scores & Top Plays — Sideline" },
      {
        property: "og:description",
        content: "Every goal, top plays and game recaps from around the NHL, all in one place.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NHL Highlights",
          description:
            "Watch the latest NHL highlights: every goal, top 10 plays, and full game recaps from around the league.",
          url: PAGE_URL,
          hasPart: nhlVideoSlugs.map((slug) => ({
            "@type": "Article",
            headline: ARTICLES.find((a) => a.slug === slug)?.title,
            url: `${BASE_URL}/media/${slug}`,
          })),
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Media", item: `${BASE_URL}/media` },
            { "@type": "ListItem", position: 2, name: "NHL Highlights", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      NHL highlights are unavailable: {error.message}
    </div>
  ),
  component: NhlHighlights,
});

function NhlHighlights() {
  const { data: articles } = useSuspenseQuery(articlesQueryOptions());
  const videos = articles.filter((a) => a.league === "nhl" && a.kind === "video");
  const more = articles.filter((a) => a.league === "nhl" && a.kind !== "video");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <Link to="/media" className="hover:text-foreground">
          Media
        </Link>{" "}
        / NHL Highlights
      </p>
      <h1 className="scoreboard mt-1 text-4xl font-bold uppercase tracking-wide">
        NHL Highlights
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every goal, the night's top 10 plays, and full game recaps from around the league —
        updated all season.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/nhl" className="text-primary underline">
          NHL hub &amp; calendar
        </Link>
        <Link to="/nhl-chat" className="text-primary underline">
          Live game threads
        </Link>
        <Link to="/nhl-rankings" className="text-primary underline">
          Rankings
        </Link>
      </div>

      <VideoReel
        league="nhl"
        heading="NHL highlight reel"
        intro="Goals, top plays and recaps straight from the league's official channels — tap a clip to watch it here."
      />

      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((a: Article) => (
          <Link
            key={a.slug}
            to="/media/$slug"
            params={{ slug: a.slug }}
            className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <div className="mb-2 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <LeagueBadge league={a.league} />
                <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  {a.kind}
                </span>
              </div>
              {a.duration && (
                <span className="scoreboard rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-bold">
                  ▶ {a.duration}
                </span>
              )}
            </div>
            <h2 className="text-lg font-bold leading-snug">{a.title}</h2>
            <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{a.dek}</p>
            <p className="mt-3 text-xs text-muted-foreground">
              {a.author} · {a.published}
            </p>
          </Link>
        ))}
        {!videos.length && (
          <p className="text-muted-foreground">No NHL highlight packages published yet.</p>
        )}
      </div>

      {more.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            More from the NHL desk
          </h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {more.map((a) => (
              <Link
                key={a.slug}
                to="/media/$slug"
                params={{ slug: a.slug }}
                className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
              >
                <div className="mb-2 flex items-center gap-2">
                  <LeagueBadge league={a.league} />
                  <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    {a.kind}
                  </span>
                </div>
                <h3 className="text-lg font-bold leading-snug">{a.title}</h3>
                <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{a.dek}</p>
                <p className="mt-3 text-xs text-muted-foreground">
                  {a.author} · {a.published}
                </p>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
