import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-football/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-football/standings",
      title: "College Football Standings — Full Table — Sideline",
      description: "The full College Football standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("cfb"),
    }),
  component: () => <SportStandingsSection league="cfb" />,
});
