import { createFileRoute } from "@tanstack/react-router";
import { IndividualScoresSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nascar/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nascar/scores",
      title: "NASCAR Races — Live Results & Schedule — Sideline",
      description: "Live NASCAR results and the full schedule of upcoming races with dates, venues and finishing positions.",
    }),
  component: () => <IndividualScoresSection sport="nascar" />,
});
