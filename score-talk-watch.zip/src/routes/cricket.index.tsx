import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { cricketBoardQueryOptions, cricketNewsQueryOptions, cricketSeriesQueryOptions } from "@/lib/feed";
import { pageHead } from "@/lib/seo";
import { useTrackHubVisit } from "@/lib/visits";

export const Route = createFileRoute("/cricket/")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/cricket",
      title: "Cricket Scores, Standings & News — Cricket Hub — Sideline",
      description:
        "Live cricket scores from every active series, points tables that fill in as results land, and the latest squad, injury and match-report headlines.",
    }),
  component: CricketHome,
});

function CricketHome() {
  const { data } = useQuery(cricketBoardQueryOptions());
  const { data: series = [] } = useQuery(cricketSeriesQueryOptions());
  const { data: news = [] } = useQuery(cricketNewsQueryOptions());
  useTrackHubVisit("/cricket", "Cricket Hub");
  const matches = data?.matches ?? [];
  const live = matches.filter((m) => m.state === "in");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">Cricket</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Tests, ODIs, T20Is and the franchise leagues — live scores, points tables and headlines, all
        refreshing on their own.
      </p>

      <section className="mt-8">
        <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">
          {live.length ? "Live right now" : "Latest matches"}
        </h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {(live.length ? live : matches).slice(0, 6).map((m) => (
            <article key={m.id} className="rounded-md border border-border bg-card p-4">
              <p className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
                {m.series}
              </p>
              <ul className="mt-2 space-y-1 text-sm">
                {m.teams.map((t, i) => (
                  <li key={i} className="flex justify-between gap-3">
                    <span className={t.winner ? "font-semibold" : ""}>{t.team}</span>
                    <span className="scoreboard text-muted-foreground">{t.score || "—"}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-muted-foreground">{m.status}</p>
            </article>
          ))}
          {matches.length === 0 && (
            <p className="text-sm text-muted-foreground">
              No matches in this window — scores appear the moment the next one starts.
            </p>
          )}
        </div>
        <Link to="/cricket/scores" className="mt-3 inline-block text-sm font-semibold text-primary underline">
          All cricket scores
        </Link>
      </section>

      <section className="mt-10 grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">Series running now</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {series.slice(0, 10).map((s) => (
              <li key={s.id} className="rounded-md border border-border bg-card px-4 py-2">
                {s.name}
              </li>
            ))}
          </ul>
          <Link
            to="/cricket/standings"
            className="mt-3 inline-block text-sm font-semibold text-primary underline"
          >
            Points tables
          </Link>
        </div>
        <div>
          <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">Latest news</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {news.slice(0, 6).map((n) => (
              <li key={n.id}>
                <a
                  href={n.url}
                  target="_blank"
                  rel="noreferrer"
                  className="block rounded-md border border-border bg-card px-4 py-2 hover:border-primary"
                >
                  {n.headline}
                </a>
              </li>
            ))}
          </ul>
          <Link to="/cricket/news" className="mt-3 inline-block text-sm font-semibold text-primary underline">
            All cricket news
          </Link>
        </div>
      </section>
    </div>
  );
}
