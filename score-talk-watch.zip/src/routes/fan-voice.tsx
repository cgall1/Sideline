import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";
import {
  addSuggestion,
  deleteSuggestion,
  suggestionsQueryOptions,
  toggleSuggestionVote,
  type SuggestionKind,
} from "@/lib/fanvoice";

const TABS: { kind: SuggestionKind; label: string; blurb: string; titleHint: string; targetHint?: string }[] = [
  {
    kind: "debate",
    label: "Suggest a debate",
    blurb: "The most-upvoted idea becomes tomorrow's Daily Debate, with your name on it.",
    titleHint: "e.g. Is Mahomes already a top-5 QB of all time?",
  },
  {
    kind: "deep_dive",
    label: "Deep dives",
    blurb: "Vote for the topic that gets a full breakdown this week, built from real stats and news.",
    titleHint: "e.g. Why the Knicks' defense collapsed in March",
  },
  {
    kind: "athlete_question",
    label: "Ask the athlete",
    blurb: "Ask an athlete or coach a question. The top questions rise to the top of the list.",
    titleHint: "Your question",
    targetHint: "Athlete or coach name",
  },
];

export const Route = createFileRoute("/fan-voice")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/fan-voice",
      title: "Fan Voice — Decide what Sideline covers",
      description: "Suggest tomorrow's debate, vote on this week's deep dive and ask athletes the questions fans care about.",
    }),
  component: FanVoicePage,
});

function FanVoicePage() {
  const [kind, setKind] = useState<SuggestionKind>("debate");
  const tab = TABS.find((t) => t.kind === kind)!;
  const { user } = useAuth();
  const qc = useQueryClient();
  const opts = suggestionsQueryOptions(kind, user?.id ?? null);
  const { data: items = [], isLoading, error } = useQuery(opts);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [target, setTarget] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  const refresh = () => qc.invalidateQueries({ queryKey: ["fan-voice", kind] });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setMsg(null);
    try {
      const author =
        (user.user_metadata?.["display_name"] as string | undefined) ?? user.email?.split("@")[0] ?? "Fan";
      await addSuggestion({ userId: user.id, author, kind, title, body, target: tab.targetHint ? target : null });
      setTitle("");
      setBody("");
      setTarget("");
      setMsg("Thanks — your idea is live.");
      await refresh();
    } catch (err) {
      setMsg((err as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Fan Voice</p>
      <h1 className="mt-1 text-3xl font-bold">You decide what we talk about</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Sideline isn't just for watching. Pitch ideas, upvote the best ones, and see them become the day's debate or the
        week's deep dive. <Link to="/deep-dives" className="text-primary underline">Past deep dives</Link>
      </p>

      <div className="mt-6 flex flex-wrap gap-2" role="tablist">
        {TABS.map((t) => (
          <button
            key={t.kind}
            role="tab"
            aria-selected={t.kind === kind}
            onClick={() => setKind(t.kind)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium ${t.kind === kind ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/70"}`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <p className="mt-3 text-sm">{tab.blurb}</p>

      {user ? (
        <form onSubmit={submit} className="mt-4 space-y-2 rounded-md border border-border bg-card p-4">
          {tab.targetHint && (
            <input
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              placeholder={tab.targetHint}
              maxLength={120}
              required
              className="w-full rounded border border-input bg-background px-3 py-2 text-sm"
            />
          )}
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={tab.titleHint}
            minLength={5}
            maxLength={200}
            required
            className="w-full rounded border border-input bg-background px-3 py-2 text-sm"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Why does this matter? (optional)"
            maxLength={1000}
            rows={2}
            className="w-full rounded border border-input bg-background px-3 py-2 text-sm"
          />
          <div className="flex items-center gap-3">
            <button className="rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Submit</button>
            {msg && <span className="text-xs text-muted-foreground">{msg}</span>}
          </div>
        </form>
      ) : (
        <p className="mt-4 rounded-md border border-border bg-card p-4 text-sm">
          <Link to="/auth" className="text-primary underline">Sign in</Link> to add ideas and vote.
        </p>
      )}

      <ol className="mt-6 space-y-3">
        {isLoading && <li className="text-sm text-muted-foreground">Loading ideas…</li>}
        {error && <li className="text-sm text-destructive">{(error as Error).message}</li>}
        {!isLoading && items.length === 0 && (
          <li className="text-sm text-muted-foreground">No ideas yet — be the first.</li>
        )}
        {items.map((s, i) => (
          <li key={s.id} className="flex gap-3 rounded-md border border-border bg-card p-3">
            <button
              type="button"
              disabled={!user}
              aria-pressed={s.votedByMe}
              aria-label="Upvote"
              onClick={async () => {
                if (!user) return;
                await toggleSuggestionVote(s.id, user.id, s.votedByMe);
                await refresh();
              }}
              className={`flex w-12 shrink-0 flex-col items-center rounded border px-1 py-1 text-xs ${s.votedByMe ? "border-primary bg-primary text-primary-foreground" : "border-border"}`}
            >
              ▲<span className="font-bold">{s.votes}</span>
            </button>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] text-muted-foreground">
                #{i + 1} · {s.author}
                {s.target && ` · for ${s.target}`}
                {s.status === "picked" && " · ✅ Picked"}
              </p>
              <p className="font-medium">{s.title}</p>
              {s.body && <p className="mt-0.5 text-sm text-muted-foreground">{s.body}</p>}
              {s.answer && (
                <p className="mt-2 rounded bg-muted p-2 text-sm">
                  <span className="font-semibold">Answer:</span> {s.answer}
                </p>
              )}
              {user?.id === s.userId && (
                <button
                  type="button"
                  onClick={async () => {
                    await deleteSuggestion(s.id);
                    await refresh();
                  }}
                  className="mt-1 text-[11px] text-muted-foreground underline"
                >
                  Delete
                </button>
              )}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
