import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-hockey/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-hockey/standings",
      title: "College Hockey Standings — Full Table — Sideline",
      description: "The full College Hockey standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("chk"),
    }),
  component: () => <SportStandingsSection league="chk" />,
});
