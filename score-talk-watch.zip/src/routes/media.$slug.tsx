import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ARTICLES } from "@/data/sports";
import { leagueOgImage } from "@/lib/seo";
import { LeagueBadge } from "@/components/LeagueFilter";

const SITE = "https://score-talk-watch.lovable.app";

function parsePublishedToISO(published: string): string {
  const now = new Date();
  const lower = published.toLowerCase().trim();

  const agoMatch = lower.match(/^(\d+)\s+(minute|minutes|hour|hours|day|days)\s+ago$/);
  if (agoMatch) {
    const value = parseInt(agoMatch[1]!, 10);
    const unit = agoMatch[2]!;
    const d = new Date(now);
    if (unit.startsWith("minute")) d.setMinutes(d.getMinutes() - value);
    else if (unit.startsWith("hour")) d.setHours(d.getHours() - value);
    else if (unit.startsWith("day")) d.setDate(d.getDate() - value);
    return d.toISOString();
  }

  if (lower === "yesterday") {
    const d = new Date(now);
    d.setDate(d.getDate() - 1);
    return d.toISOString();
  }

  if (lower === "last week") {
    const d = new Date(now);
    d.setDate(d.getDate() - 7);
    return d.toISOString();
  }

  const iso = Date.parse(published);
  if (!Number.isNaN(iso)) return new Date(iso).toISOString();

  return now.toISOString();
}

export const Route = createFileRoute("/media/$slug")({
  staticData: { sitemap: true },
  loader: ({ params }) => {
    const article = ARTICLES.find((a) => a.slug === params.slug);
    if (!article) throw notFound();
    return { article };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Story unavailable — Sideline" }, { name: "robots", content: "noindex" }],
      };
    }
    const { article } = loaderData;
    const url = `https://score-talk-watch.lovable.app/media/${params.slug}`;
    const ogImage = leagueOgImage(article.league);
    return {
      meta: [
        { title: `${article.title} — Sideline` },
        { name: "description", content: article.dek },
        { property: "og:title", content: article.title },
        { property: "og:description", content: article.dek },
        { property: "og:type", content: "article" },
        { property: "og:url", content: url },
        { property: "og:image", content: ogImage },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: `${article.title} — ${article.league.toUpperCase()} on Sideline` },
        { name: "twitter:image", content: ogImage },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Article",
            headline: article.title,
            description: article.dek,
            image: {
              "@type": "ImageObject",
              url: ogImage,
              width: 1200,
              height: 630,
            },
            datePublished: parsePublishedToISO(article.published),
            articleSection: article.kind,
            author: { "@type": "Person", name: article.author },
            publisher: { "@type": "Organization", name: "Sideline", logo: { "@type": "ImageObject", url: `${SITE}/logo-wide.png`, width: 1200, height: 512 } },
            mainEntityOfPage: url,
            articleBody: article.body.join("\n\n"),
          }),
        },
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://score-talk-watch.lovable.app/" },
              { "@type": "ListItem", position: 2, name: "Media desk", item: "https://score-talk-watch.lovable.app/media" },
              { "@type": "ListItem", position: 3, name: article.title, item: url },
            ],
          }),
        },
      ],
    };
  },

  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-3xl px-4 py-16">
      This story didn't load: {error.message}
    </div>
  ),
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">Story not found</h1>
      <Link to="/media" className="mt-4 inline-block text-primary hover:underline">
        Back to the desk →
      </Link>
    </div>
  ),
  component: ArticlePage,
});

function ArticlePage() {
  const { article } = Route.useLoaderData();

  return (
    <article className="mx-auto max-w-3xl px-4 py-10">
      <div className="mb-3 flex items-center gap-2">
        <LeagueBadge league={article.league} />
        <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          {article.kind}
        </span>
      </div>
      <h1 className="text-4xl font-bold leading-tight">{article.title}</h1>
      <p className="mt-3 text-lg text-muted-foreground">{article.dek}</p>
      <p className="mt-4 border-y border-border py-3 text-xs uppercase tracking-widest text-muted-foreground">
        {article.author} · {article.published} · {article.duration ?? article.readTime}
      </p>

      {article.kind === "video" && (
        <div className="mt-6 flex aspect-video items-center justify-center rounded-md border border-border bg-surface-2">
          <span className="scoreboard text-lg uppercase tracking-widest text-muted-foreground">
            ▶ Highlight reel · {article.duration}
          </span>
        </div>
      )}

      <div className="mt-6 space-y-4 text-base leading-relaxed">
        {article.body.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>

      <div className="mt-10 flex flex-wrap gap-4">
        <Link to="/media" className="text-sm font-semibold text-primary hover:underline">
          ← More from the desk
        </Link>
        <Link to="/community" className="text-sm font-semibold text-primary hover:underline">
          Discuss it with fans →
        </Link>
      </div>
    </article>
  );
}
