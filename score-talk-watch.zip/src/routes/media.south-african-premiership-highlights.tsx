import { createFileRoute } from "@tanstack/react-router";
import { SoccerHighlights } from "@/components/SoccerHighlights";
import { soccerCompetition } from "@/data/soccer";
import { soccerHighlightsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const SLUG = "south-african-premiership-highlights";
const PAGE_URL = `${SITE}/media/${SLUG}`;
const TITLE = "South African Premiership Highlights — Goals & Match Recaps — Sideline";
const DESCRIPTION = "South African Premiership highlights: every goal and match recap from the PSL.";
const OG_IMAGE = `${SITE}/og/soccer.jpg`;

export const Route = createFileRoute("/media/south-african-premiership-highlights")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(soccerHighlightsQueryOptions(SLUG));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — South African Premiership highlights, scores and match recaps" },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "South African Premiership Highlights",
          description: DESCRIPTION,
          url: PAGE_URL,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Media", item: `${SITE}/media` },
              { "@type": "ListItem", position: 2, name: "South African Premiership Highlights", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      South African Premiership highlights are unavailable: {error.message}
    </div>
  ),
  component: Page,
});

function Page() {
  const competition = soccerCompetition(SLUG)!;
  return <SoccerHighlights competition={competition} />;
}
