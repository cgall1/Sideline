import { createFileRoute } from "@tanstack/react-router";
import { IndividualNewsSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/f1/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/f1/news",
      title: "Formula 1 News — Latest Headlines & Results — Sideline",
      description: "The latest Formula 1 news on Sideline: headlines, results reports and roster updates, refreshed from the live sports wire.",
    }),
  component: () => <IndividualNewsSection sport="f1" />,
});
