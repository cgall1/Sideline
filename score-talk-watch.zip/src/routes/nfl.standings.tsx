import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nfl/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nfl/standings",
      title: "NFL Standings — Full Table — Sideline",
      description: "The full NFL standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("nfl"),
    }),
  component: () => <SportStandingsSection league="nfl" />,
});
