import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-football/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-football/news",
      title: "College Football News — Latest Headlines & Injuries — Sideline",
      description: "The latest College Football news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("cfb"),
    }),
  component: () => <SportNewsSection league="cfb" />,
});
