import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/admin/fan-voice")({
  head: () => ({
    meta: [
      { title: "Fan Voice admin — Sideline" },
      { name: "description", content: "Moderate Fan Voice ideas and add athlete answers." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Fan Voice admin — Sideline" },
      { property: "og:description", content: "Moderate Fan Voice ideas and add athlete answers." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

function Admin() {
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const { data: isAdmin, isLoading: checking } = useQuery({
    queryKey: ["is-admin", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.rpc("has_role", { _user_id: user!.id, _role: "admin" });
      return Boolean(data);
    },
  });
  const { data: rows = [] } = useQuery({
    queryKey: ["admin-fv"],
    enabled: !!isAdmin,
    queryFn: async () => {
      const { data } = await supabase
        .from("topic_suggestions")
        .select("id,kind,title,body,target,author_name,status,hidden,pinned,answer,created_at")
        .order("created_at", { ascending: false })
        .limit(200);
      return data ?? [];
    },
  });
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const update = async (id: string, patch: { hidden?: boolean; pinned?: boolean; status?: string; answer?: string }) => {
    await supabase.from("topic_suggestions").update(patch).eq("id", id);
    await qc.invalidateQueries({ queryKey: ["admin-fv"] });
  };

  if (loading || (user && checking)) return <p className="p-8 text-sm">Checking access…</p>;
  if (!user) return <p className="p-8 text-sm"><Link to="/auth" className="text-primary underline">Sign in</Link> first.</p>;
  if (!isAdmin) return <p className="p-8 text-sm">This page is for Sideline admins only.</p>;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-2xl font-bold">Fan Voice admin</h1>
      <ul className="mt-6 space-y-3">
        {rows.map((r) => (
          <li key={r.id} className={`rounded-md border border-border bg-card p-3 ${r.hidden ? "opacity-50" : ""}`}>
            <p className="text-[11px] text-muted-foreground">
              {r.kind} · {r.author_name} · {r.status}{r.target && ` · for ${r.target}`}{r.pinned && " · pinned"}
            </p>
            <p className="font-medium">{r.title}</p>
            {r.body && <p className="text-sm text-muted-foreground">{r.body}</p>}
            <div className="mt-2 flex flex-wrap gap-2 text-xs">
              <button className="rounded border border-border px-2 py-1" onClick={() => update(r.id, { hidden: !r.hidden })}>{r.hidden ? "Unhide" : "Hide"}</button>
              <button className="rounded border border-border px-2 py-1" onClick={() => update(r.id, { pinned: !r.pinned })}>{r.pinned ? "Unpin" : "Pin"}</button>
              {r.status !== "picked" && (
                <button className="rounded border border-primary px-2 py-1 text-primary" onClick={() => update(r.id, { status: "picked" })}>Mark picked</button>
              )}
            </div>
            {r.kind === "athlete_question" && (
              <div className="mt-2 flex gap-2">
                <input
                  value={answers[r.id] ?? r.answer ?? ""}
                  onChange={(e) => setAnswers({ ...answers, [r.id]: e.target.value })}
                  placeholder="Real answer from the athlete (with source)"
                  className="flex-1 rounded border border-input bg-background px-2 py-1 text-sm"
                />
                <button className="rounded bg-primary px-3 text-xs text-primary-foreground" onClick={() => update(r.id, { answer: answers[r.id] ?? "" })}>Save</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
