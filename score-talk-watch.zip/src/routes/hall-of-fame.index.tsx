import { createFileRoute, Link } from "@tanstack/react-router";
import { HALL_OF_FAME } from "@/data/legacy";
import { pageHead } from "@/lib/seo";

const TITLE = "Hall of Fame — All-Time Greats of Every Sport — Sideline";
const DESCRIPTION =
  "The all-time greats of the NFL, NBA, MLB, NHL, soccer, tennis, UFC, golf and NASCAR — who is enshrined, where, and what they did.";

export const Route = createFileRoute("/hall-of-fame/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/hall-of-fame", title: TITLE, description: DESCRIPTION }),
  component: HallIndex,
});

function HallIndex() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Hall of fame</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        The immortals of each sport, where they are enshrined and why they are there.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {HALL_OF_FAME.map((sport) => (
          <Link
            key={sport.slug}
            to="/hall-of-fame/$sport"
            params={{ sport: sport.slug }}
            className="rounded-md border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{sport.name}</h2>
            <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{sport.hall}</p>
            <p className="mt-2 text-sm text-muted-foreground">
              {sport.members.length} all-time greats
            </p>
          </Link>
        ))}
      </div>
      <div className="mt-8 flex flex-wrap gap-2 text-sm">
        <Link to="/history" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Sports history
        </Link>
        <Link to="/records" className="rounded-sm border border-border px-3 py-1 hover:border-primary">
          Retired numbers &amp; franchise records
        </Link>
      </div>
    </div>
  );
}
