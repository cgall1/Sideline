import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nfl/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nfl/schedule",
      title: "NFL Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete NFL schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("nfl"),
    }),
  component: () => <SportScheduleSection league="nfl" />,
});
