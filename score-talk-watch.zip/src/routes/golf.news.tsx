import { createFileRoute } from "@tanstack/react-router";
import { IndividualNewsSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/golf/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/golf/news",
      title: "Golf News — Latest Headlines & Results — Sideline",
      description: "The latest Golf news on Sideline: headlines, results reports and roster updates, refreshed from the live sports wire.",
    }),
  component: () => <IndividualNewsSection sport="golf" />,
});
