import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, type LeagueId } from "@/data/sports";
import { venuesQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/directory/venues`;
const TITLE = "Stadium & City Directory — Every Venue by League — Sideline";
const DESCRIPTION =
  "Every city and stadium across the NFL, NBA, NHL, MLB, MLS, college football and international soccer, with the home teams that play there and links to live games, standings and highlights.";

const HIGHLIGHT_HUB: Partial<Record<LeagueId, string>> = {
  nfl: "/media/nfl-highlights",
  nba: "/media/nba-highlights",
  nhl: "/media/nhl-highlights",
  cfb: "/media/college-football-highlights",
};

export const Route = createFileRoute("/directory/venues")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(venuesQueryOptions());
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Stadium & City Directory",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "Stadiums & Cities", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The stadium directory is unavailable right now: {error.message}
    </div>
  ),
  component: VenueDirectory,
});

function VenueDirectory() {
  const { data } = useSuspenseQuery(venuesQueryOptions());
  const cities = [...new Set(data.venues.map((v) => v.city || "Other"))].sort((a, b) =>
    a.localeCompare(b),
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Cities &amp; Stadiums</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        {data.venues.length} venues across {LEAGUES.length} leagues, grouped by city. Each stadium
        links straight to that league&apos;s live games, standings and highlights.
      </p>

      {cities.length === 0 && (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          Venue data is loading from the league feeds. Check back shortly.
        </p>
      )}

      <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {cities.map((city) => (
          <section key={city} className="rounded-md border border-border bg-card p-5">
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{city}</h2>
            <ul className="mt-3 space-y-4">
              {data.venues
                .filter((v) => (v.city || "Other") === city)
                .map((venue) => (
                  <li key={`${venue.league}-${venue.id}-${venue.name}`}>
                    <div className="flex items-center gap-2">
                      <LeagueBadge league={venue.league} />
                      <span className="text-xs uppercase tracking-widest text-muted-foreground">
                        {venue.indoor ? "Indoor" : "Outdoor"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-bold">{venue.name}</p>
                    <p className="text-xs text-muted-foreground">{venue.teams.join(" · ")}</p>
                    <div className="mt-1.5 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
                      <Link
                        to="/scores"
                        search={{ league: venue.league }}
                        className="text-primary underline"
                      >
                        Live games
                      </Link>
                      <Link
                        to="/standings"
                        search={{ league: venue.league }}
                        className="text-primary underline"
                      >
                        Standings
                      </Link>
                      <Link
                        to={HIGHLIGHT_HUB[venue.league] ?? "/highlights"}
                        className="text-primary underline"
                      >
                        Highlights
                      </Link>
                    </div>
                  </li>
                ))}
            </ul>
          </section>
        ))}
      </div>

      <div className="mt-10 flex flex-wrap gap-3 text-sm">
        <Link to="/directory" className="font-semibold text-primary underline">
          Back to the directory
        </Link>
        <Link to="/calendar" className="font-semibold text-primary underline">
          Season schedule calendar
        </Link>
      </div>
    </div>
  );
}
