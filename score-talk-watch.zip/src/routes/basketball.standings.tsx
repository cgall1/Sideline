import { createFileRoute } from "@tanstack/react-router";
import { BasketballStandings, basketballLeague } from "@/components/sport/BasketballSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/basketball/standings")({
  staticData: { sitemap: true },
  validateSearch: (search: Record<string, unknown>) => ({
    league: basketballLeague(search['league']),
  }),
  head: () =>
    pageHead({
      path: "/basketball/standings",
      title: "Basketball Standings — NBA, WNBA & College Tables — Sideline",
      description:
        "Basketball standings for the NBA, WNBA and college game: records, win percentage and conference order, updating as results land.",
    }),
  component: BasketballStandingsPage,
});

function BasketballStandingsPage() {
  const { league } = Route.useSearch();
  return <BasketballStandings league={league} />;
}
