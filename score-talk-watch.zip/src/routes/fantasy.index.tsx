import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";
import {
  FANTASY_SPORTS,
  createFantasyLeague,
  joinFantasyLeague,
  myFantasyLeagues,
} from "@/lib/fantasy.functions";

const TITLE = "Fantasy Leagues — Draft Real Players With Friends — Sideline";
const DESCRIPTION =
  "Create a fantasy league, invite friends with a code and draft real players from the NFL, NBA, NHL, MLB and soccer in a live snake draft.";

export const Route = createFileRoute("/fantasy/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/fantasy", title: TITLE, description: DESCRIPTION }),
  component: FantasyHub,
});

const SPORT_LABEL = Object.fromEntries(FANTASY_SPORTS.map((s) => [s.id, s.label]));

function FantasyHub() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [teamName, setTeamName] = useState("");
  const [sport, setSport] = useState<string>("nfl");
  const [joinCode, setJoinCode] = useState("");
  const [joinTeam, setJoinTeam] = useState("");
  const [error, setError] = useState<string | null>(null);

  const { data: leagues = [] } = useQuery({
    queryKey: ["fantasy", "mine"],
    queryFn: () => myFantasyLeagues(),
    enabled: !!user,
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["fantasy"] });

  const create = useMutation({
    mutationFn: () => createFantasyLeague({ data: { name, sport, teamName } }),
    onSuccess: () => {
      setName("");
      setTeamName("");
      setError(null);
      void refresh();
    },
    onError: (e) => setError(e.message),
  });

  const join = useMutation({
    mutationFn: () => joinFantasyLeague({ data: { inviteCode: joinCode, teamName: joinTeam } }),
    onSuccess: () => {
      setJoinCode("");
      setJoinTeam("");
      setError(null);
      void refresh();
    },
    onError: (e) => setError(e.message),
  });

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Fantasy leagues</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Create a league, share the invite code with friends and draft real players from the NFL,
        NBA, NHL, MLB and soccer in a live snake draft.
      </p>

      {!user && (
        <div className="mt-6 rounded-lg border border-border bg-card p-6">
          <p className="text-sm text-muted-foreground">
            Fantasy leagues are for signed-in fans.{" "}
            <Link to="/auth" className="font-semibold text-primary underline">
              Sign in
            </Link>{" "}
            to create or join a league.
          </p>
        </div>
      )}

      {user && (
        <>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border border-border bg-card p-5">
              <h2 className="text-lg font-bold">Start a league</h2>
              <div className="mt-3 space-y-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="League name"
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
                <input
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="Your team name"
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
                <select
                  value={sport}
                  onChange={(e) => setSport(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                >
                  {FANTASY_SPORTS.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => create.mutate()}
                  disabled={create.isPending}
                  className="w-full rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
                >
                  {create.isPending ? "Creating…" : "Create league"}
                </button>
              </div>
            </div>

            <div className="rounded-lg border border-border bg-card p-5">
              <h2 className="text-lg font-bold">Join with an invite code</h2>
              <div className="mt-3 space-y-2">
                <input
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                  placeholder="Invite code"
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm uppercase"
                />
                <input
                  value={joinTeam}
                  onChange={(e) => setJoinTeam(e.target.value)}
                  placeholder="Your team name"
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
                <button
                  onClick={() => join.mutate()}
                  disabled={join.isPending}
                  className="w-full rounded-md bg-secondary px-3 py-2 text-sm font-semibold text-secondary-foreground disabled:opacity-50"
                >
                  {join.isPending ? "Joining…" : "Join league"}
                </button>
              </div>
            </div>
          </div>

          {error && <p className="mt-3 text-sm text-destructive">{error}</p>}

          <h2 className="mt-8 text-xl font-bold">Your leagues</h2>
          {leagues.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              No leagues yet — create one above or join with a friend's invite code.
            </p>
          ) : (
            <div className="mt-3 grid gap-3 md:grid-cols-2">
              {leagues.map((l) => (
                <Link
                  key={l.id}
                  to="/fantasy/$leagueId"
                  params={{ leagueId: l.id }}
                  className="rounded-lg border border-border bg-card p-4 transition-colors hover:border-primary"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">{l.name}</span>
                    <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest text-accent-foreground">
                      {SPORT_LABEL[l.sport] ?? l.sport}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {l.memberCount} team{l.memberCount === 1 ? "" : "s"} ·{" "}
                    {l.status === "open"
                      ? "Open — draft not started"
                      : l.status === "drafting"
                        ? "Draft live"
                        : "Draft complete"}
                    {l.isCommissioner && " · You run this league"}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Invite code: <span className="font-mono font-bold">{l.inviteCode}</span>
                  </p>
                </Link>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
