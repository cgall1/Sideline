import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mls/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mls/news",
      title: "MLS News — Latest Headlines & Injuries — Sideline",
      description: "The latest MLS news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("mls"),
    }),
  component: () => <SportNewsSection league="mls" />,
});
