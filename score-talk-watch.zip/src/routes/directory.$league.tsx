import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, leagueById, type LeagueId } from "@/data/sports";
import { directoryQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import { leagueOgImage } from "@/lib/seo";

const SITE = "https://score-talk-watch.lovable.app";
const LEAGUE_IDS = LEAGUES.map((l) => l.id) as string[];

const HIGHLIGHT_HUB: Partial<Record<LeagueId, string>> = {
  nfl: "/media/nfl-highlights",
  nba: "/media/nba-highlights",
  nhl: "/media/nhl-highlights",
  cfb: "/media/college-football-highlights",
};

export const Route = createFileRoute("/directory/$league")({
  staticData: { sitemap: true },
  loader: ({ context, params }) => {
    if (!LEAGUE_IDS.includes(params.league)) throw notFound();
    context.queryClient.ensureQueryData(directoryQueryOptions(params.league as LeagueId));
    return { league: params.league as LeagueId };
  },
  head: ({ params }) => {
    const league = leagueById(params.league);
    if (!league) {
      return { meta: [{ title: "League not found — Sideline" }, { name: "robots", content: "noindex" }] };
    }
    const url = `${SITE}/directory/${league.id}`;
    const ogImage = leagueOgImage(league.id);
    const title = `${league.name} Teams Directory — Conferences, Standings & Scores — Sideline`;
    const description = `Every ${league.short} team by conference and division, with links to ${league.short} standings, live scores and highlights.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { property: "og:url", content: url },
        { property: "og:image", content: ogImage },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
        { name: "twitter:image", content: ogImage },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: description },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: `${league.name} Teams`,
            url,
            description,
            isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
            breadcrumb: {
              "@type": "BreadcrumbList",
              itemListElement: [
                { "@type": "ListItem", position: 1, name: "Home", item: SITE },
                { "@type": "ListItem", position: 2, name: "Sports Directory", item: `${SITE}/directory` },
                { "@type": "ListItem", position: 3, name: league.name, item: url },
              ],
            },
          }),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-7xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">League not found</h1>
      <Link to="/directory" className="mt-3 inline-block font-semibold text-primary underline">
        Back to the sports directory
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      Teams are unavailable right now: {error.message}
    </div>
  ),
  component: LeagueDirectoryPage,
});

function LeagueDirectoryPage() {
  const { league } = Route.useLoaderData();
  const meta = leagueById(league)!;
  const { data } = useSuspenseQuery(directoryQueryOptions(league));
  const hub = HIGHLIGHT_HUB[league];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <nav aria-label="Breadcrumb" className="text-xs uppercase tracking-widest text-muted-foreground">
        <Link to="/directory" className="hover:text-foreground">
          Directory
        </Link>{" "}
        / {meta.short}
      </nav>

      <div className="mt-2 flex flex-wrap items-center gap-3">
        <LeagueBadge league={league} />
        <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
          {meta.name} Teams
        </h1>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        {data.teamCount} teams across {data.groups.length}{" "}
        {data.groups.length === 1 ? "group" : "conferences"}.
      </p>

      <div className="mt-4 flex flex-wrap gap-2 text-sm">
        <Link
          to="/standings"
          search={{ league }}
          className="scoreboard rounded-sm border border-border px-3 py-1.5 font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          {meta.short} Standings
        </Link>
        <Link
          to="/scores"
          search={{ league }}
          className="scoreboard rounded-sm border border-border px-3 py-1.5 font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          {meta.short} Scores
        </Link>
        <Link
          to={hub ?? "/highlights"}
          className="scoreboard rounded-sm border border-border px-3 py-1.5 font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          {meta.short} Highlights
        </Link>
      </div>

      {data.groups.map((group) => (
        <section key={group.name} className="mt-8">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{group.name}</h2>
          {group.divisions.map((division) => (
            <div key={division.name} className="mt-4">
              <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                {division.name}
              </h3>
              <ul className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                {division.teams.map((team) => (
                  <li
                    key={team.id}
                    className="flex items-center gap-3 rounded-md border border-border bg-card p-3"
                  >
                    {team.logo && (
                      <img
                        src={team.logo}
                        alt={`${team.name} logo`}
                        loading="lazy"
                        width={32}
                        height={32}
                        className="h-8 w-8 object-contain"
                      />
                    )}
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold">{team.name}</p>
                      <p className="text-xs uppercase tracking-widest text-muted-foreground">
                        {team.abbr}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </section>
      ))}

      {!data.groups.length && (
        <p className="mt-8 text-sm text-muted-foreground">
          Team data for this league is unavailable right now. Try the{" "}
          <Link to="/standings" search={{ league }} className="font-semibold text-primary underline">
            standings
          </Link>{" "}
          instead.
        </p>
      )}
    </div>
  );
}
