import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/cricket")({
  component: CricketSection,
});

const tab =
  "scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground";

function CricketSection() {
  return (
    <>
      <nav aria-label="Cricket sections" className="border-b border-border bg-card/60 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            Cricket
          </span>
          <Link
            to="/cricket"
            activeOptions={{ exact: true }}
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            Home
          </Link>
          <Link to="/cricket/news" activeProps={{ className: "border-primary text-primary" }} className={tab}>
            News
          </Link>
          <Link to="/cricket/scores" activeProps={{ className: "border-primary text-primary" }} className={tab}>
            Scores
          </Link>
          <Link
            to="/cricket/standings"
            activeProps={{ className: "border-primary text-primary" }}
            className={tab}
          >
            Standings
          </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
