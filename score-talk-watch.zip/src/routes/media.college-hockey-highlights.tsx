import { createFileRoute, Link } from "@tanstack/react-router";
import { VideoReel } from "@/components/VideoReel";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/media/college-hockey-highlights`;
const TITLE = "College Hockey Highlights — NCAA Goals & Game Recaps — Sideline";
const DESCRIPTION =
  "Watch college hockey highlights: NCAA goals, overtime winners, Frozen Four moments and full game recaps from the official NCAA video channels.";
const OG_IMAGE = `${SITE}/og-cover.jpg`;

export const Route = createFileRoute("/media/college-hockey-highlights")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      {
        property: "og:image:alt",
        content: "Sideline — college hockey highlights, scores and game recaps",
      },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "College Hockey Highlights",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Media", item: `${SITE}/media` },
              { "@type": "ListItem", position: 2, name: "College Hockey Highlights", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  component: CollegeHockeyHighlights,
});

function CollegeHockeyHighlights() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <Link to="/media" className="hover:text-foreground">
          Media
        </Link>{" "}
        / College Hockey Highlights
      </p>
      <h1 className="scoreboard mt-1 text-4xl font-bold uppercase tracking-wide">
        College Hockey Highlights
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        NCAA goals, overtime winners and Frozen Four moments — clips straight from the official
        NCAA channels, refreshed all season.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/college-hockey" className="text-primary underline">
          Hub &amp; calendar
        </Link>
        <Link to="/college-hockey-chat" className="text-primary underline">
          Fan chat
        </Link>
        <Link to="/college-hockey-results" className="text-primary underline">
          Season results
        </Link>
        <Link to="/college-hockey-rankings" className="text-primary underline">
          Rankings
        </Link>
      </div>

      <VideoReel
        league="chk"
        heading="College hockey highlight reel"
        intro="Goals, saves and full recaps from the NCAA's official video channels."
      />
    </div>
  );
}
