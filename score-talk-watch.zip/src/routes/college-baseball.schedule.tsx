import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-baseball/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-baseball/schedule",
      title: "College Baseball Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete College Baseball schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("cbs"),
    }),
  component: () => <SportScheduleSection league="cbs" />,
});
