import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nhl/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nhl/news",
      title: "NHL News — Latest Headlines & Injuries — Sideline",
      description: "The latest NHL news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("nhl"),
    }),
  component: () => <SportNewsSection league="nhl" />,
});
