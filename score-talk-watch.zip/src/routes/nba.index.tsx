import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/nba`;
const TITLE = "NBA Scores, Standings & Schedule — Basketball Hub — Sideline";
const DESCRIPTION =
  "Live NBA scores, the full Eastern and Western Conference standings and a month-by-month basketball schedule with tip-off times, arenas and TV — plus highlights for every game.";

const SEASON_MONTHS = [10,11,12,1,2,3,4,5,6];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/nba/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("nba"));
    context.queryClient.ensureQueryData(standingsQueryOptions("nba"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("nba", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/nba.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/nba.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NBA Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "NBA Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NBA hub is unavailable right now: {error.message}
    </div>
  ),
  component: NBAPage,
});

function NBAPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/nba/" });
  useTrackHubVisit("/nba", "NBA Hub");

  return (
    <>
      <CollegeHub
        league="nba"
        month={month}
        heading="NBA Scores & Standings"
        intro="Live NBA scores, the full conference standings, and a month-by-month schedule with tip-off times, arenas and TV — with a highlight reel beside every game."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "nba" }} className="font-semibold text-primary underline">
          NBA live scores
        </Link>
        <Link to="/results" search={{ league: "nba" }} className="font-semibold text-primary underline">
          NBA season results
        </Link>
        <Link to="/directory/$league" params={{ league: "nba" }} className="font-semibold text-primary underline">
          Every NBA team
        </Link>
        <Link to="/nba-chat" className="font-semibold text-primary underline">
          NBA fan chat
        </Link>
        <Link to="/nba-rankings" className="font-semibold text-primary underline">
          NBA rankings
        </Link>
        <Link to="/nba-trivia" className="font-semibold text-primary underline">
          NBA trivia
        </Link>
        <Link to="/media/nba-highlights" className="font-semibold text-primary underline">
          NBA highlight videos
        </Link>
      </div>
    </>
  );
}
