import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/nhl`;
const TITLE = "NHL Scores, Standings & Schedule — Hockey Hub — Sideline";
const DESCRIPTION =
  "Live NHL scores, full division and conference standings and the complete hockey schedule with puck-drop times, arenas and TV — plus highlights for every game.";

const SEASON_MONTHS = [10,11,12,1,2,3,4,5,6];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/nhl/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("nhl"));
    context.queryClient.ensureQueryData(standingsQueryOptions("nhl"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("nhl", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/nhl.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/nhl.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NHL Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "NHL Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NHL hub is unavailable right now: {error.message}
    </div>
  ),
  component: NHLPage,
});

function NHLPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/nhl/" });
  useTrackHubVisit("/nhl", "NHL Hub");

  return (
    <>
      <CollegeHub
        league="nhl"
        month={month}
        heading="NHL Scores & Standings"
        intro="Live NHL scores, the full division standings, and a month-by-month schedule with puck-drop times, arenas and TV — with a highlight reel beside every game."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "nhl" }} className="font-semibold text-primary underline">
          NHL live scores
        </Link>
        <Link to="/results" search={{ league: "nhl" }} className="font-semibold text-primary underline">
          NHL season results
        </Link>
        <Link to="/directory/$league" params={{ league: "nhl" }} className="font-semibold text-primary underline">
          Every NHL team
        </Link>
        <Link to="/nhl-chat" className="font-semibold text-primary underline">
          NHL fan chat
        </Link>
        <Link to="/nhl-rankings" className="font-semibold text-primary underline">
          NHL rankings
        </Link>
        <Link to="/media/nhl-highlights" className="font-semibold text-primary underline">
          NHL highlight videos
        </Link>
        <Link to="/nhl-trivia" className="font-semibold text-primary underline">
          NHL trivia
        </Link>
      </div>
    </>
  );
}
