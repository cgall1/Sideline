import { createFileRoute } from "@tanstack/react-router";
import { IndividualScoresSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/boxing/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/boxing/scores",
      title: "Boxing Fights — Live Results & Schedule — Sideline",
      description: "Live Boxing results and the full schedule of upcoming fights with dates, venues and finishing positions.",
    }),
  component: () => <IndividualScoresSection sport="boxing" />,
});
