import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { leagueMovesQueryOptions } from "@/lib/feed";
import { leagueById, type LeagueId } from "@/data/sports";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";

export const Route = createFileRoute("/moves/$league")({
  loader: async ({ params, context }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    await context.queryClient.ensureQueryData(leagueMovesQueryOptions(league.id));
    return { league };
  },
  head: ({ params }) => {
    const league = leagueById(params.league);
    const name = league?.short ?? "League";
    const url = `${SITE}/moves/${params.league}`;
    const title = `${name} Trade Tracker — Trades, Signings & Roster Moves — Sideline`;
    const description = `Every reported ${name} trade, free agency signing, transfer and roster move, updated as the news breaks, with links to team rosters and hubs.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { property: "og:url", content: url },
        { property: "og:image", content: `${SITE}/og-cover.jpg` },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: `${name} trade tracker on Sideline` },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:image", content: `${SITE}/og-cover.jpg` },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: description },
      ],
      links: [{ rel: "canonical", href: url }],
    };
  },
  staticData: { sitemap: true },
  component: LeagueMoves,
});

function LeagueMoves() {
  const { league } = Route.useParams();
  const info = leagueById(league)!;
  const leagueId = info.id as LeagueId;
  const { data } = useSuspenseQuery(leagueMovesQueryOptions(leagueId));
  useTrackHubVisit(`/moves/${leagueId}`, `${info.short} trade tracker`);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        {info.short} trade &amp; signing tracker
      </h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Trades, free agency signings, transfers and roster moves reported around the {info.name}.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/moves" className="text-primary underline">
          All leagues
        </Link>
        <Link to="/rosters/$league" params={{ league: leagueId }} className="text-primary underline">
          {info.short} rosters
        </Link>
        <Link to="/injuries/$league" params={{ league: leagueId }} className="text-primary underline">
          Injury report
        </Link>
        <Link to="/news" search={{ league: leagueId }} className="text-primary underline">
          League news
        </Link>
      </div>

      <ul className="mt-8 space-y-3">
        {data.map((move) => (
          <li key={move.id} className="rounded-md border border-border bg-card p-4">
            <span className="scoreboard rounded-sm border border-primary/40 bg-primary/10 px-2 py-0.5 text-[10px] uppercase tracking-widest text-primary">
              {move.kind}
            </span>
            <a
              href={move.url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 block font-semibold hover:text-primary"
            >
              {move.headline}
            </a>
            {move.summary && <p className="mt-1 text-sm text-muted-foreground">{move.summary}</p>}
          </li>
        ))}
        {!data.length && (
          <li className="rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
            No moves reported in the latest {info.short} news cycle. This fills in as soon as deals
            are announced.
          </li>
        )}
      </ul>
    </div>
  );
}
