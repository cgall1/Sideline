import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-hockey`;
const TITLE = "College Hockey Hub — Live Scores, Standings & Highlights — Sideline";
const DESCRIPTION =
  "NCAA college hockey in one hub: live scores, national standings, the full season calendar with puck-drop times and arenas, and a highlight reel for every matchup.";

const SEASON_MONTHS = [10, 11, 12, 1, 2, 3];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/college-hockey/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("chk"));
    context.queryClient.ensureQueryData(standingsQueryOptions("chk"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("chk", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "College Hockey Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "College Hockey Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The college hockey hub is unavailable right now: {error.message}
    </div>
  ),
  component: CollegeHockeyPage,
});

function CollegeHockeyPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/college-hockey/" });
  useTrackHubVisit("/college-hockey", "College Hockey Hub");

  return (
    <>
      <CollegeHub
        league="chk"
        month={month}
        heading="College Hockey Hub"
        intro="Live NCAA hockey scores, national standings and a month-by-month calendar with puck-drop times, arenas and TV — plus a highlight reel beside every matchup."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto max-w-7xl px-4 pb-12 flex flex-wrap gap-4 text-sm">
        <Link to="/college-hockey-chat" className="font-semibold text-primary underline">
          Join the college hockey chat →
        </Link>
        <Link to="/college-hockey-rankings" className="font-semibold text-primary underline">
          Rankings
        </Link>
        <Link to="/college-hockey-results" className="font-semibold text-primary underline">
          Season results
        </Link>
        <Link to="/college-hockey-trivia" className="font-semibold text-primary underline">
          Trivia
        </Link>
        <Link to="/media/college-hockey-highlights" className="font-semibold text-primary underline">
          Highlight videos
        </Link>
      </div>
    </>
  );
}
