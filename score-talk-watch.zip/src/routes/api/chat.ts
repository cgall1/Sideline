import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, stepCountIs, streamText, tool, type UIMessage } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { z } from "zod";
import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayResponseHeaders,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai-gateway.server";
import { fetchLiveGames, fetchLiveStandings } from "@/lib/live-sports.functions";
import { fetchNews } from "@/lib/news.functions";
import { fetchLeagueDirectory } from "@/lib/directory.functions";
import { fetchTeamRoster } from "@/lib/rosters.functions";
import { fetchPredictionBoard } from "@/lib/predictions.functions";

const LEAGUES = [
  "nfl",
  "nba",
  "nhl",
  "mlb",
  "mls",
  "intl",
  "cfb",
  "cbb",
  "chk",
  "cbs",
  "wnba",
  "nwsl",
  "sball",
  "vball",
] as const;

const SYSTEM = `You are the Sideline assistant, the in-house sports helper for the Sideline fan site.

Rules:
- Answer ONLY from the data returned by your tools (Sideline's own live scores, league tables, rosters, news and prediction board). Never invent a score, record, stat or transaction.
- Always call a tool before answering anything factual about a game, team, player, table or pick. If the tools return nothing, say plainly that Sideline has no data for that yet and suggest the relevant page.
- Be short and punchy, like a good sports desk: a sentence or two, then bullets for numbers.
- Picks advice is entertainment only — Sideline's prediction game has no betting or money involved. Never give gambling advice.
- Link fans onward to Sideline pages where useful, e.g. /scores, /standings, /predictions, /news.`;

/**
 * Only messages the app itself produced are accepted: roles are limited to
 * user/assistant, so a caller can never smuggle in system instructions.
 */
const messageSchema = z.object({
  id: z.string().max(100).optional(),
  role: z.enum(["user", "assistant"]),
  parts: z.array(z.object({ type: z.string().max(60) }).passthrough()).max(80),
});

const bodySchema = z.object({ messages: z.array(messageSchema).max(60) });

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return new Response("AI is not configured", { status: 500 });

        // Signed-in fans only — the assistant runs on the site owner's account.
        const authHeader = request.headers.get("authorization") ?? "";
        const token = authHeader.toLowerCase().startsWith("bearer ")
          ? authHeader.slice(7).trim()
          : "";
        if (!token) return new Response("Sign in to use the assistant", { status: 401 });
        const { createClient } = await import("@supabase/supabase-js");
        const authClient = createClient(
          process.env["SUPABASE_URL"]!,
          process.env["SUPABASE_PUBLISHABLE_KEY"]!,
          { auth: { persistSession: false, autoRefreshToken: false } },
        );
        const { data: userData, error: userError } = await authClient.auth.getUser(token);
        if (userError || !userData.user) {
          return new Response("Sign in to use the assistant", { status: 401 });
        }

        const parsed = bodySchema.safeParse(await request.json());
        if (!parsed.success) return new Response("Invalid request", { status: 400 });

        // Roles and turn order are decided here, not by the caller: the caller's
        // own role labels are discarded, prior turns are reduced to plain text,
        // tool results supplied by the caller are dropped, and roles are
        // re-derived by position so the transcript alternates and ends on a fan
        // turn. A fan therefore cannot inject assistant-authored instructions.
        const history = parsed.data.messages
          .map((m) => {
            const parts = (m.parts as Array<Record<string, unknown>>).filter(
              (p) => p["type"] === "text" && typeof p["text"] === "string",
            );
            return { id: m.id, parts };
          })
          .filter((m) => m.parts.length > 0)
          .slice(-40);
        if (!history.length) return new Response("Invalid request", { status: 400 });

        // Last message is always the fan's; earlier turns alternate backwards.
        const conversation = history.map((m, i) => ({
          ...m,
          role: (history.length - 1 - i) % 2 === 0 ? ("user" as const) : ("assistant" as const),
        }));
        const messages = conversation as unknown as UIMessage[];


        const initialRunId = getLovableAiGatewayRunId(request);
        const runIdFetch = createLovableAiGatewayRunIdFetch(initialRunId);
        const lovable = createOpenAI({
          baseURL: "https://ai.gateway.lovable.dev/v1",
          apiKey: key,
          headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
          fetch: runIdFetch.fetch,
        });

        const result = streamText({
          model: lovable.responses("openai/gpt-6-astra"),
          system: SYSTEM,
          messages: await convertToModelMessages(messages),
          stopWhen: stepCountIs(50),
          abortSignal: request.signal,
          tools: {
            get_scores: tool({
              description:
                "Live, scheduled and final games from Sideline's live feed. Use for any score, kickoff time or result question.",
              inputSchema: z.object({
                league: z
                  .enum(LEAGUES)
                  .nullable()
                  .describe("League id, or null for every league"),
              }),
              execute: async ({ league }) => {
                const res = await fetchLiveGames({ data: { league: league ?? "all" } });
                return {
                  live: res.live,
                  games: res.games.slice(0, 40).map((g) => ({
                    league: g.league,
                    away: g.away.name,
                    home: g.home.name,
                    score: g.status === "scheduled" ? null : `${g.awayScore}-${g.homeScore}`,
                    status: g.status,
                    clock: g.clock,
                    start: g.startLabel,
                    venue: g.venue,
                  })),
                };
              },
            }),
            get_standings: tool({
              description: "Sideline's live league table for one league.",
              inputSchema: z.object({ league: z.enum(LEAGUES) }),
              execute: async ({ league }) => {
                const res = await fetchLiveStandings({ data: { league } });
                return {
                  group: res.group,
                  live: res.live,
                  rows: res.rows.slice(0, 30),
                };
              },
            }),
            get_news: tool({
              description: "Latest Sideline headlines for a league.",
              inputSchema: z.object({
                league: z.enum(LEAGUES).nullable().describe("League id, or null for all leagues"),
              }),
              execute: async ({ league }) => {
                const res = await fetchNews({ data: { league: league ?? "all" } });
                return res.items.slice(0, 12).map((n) => ({
                  headline: n.headline,
                  summary: n.summary,
                  league: n.league,
                  published: n.published,
                }));
              },
            }),
            get_team_roster: tool({
              description:
                "Squad, record and recent trades/signings for one team. Give the team name as fans say it.",
              inputSchema: z.object({
                league: z.enum(LEAGUES),
                team: z.string().describe("Team name, city or abbreviation"),
              }),
              execute: async ({ league, team }) => {
                const dir = await fetchLeagueDirectory({ data: { league } });
                const all = dir.groups.flatMap((g) => g.divisions.flatMap((d) => d.teams));
                const needle = team.toLowerCase();
                const match =
                  all.find((t) => t.name.toLowerCase() === needle) ??
                  all.find((t) => t.abbr.toLowerCase() === needle) ??
                  all.find((t) => t.name.toLowerCase().includes(needle));
                if (!match) return { found: false, team, league };
                const roster = await fetchTeamRoster({
                  data: { league, teamId: match.id },
                });
                return {
                  found: true,
                  team: roster.team,
                  record: roster.record,
                  standing: roster.standing,
                  venue: roster.venue,
                  players: roster.players.slice(0, 60),
                  moves: roster.moves.slice(0, 8),
                };
              },
            }),
            get_prediction_board: tool({
              description:
                "Sideline's prediction game board: overall accuracy, per-league accuracy and streaks.",
              inputSchema: z.object({
                league: z
                  .enum(LEAGUES)
                  .nullable()
                  .describe("Filter to one league's numbers, or null for everything"),
              }),
              execute: async ({ league }) => {
                const board = await fetchPredictionBoard();
                return {
                  overall: board.overall,
                  byLeague: league
                    ? { [league]: board.byLeague[league] ?? [] }
                    : board.byLeague,
                  streaks: board.streaks.slice(0, 10),
                };
              },
            }),
          },
          providerOptions: {
            openai: {
              store: false,
              include: ["reasoning.encrypted_content"],
              forceReasoning: true,
              reasoningEffort: "low",
              reasoningSummary: "auto",
            },
          },
        });

        const response = result.toUIMessageStreamResponse({
          originalMessages: messages,
          sendReasoning: true,
          headers: getLovableAiGatewayResponseHeaders(undefined, {
            ...(initialRunId ? { "X-Lovable-AIG-Run-ID": initialRunId } : {}),
          }),
        });

        return withLovableAiGatewayRunIdHeader(response, runIdFetch);
      },
    },
  },
});
