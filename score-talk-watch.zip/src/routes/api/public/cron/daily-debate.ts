import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";
import { buildDebate, todayISO } from "@/lib/daily.server";
import { sendTickle } from "@/lib/webpush.server";

/**
 * Creates today's debate if it doesn't exist yet, then nudges every fan with
 * phone alerts switched on (outside their quiet hours). Safe to run repeatedly:
 * the nudge only goes out once per day.
 */
export const Route = createFileRoute("/api/public/cron/daily-debate")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const provided = request.headers.get("x-cron-secret");
        if (provided) {
          const { data: config } = await supabaseAdmin
            .from("newsletter_config")
            .select("value")
            .eq("key", "alerts_cron_secret")
            .maybeSingle();
          if (!config?.value || provided !== config.value) {
            return new Response("Unauthorized", { status: 401 });
          }
        } else {
          const unauthorized = await authenticateCronRequest(request);
          if (unauthorized) return unauthorized;
        }

        const today = todayISO();
        const draft = buildDebate(today);
        let suggestedBy: string | null = null;
        let pickedId: string | null = null;

        // Fan Voice: the most-upvoted open debate idea (last 3 days) wins today's slot.
        const { data: existing } = await supabaseAdmin
          .from("daily_debates").select("id").eq("debate_date", today).maybeSingle();
        if (!existing) {
          const since = new Date(Date.now() - 3 * 86400000).toISOString();
          const { data: ideas } = await supabaseAdmin
            .from("topic_suggestions")
            .select("id,title,body,author_name")
            .eq("kind", "debate").eq("status", "open").eq("hidden", false)
            .gte("created_at", since);
          if (ideas?.length) {
            const { data: counts } = await supabaseAdmin.rpc("topic_vote_counts");
            const cm = new Map((counts ?? []).map((c) => [c.suggestion_id, Number(c.total)]));
            const top = [...ideas].sort((a, b) => (cm.get(b.id) ?? 0) - (cm.get(a.id) ?? 0))[0]!;
            draft.question = top.title;
            draft.context = top.body || `Suggested and voted up by Sideline fans.`;
            draft.sideA = "Yes";
            draft.sideB = "No";
            draft.league = null;
            draft.source = "Fan Voice";
            draft.link = "/fan-voice";
            suggestedBy = top.author_name;
            pickedId = top.id;
          }
        }

        const { data: inserted, error } = await supabaseAdmin
          .from("daily_debates")
          .upsert(
            {
              debate_date: today,
              question: draft.question,
              context: draft.context,
              side_a: draft.sideA,
              side_b: draft.sideB,
              league: draft.league,
              source: draft.source,
              link: draft.link,
              suggested_by: suggestedBy,
            },
            { onConflict: "debate_date", ignoreDuplicates: true },
          )
          .select("question");
        if (pickedId && inserted?.length) {
          await supabaseAdmin.from("topic_suggestions").update({ status: "picked" }).eq("id", pickedId);
        }
        if (error) {
          console.error("daily debate cron failed", error);
          return new Response("failed", { status: 500 });
        }

        // Only nudge on the run that actually created today's debate.
        const { data: already } = await supabaseAdmin
          .from("newsletter_config")
          .select("value")
          .eq("key", "debate_nudge_date")
          .maybeSingle();
        if (already?.value === today) {
          return Response.json({ ok: true, date: today, nudged: 0 });
        }
        await supabaseAdmin
          .from("newsletter_config")
          .upsert({ key: "debate_nudge_date", value: today }, { onConflict: "key" });

        const question =
          inserted?.[0]?.question ??
          (
            await supabaseAdmin
              .from("daily_debates")
              .select("question")
              .eq("debate_date", today)
              .maybeSingle()
          ).data?.question ??
          draft.question;

        const { data: subs } = await supabaseAdmin
          .from("push_subscriptions")
          .select("endpoint, user_id");
        const userIds = [...new Set((subs ?? []).map((s) => s.user_id))];
        if (!userIds.length) return Response.json({ ok: true, date: today, nudged: 0 });

        const { data: prefs } = await supabaseAdmin
          .from("alert_preferences")
          .select("user_id, quiet_enabled, quiet_start, quiet_end, tz_offset")
          .in("user_id", userIds);
        const prefMap = new Map((prefs ?? []).map((p) => [p.user_id, p]));
        const now = new Date();
        const isQuiet = (uid: string) => {
          const p = prefMap.get(uid);
          if (!p?.quiet_enabled) return false;
          const local = (now.getUTCHours() * 60 + now.getUTCMinutes() + (p.tz_offset ?? 0)) / 60;
          const hour = ((Math.floor(local) % 24) + 24) % 24;
          const s = p.quiet_start;
          const e = p.quiet_end;
          return s === e ? true : s < e ? hour >= s && hour < e : hour >= s || hour < e;
        };
        const targets = userIds.filter((u) => !isQuiet(u));
        if (!targets.length) return Response.json({ ok: true, date: today, nudged: 0 });

        await supabaseAdmin.from("push_alerts").insert(
          targets.map((user_id) => ({
            user_id,
            title: "Today's debate is up",
            body: question,
            url: "/daily",
          })),
        );

        const wake = new Set(targets);
        const dead: string[] = [];
        let woken = 0;
        for (const sub of subs ?? []) {
          if (!wake.has(sub.user_id)) continue;
          if (await sendTickle(sub.endpoint)) woken += 1;
          else dead.push(sub.endpoint);
        }
        if (dead.length) {
          await supabaseAdmin.from("push_subscriptions").delete().in("endpoint", dead);
        }
        return Response.json({ ok: true, date: today, nudged: woken });
      },
    },
  },
});
