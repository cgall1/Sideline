import { createFileRoute } from "@tanstack/react-router";
import { sendTickle } from "@/lib/webpush.server";
import { SOCCER_COMPETITIONS } from "@/data/soccer";

/* eslint-disable @typescript-eslint/no-explicit-any */

const ESPN_PATH: Record<string, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

/** Individual sports: fans follow athletes, not clubs. */
const ATHLETE_PATH: Record<string, string> = {
  golf: "golf/pga",
  tennis: "tennis/atp",
  ufc: "mma/ufc",
  boxing: "boxing",
  nascar: "racing/nascar-premier",
  f1: "racing/f1",
};

interface LiveGame {
  id: string;
  league: string;
  home: string;
  away: string;
  homeScore: number;
  awayScore: number;
  status: "scheduled" | "live" | "final";
  venue: string;
}

/** Soccer clubs are followed under their competition slug, not a league id. */
function pathFor(league: string): string | undefined {
  if (ESPN_PATH[league]) return ESPN_PATH[league];
  if (ATHLETE_PATH[league]) return ATHLETE_PATH[league];
  const comp = SOCCER_COMPETITIONS.find(
    (c) => c.slug === league || c.slug.replace(/-highlights$/, "") === league,
  );
  return comp?.path;
}

/** Events in an individual sport, one row per competitor so a followed name matches. */
function athleteGames(league: string, events: any[]): LiveGame[] {
  return events.flatMap((event: any) => {
    const comp = event?.competitions?.[0];
    const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
    const state = comp?.status?.type?.state ?? event?.status?.type?.state;
    const completed =
      comp?.status?.type?.completed === true || event?.status?.type?.completed === true;
    const status: LiveGame["status"] = completed ? "final" : state === "in" ? "live" : "scheduled";
    const name = String(event?.name ?? "");
    return competitors.flatMap((c: any) => {
      const who = String(c?.athlete?.displayName ?? c?.team?.displayName ?? "");
      if (!who) return [];
      return [
        {
          id: `${league}-${String(event?.id ?? "")}`,
          league,
          home: who,
          away: name,
          homeScore: 0,
          awayScore: 0,
          status,
          venue: String(comp?.venue?.fullName ?? event?.venue?.fullName ?? ""),
        },
      ];
    });
  });
}

async function scoreboard(league: string): Promise<LiveGame[]> {
  const path = pathFor(league);
  if (!path) return [];
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?limit=100`,
    { headers: { accept: "application/json" } },
  ).catch(() => null);
  if (!res || !res.ok) return [];
  const payload: any = await res.json().catch(() => null);
  const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
  if (ATHLETE_PATH[league]) return athleteGames(league, events);
  return events.flatMap((event: any) => {
    const comp = event?.competitions?.[0];
    const teams: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
    const home = teams.find((t: any) => t?.homeAway === "home");
    const away = teams.find((t: any) => t?.homeAway === "away");
    if (!home || !away) return [];
    const state = comp?.status?.type?.state;
    const status: LiveGame["status"] =
      comp?.status?.type?.completed === true ? "final" : state === "in" ? "live" : "scheduled";
    return [
      {
        id: `${league}-${String(event?.id ?? "")}`,
        league,
        home: String(home?.team?.displayName ?? ""),
        away: String(away?.team?.displayName ?? ""),
        homeScore: Number(home?.score ?? 0),
        awayScore: Number(away?.score ?? 0),
        status,
        venue: String(comp?.venue?.fullName ?? ""),
      },
    ];
  });
}

/**
 * Runs on a schedule: looks at every fan's followed teams and queues a
 * notification when one of their games kicks off or goes final, then wakes
 * their subscribed devices so the alert arrives with Sideline closed.
 */
export const Route = createFileRoute("/api/public/cron/score-alerts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: config } = await supabaseAdmin
          .from("newsletter_config")
          .select("value")
          .eq("key", "alerts_cron_secret")
          .maybeSingle();
        const provided = request.headers.get("x-cron-secret");
        if (!config?.value || provided !== config.value) {
          return new Response("Unauthorized", { status: 401 });
        }

        const { data: follows } = await supabaseAdmin
          .from("followed_teams")
          .select("user_id, league, name")
          .limit(5000);
        if (!follows?.length) return Response.json({ ok: true, alerts: 0 });

        const leagues = [...new Set(follows.map((f) => f.league))];
        const boards = await Promise.all(leagues.map(scoreboard));
        const games = boards.flat();
        if (!games.length) return Response.json({ ok: true, alerts: 0 });

        const { data: prefRows } = await supabaseAdmin
          .from("alert_preferences")
          .select(
            "user_id, game_start, final_score, score_updates, quiet_enabled, quiet_start, quiet_end, tz_offset",
          )
          .in("user_id", [...new Set(follows.map((f) => f.user_id))]);
        const prefs = new Map((prefRows ?? []).map((p) => [p.user_id, p]));

        /** True when the fan asked for silence at their own local hour. */
        const isQuiet = (userId: string): boolean => {
          const p = prefs.get(userId);
          if (!p?.quiet_enabled) return false;
          const now = new Date();
          const local = (now.getUTCHours() * 60 + now.getUTCMinutes() + (p.tz_offset ?? 0)) / 60;
          const hour = ((Math.floor(local) % 24) + 24) % 24;
          const start = p.quiet_start ?? 22;
          const end = p.quiet_end ?? 8;
          return start === end ? true : start < end ? hour >= start && hour < end : hour >= start || hour < end;
        };
        const wants = (userId: string, kind: "start" | "final" | "score"): boolean => {
          const p = prefs.get(userId);
          if (!p) return kind !== "score"; // no saved settings: kickoff + final only
          if (kind === "start") return p.game_start !== false;
          if (kind === "final") return p.final_score !== false;
          return p.score_updates !== false;
        };

        const { data: stateRows } = await supabaseAdmin
          .from("game_alert_state")
          .select("game_id, user_id, status, score");
        const seen = new Map<string, { status: string; score: string }>();
        for (const r of stateRows ?? [])
          seen.set(`${r.user_id}:${r.game_id}`, { status: r.status, score: r.score ?? "" });

        const alerts: { user_id: string; title: string; body: string; url: string }[] = [];
        const states: { game_id: string; user_id: string; status: string; score: string }[] = [];
        const wake = new Set<string>();

        for (const follow of follows) {
          const team = follow.name.toLowerCase();
          for (const game of games) {
            if (game.league !== follow.league) continue;
            if (game.home.toLowerCase() !== team && game.away.toLowerCase() !== team) continue;

            const key = `${follow.user_id}:${game.id}`;
            const previous = seen.get(key);
            const score = `${game.awayScore}-${game.homeScore}`;
            const statusChanged = previous?.status !== game.status;
            const scoreChanged = !!previous && previous.score !== score;
            if (!statusChanged && !scoreChanged) continue;
            states.push({
              game_id: game.id,
              user_id: follow.user_id,
              status: game.status,
              score,
            });
            seen.set(key, { status: game.status, score });
            if (!previous) continue; // first sighting: record, don't announce
            if (isQuiet(follow.user_id)) continue;

            const soccerComp = !ESPN_PATH[game.league]
              ? SOCCER_COMPETITIONS.find(
                  (c) =>
                    c.slug === game.league ||
                    c.slug.replace(/-highlights$/, "") === game.league,
                )
              : undefined;
            const athleteSport = ATHLETE_PATH[game.league] ? game.league : "";
            const url = athleteSport
              ? `/${athleteSport}/scores`
              : soccerComp
              ? `/soccer-match/${soccerComp.slug.replace(/-highlights$/, "")}/${game.id.split("-").slice(1).join("-")}`
              : `/game/${game.league}/${game.id}`;
            if (statusChanged && game.status === "live" && wants(follow.user_id, "start")) {
              alerts.push({
                user_id: follow.user_id,
                title: athleteSport ? "Under way" : "Kickoff",
                body: athleteSport
                  ? `${game.home} is in action at ${game.away}.`
                  : `${game.away} at ${game.home} is under way${game.venue ? ` · ${game.venue}` : ""}. Tap to follow it live.`,
                url,
              });
              wake.add(follow.user_id);
            } else if (statusChanged && game.status === "final" && wants(follow.user_id, "final")) {
              alerts.push({
                user_id: follow.user_id,
                title: athleteSport ? "Result in" : "Final score",
                body: athleteSport
                  ? `${game.away} is final — see where ${game.home} finished.`
                  : `${game.away} ${game.awayScore} — ${game.home} ${game.homeScore}`,
                url,
              });
              wake.add(follow.user_id);
            } else if (
              scoreChanged &&
              !athleteSport &&
              game.status === "live" &&
              wants(follow.user_id, "score")
            ) {
              alerts.push({
                user_id: follow.user_id,
                title: "Score update",
                body: `${game.away} ${game.awayScore} — ${game.home} ${game.homeScore}. Tap for the match centre.`,
                url,
              });
              wake.add(follow.user_id);
            }
          }
        }

        if (states.length) {
          await supabaseAdmin
            .from("game_alert_state")
            .upsert(states, { onConflict: "game_id,user_id" });
        }
        if (alerts.length) await supabaseAdmin.from("push_alerts").insert(alerts);

        let woken = 0;
        if (wake.size) {
          const { data: subs } = await supabaseAdmin
            .from("push_subscriptions")
            .select("endpoint, user_id")
            .in("user_id", [...wake]);
          const dead: string[] = [];
          for (const sub of subs ?? []) {
            const alive = await sendTickle(sub.endpoint);
            if (alive) woken += 1;
            else dead.push(sub.endpoint);
          }
          if (dead.length) {
            await supabaseAdmin.from("push_subscriptions").delete().in("endpoint", dead);
          }
        }

        return Response.json({ ok: true, alerts: alerts.length, devices: woken });
      },
    },
  },
});
