import { createFileRoute } from "@tanstack/react-router";
import { authenticateCronRequest } from "@/integrations/supabase/cron-auth";

const FEEDS = [
  "football/nfl", "basketball/nba", "basketball/wnba", "hockey/nhl", "baseball/mlb",
  "soccer/usa.1", "soccer/eng.1", "soccer/esp.1", "football/college-football", "basketball/mens-college-basketball",
];

interface Headline { headline: string; description: string; link: string }

async function gatherHeadlines(): Promise<Headline[]> {
  const out: Headline[] = [];
  await Promise.all(
    FEEDS.map(async (f) => {
      try {
        const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${f}/news?limit=25`);
        if (!r.ok) return;
        const j = (await r.json()) as { articles?: { headline?: string; description?: string; links?: { web?: { href?: string } } }[] };
        for (const a of j.articles ?? []) {
          if (a.headline) out.push({ headline: a.headline, description: a.description ?? "", link: a.links?.web?.href ?? "" });
        }
      } catch { /* skip feed */ }
    }),
  );
  return out;
}

/** Monday job: the most-voted open deep-dive idea gets a sourced breakdown. */
export const Route = createFileRoute("/api/public/cron/deep-dive")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const provided = request.headers.get("x-cron-secret");
        if (provided) {
          const { data: config } = await supabaseAdmin
            .from("newsletter_config").select("value").eq("key", "alerts_cron_secret").maybeSingle();
          if (!config?.value || provided !== config.value) return new Response("Unauthorized", { status: 401 });
        } else {
          const unauthorized = await authenticateCronRequest(request);
          if (unauthorized) return unauthorized;
        }

        const now = new Date();
        const monday = new Date(now);
        monday.setUTCDate(now.getUTCDate() - ((now.getUTCDay() + 6) % 7));
        const week = monday.toISOString().slice(0, 10);
        const { data: done } = await supabaseAdmin.from("deep_dives").select("id").eq("week", week).maybeSingle();
        if (done) return Response.json({ ok: true, skipped: "already written" });

        const { data: ideas } = await supabaseAdmin
          .from("topic_suggestions").select("id,title,body,target")
          .eq("kind", "deep_dive").eq("status", "open").eq("hidden", false);
        if (!ideas?.length) return Response.json({ ok: true, skipped: "no ideas" });
        const { data: counts } = await supabaseAdmin.rpc("topic_vote_counts");
        const cm = new Map((counts ?? []).map((c) => [c.suggestion_id, Number(c.total)]));
        const top = [...ideas].sort((a, b) => (cm.get(b.id) ?? 0) - (cm.get(a.id) ?? 0))[0]!;

        const words = top.title.toLowerCase().split(/\W+/).filter((w) => w.length > 3);
        const all = await gatherHeadlines();
        const related = all
          .map((h) => ({ h, score: words.filter((w) => `${h.headline} ${h.description}`.toLowerCase().includes(w)).length }))
          .filter((x) => x.score > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, 8)
          .map((x) => x.h);

        const { data: talk } = await supabaseAdmin
          .from("space_posts").select("title").eq("hidden", false)
          .order("created_at", { ascending: false }).limit(200);
        const fanTalk = (talk ?? []).filter((p) => words.some((w) => p.title.toLowerCase().includes(w))).slice(0, 5);

        const facts = [
          ...related.map((h) => `NEWS: ${h.headline} — ${h.description}`),
          ...fanTalk.map((p) => `FAN POST: ${p.title}`),
        ];
        let body =
          `Fans voted for: ${top.title}.\n\n` +
          (related.length
            ? `What the latest reporting says:\n${related.map((h) => `• ${h.headline}${h.description ? ` — ${h.description}` : ""}`).join("\n")}`
            : "There isn't enough fresh reporting on this topic yet to say more without guessing, so we're keeping it to the facts.") +
          (fanTalk.length ? `\n\nWhat fans are saying:\n${fanTalk.map((p) => `• ${p.title}`).join("\n")}` : "");

        const key = process.env["LOVABLE_API_KEY"];
        if (key && facts.length) {
          try {
            const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
              method: "POST",
              headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
              body: JSON.stringify({
                model: "openai/gpt-6-astra",
                messages: [
                  { role: "system", content: "You write short sports breakdowns (250-400 words, plain text, short paragraphs). Use ONLY the facts provided. Never invent stats, quotes or results. If the facts are thin, say so." },
                  { role: "user", content: `Topic fans chose: ${top.title}\n${top.body}\n\nFacts:\n${facts.join("\n")}` },
                ],
              }),
            });
            if (r.ok) {
              const j = (await r.json()) as { choices?: { message?: { content?: string } }[] };
              const text = j.choices?.[0]?.message?.content?.trim();
              if (text) body = text;
            }
          } catch { /* template fallback */ }
        }

        const sources = [...related.map((h) => h.headline), ...(fanTalk.length ? ["Sideline fan posts"] : [])];
        const { error } = await supabaseAdmin.from("deep_dives").insert({
          suggestion_id: top.id, week, title: top.title, body, sources,
        });
        if (error) return new Response("failed", { status: 500 });
        await supabaseAdmin.from("topic_suggestions").update({ status: "picked" }).eq("id", top.id);
        return Response.json({ ok: true, week, topic: top.title });
      },
    },
  },
});
