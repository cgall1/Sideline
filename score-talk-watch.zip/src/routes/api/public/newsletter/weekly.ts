import { createFileRoute } from "@tanstack/react-router";
import { sendLovableEmail, EmailAPIError } from "@lovable.dev/email-js";
import {
  buildLeagueIssue,
  buildPickRecaps,
  ALL_LEAGUE_IDS,
  type LeagueIssue,
  type SubscriberRecap,
} from "@/lib/newsletter.server";
import { leagueById, type LeagueId } from "@/data/sports";

const SITE = "https://score-talk-watch.lovable.app";

function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Headline links come from an external feed, so only plain https links survive
 * into the email; anything else falls back to the Sideline site.
 */
function safeHref(url: string): string {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return SITE;
    return esc(parsed.toString());
  } catch {
    return SITE;
  }
}

function issueHtml(issue: LeagueIssue): string {
  const recapUrl = `${SITE}/recap/${issue.league}`;
  const list = (items: string[]) =>
    items.length
      ? `<ul style="margin:8px 0;padding-left:18px;">${items
          .map((i) => `<li style="margin:4px 0;">${esc(i)}</li>`)
          .join("")}</ul>`
      : `<p style="color:#666;">None this week.</p>`;
  const headlines = issue.headlines.length
    ? `<ul style="margin:8px 0;padding-left:18px;">${issue.headlines
        .map((h) => `<li style="margin:4px 0;"><a href="${safeHref(h.url)}">${esc(h.title)}</a></li>`)
        .join("")}</ul>`
    : `<p style="color:#666;">No headlines this week.</p>`;
  return `
    <h2 style="margin:28px 0 6px;font-size:18px;text-transform:uppercase;letter-spacing:1px;">${esc(issue.name)}</h2>
    <h3 style="margin:12px 0 2px;font-size:14px;">This week's results</h3>
    ${list(issue.results)}
    <h3 style="margin:12px 0 2px;font-size:14px;">Coming up</h3>
    ${list(issue.upcoming)}
    <h3 style="margin:12px 0 2px;font-size:14px;">Top stories</h3>
    ${headlines}
    <p><a href="${recapUrl}">Read the full ${esc(issue.name)} recap on Sideline →</a></p>
  `;
}

function issueText(issue: LeagueIssue): string {
  const lines = [
    issue.name.toUpperCase(),
    "",
    "This week's results:",
    ...(issue.results.length ? issue.results.map((r) => `- ${r}`) : ["- None this week."]),
    "",
    "Coming up:",
    ...(issue.upcoming.length ? issue.upcoming.map((r) => `- ${r}`) : ["- None this week."]),
    "",
    "Top stories:",
    ...(issue.headlines.length
      ? issue.headlines.map((h) => `- ${h.title} (${h.url})`)
      : ["- None this week."]),
    "",
    `Full recap: ${SITE}/recap/${issue.league}`,
  ];
  return lines.join("\n");
}

function recapHtml(recap: SubscriberRecap): string {
  const rows = recap.picks.length
    ? `<ul style="margin:8px 0;padding-left:18px;">${recap.picks
        .map(
          (p) =>
            `<li style="margin:4px 0;">${esc(p.gameLabel)} — you picked <strong>${esc(p.pick)}</strong> · ${
              p.correct ? "✅ correct" : "❌ missed"
            }</li>`,
        )
        .join("")}</ul>`
    : `<p style="color:#666;">No picks scored last week — <a href="${SITE}/predictions">get back on the board</a>.</p>`;
  const accuracy = recap.total ? Math.round((recap.correct / recap.total) * 100) : 0;
  return `
    <h2 style="margin:28px 0 6px;font-size:18px;text-transform:uppercase;letter-spacing:1px;">Your results</h2>
    ${
      recap.total
        ? `<p style="margin:4px 0;"><strong>${recap.correct} of ${recap.total} correct (${accuracy}%)</strong> · ${recap.current} in a row right now · best run ${recap.best}</p>`
        : ""
    }
    ${rows}
    <p><a href="${SITE}/leaderboard">See where you sit on the leaderboard →</a></p>
  `;
}

function recapText(recap: SubscriberRecap): string {
  const accuracy = recap.total ? Math.round((recap.correct / recap.total) * 100) : 0;
  return [
    "YOUR RESULTS",
    recap.total
      ? `${recap.correct} of ${recap.total} correct (${accuracy}%) · ${recap.current} in a row · best ${recap.best}`
      : "No picks scored last week.",
    ...recap.picks.map(
      (p) => `- ${p.gameLabel} — you picked ${p.pick} · ${p.correct ? "correct" : "missed"}`,
    ),
    "",
    `Leaderboard: ${SITE}/leaderboard`,
  ].join("\n");
}

function weekId(): string {
  const now = new Date();
  const start = new Date(Date.UTC(now.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((now.getTime() - start.getTime()) / 86_400_000 + 1) / 7);
  return `${now.getUTCFullYear()}-w${String(week).padStart(2, "0")}`;
}

export const Route = createFileRoute("/api/public/newsletter/weekly")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) {
          return Response.json({ error: "server_configuration_error" }, { status: 500 });
        }

        const senderDomain = process.env["SIDELINE_SENDER_DOMAIN"];
        if (!senderDomain) {
          return Response.json(
            {
              error: "sender_domain_not_configured",
              detail:
                "Set up a sender domain for this project, then set SIDELINE_SENDER_DOMAIN to the delegated subdomain (e.g. notify.example.com).",
            },
            { status: 503 },
          );
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        // Verify the caller against the secret stored in newsletter_config.
        const { data: configRow } = await supabaseAdmin
          .from("newsletter_config")
          .select("value")
          .eq("key", "cron_secret")
          .maybeSingle();
        const secret = request.headers.get("x-cron-secret");
        if (!configRow?.value || !secret || secret !== configRow.value) {
          return Response.json({ error: "unauthorized" }, { status: 401 });
        }

        const { data: subscribers, error } = await supabaseAdmin
          .from("newsletter_subscribers")
          .select("email, leagues");
        if (error) {
          return Response.json({ error: error.message }, { status: 500 });
        }
        if (!subscribers?.length) {
          return Response.json({ sent: 0, detail: "no subscribers" });
        }

        // Build each needed league's issue once.
        const needed = new Set<LeagueId>();
        for (const sub of subscribers) {
          const leagues = (sub.leagues?.length ? sub.leagues : ALL_LEAGUE_IDS) as LeagueId[];
          for (const id of leagues) if (leagueById(id)) needed.add(id);
        }
        const issues = new Map<LeagueId, LeagueIssue>();
        for (const id of needed) {
          issues.set(id, await buildLeagueIssue(id));
        }

        // How each subscriber's picks did last week.
        const recaps = await buildPickRecaps(subscribers.map((s) => s.email));

        const week = weekId();
        const subject = `Your Sideline weekly recap — ${new Date().toLocaleDateString("en-US", { month: "long", day: "numeric" })}`;

        let sent = 0;
        let failed = 0;
        let rateLimited = false;

        for (const sub of subscribers) {
          if (rateLimited) break;
          const leagues = (sub.leagues?.length ? sub.leagues : ALL_LEAGUE_IDS) as LeagueId[];
          const subIssues = leagues
            .map((id) => issues.get(id))
            .filter((i): i is LeagueIssue => i !== undefined);
          if (!subIssues.length) continue;
          const recap = recaps.get(sub.email);

          const html = `
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#111;">
              <h1 style="font-size:24px;text-transform:uppercase;letter-spacing:2px;">Sideline Weekly</h1>
              <p style="color:#555;">The week's results, the stories that mattered and the games coming up.</p>
              ${recap ? recapHtml(recap) : ""}
              ${subIssues.map(issueHtml).join("")}
              <hr style="margin:32px 0;border:none;border-top:1px solid #ddd;" />
              <p style="font-size:12px;color:#888;">
                You're getting this because you joined the Sideline newsletter.
                Pick scores and climb the leaderboard: <a href="${SITE}/predictions">${SITE}/predictions</a>
              </p>
            </div>`;
          const text = [
            "SIDELINE WEEKLY",
            "",
            ...(recap ? [recapText(recap), ""] : []),
            ...subIssues.flatMap((i) => [issueText(i), ""]),
            `You're getting this because you joined the Sideline newsletter.`,
          ].join("\n");

          try {
            await sendLovableEmail(
              {
                to: sub.email,
                from: `Sideline Weekly <newsletter@${senderDomain}>`,
                sender_domain: senderDomain,
                subject,
                html,
                text,
                purpose: "transactional",
                label: "weekly-newsletter",
                idempotency_key: `newsletter-${week}-${sub.email}`,
              },
              { apiKey },
            );
            sent += 1;
          } catch (err) {
            if (err instanceof EmailAPIError && err.status === 429) {
              rateLimited = true;
              break;
            }
            failed += 1;
          }
        }

        return Response.json({ week, sent, failed, rateLimited, subscribers: subscribers.length });
      },
    },
  },
});
