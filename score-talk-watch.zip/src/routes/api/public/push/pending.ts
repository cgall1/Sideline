import { createFileRoute } from "@tanstack/react-router";

/**
 * The service worker calls this after a push wakes it up. The device token is
 * a secret generated when the fan subscribed, so it only ever returns that
 * one fan's undelivered alerts.
 */
export const Route = createFileRoute("/api/public/push/pending")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const token = new URL(request.url).searchParams.get("token") ?? "";
        if (!/^[A-Za-z0-9_-]{20,100}$/.test(token)) {
          return new Response("Bad request", { status: 400 });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: sub } = await supabaseAdmin
          .from("push_subscriptions")
          .select("user_id")
          .eq("token", token)
          .maybeSingle();
        if (!sub) return new Response("Not found", { status: 404 });

        const { data: alerts } = await supabaseAdmin
          .from("push_alerts")
          .select("id, title, body, url")
          .eq("user_id", sub.user_id)
          .eq("delivered", false)
          .order("created_at", { ascending: true })
          .limit(10);

        const rows = alerts ?? [];
        if (rows.length) {
          await supabaseAdmin
            .from("push_alerts")
            .update({ delivered: true })
            .in(
              "id",
              rows.map((r) => r.id),
            );
        }

        return new Response(JSON.stringify({ alerts: rows }), {
          headers: { "content-type": "application/json", "cache-control": "no-store" },
        });
      },
    },
  },
});
