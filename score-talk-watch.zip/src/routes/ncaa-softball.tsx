import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/ncaa-softball`;
const TITLE =
  "NCAA Softball Scores, Standings & Schedule — College Softball Hub — Sideline";
const DESCRIPTION =
  "Live NCAA softball scores, national rankings and a month-by-month college softball schedule with first-pitch times, ballparks and TV — plus team rosters, news and match threads.";

const SEASON_MONTHS = [2, 3, 4, 5, 6];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/ncaa-softball")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("sball"));
    context.queryClient.ensureQueryData(standingsQueryOptions("sball"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("sball", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/college.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NCAA Softball Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "NCAA Softball Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NCAA softball hub is unavailable right now: {error.message}
    </div>
  ),
  component: SoftballPage,
});

function SoftballPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/ncaa-softball" });
  useTrackHubVisit("/ncaa-softball", "NCAA Softball Hub");

  return (
    <>
      <CollegeHub
        league="sball"
        month={month}
        heading="NCAA Softball Scores & Rankings"
        intro="Live college softball scores, the national rankings, and a month-by-month schedule with first-pitch times, ballparks and TV — with a match thread beside every game."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball live scores
        </Link>
        <Link to="/results" search={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball season results
        </Link>
        <Link to="/directory/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          Every NCAA softball team
        </Link>
        <Link to="/rosters/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball rosters
        </Link>
        <Link to="/news" search={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball news
        </Link>
        <Link to="/standings" search={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball standings
        </Link>
        <Link to="/team-stats/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball advanced team stats
        </Link>
        <Link to="/compare/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          Compare NCAA softball players
        </Link>
        <Link to="/leaders/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball stat leaders
        </Link>
        <Link to="/recap/$league" params={{ league: "sball" }} className="font-semibold text-primary underline">
          NCAA softball weekly recap
        </Link>
        <a href="/rss/sball.xml" className="font-semibold text-primary underline">
          NCAA softball news feed (RSS)
        </a>
        <Link to="/community" className="font-semibold text-primary underline">
          NCAA softball fan chat
        </Link>
      </div>
    </>
  );
}
