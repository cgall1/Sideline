import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { historyBySlug, SPORT_HISTORY } from "@/data/history";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/history/$slug")({
  staticData: { sitemap: true },
  loader: ({ params }) => {
    const sport = historyBySlug(params.slug);
    if (!sport) throw notFound();
    return { sport };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Unavailable — Sideline" }, { name: "robots", content: "noindex" }] };
    }
    const { sport } = loaderData;
    const title = `${sport.name} History — Origins, Greatest Moments & Dynasties — Sideline`;
    const description = `${sport.summary.slice(0, 150)}`;
    return pageHead({ path: `/history/${params.slug}`, title, description, type: "article" });
  },
  component: HistoryDetail,
});

function HistoryDetail() {
  const { sport } = Route.useLoaderData();
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <Link to="/history" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground">
        ← All sports history
      </Link>
      <h1 className="scoreboard mt-3 text-4xl font-bold uppercase tracking-wide">
        {sport.name} history
      </h1>
      <p className="mt-1 text-sm uppercase tracking-widest text-muted-foreground">{sport.origin}</p>
      <p className="mt-4 text-muted-foreground">{sport.summary}</p>

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Defining moments</h2>
        <ol className="mt-4 space-y-3">
          {sport.milestones.map((m) => (
            <li key={`${m.year}-${m.title}`} className="rounded-md border border-border bg-card p-4">
              <div className="flex items-baseline gap-3">
                <span className="scoreboard text-lg font-bold text-primary">{m.year}</span>
                <h3 className="font-semibold text-foreground">{m.title}</h3>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{m.detail}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-10 grid gap-6 md:grid-cols-2">
        <div>
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">All-time greats</h2>
          <ul className="mt-4 space-y-2">
            {sport.greats.map((g) => (
              <li key={g.name} className="rounded-md border border-border bg-card p-3">
                <p className="font-semibold text-foreground">{g.name}</p>
                <p className="text-sm text-muted-foreground">{g.note}</p>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Great dynasties</h2>
          <ul className="mt-4 space-y-2">
            {sport.dynasties.map((d) => (
              <li key={d.name} className="rounded-md border border-border bg-card p-3">
                <p className="font-semibold text-foreground">{d.name}</p>
                <p className="text-sm text-muted-foreground">{d.note}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">More history</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {SPORT_HISTORY.filter((s) => s.slug !== sport.slug).map((s) => (
            <Link
              key={s.slug}
              to="/history/$slug"
              params={{ slug: s.slug }}
              className="scoreboard rounded-sm border border-border px-3 py-1 text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
            >
              {s.name}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
