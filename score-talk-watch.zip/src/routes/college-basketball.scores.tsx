import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-basketball/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-basketball/scores",
      title: "College Basketball Scores — Live & Final — Sideline",
      description: "Live College Basketball scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("cbb"),
    }),
  component: () => <SportScoresSection league="cbb" />,
});
