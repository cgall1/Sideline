import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-baseball/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-baseball/scores",
      title: "College Baseball Scores — Live & Final — Sideline",
      description: "Live College Baseball scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("cbs"),
    }),
  component: () => <SportScoresSection league="cbs" />,
});
