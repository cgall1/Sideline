import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, leagueById } from "@/data/sports";
import { directoryOverviewQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/directory`;
const TITLE = "Sports Directory — Every League, Conference & Team — Sideline";
const DESCRIPTION =
  "Browse every league, conference, division and team we cover — NFL, NBA, NHL, MLB, MLS, college football and international soccer — with links to standings, scores and highlights.";

export const Route = createFileRoute("/directory/")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(directoryOverviewQueryOptions());
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Sports Directory",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          mainEntity: {
            "@type": "ItemList",
            itemListElement: LEAGUES.map((l, i) => ({
              "@type": "ListItem",
              position: i + 1,
              name: l.name,
              url: `${SITE}/directory/${l.id}`,
            })),
          },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              { "@type": "ListItem", position: 2, name: "Sports Directory", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The directory is unavailable right now: {error.message}
    </div>
  ),
  component: DirectoryIndex,
});

function DirectoryIndex() {
  const { data } = useSuspenseQuery(directoryOverviewQueryOptions());

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Sports Directory</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Every league, conference, division and team on Sideline — each one linked to its standings,
        scores and highlights.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <Link
          to="/calendar"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🗓 Season Schedule Calendar — dates, venues &amp; highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/directory/venues"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏟 Cities &amp; Stadiums — every venue
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Browse
          </span>
        </Link>
        <Link
          to="/results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📊 Season Results — wins, losses &amp; points
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/college-football"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏈 College Football — calendar, scores &amp; highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-basketball"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏀 College Basketball — scores, standings &amp; reels
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-basketball-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📊 College Basketball Results — wins, losses &amp; points
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-basketball-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 College Basketball Chat — live game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nfl"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏈 NFL — schedule, scores &amp; standings
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mlb"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚾ MLB — scores, standings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nba"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏀 NBA — scores, standings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nhl"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏒 NHL — scores, standings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mls"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚽ MLS — scores, table &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/world-soccer"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🌍 World soccer — scores, tables &amp; fixtures
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>

        <Link
          to="/nhl-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 NHL Chat — live hockey game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nfl-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 NFL Chat — live football game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nfl-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 NFL Rankings — records &amp; projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nba-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 NBA Rankings — records &amp; projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mls-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 MLS Rankings — records &amp; projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mls-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📋 MLS Results — wins, losses &amp; points
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/wnba"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏀 WNBA Hub — live scores, standings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nwsl"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚽ NWSL Hub — live scores, table &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/ncaa-softball"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🥎 NCAA Softball Hub — scores, rankings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/ncaa-volleyball"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏐 NCAA Volleyball Hub — scores, rankings &amp; schedule
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/team-stats"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📊 Advanced Team Stats — scoring, margin &amp; splits
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/compare"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚖️ Player Comparison — any two players, side by side
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/rosters"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            👥 Team Rosters — players, trades &amp; team chat
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/soccer-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 World Soccer Rankings — form &amp; projections
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/soccer-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📋 World Soccer Results — wins, losses &amp; points
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-football-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 College Football Chat — live game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-football-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 College Football Rankings — projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-football-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📋 College Football Results — wins &amp; losses
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-hockey-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 College Hockey Rankings — projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-hockey-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📋 College Hockey Results — wins &amp; losses
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/media/college-hockey-highlights"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🎬 College Hockey Highlights — NCAA clips
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mls-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 MLS Chat — live soccer match threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/soccer-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 Soccer Chat — world football match threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nhl-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 NHL Rankings — records &amp; projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nba-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 NBA Chat — live basketball game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link

          to="/mlb-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 MLB Chat — live baseball game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mlb-results"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📊 MLB Results — wins, losses &amp; streaks
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/mlb-rankings"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 MLB Rankings — records &amp; projected finish
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-hockey"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏒 College Hockey — scores, standings &amp; calendar
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/college-hockey-chat"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            💬 College Hockey Chat — live game threads
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/visitors"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📈 Visitors — which college hubs fans open most
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/standings-calculator"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🧮 Standings Calculator — rank your team
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Try it
          </span>
        </Link>
        <Link
          to="/tennis"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🎾 Tennis — ATP & WTA scores, draws, highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/ufc"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🥊 UFC & MMA — fight cards, results, highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/boxing"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🥊 Boxing — fights, headlines, highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/golf"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⛳ Golf — PGA Tour leaderboards and highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/nascar"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏁 NASCAR — race results, calendar, highlights
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/f1"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏎️ Formula 1 — standings, schedule, race results
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Open
          </span>
        </Link>
        <Link
          to="/history"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📜 Sports History — origins, greats, dynasties
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Browse
          </span>
        </Link>
        <Link
          to="/on-this-day"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🗓️ On This Day — historic moments from today
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/injuries"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏥 Injury Reports — every league's latest list
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/moves"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🔁 Trade &amp; Free Agency Tracker — every league
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/leaderboard"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏆 Predictions Leaderboard — top fans by record
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/alerts"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📬 Email Alerts — scores &amp; news for your teams
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Set up
          </span>
        </Link>
        <Link
          to="/premium"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⭐ Sideline Premium — ad-free &amp; advanced stats
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        <Link
          to="/odds"
          search={{ league: "nfl" as const }}
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            📊 Favorites &amp; Win Probabilities — every game
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            View
          </span>
        </Link>
        {[
          { to: "/must-watch" as const, label: "🔥 Must-Watch Games Today — every sport" },
          { to: "/power-rankings" as const, label: "📈 Power Rankings — every league by form" },
          { to: "/rivalries" as const, label: "⚔️ Greatest Rivalries — history & head-to-head" },
          { to: "/championships" as const, label: "🏆 Championship History — every league" },
          { to: "/hall-of-fame" as const, label: "🎖️ Hall of Fame — all-time greats" },
          { to: "/records" as const, label: "📜 Retired Numbers & Franchise Records" },
          { to: "/recaps" as const, label: "📝 Game Recaps — every final score written up" },
          { to: "/leaders" as const, label: "⭐ Stat Leaders — best players by position" },
          { to: "/brackets" as const, label: "🥇 Playoff Brackets — postseason picture" },
          { to: "/draft" as const, label: "🎓 Draft Coverage — prospects & mock drafts" },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
          >
            <span className="scoreboard text-lg font-bold uppercase tracking-wide">{item.label}</span>
            <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              View
            </span>
          </Link>
        ))}
      </div>

      <ul className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {LEAGUES.map((league) => {
          const stats = data.find((d) => d.league === league.id);
          return (
            <li key={league.id}>
              <Link
                to="/directory/$league"
                params={{ league: league.id }}
                className="flex h-full flex-col rounded-md border border-border bg-card p-5 transition-colors hover:border-primary/60"
              >
                <div className="flex items-center gap-2">
                  <LeagueBadge league={league.id} />
                  <span className="text-xs uppercase tracking-widest text-muted-foreground">
                    {league.sport}
                  </span>
                </div>
                <h2 className="scoreboard mt-3 text-2xl font-bold uppercase tracking-wide">
                  {league.name}
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  {stats?.teamCount ? `${stats.teamCount} teams` : "Teams"}
                  {stats?.groups.length ? ` · ${stats.groups.slice(0, 2).join(", ")}` : ""}
                </p>
                <span className="mt-auto pt-4 text-xs font-semibold uppercase tracking-widest text-primary">
                  Browse teams →
                </span>
              </Link>
            </li>
          );
        })}
      </ul>

      <div className="mt-8 flex flex-wrap gap-3 text-sm">
        <Link to="/standings" className="font-semibold text-primary underline">
          League standings
        </Link>
        <Link to="/scores" className="font-semibold text-primary underline">
          Live scores
        </Link>
        <Link to="/highlights" className="font-semibold text-primary underline">
          Daily highlights
        </Link>
      </div>

      <p className="mt-6 text-xs text-muted-foreground">
        Covering {LEAGUES.map((l) => leagueById(l.id)?.short).join(" · ")}.
      </p>
    </div>
  );
}
