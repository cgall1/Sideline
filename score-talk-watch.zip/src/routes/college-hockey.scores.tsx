import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-hockey/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-hockey/scores",
      title: "College Hockey Scores — Live & Final — Sideline",
      description: "Live College Hockey scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("chk"),
    }),
  component: () => <SportScoresSection league="chk" />,
});
