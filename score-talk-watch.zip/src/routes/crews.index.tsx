import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { displayNameOf, useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/crews/")({
  head: () => ({
    meta: [
      { title: "Your Crews — Private Fan Groups — Sideline" },
      { name: "description", content: "Start a private group for your fantasy league, fan club or family rivalry and invite your crew with one link." },
      { property: "og:title", content: "Your Crews — Sideline" },
      { property: "og:description", content: "Private fan groups with an invite link and a group chat." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CrewsPage,
});

function CrewsPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const { data: crews = [] } = useQuery({
    queryKey: ["my-crews", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("crews").select("id, name, created_at").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function create(e: React.FormEvent) {
    e.preventDefault();
    if (!user || name.trim().length < 2) return;
    setBusy(true);
    setErr("");
    const { data, error } = await supabase.from("crews").insert({ name: name.trim(), owner_id: user.id }).select("id").single();
    if (error || !data) {
      setBusy(false);
      return setErr("Couldn't create the crew. Try again.");
    }
    await supabase.from("crew_members").insert({ crew_id: data.id, user_id: user.id, display_name: displayNameOf(user) });
    navigate({ to: "/crews/$crewId", params: { crewId: data.id } });
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">Your crews</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        A private corner for your fantasy league, fan club or family rivalry. Start one, share the link, talk sport.
      </p>

      {!loading && !user && (
        <p className="mt-6 text-sm">
          <Link to="/auth" search={{ next: "/crews" }} className="font-semibold text-primary underline">Sign in</Link> to start or join a crew.
        </p>
      )}

      {user && (
        <>
          <form onSubmit={create} className="mt-6 flex flex-col gap-2 sm:flex-row">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={60}
              placeholder="Crew name, e.g. Sunday League Legends"
              className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm"
            />
            <button disabled={busy || name.trim().length < 2} className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50">
              Start a crew
            </button>
          </form>
          {err && <p className="mt-2 text-sm text-destructive">{err}</p>}

          <div className="mt-8 space-y-2">
            {crews.length === 0 && <p className="text-sm text-muted-foreground">You're not in any crews yet.</p>}
            {crews.map((c) => (
              <Link key={c.id} to="/crews/$crewId" params={{ crewId: c.id }} className="block rounded-lg border border-border p-3 font-semibold hover:border-primary">
                {c.name}
              </Link>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
