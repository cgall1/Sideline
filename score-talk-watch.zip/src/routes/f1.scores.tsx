import { createFileRoute } from "@tanstack/react-router";
import { IndividualScoresSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/f1/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/f1/scores",
      title: "Formula 1 Races — Live Results & Schedule — Sideline",
      description: "Live Formula 1 results and the full schedule of upcoming races with dates, venues and finishing positions.",
    }),
  component: () => <IndividualScoresSection sport="f1" />,
});
