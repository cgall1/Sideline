import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, type LeagueId } from "@/data/sports";
import { dayScheduleQueryOptions, newsQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";

const SITE = "https://score-talk-watch.lovable.app";
const LEAGUE_IDS = LEAGUES.map((l) => l.id) as string[];

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function longDate(day: string): string {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${day}T12:00:00Z`));
}

function shiftDay(day: string, delta: number): string {
  return new Date(new Date(`${day}T12:00:00Z`).getTime() + delta * 86_400_000)
    .toISOString()
    .slice(0, 10);
}

function pageUrl(league: string, date: string): string {
  return `${SITE}/news/${league}/${date}`;
}

export const Route = createFileRoute("/news/$league/$date")({
  staticData: { sitemap: true },
  beforeLoad: ({ params }) => {
    if (!LEAGUE_IDS.includes(params.league) || !/^\d{4}-\d{2}-\d{2}$/.test(params.date)) {
      throw notFound();
    }
  },
  loader: ({ context, params }) => {
    const league = params.league as LeagueId;
    context.queryClient.ensureQueryData(dayScheduleQueryOptions(league, params.date));
    context.queryClient.ensureQueryData(newsQueryOptions(league));
  },
  head: ({ params }) => {
    const league = LEAGUES.find((l) => l.id === params.league);
    if (!league || !/^\d{4}-\d{2}-\d{2}$/.test(params.date)) {
      return { meta: [{ title: "Not found" }, { name: "robots", content: "noindex" }] };
    }
    const url = pageUrl(params.league, params.date);
    const title = `${league.name} News & Scores — ${longDate(params.date)} — Sideline`;
    const description = `${league.name} news, results and schedule for ${longDate(
      params.date,
    )}: every game, final score, start time and the day's headlines in one page.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { property: "og:url", content: url },
        { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
        { property: "og:image:width", content: "1200" },
        { property: "og:image:height", content: "630" },
        { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
        { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
        { name: "twitter:card", content: "summary_large_image" },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: description },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: title,
            url,
            description,
            isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
            breadcrumb: {
              "@type": "BreadcrumbList",
              itemListElement: [
                { "@type": "ListItem", position: 1, name: "Home", item: SITE },
                { "@type": "ListItem", position: 2, name: "Sports News", item: `${SITE}/news` },
                { "@type": "ListItem", position: 3, name: `${league.name} — ${params.date}`, item: url },
              ],
            },
          }),
        },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-7xl px-4 py-16">
      <h1 className="scoreboard text-3xl font-bold uppercase">Page not found</h1>
      <Link to="/news" className="mt-4 inline-block font-semibold text-primary underline">
        Back to sports news
      </Link>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      This day is unavailable right now: {error.message}
    </div>
  ),
  component: DailyLeagueNews,
});

function DailyLeagueNews() {
  const { league: leagueParam, date } = Route.useParams();
  const league = leagueParam as LeagueId;
  const leagueMeta = LEAGUES.find((l) => l.id === league);
  const { data: schedule } = useSuspenseQuery(dayScheduleQueryOptions(league, date));
  const { data: news } = useSuspenseQuery(newsQueryOptions(league));

  const dayItems = news.items.filter((item) => item.published.slice(0, 10) === date);
  const items = dayItems.length > 0 ? dayItems : news.items.slice(0, 6);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex items-center gap-2">
        <LeagueBadge league={league} />
        <span className="text-xs uppercase tracking-widest text-muted-foreground">
          {longDate(date)}
        </span>
      </div>
      <h1 className="scoreboard mt-2 text-4xl font-bold uppercase tracking-wide">
        {leagueMeta?.name} News &amp; Scores — {longDate(date)}
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Everything that happened in the {leagueMeta?.name} on this date: results, start times,
        stadiums and the headlines that followed.
      </p>

      <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-widest">
        <Link
          to="/news/$league/$date"
          params={{ league, date: shiftDay(date, -1) }}
          className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
        >
          ← {shiftDay(date, -1)}
        </Link>
        <Link
          to="/news/$league/$date"
          params={{ league, date: shiftDay(date, 1) }}
          className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
        >
          {shiftDay(date, 1)} →
        </Link>
        {LEAGUES.filter((l) => l.id !== league).map((l) => (
          <Link
            key={l.id}
            to="/news/$league/$date"
            params={{ league: l.id, date }}
            className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
          >
            {l.short}
          </Link>
        ))}
      </div>

      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Games</h2>
        {schedule.games.length === 0 ? (
          <p className="mt-3 rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">
            No {leagueMeta?.short} games on this date.
          </p>
        ) : (
          <ul className="mt-3 grid gap-3 lg:grid-cols-2">
            {schedule.games.map((game) => (
              <li key={game.id} className="rounded-md border border-border bg-card p-4">
                <p className="scoreboard text-lg font-bold uppercase tracking-wide">
                  {game.away} at {game.home}
                  {game.homeScore !== null && (
                    <span className="ml-2 text-primary">
                      {game.awayScore}–{game.homeScore}
                    </span>
                  )}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {game.statusLabel} · {game.venue}
                  {game.city ? ` · ${game.city}` : ""}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Headlines</h2>
        <ul className="mt-3 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <li key={item.id}>
              <a
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-full flex-col overflow-hidden rounded-md border border-border bg-card transition-colors hover:border-primary/60"
              >
                {item.image && (
                  <img
                    src={item.image}
                    alt={item.headline}
                    loading="lazy"
                    className="h-40 w-full object-cover"
                  />
                )}
                <div className="p-4">
                  <h3 className="text-base font-bold leading-snug">{item.headline}</h3>
                  {item.summary && (
                    <p className="mt-1.5 line-clamp-3 text-sm text-muted-foreground">
                      {item.summary}
                    </p>
                  )}
                </div>
              </a>
            </li>
          ))}
        </ul>
      </section>

      <div className="mt-10 flex flex-wrap gap-3 text-sm">
        <Link to="/news" className="font-semibold text-primary underline">
          All sports news
        </Link>
        <Link to="/calendar" search={{ league }} className="font-semibold text-primary underline">
          {leagueMeta?.short} season calendar
        </Link>
        <Link to="/standings" search={{ league }} className="font-semibold text-primary underline">
          Standings
        </Link>
      </div>
    </div>
  );
}
