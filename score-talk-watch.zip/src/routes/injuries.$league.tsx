import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import { leagueInjuriesQueryOptions } from "@/lib/feed";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/injuries/$league")({
  staticData: { sitemap: true },
  loader: ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    context.queryClient.ensureQueryData(leagueInjuriesQueryOptions(league.id as LeagueId));
    return { leagueName: league.name };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Unavailable — Sideline" }, { name: "robots", content: "noindex" }] };
    }
    const name = loaderData.leagueName;
    return pageHead({
      path: `/injuries/${params.league}`,
      title: `${name} Injury Report — Who's Out, Questionable and Back — Sideline`,
      description: `The current ${name} injury report: every listed player, their position, status and the latest update, refreshed through the day.`,
    });
  },
  component: LeagueInjuries,
});

function LeagueInjuries() {
  const { league } = Route.useParams();
  const { leagueName } = Route.useLoaderData();
  const { data: entries = [], isLoading } = useQuery(leagueInjuriesQueryOptions(league as LeagueId));

  const byTeam = new Map<string, typeof entries>();
  for (const entry of entries) {
    const list = byTeam.get(entry.team) ?? [];
    list.push(entry);
    byTeam.set(entry.team, list);
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link to="/injuries" className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground">
        ← All injury reports
      </Link>
      <h1 className="scoreboard mt-3 text-4xl font-bold uppercase tracking-wide">
        {leagueName} injury report
      </h1>
      <p className="mt-2 text-muted-foreground">
        Every listed {leagueName} injury by team, with status and the latest update.
      </p>

      {isLoading && <p className="mt-6 text-sm text-muted-foreground">Loading the latest report…</p>}
      {!isLoading && entries.length === 0 && (
        <p className="mt-6 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No injuries listed right now — this fills in as teams file their reports.
        </p>
      )}

      <div className="mt-6 space-y-5">
        {[...byTeam.entries()].map(([team, list]) => (
          <section key={team} className="rounded-md border border-border bg-card p-4">
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{team}</h2>
            <ul className="mt-3 space-y-2">
              {list.map((entry, i) => (
                <li key={`${entry.player}-${i}`} className="border-t border-border pt-2 text-sm first:border-0 first:pt-0">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-semibold text-foreground">
                      {entry.playerId ? (
                        <Link
                          to="/players/$league/$playerId"
                          params={{ league, playerId: entry.playerId }}
                          className="hover:text-primary"
                        >
                          {entry.player}
                        </Link>
                      ) : (
                        entry.player
                      )}
                      {entry.position ? ` · ${entry.position}` : ""}
                    </span>
                    <span className="scoreboard text-xs uppercase tracking-widest text-[color:var(--live)]">
                      {entry.status}
                    </span>
                  </div>
                  {entry.detail && <p className="mt-1 text-muted-foreground">{entry.detail}</p>}
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </div>
  );
}
