import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/nfl`;
const TITLE = "NFL Schedule, Scores & Standings — Football Hub — Sideline";
const DESCRIPTION =
  "The full NFL schedule week by week with kickoff times, stadiums and TV, plus live football scores, conference standings and a highlight reel for every game.";

const SEASON_MONTHS = [9, 10, 11, 12, 1, 2];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/nfl/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("nfl"));
    context.queryClient.ensureQueryData(standingsQueryOptions("nfl"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("nfl", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: `${SITE}/og/nfl.jpg` },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      {
        property: "og:image:alt",
        content: "Sideline — live sports scores, standings, highlights and fan chat",
      },
      { name: "twitter:image", content: `${SITE}/og/nfl.jpg` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "NFL Schedule & Scores Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "NFL Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The NFL hub is unavailable right now: {error.message}
    </div>
  ),
  component: NflPage,
});

function NflPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/nfl/" });
  useTrackHubVisit("/nfl", "NFL Hub");

  return (
    <>
      <CollegeHub
        league="nfl"
        month={month}
        heading="NFL Schedule, Scores & Standings"
        intro="The complete NFL schedule month by month with kickoff times, stadiums and TV listings, live scores as they happen, AFC and NFC standings, and a highlight reel beside every matchup."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "nfl" }} className="font-semibold text-primary underline">
          NFL live scores
        </Link>
        <Link to="/results" search={{ league: "nfl" }} className="font-semibold text-primary underline">
          NFL season results
        </Link>
        <Link to="/media/nfl-highlights" className="font-semibold text-primary underline">
          NFL highlights
        </Link>
        <Link to="/directory/$league" params={{ league: "nfl" }} className="font-semibold text-primary underline">
          Every NFL team
        </Link>
        <Link to="/nfl-chat" className="font-semibold text-primary underline">
          NFL fan chat
        </Link>
        <Link to="/nfl-rankings" className="font-semibold text-primary underline">
          NFL rankings
        </Link>
        <Link to="/nfl-trivia" className="font-semibold text-primary underline">
          NFL trivia
        </Link>
      </div>
    </>
  );
}
