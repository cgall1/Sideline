import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/college-baseball")({
  component: CBSSection,
});

function CBSSection() {
  return (
    <>
      <nav
        aria-label="College Baseball sections"
        className="border-b border-border bg-card/60 backdrop-blur"
      >
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-5 px-4">
          <span className="scoreboard py-3 text-sm font-bold uppercase tracking-wide text-foreground">
            College Baseball
          </span>
        <Link
          to="/college-baseball"
          activeOptions={{ exact: true }}
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Home
        </Link>
        <Link
          to="/college-baseball/news"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          News
        </Link>
        <Link
          to="/college-baseball/scores"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Scores
        </Link>
        <Link
          to="/college-baseball/standings"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Standings
        </Link>
        <Link
          to="/college-baseball/schedule"
          activeProps={{ className: "border-primary text-primary" }}
          className="scoreboard border-b-2 border-transparent px-1 py-3 text-xs font-bold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
        >
          Schedule
        </Link>
        </div>
      </nav>
      <Outlet />
    </>
  );
}
