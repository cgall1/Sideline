import { createFileRoute, Link } from "@tanstack/react-router";
import { SPORT_HISTORY } from "@/data/history";
import { pageHead } from "@/lib/seo";

const TITLE = "Sports History — Every League, Team and Era Explained — Sideline";
const DESCRIPTION =
  "Dive into the history of the NFL, NBA, NHL, MLB, soccer, tennis, UFC, golf, NASCAR and college sports — origins, defining moments, all-time greats and the great dynasties.";

export const Route = createFileRoute("/history/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/history", title: TITLE, description: DESCRIPTION }),
  component: HistoryIndex,
});

function HistoryIndex() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Sports history</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        How each sport began, the moments that changed it, the players who defined it and the teams
        that ruled it.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {[
          { to: "/on-this-day" as const, label: "On this day in sports" },
          { to: "/rivalries" as const, label: "Rivalries" },
          { to: "/championships" as const, label: "Championship history" },
          { to: "/hall-of-fame" as const, label: "Hall of fame" },
          { to: "/records" as const, label: "Retired numbers & records" },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="scoreboard inline-block rounded-sm border border-border px-3 py-1 text-sm uppercase tracking-widest text-muted-foreground hover:text-foreground"
          >
            {item.label}
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {SPORT_HISTORY.map((sport) => (
          <Link
            key={sport.slug}
            to="/history/$slug"
            params={{ slug: sport.slug }}
            className="rounded-md border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{sport.name}</h2>
            <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{sport.origin}</p>
            <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{sport.summary}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
