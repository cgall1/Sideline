import { createFileRoute } from "@tanstack/react-router";
import { SportHub } from "@/components/SportHub";
import { sportById } from "@/lib/individual-sports.functions";
import { pageHead } from "@/lib/seo";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";

const TITLE = 'NASCAR Race Results, Schedule & Highlights — Cup Series Hub — Sideline';
const DESCRIPTION = 'Live NASCAR Cup Series race results and the full race calendar, official race highlights, driver news, trivia and race-day fan chat.';

export const Route = createFileRoute("/nascar/")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(sportEventsQueryOptions("nascar"));
    context.queryClient.ensureQueryData(sportNewsQueryOptions("nascar"));
  },
  head: () => pageHead({ path: "/nascar", title: TITLE, description: DESCRIPTION }),
  component: NascarPage,
});

function NascarPage() {
  const sport = sportById("nascar")!;
  return <SportHub sport={sport} />;
}
