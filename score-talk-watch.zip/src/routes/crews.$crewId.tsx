import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { displayNameOf, useAuth } from "@/hooks/useAuth";
import { relativeTime } from "@/lib/spaces";
import { WatchParties } from "@/components/WatchParties";
import { TopVoiceBadge, useTopVoices } from "@/components/TopVoiceBadge";

export const Route = createFileRoute("/crews/$crewId")({
  head: () => ({
    meta: [
      { title: "Crew Chat — Sideline" },
      { name: "description", content: "Your private Sideline crew: members, invite link and group chat." },
      { property: "og:title", content: "Crew Chat — Sideline" },
      { property: "og:description", content: "A private fan group on Sideline." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: CrewPage,
});

function CrewPage() {
  const { crewId } = Route.useParams();
  const { user, loading } = useAuth();
  const qc = useQueryClient();
  const topVoices = useTopVoices();
  const [body, setBody] = useState("");
  const [copied, setCopied] = useState(false);

  const { data: crew, isLoading } = useQuery({
    queryKey: ["crew", crewId, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [c, m] = await Promise.all([
        supabase.from("crews").select("id, name, invite_code, owner_id").eq("id", crewId).maybeSingle(),
        supabase.from("crew_members").select("user_id, display_name").eq("crew_id", crewId),
      ]);
      return c.data ? { ...c.data, members: m.data ?? [] } : null;
    },
  });

  const { data: msgs = [] } = useQuery({
    queryKey: ["crew-msgs", crewId],
    enabled: !!crew,
    queryFn: async () => {
      const { data } = await supabase
        .from("crew_messages")
        .select("id, author_name, body, created_at, user_id")
        .eq("crew_id", crewId)
        .order("created_at", { ascending: false })
        .limit(100);
      return (data ?? []).reverse();
    },
  });

  useEffect(() => {
    if (!crew) return;
    const ch = supabase
      .channel(`crew-${crewId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "crew_messages", filter: `crew_id=eq.${crewId}` }, () =>
        qc.invalidateQueries({ queryKey: ["crew-msgs", crewId] }),
      )
      .subscribe();
    const t = setInterval(() => qc.invalidateQueries({ queryKey: ["crew-msgs", crewId] }), 20000);
    return () => {
      clearInterval(t);
      supabase.removeChannel(ch);
    };
  }, [crew, crewId, qc]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const text = body.trim();
    if (!user || !text) return;
    setBody("");
    await supabase.from("crew_messages").insert({ crew_id: crewId, user_id: user.id, author_name: displayNameOf(user), body: text.slice(0, 1000) });
    qc.invalidateQueries({ queryKey: ["crew-msgs", crewId] });
  }

  if (!loading && !user)
    return (
      <div className="mx-auto max-w-3xl px-4 py-10 text-sm">
        <Link to="/auth" search={{ next: `/crews/${crewId}` }} className="font-semibold text-primary underline">Sign in</Link> to see this crew.
      </div>
    );
  if (isLoading || loading) return <div className="mx-auto max-w-3xl px-4 py-10 text-sm text-muted-foreground">Loading…</div>;
  if (!crew)
    return (
      <div className="mx-auto max-w-3xl px-4 py-10 text-sm">
        This crew is private. Ask a member for their invite link. <Link to="/crews" className="text-primary underline">Your crews</Link>
      </div>
    );

  const link = `${typeof window !== "undefined" ? window.location.origin : "https://score-talk-watch.lovable.app"}/join/${crew.invite_code}?from=${user?.id ?? ""}`;

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <Link to="/crews" className="text-xs font-semibold uppercase tracking-widest text-primary underline">Your crews</Link>
      <h1 className="scoreboard mt-2 text-3xl font-bold uppercase tracking-wide">{crew.name}</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {crew.members.length} {crew.members.length === 1 ? "member" : "members"}: {crew.members.map((m) => m.display_name).join(", ")}
      </p>

      <div className="mt-4 flex flex-col gap-2 rounded-lg border border-border bg-card p-3 sm:flex-row sm:items-center">
        <span className="text-sm font-semibold">Invite your crew</span>
        <code className="flex-1 truncate rounded bg-muted px-2 py-1 text-xs">{link}</code>
        <button
          type="button"
          onClick={async () => {
            if (navigator.share) {
              try { await navigator.share({ title: `Join ${crew.name} on Sideline`, url: link }); return; } catch { /* fall back to copy */ }
            }
            await navigator.clipboard.writeText(link);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
          }}
          className="rounded-md bg-primary px-3 py-1.5 text-xs font-bold text-primary-foreground"
        >
          {copied ? "Copied" : "Share link"}
        </button>
      </div>

      {user && <WatchParties crewId={crewId} user={user} />}

      <div className="mt-6 space-y-3 rounded-lg border border-border p-4">
        {msgs.length === 0 && <p className="text-sm text-muted-foreground">No messages yet. Kick things off.</p>}
        {msgs.map((m) => (
          <div key={m.id} className="text-sm">
            <span className="font-semibold">{m.author_name}</span>
            <TopVoiceBadge userId={m.user_id} voices={topVoices} />
            <span className="ml-2 text-xs text-muted-foreground">{relativeTime(m.created_at)}</span>
            <p className="whitespace-pre-wrap">{m.body}</p>
          </div>
        ))}
        <form onSubmit={send} className="flex gap-2 border-t border-border pt-3">
          <input value={body} onChange={(e) => setBody(e.target.value)} maxLength={1000} placeholder="Say something to the crew…" className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm" />
          <button disabled={!body.trim()} className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50">Send</button>
        </form>
      </div>
    </div>
  );
}
