import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES } from "@/data/sports";
import { articlesQueryOptions, gamesQueryOptions } from "@/lib/feed";
import { ForYou } from "@/components/ForYou";
import { Onboarding } from "@/components/Onboarding";
import { WhatYouMissed } from "@/components/WhatYouMissed";
import { ScoreCard } from "@/components/ScoreCard";
import { RivalryWeek } from "@/components/RivalryWeek";
import { LeagueBadge } from "@/components/LeagueFilter";
import editorialHero from "@/assets/sideline-editorial-hero.jpg";

export const Route = createFileRoute("/")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: "Sideline — Live Scores, News & Fan Community" },
      {
        name: "description",
        content:
          "Follow live scores, standings, highlights and fan reaction across the NFL, NBA, NHL, MLB, MLS and international soccer.",
      },
      { property: "og:title", content: "Sideline — Live Scores, News & Fan Community" },
      {
        property: "og:description",
        content:
          "Live scores, stats, schedules, video highlights and game threads for every major league.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://score-talk-watch.lovable.app/" },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "https://score-talk-watch.lovable.app/" }],
  }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("all"));
    context.queryClient.ensureQueryData(articlesQueryOptions());
  },
  component: Home,
});

function Home() {
  const {
    data: games,
    refetch,
    isFetching,
    dataUpdatedAt,
  } = useSuspenseQuery(gamesQueryOptions("all"));
  const [stamp, setStamp] = useState("");
  useEffect(() => {
    setStamp(new Date(dataUpdatedAt).toLocaleTimeString());
  }, [dataUpdatedAt]);
  const { data: articles } = useSuspenseQuery(articlesQueryOptions());

  const live = games.filter((g) => g.status === "live");
  const upcoming = games.filter((g) => g.status === "scheduled").slice(0, 4);
  const lead = articles.find((article) => article.league === "nba") ?? articles[0] ?? ARTICLES[0];
  const rest = articles.filter((article) => article.slug !== lead?.slug).slice(0, 5);

  if (!lead) return null;

  return (
    <div>
      <Onboarding />
      <section className="border-b border-foreground bg-foreground text-background">
        <div className="mx-auto flex max-w-7xl items-stretch overflow-x-auto px-4">
          <div className="sticky left-0 z-10 flex shrink-0 items-center border-r border-background/20 bg-foreground pr-5">
            <span className="live-dot scoreboard text-[11px] font-bold uppercase text-primary">Live desk</span>
          </div>
          {(live.length > 0 ? live : upcoming).slice(0, 5).map((game) => (
            <Link
              key={game.id}
              to="/game/$league/$gameId"
              params={{ league: game.league, gameId: game.id }}
              className="min-w-56 border-r border-background/20 px-5 py-3 transition-colors hover:bg-background/10"
            >
              <div className="mb-1 flex items-center justify-between text-[10px] font-bold uppercase opacity-55">
                <span>{game.league}</span><span>{game.status === "live" ? game.clock : game.startLabel}</span>
              </div>
              <div className="flex items-center justify-between text-sm font-bold"><span>{game.away.abbr}</span><span>{game.status === "scheduled" ? "–" : game.awayScore}</span></div>
              <div className="flex items-center justify-between text-sm font-bold"><span>{game.home.abbr}</span><span>{game.status === "scheduled" ? "–" : game.homeScore}</span></div>
            </Link>
          ))}
          <div className="flex shrink-0 items-center gap-4 px-6">
            <button
              type="button"
              onClick={() => void refetch()}
              disabled={isFetching}
              className="text-[11px] font-bold uppercase text-background/70 transition-colors hover:text-primary disabled:opacity-50"
            >
              {isFetching ? "Updating…" : "Refresh"}
            </button>
            {stamp ? (
              <span className="text-[10px] font-bold uppercase text-background/50">
                Updated {stamp}
              </span>
            ) : null}
            <Link to="/scores" className="text-[11px] font-bold uppercase text-primary hover:underline">
              All scores →
            </Link>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4">
        <div className="mt-2 grid items-stretch gap-2 sm:grid-cols-2">
          <WhatYouMissed />
          <ForYou />
        </div>
        <RivalryWeek games={games} />

        <section className="grid border-x border-border lg:grid-cols-[minmax(0,1.65fr)_minmax(20rem,0.75fr)]">
          <div className="border-b border-border p-5 sm:p-8 lg:border-r lg:p-10">
            <div className="mb-8 flex items-end justify-between gap-6 border-b border-foreground pb-4">
              <div>
                <p className="mb-2 text-[11px] font-bold uppercase text-primary">Independent sports intelligence</p>
                <h1 className="scoreboard text-4xl font-bold uppercase leading-none sm:text-6xl">The Daily<br />Sideline</h1>
              </div>
              <p className="max-w-48 text-right text-xs leading-relaxed text-muted-foreground">
                Scores, stories and fan reaction—updated as the game changes.
              </p>
            </div>
            <Link to="/media/$slug" params={{ slug: lead.slug }} className="group block">
              <div className="relative aspect-[16/9] overflow-hidden bg-surface">
                <img
                  src={editorialHero}
                  alt="Basketball player rising toward the rim under arena lights"
                  width={1600}
                  height={900}
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.02]"
                />
                <span className="absolute bottom-0 left-0 bg-primary px-3 py-2 text-[10px] font-bold uppercase text-primary-foreground">Featured story</span>
              </div>
              <div className="pt-7">
                <div className="mb-4 flex items-center gap-3"><LeagueBadge league={lead.league} /><span className="text-[10px] font-bold uppercase text-muted-foreground">{lead.kind}</span></div>
                <h2 className="max-w-4xl text-4xl font-bold leading-[0.98] sm:text-6xl">{lead.title}</h2>
                <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">{lead.dek}</p>
                <p className="mt-6 text-[11px] font-bold uppercase text-muted-foreground">{lead.author} · {lead.published} · {lead.duration ?? lead.readTime}</p>
              </div>
            </Link>
          </div>

          <aside className="flex flex-col">
            <div className="flex items-center justify-between border-b border-foreground px-5 py-4 sm:px-8">
              <h2 className="scoreboard text-sm font-bold uppercase">The bulletin</h2>
              <Link to="/news" className="text-[11px] font-bold uppercase text-primary hover:underline">All news →</Link>
            </div>
            {rest.slice(0, 3).map((article, index) => (
              <Link
                key={article.slug}
                to="/media/$slug"
                params={{ slug: article.slug }}
                className="group grid grid-cols-[2.5rem_1fr] gap-4 border-b border-border p-5 transition-colors hover:bg-surface sm:p-8"
              >
                <span className={index === 0 ? "scoreboard text-2xl font-bold text-primary" : "scoreboard text-2xl font-bold text-muted-foreground/40"}>0{index + 1}</span>
                <span>
                  <span className="mb-3 block text-[10px] font-bold uppercase text-muted-foreground">{article.league} · {article.kind}</span>
                  <span className="block text-xl font-bold leading-tight group-hover:underline">{article.title}</span>
                  <span className="mt-3 block text-xs text-muted-foreground">{article.published}</span>
                </span>
              </Link>
            ))}
            <div className="mt-auto bg-foreground p-6 text-background sm:p-8">
              <p className="mb-5 text-[10px] font-bold uppercase opacity-50">Today on Sideline</p>
              <div className="grid grid-cols-2 gap-6">
                <div><strong className="scoreboard block text-4xl">{live.length}</strong><span className="text-[10px] font-bold uppercase opacity-55">Live now</span></div>
                <div><strong className="scoreboard block text-4xl">{games.length}</strong><span className="text-[10px] font-bold uppercase opacity-55">Games tracked</span></div>
              </div>
            </div>
          </aside>
        </section>


        <section className="mt-16 border-t border-foreground pt-5">
          <div className="mb-6 flex items-end justify-between gap-4">
            <div><p className="text-[10px] font-bold uppercase text-primary">Scoreboard</p><h2 className="scoreboard text-3xl font-bold uppercase">Live right now</h2></div>
            <Link to="/scores" className="text-[11px] font-bold uppercase text-primary hover:underline">Full scoreboard →</Link>
          </div>
          <div className="grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
            {live.slice(0, 6).map((game) => <ScoreCard key={game.id} game={game} />)}
          </div>
        </section>

        <div className="mt-16 grid gap-10 border-t border-foreground pt-5 lg:grid-cols-[2fr_1fr]">
          <section>
            <h2 className="scoreboard mb-5 text-3xl font-bold uppercase">More stories</h2>
            <div className="divide-y divide-border border-y border-border">
              {rest.slice(3).map((a) => (
                <Link key={a.slug} to="/media/$slug" params={{ slug: a.slug }} className="grid gap-3 py-6 transition-colors hover:bg-surface sm:grid-cols-[auto_1fr_auto] sm:items-center sm:px-3">
                  <LeagueBadge league={a.league} />
                  <span><span className="block text-xl font-bold">{a.title}</span><span className="mt-1 block text-sm text-muted-foreground">{a.dek}</span></span>
                  <span className="text-xs text-muted-foreground">{a.published}</span>
                </Link>
              ))}
            </div>
          </section>

          <aside>
            <h2 className="scoreboard mb-5 text-3xl font-bold uppercase">Coming up</h2>
            <div className="grid gap-px bg-border">
              {upcoming.map((g) => <ScoreCard key={g.id} game={g} compact />)}
            </div>
            <div className="mt-6 flex flex-wrap gap-4 text-[11px] font-bold uppercase">
              <Link to="/watch" className="text-primary hover:underline">Where to watch →</Link>
              <Link to="/predictions" className="text-primary hover:underline">Make your picks →</Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
