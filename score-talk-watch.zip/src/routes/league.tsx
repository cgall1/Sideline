import { createFileRoute, Link } from "@tanstack/react-router";
import { pageHead } from "@/lib/seo";
import logo from "@/assets/league-logo.png";

const TITLE = "S League — Fantasy Drafts With Real Players";
const DESCRIPTION =
  "S League is Sideline's standalone fantasy home: create a league, invite friends with a code and run a live snake draft with real NFL, NBA, NHL, MLB and soccer players.";

export const Route = createFileRoute("/league")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/league", title: TITLE, description: DESCRIPTION }),
  component: LeagueLanding,
});

const STEPS = [
  {
    title: "Create your league",
    body: "Pick a sport, name the league and your team. You are the commissioner.",
  },
  {
    title: "Invite the group",
    body: "Share the invite code. Everyone joins with their own team name.",
  },
  {
    title: "Draft live",
    body: "A snake draft with real rosters, a live clock and an on-the-clock board.",
  },
];

const SPORTS = ["NFL", "NBA", "NHL", "MLB", "MLS", "World Soccer"];

function LeagueLanding() {
  return (
    <main className="min-h-screen">
      <section className="relative overflow-hidden">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-0 opacity-70"
          style={{
            background:
              "radial-gradient(60% 60% at 15% 10%, rgba(124,58,237,.35), transparent 70%), radial-gradient(55% 55% at 85% 20%, rgba(238,95,162,.3), transparent 70%), radial-gradient(50% 50% at 50% 100%, rgba(125,211,252,.28), transparent 70%)",
          }}
        />
        <div className="relative mx-auto w-full max-w-4xl px-4 py-20 text-center">
          <img
            src={logo}
            alt="S League logo"
            width={816}
            height={816}
            className="mx-auto h-28 w-28"
          />
          <h1 className="scoreboard mt-6 text-4xl font-black uppercase tracking-wide sm:text-6xl">
            S League
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground">
            The fantasy home of Sideline. Real players, a live snake draft and a league room built
            for the group chat.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/fantasy"
              className="rounded-md bg-primary px-6 py-3 text-sm font-bold uppercase tracking-wide text-primary-foreground"
            >
              Start a league
            </Link>
            <Link
              to="/fantasy"
              className="rounded-md border border-border px-6 py-3 text-sm font-bold uppercase tracking-wide"
            >
              Join with a code
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {SPORTS.map((s) => (
              <span
                key={s}
                className="rounded-full border border-border px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground"
              >
                {s}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-4xl px-4 pb-16">
        <div className="grid gap-4 sm:grid-cols-3">
          {STEPS.map((s, i) => (
            <div key={s.title} className="rounded-md border border-border bg-card p-5">
              <span className="scoreboard text-3xl font-black text-primary">{i + 1}</span>
              <h2 className="scoreboard mt-2 text-lg font-bold uppercase tracking-wide">{s.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 rounded-md border border-border bg-card p-6 text-center">
          <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">
            Ready for its own address
          </h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-muted-foreground">
            This page stands on its own — its own logo, its own look, no site chrome needed. Point a
            domain at it and S League becomes its own home.
          </p>
          <Link to="/brand" className="mt-4 inline-block text-sm font-semibold text-primary underline">
            View the brand kit →
          </Link>
        </div>
      </section>
    </main>
  );
}
