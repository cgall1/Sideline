import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ensureDailyDebates } from "@/lib/daily.functions";
import { debatesQueryOptions } from "@/lib/daily";
import { DebateCard } from "@/components/DailyDebate";
import { useAuth } from "@/hooks/useAuth";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/daily/$date")({
  staticData: { sitemap: false },
  loader: () => ensureDailyDebates(),
  head: ({ params }) =>
    pageHead({
      path: `/daily/${params.date}`,
      title: `The Daily Debate — ${params.date} — Sideline`,
      description: `The sports argument Sideline fans picked a side on for ${params.date}, with the running vote split.`,
      type: "article",
    }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-3xl px-4 py-16">
      That debate is unavailable: {error.message}
    </div>
  ),
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-16">No debate for that day.</div>
  ),
  component: DebateByDate,
});

function DebateByDate() {
  const { date } = Route.useParams();
  const { user } = useAuth();
  const { data: debates = [], isLoading } = useQuery(debatesQueryOptions(user?.id ?? null));
  const debate = debates.find((d) => d.date === date);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <Link to="/daily" className="text-xs font-semibold uppercase tracking-widest text-primary underline">
        ← All debates
      </Link>
      <h1 className="scoreboard mt-3 text-3xl font-bold uppercase tracking-wide">
        Debate · {date}
      </h1>
      <div className="mt-6">
        {isLoading && <p className="text-sm text-muted-foreground">Loading…</p>}
        {!isLoading && !debate && (
          <p className="text-sm text-muted-foreground">
            No debate was posted on that date. Today's is on the{" "}
            <Link to="/daily" className="text-primary underline">
              daily debate page
            </Link>
            .
          </p>
        )}
        {debate && <DebateCard debate={debate} />}
      </div>
    </div>
  );
}
