import { FanPulse } from "@/components/FanPulse";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { LEAGUES, type LeagueId } from "@/data/sports";
import { newsQueryOptions } from "@/lib/feed";
import { LeagueBadge, LeagueFilter } from "@/components/LeagueFilter";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/news`;
const TITLE = "Sports News — Latest NFL, NBA, NHL, MLB & Soccer Headlines — Sideline";
const DESCRIPTION =
  "Today's sports news in one feed: breaking NFL, NBA, NHL, MLB, college football, MLS and international soccer headlines with summaries and links to the full story.";

const LEAGUE_IDS = LEAGUES.map((l) => l.id) as string[];

export const Route = createFileRoute("/news/")({
  staticData: { sitemap: true },
  validateSearch: (
    search: Partial<{ league: LeagueId | "all" }>,
  ): Partial<{ league: LeagueId | "all" }> => {
    const raw = typeof search.league === "string" ? search.league : "all";
    return { league: (LEAGUE_IDS.includes(raw) ? raw : "all") as LeagueId | "all" };
  },
  loaderDeps: ({ search: { league } }) => ({ league: league ?? "all" }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(newsQueryOptions(deps.league));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "Sports News",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              { "@type": "ListItem", position: 2, name: "Sports News", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      News is unavailable right now: {error.message}
    </div>
  ),
  component: News,
});

function when(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (diff < 1) return "just now";
  if (diff < 60) return `${diff}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return `${Math.floor(diff / 1440)}d ago`;
}

function News() {
  const { league = "all" } = Route.useSearch();
  const navigate = useNavigate({ from: "/news/" });
  const { data } = useSuspenseQuery(newsQueryOptions(league));
  const [lead, ...rest] = data.items;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Sports News</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Breaking headlines from every league we cover, refreshed through the day. Tap a story to
        read it in full at the source.
      </p>

      <div className="mt-4">
        <LeagueFilter
          value={league}
          onChange={(next) => navigate({ to: "/news", search: { league: next } })}
        />
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Link
          to="/podcasts"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🎧 Sports Podcasts — shows &amp; episodes
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Listen
          </span>
        </Link>
        <Link
          to="/trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ❓ Sports Trivia — questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/mlb-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚾ MLB Trivia — baseball questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/nhl-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏒 NHL Trivia — hockey questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/nfl-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏈 NFL Trivia — football questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/nba-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏀 NBA Trivia — basketball questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/mls-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚽ MLS Trivia — soccer questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/soccer-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🌍 World Soccer Trivia — global football Q&amp;A
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/college-football-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏈 College Football Trivia — NCAA Q&amp;A
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/college-hockey-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏒 College Hockey Trivia — NCAA Q&amp;A
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/golf-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⛳ Golf Trivia — PGA Tour &amp; majors Q&amp;A
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/college-basketball-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            🏀 College Basketball Trivia — NCAA hoops Q&amp;A
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
        <Link
          to="/soccer-news"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⚽ Soccer News — transfers, injuries &amp; matchday
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Read
          </span>
        </Link>
      </div>

      <div className="mt-4 rounded-md border border-border bg-card p-4">
        <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
          Today&apos;s news by league
        </h2>
        <div className="mt-2 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-widest">
          {LEAGUES.map((l) => (
            <Link
              key={l.id}
              to="/news/$league/$date"
              params={{ league: l.id, date: new Date().toISOString().slice(0, 10) }}
              className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
            >
              {l.short}
            </Link>
          ))}
        </div>
        <h2 className="scoreboard mt-4 text-sm font-bold uppercase tracking-widest text-muted-foreground">
          Weekly recap
        </h2>
        <div className="mt-2 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-widest">
          {LEAGUES.map((l) => (
            <Link
              key={l.id}
              to="/recap/$league"
              params={{ league: l.id }}
              className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
            >
              {l.short}
            </Link>
          ))}
        </div>
        <h2 className="scoreboard mt-4 text-sm font-bold uppercase tracking-widest text-muted-foreground">
          Subscribe by RSS
        </h2>
        <div className="mt-2 flex flex-wrap gap-2 text-xs font-semibold uppercase tracking-widest">
          {LEAGUES.map((l) => (
            <a
              key={l.id}
              href={`/rss/${l.id}.xml`}
              className="rounded-sm border border-border px-3 py-1 text-muted-foreground hover:text-foreground"
            >
              {l.short} feed
            </a>
          ))}
        </div>
        <p className="mt-3 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
          <Link to="/moves" className="text-primary underline">
            Trade &amp; free agency tracker
          </Link>
          <Link to="/draft" className="text-primary underline">
            Draft coverage
          </Link>
          <Link to="/recaps" className="text-primary underline">
            Game recaps
          </Link>
          <Link to="/leaders" className="text-primary underline">
            Stat leaders
          </Link>
        </p>
      </div>

      {lead && (
        <a
          href={lead.url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 block overflow-hidden rounded-md border border-border bg-card transition-colors hover:border-primary/60"
        >
          <div className="grid gap-0 md:grid-cols-[1.2fr_1fr]">
            <div className="p-5">
              <div className="flex items-center gap-2">
                <LeagueBadge league={lead.league} />
                <span className="text-xs uppercase tracking-widest text-muted-foreground">
                  {when(lead.published)}
                </span>
              </div>
              <h2 className="scoreboard mt-3 text-3xl font-bold uppercase tracking-wide">
                {lead.headline}
              </h2>
              {lead.summary && <p className="mt-2 text-sm text-muted-foreground">{lead.summary}</p>}
              <p className="mt-4 scoreboard text-sm font-bold uppercase tracking-widest text-primary">
                Read the story →
              </p>
            </div>
            {lead.image && (
              <img
                src={lead.image}
                alt={lead.headline}
                loading="lazy"
                className="h-full w-full object-cover"
              />
            )}
          </div>
        </a>
      )}
      {lead && (
        <div className="mt-4">
          <FanPulse type="news" id={String(lead.id)} question={`Top story: do you agree this is the biggest news today?`} />
        </div>
      )}

      <ul className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {rest.map((item) => (
          <li key={item.id}>
            <a
              href={item.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-full flex-col overflow-hidden rounded-md border border-border bg-card transition-colors hover:border-primary/60"
            >
              {item.image && (
                <img
                  src={item.image}
                  alt={item.headline}
                  loading="lazy"
                  className="h-40 w-full object-cover"
                />
              )}
              <div className="flex flex-1 flex-col p-4">
                <div className="flex items-center gap-2">
                  <LeagueBadge league={item.league} />
                  <span className="text-xs uppercase tracking-widest text-muted-foreground">
                    {when(item.published)}
                  </span>
                </div>
                <h3 className="mt-2 text-base font-bold leading-snug">{item.headline}</h3>
                {item.summary && (
                  <p className="mt-1.5 line-clamp-3 text-sm text-muted-foreground">
                    {item.summary}
                  </p>
                )}
                <span className="mt-auto pt-3 text-xs font-semibold uppercase tracking-widest text-primary">
                  Read more
                </span>
              </div>
            </a>
          </li>
        ))}
        {!data.items.length && (
          <li className="text-sm text-muted-foreground">
            No headlines for this league right now — try another filter.
          </li>
        )}
      </ul>

      <p className="mt-8 text-sm text-muted-foreground">
        Looking for video?{" "}
        <Link to="/media" className="font-semibold text-primary underline">
          Browse Sideline analysis and highlight hubs
        </Link>
        .
      </p>
    </div>
  );
}
