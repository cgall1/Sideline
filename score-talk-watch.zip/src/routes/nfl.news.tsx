import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nfl/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nfl/news",
      title: "NFL News — Latest Headlines & Injuries — Sideline",
      description: "The latest NFL news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("nfl"),
    }),
  component: () => <SportNewsSection league="nfl" />,
});
