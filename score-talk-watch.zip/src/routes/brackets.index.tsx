import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Playoff Brackets & Postseason Picture — Sideline";
const DESCRIPTION =
  "Live playoff brackets and postseason projections for the NFL, NBA, NHL, MLB, MLS and college sports — current seeds and projected first-round matchups.";

export const Route = createFileRoute("/brackets/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/brackets", title: TITLE, description: DESCRIPTION }),
  component: BracketsIndex,
});

function BracketsIndex() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Playoff brackets</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Where every team sits in the postseason picture right now, with projected first-round
        matchups built from live standings.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/brackets/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{league.short}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{league.name}</p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-primary">
              View bracket →
            </p>
          </Link>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/power-rankings" className="text-primary underline">
          Power rankings
        </Link>
        <Link to="/championships" className="text-primary underline">
          Championship history
        </Link>
      </div>
    </div>
  );
}
