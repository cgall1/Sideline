import { createFileRoute } from "@tanstack/react-router";
import { BasketballScores, basketballLeague } from "@/components/sport/BasketballSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/basketball/scores")({
  staticData: { sitemap: true },
  validateSearch: (search: Record<string, unknown>) => ({
    league: basketballLeague(search['league']),
  }),
  head: () =>
    pageHead({
      path: "/basketball/scores",
      title: "Basketball Scores — NBA, WNBA & College — Sideline",
      description:
        "Live basketball scores across the NBA, WNBA and college game, with quarter-by-quarter updates that refresh on their own.",
    }),
  component: BasketballScoresPage,
});

function BasketballScoresPage() {
  const { league } = Route.useSearch();
  return <BasketballScores league={league} />;
}
