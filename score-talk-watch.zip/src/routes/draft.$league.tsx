import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { leagueById, type LeagueId } from "@/data/sports";
import { newsQueryOptions } from "@/lib/feed";
import { pageHead } from "@/lib/seo";

const DRAFT_WORDS = ["draft", "prospect", "mock", "combine", "rookie", "signing class", "recruit"];

export const Route = createFileRoute("/draft/$league")({
  loader: async ({ context, params }) => {
    const league = leagueById(params.league);
    if (!league) throw notFound();
    await context.queryClient.ensureQueryData(newsQueryOptions(league.id as LeagueId));
    return { name: league.name, short: league.short };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Draft coverage unavailable — Sideline" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.short} Draft — Prospects, Mocks & Draft News — Sideline`;
    const description = `Live ${loaderData.name} draft coverage — prospect reporting, mock drafts, combine news and rookie signings, refreshed through the day.`;
    return pageHead({ path: `/draft/${params.league}`, title, description });
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-5xl px-4 py-16">
      Draft coverage is unavailable right now: {error.message}
    </div>
  ),
  component: LeagueDraft,
});

function LeagueDraft() {
  const { league } = Route.useParams();
  const { short, name } = Route.useLoaderData();
  const { data: news } = useSuspenseQuery(newsQueryOptions(league as LeagueId));

  const draftNews = news.items.filter((n) => {
    const text = `${n.headline} ${n.summary}`.toLowerCase();
    return DRAFT_WORDS.some((w) => text.includes(w));
  });

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <Link
        to="/draft"
        className="text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ← All draft coverage
      </Link>

      <h1 className="scoreboard mt-4 text-4xl font-bold uppercase tracking-wide">{short} draft</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Everything on the {name} draft — prospects, mock drafts, combine reporting and rookie
        signings as the stories break.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/moves/$league" params={{ league }} className="text-primary underline">
          Trades & signings
        </Link>
        <Link to="/rosters/$league" params={{ league }} className="text-primary underline">
          Rosters
        </Link>
        <Link to="/brackets/$league" params={{ league }} className="text-primary underline">
          Playoff bracket
        </Link>
      </div>

      {!draftNews.length ? (
        <p className="mt-10 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No draft stories in the feed right now — coverage builds through the pre-draft season.
        </p>
      ) : (
        <div className="mt-8 space-y-3">
          {draftNews.map((item) => (
            <article key={item.id} className="rounded-md border border-border bg-card p-5">
              <h2 className="text-lg font-semibold">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary"
                >
                  {item.headline}
                </a>
              </h2>
              {item.summary && <p className="mt-1 text-sm text-muted-foreground">{item.summary}</p>}
              {item.published && (
                <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">
                  {item.published}
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
