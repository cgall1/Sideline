import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LEAGUES, leagueById } from "@/data/sports";
import { useAuth } from "@/hooks/useAuth";
import {
  buildStreak,
  predictionBoardQueryOptions,
  predictionsQueryOptions,
} from "@/lib/predictions";
import { pageHead } from "@/lib/seo";

const TITLE = "My Prediction Results — Picks, Streaks & Accuracy — Sideline";
const DESCRIPTION =
  "See every pick you've made on Sideline, how many you got right, your current and best streak, your accuracy by league and where you sit on the fan leaderboard.";

export const Route = createFileRoute("/my-picks")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/my-picks", title: TITLE, description: DESCRIPTION }),
  component: MyPicksPage,
});

function MyPicksPage() {
  const { user } = useAuth();
  const { data: picks = [] } = useQuery(predictionsQueryOptions(user?.id));
  const { data: board } = useQuery(predictionBoardQueryOptions());

  const streak = user ? buildStreak(picks, user.id) : null;
  const resolved = picks.filter((p) => p.resolved);
  const correct = resolved.filter((p) => p.correct).length;
  const accuracy = resolved.length ? Math.round((correct / resolved.length) * 100) : 0;
  const pending = picks.filter((p) => !p.resolved);

  const overall = board?.overall ?? [];
  const mine = overall.find((e) => e.userId === user?.id);
  const rank = mine ? overall.indexOf(mine) + 1 : null;

  const byLeague = LEAGUES.map((l) => {
    const rows = resolved.filter((p) => p.league === l.id);
    return {
      id: l.id,
      name: l.name,
      picks: rows.length,
      correct: rows.filter((p) => p.correct).length,
    };
  }).filter((row) => row.picks > 0);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        My prediction results
      </h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Every pick you've locked in, how it turned out, and your streaks — all here, no email
        needed.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/predictions" className="text-primary underline">
          Make your picks
        </Link>
        <Link to="/leaderboard" className="text-primary underline">
          Full leaderboard
        </Link>
        <Link to="/predictions-chat" className="text-primary underline">
          Fans-only picks chat
        </Link>
      </div>

      {!user ? (
        <p className="mt-8 rounded-md border border-border bg-card p-6 text-sm">
          <Link to="/auth" className="text-primary underline">
            Sign in
          </Link>{" "}
          to see your picks, streaks and accuracy.
        </p>
      ) : (
        <>
          <div className="mt-8 grid gap-3 sm:grid-cols-4">
            {[
              { label: "Picks scored", value: String(resolved.length) },
              { label: "Correct", value: String(correct) },
              { label: "Accuracy", value: `${accuracy}%` },
              {
                label: "Streak",
                value: `${streak?.current ?? 0} (best ${streak?.best ?? 0})`,
              },
            ].map((card) => (
              <div key={card.label} className="rounded-md border border-border bg-card p-4">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">
                  {card.label}
                </p>
                <p className="scoreboard mt-1 text-2xl font-bold">{card.value}</p>
              </div>
            ))}
          </div>

          {rank && (
            <p className="mt-4 rounded-md border border-primary/40 bg-primary/10 p-4 text-sm">
              You're <strong>#{rank}</strong> of {overall.length} fans on the leaderboard.
            </p>
          )}

          {streak?.badges.length ? (
            <div className="mt-6 flex flex-wrap gap-2">
              {streak.badges.map((badge) => (
                <span
                  key={badge}
                  className="rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold uppercase tracking-widest"
                >
                  {badge}
                </span>
              ))}
            </div>
          ) : null}

          {byLeague.length > 0 && (
            <section className="mt-10">
              <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">By league</h2>
              <div className="mt-3 overflow-x-auto rounded-md border border-border bg-card">
                <table className="w-full text-sm">
                  <thead className="text-xs uppercase tracking-widest text-muted-foreground">
                    <tr className="border-b border-border">
                      <th className="px-4 py-2 text-left">League</th>
                      <th className="px-4 py-2 text-right">Scored</th>
                      <th className="px-4 py-2 text-right">Correct</th>
                      <th className="px-4 py-2 text-right">Accuracy</th>
                    </tr>
                  </thead>
                  <tbody>
                    {byLeague.map((row) => (
                      <tr key={row.id} className="border-b border-border/60 last:border-0">
                        <td className="px-4 py-2">{row.name}</td>
                        <td className="px-4 py-2 text-right">{row.picks}</td>
                        <td className="px-4 py-2 text-right">{row.correct}</td>
                        <td className="px-4 py-2 text-right">
                          {Math.round((row.correct / row.picks) * 100)}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          <section className="mt-10">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              Picks still open
            </h2>
            {pending.length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">
                No open picks — <Link to="/predictions" className="text-primary underline">
                  pick this week's games
                </Link>
                .
              </p>
            ) : (
              <ul className="mt-3 space-y-2">
                {pending.map((p) => (
                  <li
                    key={p.id}
                    className="rounded-md border border-border bg-card px-4 py-3 text-sm"
                  >
                    <span className="text-xs uppercase tracking-widest text-muted-foreground">
                      {leagueById(p.league)?.name ?? p.league}
                    </span>
                    <p className="mt-1">
                      {p.gameLabel} — you picked <strong>{p.pick}</strong>
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mt-10">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              Scored picks
            </h2>
            {resolved.length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">
                Nothing scored yet — results appear once your games finish.
              </p>
            ) : (
              <ul className="mt-3 space-y-2">
                {resolved.map((p) => (
                  <li
                    key={p.id}
                    className="flex items-center justify-between gap-4 rounded-md border border-border bg-card px-4 py-3 text-sm"
                  >
                    <span>
                      <span className="text-xs uppercase tracking-widest text-muted-foreground">
                        {leagueById(p.league)?.name ?? p.league}
                      </span>
                      <span className="block">
                        {p.gameLabel} — you picked <strong>{p.pick}</strong>
                      </span>
                    </span>
                    <span
                      className={`text-xs font-semibold uppercase tracking-widest ${
                        p.correct ? "text-primary" : "text-muted-foreground"
                      }`}
                    >
                      {p.correct ? "Correct" : "Missed"}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}
