import { createFileRoute, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

type OAuthResult = { redirect_url?: string; redirect_to?: string; client?: { name?: string }; scope?: string };
type OAuthApi = {
  getAuthorizationDetails: (id: string) => Promise<{ data: OAuthResult | null; error: { message: string } | null }>;
  approveAuthorization: (id: string) => Promise<{ data: OAuthResult | null; error: { message: string } | null }>;
  denyAuthorization: (id: string) => Promise<{ data: OAuthResult | null; error: { message: string } | null }>;
};
const oauth = () => (supabase.auth as unknown as { oauth: OAuthApi }).oauth;

export const Route = createFileRoute("/.lovable/oauth/consent")({
  ssr: false,
  staticData: { sitemap: false },
  validateSearch: (s: Record<string, unknown>) => ({
    authorization_id: typeof s['authorization_id'] === "string" ? s['authorization_id'] : "",
  }),
  beforeLoad: async ({ search, location }) => {
    if (!search.authorization_id) throw new Error("Missing authorization_id");
    const { data } = await supabase.auth.getSession();
    if (!data.session) {
      throw redirect({ to: "/auth", search: { next: location.pathname + location.searchStr } });
    }
  },
  loader: async ({ location }) => {
    const authorizationId = new URLSearchParams(location.search).get("authorization_id")!;
    const { data, error } = await oauth().getAuthorizationDetails(authorizationId);
    if (error) throw new Error(error.message);
    const immediate = data?.redirect_url ?? data?.redirect_to;
    if (immediate && !data?.client) throw redirect({ href: immediate });
    const { data: session } = await supabase.auth.getSession();
    return { details: data, email: session.session?.user.email ?? null };
  },
  errorComponent: ({ error }) => (
    <main className="mx-auto max-w-md px-4 py-16">
      <h1 className="font-[family-name:var(--font-display)] text-3xl uppercase">Authorization problem</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        Could not load this authorization request: {String((error as Error)?.message ?? error)}
      </p>
    </main>
  ),
  component: Consent,
});

function Consent() {
  const { details, email } = Route.useLoaderData();
  const { authorization_id } = Route.useSearch();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const clientName = details?.client?.name ?? "this app";
  const scopes = (details?.scope ?? "").split(" ").filter(Boolean);

  async function decide(approve: boolean) {
    setBusy(true);
    setError(null);
    const { data, error: decisionError } = approve
      ? await oauth().approveAuthorization(authorization_id)
      : await oauth().denyAuthorization(authorization_id);
    if (decisionError) {
      setBusy(false);
      setError(decisionError.message);
      return;
    }
    const target = data?.redirect_url ?? data?.redirect_to;
    if (!target) {
      setBusy(false);
      setError("No redirect returned by the authorization server.");
      return;
    }
    window.location.href = target;
  }

  return (
    <main className="mx-auto flex w-full max-w-md flex-col gap-5 px-4 py-16">
      <h1 className="font-[family-name:var(--font-display)] text-3xl uppercase tracking-wide">
        Connect {clientName} to Sideline
      </h1>
      {email && <p className="text-sm text-muted-foreground">Signed in as {email}</p>}
      <p className="text-sm">
        {clientName} will be able to call Sideline&apos;s enabled tools — scores, standings, stories and fan community
        activity — while you are signed in.
      </p>
      {scopes.length > 0 && (
        <ul className="list-disc pl-5 text-sm text-muted-foreground">
          {scopes.map((scope) => (
            <li key={scope}>
              {scope === "email"
                ? "Share your email address"
                : scope === "profile" || scope === "openid"
                  ? "Share your basic profile"
                  : `Additional permission requested: ${scope}`}
            </li>
          ))}
        </ul>
      )}
      <p className="text-xs text-muted-foreground">
        This does not bypass Sideline&apos;s permissions or backend policies.
      </p>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-3">
        <Button disabled={busy} onClick={() => decide(true)}>Approve</Button>
        <Button variant="outline" disabled={busy} onClick={() => decide(false)}>Cancel connection</Button>
      </div>
    </main>
  );
}
