import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import {
  fanFollowsQueryOptions,
  fanPostsByAuthorQueryOptions,
  sortPosts,
  toggleFanFollow,
  toggleVote,
} from "@/lib/spaces";
import { PostCard } from "@/components/spaces/PostCard";
import { BADGE_LABELS, fanStandingQueryOptions } from "@/lib/daily";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

const SITE = "https://score-talk-watch.lovable.app";

export const Route = createFileRoute("/fan/$fanId")({
  loader: async ({ params }) => {
    if (!/^[0-9a-f-]{36}$/i.test(params.fanId)) return { fanName: null as string | null };
    try {
      const { data } = await supabase.from("profiles").select("display_name").eq("id", params.fanId).maybeSingle();
      if (data?.display_name) return { fanName: data.display_name as string | null };
      const { data: post } = await supabase.from("space_posts").select("author_name").eq("user_id", params.fanId).limit(1).maybeSingle();
      return { fanName: (post?.author_name ?? null) as string | null };
    } catch {
      return { fanName: null as string | null };
    }
  },
  head: ({ params, loaderData }) => {
    const name = loaderData?.fanName?.trim();
    const title = name ? `${name} — Fan profile on Sideline` : "Fan profile — Sideline community";
    const description = name
      ? `See ${name}'s posts, replies, badges and fan communities on Sideline.`
      : "See this fan's posts, replies and communities on Sideline.";
    const url = `${SITE}/fan/${params.fanId}`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:url", content: url },
        { property: "og:type", content: "profile" },
        { name: "twitter:card", content: "summary" },
      ],
      links: [{ rel: "canonical", href: url }],
    };
  },
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-3xl px-4 py-16">
      This profile is unavailable: {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="mx-auto max-w-3xl px-4 py-16">No such fan.</div>,
  component: FanProfile,
});

function FanProfile() {
  const { fanId } = Route.useParams();
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const queryClient = useQueryClient();

  const { data: posts } = useSuspenseQuery(fanPostsByAuthorQueryOptions(fanId, userId));
  const { data: follows } = useSuspenseQuery(fanFollowsQueryOptions(userId));
  const { data: standing } = useQuery({ ...fanStandingQueryOptions(fanId), enabled: userId === fanId });

  const name = posts[0]?.author ?? "Sideline fan";
  const following = follows.following.includes(fanId);
  const followerCount = follows.followers[fanId] ?? 0;
  const isMe = userId === fanId;

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["spaces"] });

  const spaces = Array.from(new Set(posts.map((p) => p.spaceName))).slice(0, 8);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">{name}</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {posts.length} post{posts.length === 1 ? "" : "s"} · {followerCount} follower
            {followerCount === 1 ? "" : "s"}
          </p>
          {standing && (standing.currentDays > 0 || standing.badges.length > 0) && (
            <div className="mt-3">
              {standing.currentDays > 0 && (
                <p className="scoreboard text-xs font-bold uppercase tracking-widest text-primary">
                  🔥 {standing.currentDays}-day streak · longest {standing.longestDays}
                </p>
              )}
              {standing.badges.length > 0 && (
                <ul className="mt-2 flex flex-wrap gap-2">
                  {standing.badges.map((b) => (
                    <li
                      key={b}
                      className="rounded-full border border-border px-3 py-1 text-[11px] font-semibold"
                    >
                      {BADGE_LABELS[b] ?? b}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
        {!isMe && (
          <button
            onClick={async () => {
              if (!userId) return;
              await toggleFanFollow(userId, fanId, following);
              await refresh();
            }}
            disabled={!userId}
            className={cn(
              "scoreboard rounded-sm border px-4 py-2 text-xs font-bold uppercase tracking-widest",
              following
                ? "border-primary bg-primary/15 text-primary"
                : "border-border hover:border-primary/60",
              !userId && "opacity-60",
            )}
          >
            {following ? "Following" : "Follow"}
          </button>
        )}
      </div>

      {!!spaces.length && (
        <p className="mt-4 text-xs text-muted-foreground">
          Active in: {spaces.join(" · ")}
        </p>
      )}

      {isMe && (
        <p className="mt-4 text-sm text-muted-foreground">
          This is you.{" "}
          <Link to="/my-teams" className="text-primary underline">
            Manage your teams and colors
          </Link>
          .
        </p>
      )}

      <h2 className="scoreboard mt-8 text-xl font-bold uppercase tracking-wide">Posts</h2>
      <div className="mt-3 space-y-3">
        {sortPosts(posts, "new").map((p) => (
          <PostCard
            key={p.id}
            post={p}
            canVote={!!userId}
            onVote={async () => {
              if (!userId) return;
              await toggleVote({ postId: p.id }, userId, p.votedByMe);
              await refresh();
            }}
          />
        ))}
        {!posts.length && <p className="text-sm text-muted-foreground">No posts yet.</p>}
      </div>
    </div>
  );
}
