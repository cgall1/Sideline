import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-baseball/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-baseball/news",
      title: "College Baseball News — Latest Headlines & Injuries — Sideline",
      description: "The latest College Baseball news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("cbs"),
    }),
  component: () => <SportNewsSection league="cbs" />,
});
