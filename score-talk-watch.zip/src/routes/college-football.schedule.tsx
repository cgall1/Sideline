import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-football/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-football/schedule",
      title: "College Football Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete College Football schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("cfb"),
    }),
  component: () => <SportScheduleSection league="cfb" />,
});
