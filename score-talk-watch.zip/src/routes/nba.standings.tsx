import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nba/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nba/standings",
      title: "NBA Standings — Full Table — Sideline",
      description: "The full NBA standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("nba"),
    }),
  component: () => <SportStandingsSection league="nba" />,
});
