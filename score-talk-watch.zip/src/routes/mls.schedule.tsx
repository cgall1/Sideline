import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/mls/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/mls/schedule",
      title: "MLS Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete MLS schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("mls"),
    }),
  component: () => <SportScheduleSection league="mls" />,
});
