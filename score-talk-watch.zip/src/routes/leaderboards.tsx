import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { getDiehardLeaderboard } from "@/lib/leaderboard.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/leaderboards")({
  validateSearch: (s: Record<string, unknown>): { team?: string } =>
    typeof s["team"] === "string" ? { team: s["team"] } : {},
  head: () => ({
    meta: [
      { title: "Diehard Leaderboards — Top Fans This Month — Sideline" },
      { name: "description", content: "Monthly rankings of Sideline's most dedicated fans, earned through correct picks, great posts and live match threads." },
      { property: "og:title", content: "Diehard Leaderboards — Sideline" },
      { property: "og:description", content: "Who are the top fans of your team this month?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Leaderboards,
});

function Leaderboards() {
  const { team } = Route.useSearch();
  const navigate = useNavigate({ from: "/leaderboards" });
  const { user } = useAuth();
  const fetchBoard = useServerFn(getDiehardLeaderboard);

  const { data: teams = [] } = useQuery({
    queryKey: ["lb-teams", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("followed_teams").select("team_id, name").eq("user_id", user!.id);
      return data ?? [];
    },
  });
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["leaderboard", team ?? "all"],
    queryFn: () => fetchBoard({ data: { team, days: 30 } }),
  });
  const teamName = teams.find((t) => t.team_id === team)?.name;

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Diehard leaderboards</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Last 30 days. Correct pick = 10 pts · space post = 3 · match thread message = 2 · upvote received = 1. The top 3 wear the Top Voice flair.
      </p>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {[{ team_id: undefined as string | undefined, name: "All fans" }, ...teams].map((t) => (
          <button
            key={t.team_id ?? "all"}
            onClick={() => navigate({ search: t.team_id ? { team: t.team_id } : {} })}
            className={cn(
              "rounded-sm border px-2.5 py-1 text-xs font-semibold",
              t.team_id === team ? "border-foreground bg-foreground text-background" : "border-border text-muted-foreground hover:text-foreground",
            )}
          >
            {t.name}
          </button>
        ))}
      </div>
      {!user && (
        <p className="mt-2 text-xs text-muted-foreground">
          <Link to="/auth" search={{ next: "/leaderboards" }} className="text-primary underline">Sign in</Link> and follow teams to see team leaderboards.
        </p>
      )}

      <h2 className="scoreboard mt-6 text-sm font-bold uppercase tracking-widest text-muted-foreground">
        {teamName ? `Top ${teamName} fans` : "Top Sideline fans"}
      </h2>
      <ol className="mt-2 divide-y divide-border rounded-md border border-border bg-card">
        {isLoading && <li className="p-4 text-sm text-muted-foreground">Loading…</li>}
        {!isLoading && rows.length === 0 && (
          <li className="p-4 text-sm text-muted-foreground">No points yet this month. Lock in a pick or post in a space to get on the board.</li>
        )}
        {rows.map((r, i) => (
          <li key={r.user_id} className={cn("flex items-center gap-3 px-4 py-3", r.user_id === user?.id && "bg-primary/10")}>
            <span className="scoreboard w-8 text-xl font-bold tabular-nums text-muted-foreground">{i + 1}</span>
            <div className="min-w-0 flex-1">
              <Link to="/fan/$fanId" params={{ fanId: r.user_id }} className="font-semibold hover:underline">
                {r.display_name}
              </Link>
              {i < 3 && (
                <span className="ml-2 rounded-sm bg-primary px-1.5 py-0.5 text-[10px] font-bold uppercase text-primary-foreground">Top Voice</span>
              )}
              <p className="text-xs text-muted-foreground">
                {r.correct_picks} correct picks · {r.posts} posts · {r.thread_posts} thread msgs · {r.upvotes} upvotes
              </p>
            </div>
            <span className="scoreboard text-xl font-bold tabular-nums">{r.points}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}
