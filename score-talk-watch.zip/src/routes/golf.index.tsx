import { createFileRoute, Link } from "@tanstack/react-router";
import { SportHub } from "@/components/SportHub";
import { sportById } from "@/lib/individual-sports.functions";
import { pageHead } from "@/lib/seo";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";

const TITLE = 'Golf Leaderboards, Tee Times & Highlights — PGA Tour Hub — Sideline';
const DESCRIPTION = 'Live PGA Tour leaderboards, tournament schedules and majors coverage, official golf highlights, news, trivia and fan chat.';

export const Route = createFileRoute("/golf/")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(sportEventsQueryOptions("golf"));
    context.queryClient.ensureQueryData(sportNewsQueryOptions("golf"));
  },
  head: () => pageHead({ path: "/golf", title: TITLE, description: DESCRIPTION }),
  component: GolfPage,
});

function GolfPage() {
  const sport = sportById("golf")!;
  return (
    <>
      <SportHub sport={sport} />
      <div className="mx-auto max-w-5xl px-4 pb-8">
        <Link
          to="/golf-trivia"
          className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-3 transition-colors hover:border-primary/50"
        >
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            ⛳ Golf Trivia — questions &amp; answers
          </span>
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
            Play
          </span>
        </Link>
      </div>
    </>
  );
}
