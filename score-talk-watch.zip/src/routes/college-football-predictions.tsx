import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { gamesQueryOptions } from "@/lib/feed";
import type { Game } from "@/data/sports";
import { useAuth } from "@/hooks/useAuth";
import { predictionsQueryOptions, savePick } from "@/lib/predictions";
import { SITE, pageHead } from "@/lib/seo";

const PAGE_URL = `${SITE}/college-football-predictions`;
const TITLE = "College Football Predictions — Weekly Picks, Odds & Fan Consensus — Sideline";
const DESCRIPTION =
  "College football predictions for every game on this week's slate: make your pick, see the fan consensus, and track your record against other fans on Sideline.";

export const Route = createFileRoute("/college-football-predictions")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("cfb"));
  },
  head: () => {
    const base = pageHead({
      path: "/college-football-predictions",
      title: TITLE,
      description: DESCRIPTION,
    });
    return {
      ...base,
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            name: "College Football Predictions",
            url: PAGE_URL,
            description: DESCRIPTION,
            isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
            breadcrumb: {
              "@type": "BreadcrumbList",
              itemListElement: [
                { "@type": "ListItem", position: 1, name: "Home", item: SITE },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "College Football",
                  item: `${SITE}/college-football`,
                },
                {
                  "@type": "ListItem",
                  position: 3,
                  name: "College Football Predictions",
                  item: PAGE_URL,
                },
              ],
            },
          }),
        },
      ],
    };
  },
  component: CollegeFootballPredictions,
});

function CollegeFootballPredictions() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: games = [], isLoading } = useQuery(gamesQueryOptions("cfb"));
  const { data: picks = [] } = useQuery(predictionsQueryOptions(user?.id));

  const myPicks = new Map(picks.map((p) => [p.gameId, p]));
  const upcoming = games.filter((g) => g.status !== "final").slice(0, 30);
  const finals = games.filter((g) => g.status === "final").slice(0, 10);

  async function choose(game: Game, team: string) {
    if (!user) return;
    await savePick({
      userId: user.id,
      league: game.league,
      gameId: game.id,
      gameLabel: `${game.away.name} at ${game.home.name}`,
      pick: team,
      kickoff: null,
    });
    void queryClient.invalidateQueries({ queryKey: ["predictions"] });
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">
        College football predictions
      </h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Every college football game on this week's slate, with a pick button for each side. Picks
        lock when a game kicks final, results are graded against the official scoreboard, and your
        record carries over to the Sideline leaderboard.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/college-football" className="text-primary underline">
          College football hub
        </Link>
        <Link to="/college-football-rankings" className="text-primary underline">
          Rankings
        </Link>
        <Link to="/college-football-results" className="text-primary underline">
          Results
        </Link>
        <Link to="/leaderboard" className="text-primary underline">
          Leaderboard
        </Link>
      </div>

      {!user && (
        <p className="mt-6 rounded-md border border-border bg-card p-4 text-sm text-muted-foreground">
          <Link
            to="/auth"
            search={{ next: "/college-football-predictions" }}
            className="font-semibold text-primary"
          >
            Sign in
          </Link>{" "}
          to lock in your college football picks and track your accuracy.
        </p>
      )}

      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
          This week's college football board
        </h2>
        {isLoading && (
          <p className="mt-3 text-sm text-muted-foreground">Loading this week's matchups…</p>
        )}
        {!isLoading && upcoming.length === 0 && (
          <p className="mt-3 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
            No upcoming college football games on the board right now — check back when the next
            slate is posted.
          </p>
        )}
        <div className="mt-4 space-y-3">
          {upcoming.map((game) => {
            const mine = myPicks.get(game.id);
            return (
              <article key={game.id} className="rounded-md border border-border bg-card p-4">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">
                  NCAAF · {game.startLabel}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {[game.away, game.home].map((team) => (
                    <button
                      key={team.name}
                      disabled={!user}
                      onClick={() => void choose(game, team.name)}
                      className={`rounded-sm border px-3 py-2 text-sm font-semibold transition-colors disabled:opacity-50 ${
                        mine?.pick === team.name
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-foreground hover:border-primary"
                      }`}
                    >
                      {team.name}
                    </button>
                  ))}
                </div>
                {mine && (
                  <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">
                    Your pick: {mine.pick}
                    {mine.resolved ? (mine.correct ? " · correct" : " · missed") : ""}
                  </p>
                )}
              </article>
            );
          })}
        </div>
      </section>

      {finals.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            How the last games finished
          </h2>
          <ul className="mt-4 space-y-2">
            {finals.map((game) => (
              <li
                key={game.id}
                className="flex items-center justify-between rounded-md border border-border bg-card px-4 py-2 text-sm"
              >
                <span className="font-semibold">
                  {game.away.name} at {game.home.name}
                </span>
                <span className="scoreboard tabular-nums text-muted-foreground">
                  {game.awayScore} – {game.homeScore}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
