import { createFileRoute } from "@tanstack/react-router";
import { SoccerHighlights } from "@/components/SoccerHighlights";
import { soccerCompetition } from "@/data/soccer";
import { soccerHighlightsQueryOptions } from "@/lib/feed";

const SITE = "https://score-talk-watch.lovable.app";
const SLUG = "concacaf-champions-cup-highlights";
const PAGE_URL = `${SITE}/media/${SLUG}`;
const TITLE = "CONCACAF Champions Cup Highlights — Goals & Match Recaps — Sideline";
const DESCRIPTION =
  "CONCACAF Champions Cup highlights: the best clubs from North America, Central America and the Caribbean, goal by goal.";
const OG_IMAGE = `${SITE}/og/soccer.jpg`;

export const Route = createFileRoute("/media/concacaf-champions-cup-highlights")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(soccerHighlightsQueryOptions(SLUG));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — CONCACAF Champions Cup highlights, scores and match recaps" },
      { name: "twitter:image", content: OG_IMAGE },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "CONCACAF Champions Cup Highlights",
          description: DESCRIPTION,
          url: PAGE_URL,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Media", item: `${SITE}/media` },
              { "@type": "ListItem", position: 2, name: "CONCACAF Champions Cup Highlights", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      CONCACAF Champions Cup highlights are unavailable: {error.message}
    </div>
  ),
  component: Page,
});

function Page() {
  const competition = soccerCompetition(SLUG)!;
  return <SoccerHighlights competition={competition} />;
}
