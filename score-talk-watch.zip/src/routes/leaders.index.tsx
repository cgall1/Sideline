import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Stat Leaders — Best Players in Every League — Sideline";
const DESCRIPTION =
  "Season stat leaders for the NFL, NBA, NHL, MLB, MLS, college football and more — the best players by position and category, updated from live league data.";

export const Route = createFileRoute("/leaders/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/leaders", title: TITLE, description: DESCRIPTION }),
  component: LeadersIndex,
});

function LeadersIndex() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Stat leaders</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        The best players in every league, by category and position — passing, scoring, goals, home
        runs and more, straight from the live season stats.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/leaders/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{league.short}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{league.name}</p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-primary">
              Best players →
            </p>
          </Link>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/team-stats" className="text-primary underline">
          Advanced team stats
        </Link>
        <Link to="/compare" className="text-primary underline">
          Compare players
        </Link>
        <Link to="/power-rankings" className="text-primary underline">
          Power rankings
        </Link>
        <Link to="/rosters" className="text-primary underline">
          Team rosters
        </Link>
        <Link to="/injuries" className="text-primary underline">
          Injury reports
        </Link>
      </div>
    </div>
  );
}
