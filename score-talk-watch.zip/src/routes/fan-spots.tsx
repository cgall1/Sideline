import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const Route = createFileRoute("/fan-spots")({
  head: () => ({
    meta: [
      { title: "Fan Bars & Supporter Spots — Where Fans Watch — Sideline" },
      { name: "description", content: "Find supporter bars, fan club venues and watch spots for your team in your city, added by Sideline fans." },
      { property: "og:title", content: "Fan Bars & Supporter Spots — Sideline" },
      { property: "og:description", content: "Where your team's fans gather to watch, city by city." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: FanSpots,
});

const input = "rounded-md border border-border bg-background px-3 py-2 text-sm";

function FanSpots() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [form, setForm] = useState({ team: "", city: "", name: "", address: "", notes: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: venues = [] } = useQuery({
    queryKey: ["fan-venues"],
    queryFn: async () => {
      const { data } = await supabase
        .from("fan_venues")
        .select("id, user_id, team, city, name, address, notes, created_at")
        .order("created_at", { ascending: false })
        .limit(500);
      return data ?? [];
    },
  });

  const needle = q.trim().toLowerCase();
  const shown = venues.filter((v) => !needle || `${v.team} ${v.city} ${v.name}`.toLowerCase().includes(needle));

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setBusy(true);
    setErr("");
    const { error } = await supabase.from("fan_venues").insert({ ...Object.fromEntries(Object.entries(form).map(([k, v]) => [k, v.trim()])), user_id: user.id } as never);
    setBusy(false);
    if (error) return setErr("Please fill in team, city, venue name and address.");
    setForm({ team: "", city: "", name: "", address: "", notes: "" });
    qc.invalidateQueries({ queryKey: ["fan-venues"] });
  }

  async function remove(id: string) {
    await supabase.from("fan_venues").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["fan-venues"] });
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <Link to="/watch" className="text-xs font-semibold uppercase tracking-widest text-primary underline">Where to watch</Link>
      <h1 className="scoreboard mt-2 text-4xl font-bold uppercase tracking-wide">Fan bars & supporter spots</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Where fans gather to watch, added by the community. Planning with friends? Start a watch party in your <Link to="/crews" className="text-primary underline">crew</Link>.
      </p>

      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by team, city or venue…" className={`${input} mt-4 w-full`} />

      <ul className="mt-4 grid gap-3 sm:grid-cols-2">
        {shown.map((v) => (
          <li key={v.id} className="rounded-md border border-border bg-card p-4">
            <p className="text-xs font-bold uppercase tracking-widest text-primary">{v.team} · {v.city}</p>
            <p className="mt-1 font-semibold">{v.name}</p>
            <a
              href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${v.name} ${v.address} ${v.city}`)}`}
              target="_blank"
              rel="noreferrer"
              className="text-sm text-muted-foreground underline"
            >
              {v.address}
            </a>
            {v.notes && <p className="mt-1 text-sm">{v.notes}</p>}
            {v.user_id === user?.id && (
              <button onClick={() => remove(v.id)} className="mt-2 text-xs text-muted-foreground underline">Remove</button>
            )}
          </li>
        ))}
        {shown.length === 0 && <li className="text-sm text-muted-foreground">No spots yet{needle ? " for that search" : ""}. Be the first to add one.</li>}
      </ul>

      <section className="mt-8 rounded-md border border-border bg-card p-5">
        <h2 className="scoreboard text-sm font-bold uppercase tracking-widest">Add a spot</h2>
        {user ? (
          <form onSubmit={add} className="mt-3 grid gap-2 sm:grid-cols-2">
            <input className={input} placeholder="Team (e.g. Liverpool)" maxLength={60} value={form.team} onChange={(e) => setForm({ ...form, team: e.target.value })} />
            <input className={input} placeholder="City" maxLength={60} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            <input className={input} placeholder="Venue name" maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className={input} placeholder="Address" maxLength={160} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <input className={`${input} sm:col-span-2`} placeholder="Notes (official supporters club, sound on, etc.)" maxLength={300} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            {err && <p className="text-sm text-destructive sm:col-span-2">{err}</p>}
            <button disabled={busy} className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50 sm:col-span-2">Add spot</button>
          </form>
        ) : (
          <p className="mt-2 text-sm"><Link to="/auth" search={{ next: "/fan-spots" }} className="text-primary underline">Sign in</Link> to add a spot.</p>
        )}
      </section>
    </div>
  );
}
