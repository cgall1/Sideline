import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-baseball/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-baseball/standings",
      title: "College Baseball Standings — Full Table — Sideline",
      description: "The full College Baseball standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("cbs"),
    }),
  component: () => <SportStandingsSection league="cbs" />,
});
