import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Draft Coverage — Prospects, Mocks & Draft News — Sideline";
const DESCRIPTION =
  "Draft coverage for every league — the latest prospect news, mock drafts and draft-order reporting for the NFL, NBA, NHL, MLB, MLS and college sports.";

export const Route = createFileRoute("/draft/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/draft", title: TITLE, description: DESCRIPTION }),
  component: DraftIndex,
});

function DraftIndex() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Draft coverage</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        Prospect reporting, mock drafts and draft-order news for every league, pulled from the live
        news feeds.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/draft/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
          >
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{league.short}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{league.name}</p>
            <p className="mt-2 text-xs font-semibold uppercase tracking-widest text-primary">
              Draft news →
            </p>
          </Link>
        ))}
      </div>

      <div className="mt-8 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/moves" className="text-primary underline">
          Trades & free agency
        </Link>
        <Link to="/rosters" className="text-primary underline">
          Team rosters
        </Link>
      </div>
    </div>
  );
}
