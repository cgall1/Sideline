import { createFileRoute, Link } from "@tanstack/react-router";
import { LEAGUES } from "@/data/sports";
import { pageHead } from "@/lib/seo";

const TITLE = "Injury Reports — Every League's Latest Injuries — Sideline";
const DESCRIPTION =
  "Up-to-date injury reports for the NFL, NBA, WNBA, NHL, MLB, MLS and college sports — player status, position and the latest word on every listed injury.";

export const Route = createFileRoute("/injuries/")({
  staticData: { sitemap: true },
  head: () => pageHead({ path: "/injuries", title: TITLE, description: DESCRIPTION }),
  component: InjuriesIndex,
});

function InjuriesIndex() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Injury reports</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Who's out, who's questionable and who's back. Pick a league for its current injury list.
      </p>
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {LEAGUES.map((league) => (
          <Link
            key={league.id}
            to="/injuries/$league"
            params={{ league: league.id }}
            className="rounded-md border border-border bg-card p-5 transition-colors hover:border-primary"
          >
            <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">{league.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{league.name} injury report</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
