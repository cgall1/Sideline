import { createFileRoute } from "@tanstack/react-router";
import { CricketScoresSection } from "@/components/sport/CricketSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/cricket/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/cricket/scores",
      title: "Live Cricket Scores — Every Active Series — Sideline",
      description:
        "Live cricket scores across Tests, ODIs, T20Is and the franchise leagues, with innings totals, match status and a refresh button.",
    }),
  component: () => <CricketScoresSection />,
});
