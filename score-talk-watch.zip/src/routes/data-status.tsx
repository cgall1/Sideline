import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { fetchProviderHealth, fetchProviderStatus } from "@/lib/apisports.functions";
import { useAuth } from "@/hooks/useAuth";
import { leagueById } from "@/data/sports";

export const Route = createFileRoute("/data-status")({
  head: () => ({
    meta: [
      { title: "Live data status | Sideline" },
      {
        name: "description",
        content:
          "Check whether Sideline's live sports data subscription is connected and which leagues it currently covers.",
      },
      { property: "og:title", content: "Live data status | Sideline" },
      {
        property: "og:description",
        content: "Which league feeds Sideline's live data subscription is serving right now.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DataStatusPage,
});

function DataStatusPage() {
  const { user } = useAuth();
  const status = useQuery({
    queryKey: ["provider-status"],
    queryFn: () => fetchProviderStatus(),
  });
  const health = useQuery({
    queryKey: ["provider-health", user?.id],
    enabled: !!user && !!status.data?.configured,
    queryFn: () => fetchProviderHealth(),
    retry: false,
    refetchInterval: 60_000,
  });
  const isLoading = status.isLoading;
  const data = {
    configured: status.data?.configured ?? false,
    leagues: health.data?.leagues ?? [],
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-bold tracking-tight">Live data status</h1>
      <p className="mt-2 text-muted-foreground">
        Sideline can pull scores, tables and stats from a paid live data subscription. When it is
        connected, it takes priority; otherwise the free feeds keep every page populated.
      </p>

      {isLoading ? (
        <p className="mt-8 text-sm text-muted-foreground">Checking…</p>
      ) : !data?.configured ? (
        <div className="mt-8 rounded-xl border border-border bg-card p-6">
          <p className="font-semibold">Not connected yet</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Add your subscription key and this page will show exactly which leagues your plan
            covers. Everything on the site keeps working in the meantime.
          </p>
        </div>
      ) : !health.data ? (
        <div className="mt-8 rounded-xl border border-border bg-card p-6">
          <p className="font-semibold">Connected</p>
          <p className="mt-2 text-sm text-muted-foreground">
            The live data subscription is active. League-by-league coverage is visible to Sideline
            admins only.
          </p>
        </div>
      ) : (
        <div className="mt-8 overflow-hidden rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left">
              <tr>
                <th className="px-4 py-3 font-semibold">League</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold">Games today</th>
              </tr>
            </thead>
            <tbody>
              {data.leagues.map((row) => (
                <tr key={row.league} className="border-t border-border">
                  <td className="px-4 py-3">{leagueById(row.league)?.name ?? row.league}</td>
                  <td className="px-4 py-3">
                    {row.ok ? (
                      <span className="text-primary">Covered</span>
                    ) : (
                      <span className="text-muted-foreground">{row.error ?? "Unavailable"}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">{row.games}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
