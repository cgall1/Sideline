import { createFileRoute } from "@tanstack/react-router";
import { SportScheduleSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nba/schedule")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nba/schedule",
      title: "NBA Schedule — Fixtures, Times & TV — Sideline",
      description: "The complete NBA schedule month by month with start times, venues and TV listings.",
      image: leagueOgImage("nba"),
    }),
  component: () => <SportScheduleSection league="nba" />,
});
