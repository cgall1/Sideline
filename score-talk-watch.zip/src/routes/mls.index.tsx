import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CollegeHub, seasonMonth } from "@/components/CollegeHub";
import { gamesQueryOptions, monthScheduleQueryOptions, standingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/mls`;
const TITLE = "MLS Scores, Table & Schedule — Soccer Hub — Sideline";
const DESCRIPTION =
  "Live MLS scores, the Eastern and Western Conference table and the full Major League Soccer schedule with kickoff times, stadiums and TV — plus highlights for every match.";

const SEASON_MONTHS = [2,3,4,5,6,7,8,9,10,11];

function defaultMonth(): string {
  return seasonMonth(SEASON_MONTHS);
}

interface HubSearch {
  month: string;
}

export const Route = createFileRoute("/mls/")({
  staticData: { sitemap: true },
  validateSearch: (search: Partial<HubSearch>): Partial<HubSearch> => ({
    month:
      typeof search.month === "string" && /^\d{4}-\d{2}$/.test(search.month)
        ? search.month
        : defaultMonth(),
  }),
  loaderDeps: ({ search }) => ({ month: search.month ?? defaultMonth() }),
  loader: ({ context, deps }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("mls"));
    context.queryClient.ensureQueryData(standingsQueryOptions("mls"));
    context.queryClient.ensureQueryData(monthScheduleQueryOptions("mls", deps.month));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og/soccer.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og/soccer.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "CollectionPage",
          name: "MLS Hub",
          url: PAGE_URL,
          description: DESCRIPTION,
          isPartOf: { "@type": "WebSite", name: "Sideline", url: SITE },
          breadcrumb: {
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: SITE },
              {
                "@type": "ListItem",
                position: 2,
                name: "Sports Directory",
                item: `${SITE}/directory`,
              },
              { "@type": "ListItem", position: 3, name: "MLS Hub", item: PAGE_URL },
            ],
          },
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The MLS hub is unavailable right now: {error.message}
    </div>
  ),
  component: MLSPage,
});

function MLSPage() {
  const { month = defaultMonth() } = Route.useSearch();
  const navigate = useNavigate({ from: "/mls/" });
  useTrackHubVisit("/mls", "MLS Hub");

  return (
    <>
      <CollegeHub
        league="mls"
        month={month}
        heading="MLS Scores & Table"
        intro="Live MLS scores, the conference table, and a month-by-month schedule with kickoff times, stadiums and TV — with a highlight reel beside every match."
        seasonMonths={SEASON_MONTHS}
        onMonth={(next) => navigate({ search: { month: next } })}
      />
      <div className="mx-auto flex max-w-7xl flex-wrap gap-3 px-4 pb-12 text-sm">
        <Link to="/scores" search={{ league: "mls" }} className="font-semibold text-primary underline">
          MLS live scores
        </Link>
        <Link to="/results" search={{ league: "mls" }} className="font-semibold text-primary underline">
          MLS season results
        </Link>
        <Link to="/mls-chat" className="font-semibold text-primary underline">
          MLS fan chat
        </Link>
        <Link to="/media/mls-highlights" className="font-semibold text-primary underline">
          MLS highlights
        </Link>
        <Link to="/directory/$league" params={{ league: "mls" }} className="font-semibold text-primary underline">
          Every MLS team
        </Link>
        <Link to="/mls-rankings" className="font-semibold text-primary underline">
          MLS rankings
        </Link>
        <Link to="/mls-results" className="font-semibold text-primary underline">
          MLS results table
        </Link>
        <Link to="/mls-trivia" className="font-semibold text-primary underline">
          MLS trivia
        </Link>
      </div>
    </>
  );
}
