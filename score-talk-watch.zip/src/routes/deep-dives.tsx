import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/deep-dives")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/deep-dives",
      title: "Fan-chosen Deep Dives — Sideline",
      description: "Weekly breakdowns of the topics Sideline fans voted for, built from real stats, standings and news.",
    }),
  component: DeepDives,
});

function DeepDives() {
  const { data = [], isLoading } = useQuery({
    queryKey: ["deep-dives"],
    queryFn: async () => {
      const { data } = await supabase
        .from("deep_dives")
        .select("id,week,title,body,sources")
        .order("week", { ascending: false })
        .limit(30);
      return data ?? [];
    },
  });
  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Fan Voice</p>
      <h1 className="mt-1 text-3xl font-bold">Deep dives fans chose</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Every week the most-voted topic in <Link to="/fan-voice" className="text-primary underline">Fan Voice</Link> gets a
        full breakdown.
      </p>
      {isLoading && <p className="mt-6 text-sm">Loading…</p>}
      {!isLoading && data.length === 0 && (
        <p className="mt-6 rounded-md border border-border bg-card p-4 text-sm">
          The first deep dive lands next Monday — go vote for the topic.
        </p>
      )}
      <div className="mt-6 space-y-6">
        {data.map((d) => (
          <article key={d.id} className="rounded-md border border-border bg-card p-4">
            <p className="text-[11px] text-muted-foreground">Week of {d.week}</p>
            <h2 className="text-xl font-bold">{d.title}</h2>
            <div className="mt-2 whitespace-pre-line text-sm">{d.body}</div>
            {Array.isArray(d.sources) && d.sources.length > 0 && (
              <p className="mt-3 text-[11px] text-muted-foreground">
                Based on: {(d.sources as string[]).join(" · ")}
              </p>
            )}
          </article>
        ))}
      </div>
    </div>
  );
}
