import { createFileRoute } from "@tanstack/react-router";
import { SportStandingsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-basketball/standings")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-basketball/standings",
      title: "College Basketball Standings — Full Table — Sideline",
      description: "The full College Basketball standings with every team's record, updated as results come in from the live feed.",
      image: leagueOgImage("cbb"),
    }),
  component: () => <SportStandingsSection league="cbb" />,
});
