import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { gamesQueryOptions, newsQueryOptions } from "@/lib/feed";
import type { LeagueId } from "@/data/sports";
import { BASKETBALL_LEAGUES } from "@/components/sport/BasketballSections";
import { pageHead } from "@/lib/seo";
import { useTrackHubVisit } from "@/lib/visits";

export const Route = createFileRoute("/basketball/")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/basketball",
      title: "Basketball — NBA, WNBA & College Scores, Standings, News — Sideline",
      description:
        "One basketball home for the NBA, WNBA and college game: live scores, conference standings and the latest headlines, all updating on their own.",
    }),
  component: BasketballHome,
});

function LeagueCard({ league, label }: { league: LeagueId; label: string }) {
  const { data: games = [] } = useQuery(gamesQueryOptions(league));
  const { data: news } = useQuery(newsQueryOptions(league));
  const live = games.filter((g) => g.status === "live");
  const shown = (live.length ? live : games).slice(0, 4);

  return (
    <section className="rounded-md border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">{label}</h2>
        <Link
          to="/basketball/scores"
          search={{ league }}
          className="text-xs font-semibold text-primary underline"
        >
          All scores
        </Link>
      </div>
      <ul className="mt-3 space-y-2 text-sm">
        {shown.map((g) => (
          <li key={g.id} className="flex items-center justify-between gap-3">
            <span>
              {g.away.name} @ {g.home.name}
            </span>
            <span className="scoreboard text-muted-foreground">
              {g.status === "scheduled" ? "—" : `${g.awayScore}-${g.homeScore}`}
            </span>
          </li>
        ))}
        {shown.length === 0 && <li className="text-muted-foreground">No games on the board.</li>}
      </ul>
      <ul className="mt-4 space-y-1 text-sm">
        {(news?.items ?? []).slice(0, 3).map((n) => (
          <li key={n.id} className="text-muted-foreground">
            {n.headline}
          </li>
        ))}
      </ul>
      <div className="mt-3 flex gap-3 text-xs">
        <Link to="/basketball/standings" search={{ league }} className="font-semibold text-primary underline">
          Standings
        </Link>
        <Link to="/basketball/news" search={{ league }} className="font-semibold text-primary underline">
          News
        </Link>
      </div>
    </section>
  );
}

function BasketballHome() {
  useTrackHubVisit("/basketball", "Basketball Hub");
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">Basketball</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        The NBA, WNBA and college game in one place — live scores, standings and headlines.
      </p>
      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {BASKETBALL_LEAGUES.map((l) => (
          <LeagueCard key={l.id} league={l.id} label={l.label} />
        ))}
      </div>
    </div>
  );
}
