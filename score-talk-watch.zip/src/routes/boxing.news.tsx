import { createFileRoute } from "@tanstack/react-router";
import { IndividualNewsSection } from "@/components/sport/IndividualSections";
import { pageHead } from "@/lib/seo";

export const Route = createFileRoute("/boxing/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/boxing/news",
      title: "Boxing News — Latest Headlines & Results — Sideline",
      description: "The latest Boxing news on Sideline: headlines, results reports and roster updates, refreshed from the live sports wire.",
    }),
  component: () => <IndividualNewsSection sport="boxing" />,
});
