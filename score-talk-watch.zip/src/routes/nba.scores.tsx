import { createFileRoute } from "@tanstack/react-router";
import { SportScoresSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/nba/scores")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/nba/scores",
      title: "NBA Scores — Live & Final — Sideline",
      description: "Live NBA scores with in-game clocks plus every final from the latest slate, refreshing automatically.",
      image: leagueOgImage("nba"),
    }),
  component: () => <SportScoresSection league="nba" />,
});
