import { createFileRoute } from "@tanstack/react-router";
import { SportNewsSection } from "@/components/sport/SportSections";
import { leagueOgImage, pageHead } from "@/lib/seo";

export const Route = createFileRoute("/college-basketball/news")({
  staticData: { sitemap: true },
  head: () =>
    pageHead({
      path: "/college-basketball/news",
      title: "College Basketball News — Latest Headlines & Injuries — Sideline",
      description: "The latest College Basketball news: headlines, injuries, roster moves and matchday reports, refreshed from the live sports wire.",
      image: leagueOgImage("cbb"),
    }),
  component: () => <SportNewsSection league="cbb" />,
});
