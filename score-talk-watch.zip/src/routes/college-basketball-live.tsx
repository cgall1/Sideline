import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, leagueById, type Game } from "@/data/sports";
import { gamesQueryOptions } from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/college-basketball-live`;
const TITLE = "College Basketball Live Scores — Clocks, Arenas & Highlights — Sideline";
const DESCRIPTION =
  "Live college basketball scores with the game clock, arena, TV listing and a highlight video for every NCAA men's basketball matchup on the board right now.";

const VIDEOS = ARTICLES.filter((a) => a.kind === "video");

/** Pick a stable highlight reel for a game: same league first, otherwise rotate. */
function reelFor(game: Game, index: number) {
  const sameLeague = VIDEOS.filter((v) => v.league === game.league);
  const pool = sameLeague.length ? sameLeague : VIDEOS;
  return pool.length ? pool[index % pool.length] : undefined;
}

export const Route = createFileRoute("/college-basketball-live")({
  staticData: { sitemap: true },
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(gamesQueryOptions("cbb"));
  },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: "https://score-talk-watch.lovable.app/og-cover.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Sideline", item: SITE },
            {
              "@type": "ListItem",
              position: 2,
              name: "College Basketball",
              item: `${SITE}/college-basketball`,
            },
            { "@type": "ListItem", position: 3, name: "Live Scores", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  errorComponent: ({ error }) => (
    <div role="alert" className="mx-auto max-w-7xl px-4 py-16">
      The college basketball feed is unavailable: {error.message}
    </div>
  ),
  component: CollegeBasketballLive,
});

function CollegeBasketballLive() {
  const { data: games } = useSuspenseQuery(gamesQueryOptions("cbb"));
  const liveCount = games.filter((g) => g.status === "live").length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <LeagueBadge league="cbb" />
          <h1 className="scoreboard mt-2 text-4xl font-bold uppercase tracking-wide">
            College basketball live scores
          </h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Every NCAA men&apos;s basketball game on the board with its score, clock, arena and a
            highlight reel — refreshed automatically. {liveCount} game
            {liveCount === 1 ? "" : "s"} in progress right now.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link
            to="/college-basketball"
            className="scoreboard rounded-sm border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
          >
            Season calendar
          </Link>
          <Link
            to="/standings"
            search={{ league: "cbb" }}
            className="scoreboard rounded-sm border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
          >
            Standings
          </Link>
        </div>
      </div>

      <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {games.map((g, i) => {
          const reel = reelFor(g, i);
          return (
            <li key={g.id} className="flex flex-col rounded-md border border-border bg-card p-4">
              <div className="mb-2 flex items-center justify-between gap-2">
                <LeagueBadge league={g.league} />
                <span
                  className={cn(
                    "scoreboard text-xs font-bold uppercase",
                    g.status === "live" ? "live-dot text-live" : "text-muted-foreground",
                  )}
                >
                  {g.status === "scheduled" ? g.startLabel : g.clock}
                </span>
              </div>
              <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                <span>{g.away.name}</span>
                <span className="scoreboard text-lg tabular-nums">
                  {g.status === "scheduled" ? "—" : g.awayScore}
                </span>
              </p>
              <p className="flex items-baseline justify-between gap-3 text-sm font-semibold">
                <span>{g.home.name}</span>
                <span className="scoreboard text-lg tabular-nums">
                  {g.status === "scheduled" ? "—" : g.homeScore}
                </span>
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                {g.venue}
                {g.broadcasters.length ? ` · ${g.broadcasters.join(", ")}` : ""}
              </p>
              {reel && (
                <Link
                  to="/media/$slug"
                  params={{ slug: reel.slug }}
                  className="mt-3 block rounded-sm border border-border bg-surface-2 p-2.5 transition-colors hover:border-primary/50"
                >
                  <span className="scoreboard text-[0.7rem] uppercase tracking-widest text-muted-foreground">
                    ▶ Highlights · {leagueById(reel.league)?.short} ·{" "}
                    {reel.duration ?? reel.readTime}
                  </span>
                  <p className="mt-0.5 text-xs font-semibold">{reel.title}</p>
                </Link>
              )}
            </li>
          );
        })}
      </ul>

      {!games.length && (
        <p className="mt-8 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No college basketball games on the board right now. Check the{" "}
          <Link to="/college-basketball" className="underline">
            season calendar
          </Link>{" "}
          for the next tip-off.
        </p>
      )}
    </div>
  );
}
