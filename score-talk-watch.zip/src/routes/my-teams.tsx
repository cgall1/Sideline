import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { gamesQueryOptions, liveSoccerQueryOptions, newsQueryOptions } from "@/lib/feed";
import { useFavorites, type FavoriteTeam } from "@/lib/favorites";
import { sportEventsQueryOptions } from "@/lib/feed";
import { INDIVIDUAL_SPORTS, type SportId } from "@/lib/individual-sports.functions";
import { PushToggle } from "@/components/PushToggle";
import { AccentPicker } from "@/components/AccentPicker";

const SITE = "https://score-talk-watch.lovable.app";
const URL = `${SITE}/my-teams`;
const TITLE = "My Teams — Your Followed Clubs, Scores & News — Sideline";
const DESCRIPTION =
  "Follow any team on Sideline and this page becomes your own feed: live scores and fixtures for your clubs, their latest headlines, and quick links to rosters and team hubs.";

export const Route = createFileRoute("/my-teams")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: URL },
      { property: "og:image", content: `${SITE}/og-cover.jpg` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: `${SITE}/og-cover.jpg` },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: URL }],
  }),
  component: MyTeamsPage,
});

const SPORT_IDS = INDIVIDUAL_SPORTS.map((s) => s.id);

/** Upcoming and live events for the athletes a fan follows in one sport. */
function AthleteEvents({ sport, follows }: { sport: SportId; follows: FavoriteTeam[] }) {
  const { data: events = [] } = useQuery(sportEventsQueryOptions(sport));
  const names = follows.map((f) => f.name.toLowerCase());
  const meta = INDIVIDUAL_SPORTS.find((s) => s.id === sport);
  const mine = events
    .filter((e) => e.competitors.some((c) => names.includes(c.name.toLowerCase())))
    .slice(0, 6);
  if (mine.length === 0) return null;
  return (
    <div className="mt-4">
      <h3 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
        {meta?.name ?? sport}
      </h3>
      <ul className="mt-2 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {mine.map((event) => (
          <li key={event.id} className="rounded-md border border-border bg-card p-4">
            <p className="font-semibold">{event.name}</p>
            <p
              className={`scoreboard mt-1 text-xs uppercase tracking-widest ${
                event.state === "in" ? "text-[color:var(--live)]" : "text-muted-foreground"
              }`}
            >
              {event.status}
            </p>
            <ul className="mt-2 space-y-1 text-sm">
              {event.competitors
                .filter((c) => names.includes(c.name.toLowerCase()))
                .map((c, i) => (
                  <li key={`${event.id}-${i}`} className="flex justify-between gap-3">
                    <span className="font-semibold">{c.name}</span>
                    <span className="scoreboard text-muted-foreground">{c.detail}</span>
                  </li>
                ))}
            </ul>
          </li>
        ))}
      </ul>
    </div>
  );
}

function MyTeamsPage() {
  const { favorites, toggle, synced } = useFavorites();
  const { data: games = [] } = useQuery(gamesQueryOptions("all"));
  const { data: newsFeed } = useQuery(newsQueryOptions("all"));
  const news = newsFeed?.items ?? [];

  const athletes = favorites.filter((f) => (SPORT_IDS as string[]).includes(f.league));
  const clubs = favorites.filter((f) => !(SPORT_IDS as string[]).includes(f.league));
  const athleteSports = [...new Set(athletes.map((f) => f.league as SportId))];
  const names = clubs.map((f) => f.name.toLowerCase());
  const myGames = games.filter(
    (g) => names.includes(g.home.name.toLowerCase()) || names.includes(g.away.name.toLowerCase()),
  );
  const { data: soccerBoard } = useQuery(liveSoccerQueryOptions());
  const mySoccer = (soccerBoard?.matches ?? []).filter(
    (m) => names.includes(m.home.toLowerCase()) || names.includes(m.away.toLowerCase()),
  );
  const myNews = (Array.isArray(news) ? news : []).filter((item) =>
    names.some(
      (n) =>
        item.headline.toLowerCase().includes(n) || (item.summary ?? "").toLowerCase().includes(n),
    ),
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">My teams</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        {synced
          ? "Your followed teams are saved to your account, so they travel with you to any device."
          : "Sign in to keep your followed teams across devices."}{" "}
        {!synced && (
          <Link to="/auth" className="font-semibold text-primary underline">
            Sign in
          </Link>
        )}
      </p>

      <div className="mt-8">
        <AccentPicker />
      </div>

      {favorites.length === 0 ? (
        <p className="mt-8 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          You aren't following anyone yet. Open any{" "}
          <Link to="/directory" className="font-semibold text-primary underline">
            team page
          </Link>{" "}
          and tap “Add to my teams”, or star an athlete on any golf, tennis, UFC, boxing, NASCAR or F1
          page.
        </p>
      ) : (
        <>
          <section className="mt-8">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Following</h2>
            <div className="mt-3 flex flex-wrap gap-2">
              {clubs.map((f) => (
                <span
                  key={`${f.league}-${f.teamId}`}
                  className="flex items-center gap-2 rounded-sm border border-border bg-card px-3 py-2 text-xs font-bold uppercase tracking-widest"
                >
                  {f.logo && <img src={f.logo} alt={`${f.name} logo`} className="h-5 w-5" />}
                  <Link
                    to="/teams/$league/$team"
                    params={{ league: f.league, team: f.teamId }}
                    className="hover:text-primary"
                  >
                    {f.name}
                  </Link>
                  <button
                    onClick={() => toggle(f)}
                    aria-label={`Unfollow ${f.name}`}
                    className="text-muted-foreground hover:text-[color:var(--live)]"
                  >
                    ✕
                  </button>
                </span>
              ))}
            </div>
          </section>

          <section className="mt-10">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              Their games
            </h2>
            {myGames.length === 0 ? (
              <p className="mt-3 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
                None of your teams are playing right now — their next games appear here
                automatically.
              </p>
            ) : (
              <div className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {myGames.map((game) => (
                  <article key={game.id} className="rounded-md border border-border bg-card p-4">
                    <p className="text-xs uppercase tracking-widest text-muted-foreground">
                      {game.startLabel} {game.venue ? `· ${game.venue}` : ""}
                    </p>
                    <p className="mt-2 flex justify-between text-sm font-semibold">
                      <span>{game.away.name}</span>
                      <span className="scoreboard">{game.awayScore}</span>
                    </p>
                    <p className="mt-1 flex justify-between text-sm font-semibold">
                      <span>{game.home.name}</span>
                      <span className="scoreboard">{game.homeScore}</span>
                    </p>
                    <p
                      className={`scoreboard mt-2 text-xs uppercase tracking-widest ${
                        game.status === "live"
                          ? "text-[color:var(--live)]"
                          : "text-muted-foreground"
                      }`}
                    >
                      {game.status === "live" ? `Live · ${game.clock}` : game.status}
                    </p>
                  </article>
                ))}
              </div>
            )}
          </section>

          <section className="mt-10">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              Their soccer matches
            </h2>
            {mySoccer.length === 0 ? (
              <p className="mt-3 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
                No soccer clubs you follow are playing today.
              </p>
            ) : (
              <ul className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {mySoccer.map((m) => (
                  <li key={m.id} className="rounded-md border border-border bg-card p-4">
                    <p className="text-xs uppercase tracking-widest text-muted-foreground">
                      {m.league}
                    </p>
                    <p className="mt-2 flex justify-between text-sm font-semibold">
                      <span>{m.home}</span>
                      <span className="scoreboard">{m.homeScore}</span>
                    </p>
                    <p className="mt-1 flex justify-between text-sm font-semibold">
                      <span>{m.away}</span>
                      <span className="scoreboard">{m.awayScore}</span>
                    </p>
                    <p
                      className={`scoreboard mt-2 text-xs uppercase tracking-widest ${
                        m.status === "live"
                          ? "text-[color:var(--live)]"
                          : "text-muted-foreground"
                      }`}
                    >
                      {m.status === "live" ? `Live · ${m.clock}` : m.detail}
                    </p>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {athletes.length > 0 && (
            <section className="mt-10">
              <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
                Athletes you follow
              </h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {athletes.map((f) => (
                  <span
                    key={`${f.league}-${f.teamId}`}
                    className="flex items-center gap-2 rounded-sm border border-border bg-card px-3 py-2 text-xs font-bold uppercase tracking-widest"
                  >
                    {f.name}
                    <button
                      onClick={() => toggle(f)}
                      aria-label={`Unfollow ${f.name}`}
                      className="text-muted-foreground hover:text-[color:var(--live)]"
                    >
                      ✕
                    </button>
                  </span>
                ))}
              </div>
              {athleteSports.map((sport) => (
                <AthleteEvents
                  key={sport}
                  sport={sport}
                  follows={athletes.filter((f) => f.league === sport)}
                />
              ))}
            </section>
          )}

          <section className="mt-10">

            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
              Alerts for every team you follow
            </h2>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Switch on notifications and Sideline pings your phone at kickoff and at the final
              whistle for every club above — across every sport.
            </p>
            <div className="mt-3">
              <PushToggle />
            </div>
            <Link
              to="/alerts"
              className="mt-3 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
            >
              Manage alerts
            </Link>
          </section>

          <section className="mt-10">
            <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Their news</h2>
            {myNews.length === 0 ? (
              <p className="mt-3 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
                No stories mentioning your teams in the latest news cycle.
              </p>
            ) : (
              <ul className="mt-3 space-y-2">
                {myNews.slice(0, 20).map((item) => (
                  <li key={item.id} className="rounded-md border border-border bg-card p-4">
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold hover:text-primary"
                    >
                      {item.headline}
                    </a>
                    {item.summary && (
                      <p className="mt-1 text-sm text-muted-foreground">{item.summary}</p>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}
