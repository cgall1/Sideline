import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";

const SITE = "https://score-talk-watch.lovable.app";
const PAGE_URL = `${SITE}/golf-trivia`;
const TITLE = "Golf Trivia — PGA Tour & Majors Questions and Answers — Sideline";
const DESCRIPTION =
  "Golf trivia with answers: majors history, Ryder Cup, Augusta National, scoring terms and record books — guess first, then reveal the story behind each answer.";

interface GolfQuestion {
  id: string;
  question: string;
  answer: string;
  detail: string;
  difficulty: "easy" | "medium" | "hard";
}

const QUESTIONS: GolfQuestion[] = [
  {
    id: "golf-1",
    question: "Which four tournaments make up golf's men's majors?",
    answer: "The Masters, PGA Championship, US Open and The Open",
    detail:
      "They run April through July: the Masters at Augusta National, then the PGA Championship, the US Open and The Open Championship.",
    difficulty: "easy",
  },
  {
    id: "golf-2",
    question: "Who has won the most men's professional majors?",
    answer: "Jack Nicklaus, with 18",
    detail: "Nicklaus won his first at the 1962 US Open and his last at the 1986 Masters, aged 46.",
    difficulty: "easy",
  },
  {
    id: "golf-3",
    question: "What is an albatross?",
    answer: "Three under par on a single hole",
    detail: "Also called a double eagle — usually a hole-out from the fairway on a par five.",
    difficulty: "medium",
  },
  {
    id: "golf-4",
    question: "Which course hosts the Masters every year?",
    answer: "Augusta National Golf Club",
    detail: "The Georgia course has hosted every Masters since 1934, apart from three war years.",
    difficulty: "easy",
  },
  {
    id: "golf-5",
    question: "By how many shots did Tiger Woods win the 1997 Masters?",
    answer: "Twelve",
    detail: "At 21 he became the youngest Masters champion, finishing 18 under par — a record at the time.",
    difficulty: "medium",
  },
  {
    id: "golf-6",
    question: "What is the Ryder Cup?",
    answer: "A biennial team match between the United States and Europe",
    detail: "First played in 1927 against Great Britain; continental Europe joined the team in 1979.",
    difficulty: "easy",
  },
  {
    id: "golf-7",
    question: "Which course is known as the home of golf?",
    answer: "The Old Course at St Andrews",
    detail: "Golf has been played on the Scottish links since the 1500s; it regularly hosts The Open.",
    difficulty: "easy",
  },
  {
    id: "golf-8",
    question: "What does a links course actually mean?",
    answer: "A coastal course on sandy ground between beach and farmland",
    detail: "Firm turf, deep pot bunkers and wind define true links golf, mostly found in Britain and Ireland.",
    difficulty: "medium",
  },
  {
    id: "golf-9",
    question: "What is the green jacket awarded for?",
    answer: "Winning the Masters",
    detail: "The champion receives it from the previous winner and keeps it for a year before returning it to Augusta.",
    difficulty: "easy",
  },
  {
    id: "golf-10",
    question: "What is the maximum number of clubs allowed in a player's bag?",
    answer: "Fourteen",
    detail: "Carrying more brings a two-stroke penalty per hole, capped at four strokes in stroke play.",
    difficulty: "medium",
  },
  {
    id: "golf-11",
    question: "What is the lowest score ever shot on the PGA Tour in a single round?",
    answer: "58",
    detail: "Jim Furyk shot 58 in the final round of the 2016 Travelers Championship.",
    difficulty: "hard",
  },
  {
    id: "golf-12",
    question: "Which trophy goes to The Open champion?",
    answer: "The Claret Jug",
    detail: "Officially the Golf Champion Trophy, first awarded in 1873 to Tom Kidd.",
    difficulty: "medium",
  },
  {
    id: "golf-13",
    question: "What does the term bogey mean?",
    answer: "One over par on a hole",
    detail: "Double bogey is two over, triple bogey three over; birdie and eagle go the other way.",
    difficulty: "easy",
  },
  {
    id: "golf-14",
    question: "Which women's team event mirrors the Ryder Cup?",
    answer: "The Solheim Cup",
    detail: "Played every two years between the United States and Europe, first contested in 1990.",
    difficulty: "medium",
  },
  {
    id: "golf-15",
    question: "Who is the youngest player to win a men's major in the modern era?",
    answer: "Tiger Woods at the 1997 Masters",
    detail: "He was 21 years and three months old. Young Tom Morris won The Open at 17 back in 1868.",
    difficulty: "hard",
  },
  {
    id: "golf-16",
    question: "What is the FedExCup?",
    answer: "The PGA Tour's season-long points race",
    detail: "Points accumulate all season and the standings reset for the playoffs, ending at the Tour Championship.",
    difficulty: "medium",
  },
  {
    id: "golf-17",
    question: "How deep is a regulation golf hole?",
    answer: "At least four inches",
    detail: "The cup is 4.25 inches wide and must be sunk at least four inches below the putting surface.",
    difficulty: "hard",
  },
  {
    id: "golf-18",
    question: "What is a shotgun start?",
    answer: "Groups begin at the same time from different holes",
    detail: "It gets a full field around the course in one window — common in pro-ams and charity events.",
    difficulty: "medium",
  },
  {
    id: "golf-19",
    question: "Which golfer is nicknamed the Golden Bear?",
    answer: "Jack Nicklaus",
    detail: "The nickname came from his school colours and build, and now marks his course design business.",
    difficulty: "easy",
  },
  {
    id: "golf-20",
    question: "What happens when a men's major finishes in a tie?",
    answer: "A playoff decides it, and the format varies by major",
    detail:
      "The Masters uses sudden death, the PGA Championship a three-hole aggregate, The Open four holes and the US Open two.",
    difficulty: "hard",
  },
];

export const Route = createFileRoute("/golf-trivia")({
  staticData: { sitemap: true },
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: PAGE_URL },
      { property: "og:image", content: `${SITE}/og-cover.jpg` },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Sideline — live sports scores, standings, highlights and fan chat" },
      { name: "twitter:image", content: `${SITE}/og-cover.jpg` },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      { name: "twitter:description", content: DESCRIPTION },
    ],
    links: [{ rel: "canonical", href: PAGE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Quiz",
          name: "Golf Trivia",
          url: PAGE_URL,
          about: { "@type": "Thing", name: "Golf" },
          hasPart: QUESTIONS.map((q) => ({
            "@type": "Question",
            eduQuestionType: "Flashcard",
            name: q.question,
            acceptedAnswer: { "@type": "Answer", text: `${q.answer}. ${q.detail}` },
          })),
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: SITE },
            { "@type": "ListItem", position: 2, name: "News", item: `${SITE}/news` },
            { "@type": "ListItem", position: 3, name: "Golf Trivia", item: PAGE_URL },
          ],
        }),
      },
    ],
  }),
  component: GolfTrivia,
});

function GolfTrivia() {
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const allShown = QUESTIONS.every((q) => revealed[q.id]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">Golf trivia</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
        {QUESTIONS.length} golf questions — majors history, Augusta, the Ryder Cup, scoring terms and
        the record books. Guess first, then reveal the answer.
      </p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <button
          onClick={() =>
            setRevealed(allShown ? {} : Object.fromEntries(QUESTIONS.map((q) => [q.id, true])))
          }
          className="scoreboard rounded-sm border border-border px-3 py-1.5 text-muted-foreground transition-colors hover:text-foreground"
        >
          {allShown ? "Hide all answers" : "Reveal all answers"}
        </button>
        <Link to="/golf" className="self-center text-primary underline">
          Leaderboards &amp; schedule
        </Link>
        <Link to="/trivia" className="self-center text-primary underline">
          All sports trivia
        </Link>
      </div>

      <ol className="mt-6 space-y-3">
        {QUESTIONS.map((q, i) => {
          const open = Boolean(revealed[q.id]);
          return (
            <li key={q.id} className="rounded-md border border-border bg-card p-4">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">
                Golf · {q.difficulty}
              </p>
              <h2 className="mt-2 text-lg font-bold leading-snug">
                {i + 1}. {q.question}
              </h2>
              <button
                onClick={() => setRevealed((prev) => ({ ...prev, [q.id]: !open }))}
                aria-expanded={open}
                className="scoreboard mt-3 rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:text-foreground"
              >
                {open ? "Hide answer" : "Show answer"}
              </button>
              {open && (
                <div className="mt-3 border-l-2 border-primary pl-3">
                  <p className="scoreboard text-lg font-bold uppercase tracking-wide text-primary">
                    {q.answer}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{q.detail}</p>
                </div>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}
