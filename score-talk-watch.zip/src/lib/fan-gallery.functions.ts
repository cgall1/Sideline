import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const PathsInput = z.object({ paths: z.array(z.string().min(1).max(300)).max(120) });

/**
 * Viewable links for gallery images. Files stay private in storage — only the
 * uploader can read them directly — so the server signs short-lived links for
 * the pictures fans have chosen to share.
 */
export const fetchFanImageUrls = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => PathsInput.parse(input))
  .handler(async ({ data }): Promise<Record<string, string>> => {
    if (!data.paths.length) return {};
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error: rowsError } = await supabaseAdmin
      .from("fan_posts")
      .select("image_path")
      .in("image_path", data.paths)
      .eq("hidden", false);
    if (rowsError) {
      console.error("fetchFanImageUrls post lookup failed", rowsError);
      throw new Error("Could not load gallery images");
    }
    const allowed = (rows ?? []).map((r) => r.image_path);
    if (!allowed.length) return {};

    const { data: signed, error } = await supabaseAdmin.storage
      .from("fan-gallery")
      .createSignedUrls(allowed, 60 * 60);
    if (error) {
      console.error("fetchFanImageUrls signing failed", error);
      throw new Error("Could not load gallery images");
    }
    const out: Record<string, string> = {};
    for (const s of signed ?? []) {
      if (s.path && s.signedUrl) out[s.path] = s.signedUrl;
    }
    return out;
  });

export interface FanLikeCount {
  post_id: string;
  likes: number;
}

/** Anonymous like totals for gallery posts (who liked what stays private). */
export const fetchFanPostLikeCounts = createServerFn({ method: "GET" }).handler(
  async (): Promise<FanLikeCount[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("fan_post_like_counts");
    if (error) {
      console.error("fetchFanPostLikeCounts failed", error);
      throw new Error("Could not load like counts");
    }
    return (data ?? []).map((r) => ({ post_id: r.post_id, likes: Number(r.likes) }));
  },
);
