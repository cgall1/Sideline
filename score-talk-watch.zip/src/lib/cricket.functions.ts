import { createServerFn } from "@tanstack/react-start";

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface CricketSeries {
  id: string;
  name: string;
  endDate: string;
  hasStandings: boolean;
}

export interface CricketInnings {
  team: string;
  logo: string | null;
  score: string;
  winner: boolean;
}

export interface CricketMatch {
  id: string;
  seriesId: string;
  series: string;
  name: string;
  note: string;
  date: string;
  venue: string;
  format: string;
  state: "pre" | "in" | "post";
  status: string;
  teams: CricketInnings[];
}

export interface CricketStory {
  id: string;
  headline: string;
  summary: string;
  url: string;
  published: string;
}

export interface CricketTableRow {
  team: string;
  logo: string | null;
  rank: number;
  played: number;
  won: number;
  lost: number;
  points: number;
  note: string;
}

export interface CricketTable {
  seriesId: string;
  series: string;
  rows: CricketTableRow[];
}

const DROPDOWN =
  "https://site.web.api.espn.com/apis/site/v2/leagues/dropdown?sport=cricket&lang=en&region=us";

async function json(url: string): Promise<any | null> {
  const res = await fetch(url, { headers: { accept: "application/json" } }).catch(() => null);
  if (!res || !res.ok) return null;
  return res.json().catch(() => null);
}

/** Series that are running now or wrapped up in the last few weeks. */
async function activeSeries(limit: number): Promise<CricketSeries[]> {
  const payload = await json(DROPDOWN);
  const leagues: any[] = Array.isArray(payload?.leagues) ? payload.leagues : [];
  const floor = Date.now() - 21 * 86_400_000;
  return leagues
    .map((l): CricketSeries | null => {
      const end = l?.season?.endDate;
      if (typeof end !== "string" || typeof l?.id !== "string") return null;
      const t = Date.parse(end.replace("Z", "+00:00"));
      if (!Number.isFinite(t) || t < floor) return null;
      return {
        id: l.id,
        name: typeof l.name === "string" ? l.name : "Cricket series",
        endDate: end,
        hasStandings: Boolean(l?.season?.type?.hasStandings),
      };
    })
    .filter((s): s is CricketSeries => s !== null)
    .sort((a, b) => a.endDate.localeCompare(b.endDate))
    .slice(0, limit);
}

/** Cricket series running right now, most imminent finish first. */
export const fetchCricketSeries = createServerFn({ method: "GET" }).handler(
  async (): Promise<CricketSeries[]> => activeSeries(30),
);

function dayKey(offset: number): string {
  const d = new Date(Date.now() + offset * 86_400_000);
  return `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, "0")}${String(
    d.getUTCDate(),
  ).padStart(2, "0")}`;
}

function parseEvent(event: any, series: CricketSeries): CricketMatch | null {
  const id = typeof event?.id === "string" ? event.id : null;
  if (!id) return null;
  const comp = Array.isArray(event?.competitions) ? event.competitions[0] : null;
  const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
  const stateRaw = event?.status?.type?.state;
  const state: CricketMatch["state"] =
    stateRaw === "in" ? "in" : stateRaw === "post" ? "post" : "pre";
  return {
    id,
    seriesId: series.id,
    series: series.name,
    name: typeof event?.name === "string" ? event.name : "",
    note: typeof comp?.status?.type?.detail === "string" ? comp.status.type.detail : "",
    date: typeof event?.date === "string" ? event.date : "",
    venue: typeof comp?.venue?.fullName === "string" ? comp.venue.fullName : "",
    format: typeof comp?.class?.eventType === "string" ? comp.class.eventType : "",
    state,
    status:
      typeof event?.status?.type?.shortDetail === "string"
        ? event.status.type.shortDetail
        : typeof event?.status?.type?.description === "string"
          ? event.status.type.description
          : "",
    teams: competitors.map((c) => ({
      team:
        typeof c?.team?.displayName === "string" ? c.team.displayName : String(c?.team?.name ?? ""),
      logo: typeof c?.team?.logo === "string" ? c.team.logo : null,
      score: typeof c?.score === "string" ? c.score : "",
      winner: c?.winner === "true" || c?.winner === true,
    })),
  };
}

/** Live, just-finished and upcoming cricket matches across the active series. */
export const fetchCricketBoard = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ updated: string; matches: CricketMatch[] }> => {
    const series = (await activeSeries(30)).slice(0, 6);
    const days = [-2, -1, 0, 1, 2].map(dayKey);
    const results = await Promise.all(
      series.flatMap((s) =>
        days.map(async (d) => {
          const payload = await json(
            `https://site.api.espn.com/apis/site/v2/sports/cricket/${s.id}/scoreboard?dates=${d}`,
          );
          const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
          return events.map((e) => parseEvent(e, s)).filter((m): m is CricketMatch => m !== null);
        }),
      ),
    );
    const byId = new Map<string, CricketMatch>();
    for (const m of results.flat()) byId.set(m.id, m);
    const order = { in: 0, pre: 1, post: 2 } as const;
    const matches = [...byId.values()].sort(
      (a, b) => order[a.state] - order[b.state] || a.date.localeCompare(b.date),
    );
    return { updated: new Date().toISOString(), matches };
  },
);

/** League table for one cricket series — fills in as results are published. */
export const fetchCricketStandings = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = (data as { seriesId?: unknown } | undefined)?.seriesId;
    const id = typeof raw === "string" && /^\d{1,9}$/.test(raw) ? raw : "";
    return { seriesId: id };
  })
  .handler(async ({ data }): Promise<CricketTable> => {
    const list = await activeSeries(30);
    const series =
      list.find((s) => s.id === data.seriesId) ?? list.find((s) => s.hasStandings) ?? list[0];
    if (!series) return { seriesId: "", series: "", rows: [] };

    const payload = await json(
      `https://site.web.api.espn.com/apis/v2/sports/cricket/${series.id}/standings`,
    );
    const children: any[] = Array.isArray(payload?.children) ? payload.children : [];
    const entries: any[] = children.length
      ? children.flatMap((c) => (Array.isArray(c?.standings?.entries) ? c.standings.entries : []))
      : Array.isArray(payload?.standings?.entries)
        ? payload.standings.entries
        : [];

    const stat = (stats: any[], name: string): number => {
      const s = stats.find((x) => x?.name === name || x?.abbreviation === name);
      const v = s?.value;
      return typeof v === "number" ? v : Number(s?.displayValue ?? 0) || 0;
    };

    const rows: CricketTableRow[] = entries
      .map((entry, i): CricketTableRow | null => {
        const team = typeof entry?.team?.displayName === "string" ? entry.team.displayName : "";
        if (!team) return null;
        const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
        return {
          team,
          logo: typeof entry?.team?.logo === "string" ? entry.team.logo : null,
          rank: i + 1,
          played: stat(stats, "gamesPlayed") || stat(stats, "GP"),
          won: stat(stats, "wins") || stat(stats, "W"),
          lost: stat(stats, "losses") || stat(stats, "L"),
          points: stat(stats, "points") || stat(stats, "PTS"),
          note: typeof entry?.note?.description === "string" ? entry.note.description : "",
        };
      })
      .filter((r): r is CricketTableRow => r !== null)
      .sort((a, b) => b.points - a.points || b.won - a.won)
      .map((r, i) => ({ ...r, rank: i + 1 }));

    if (rows.length) return { seriesId: series.id, series: series.name, rows };

    // No published table yet — build one from the results that have landed.
    return {
      seriesId: series.id,
      series: series.name,
      rows: await tallyFromResults(series),
    };
  });

/** Tally a table from completed matches so it fills in as results arrive. */
async function tallyFromResults(series: CricketSeries): Promise<CricketTableRow[]> {
  const days = Array.from({ length: 21 }, (_, i) => dayKey(-i));
  const payloads = await Promise.all(
    days.map((d) =>
      json(`https://site.api.espn.com/apis/site/v2/sports/cricket/${series.id}/scoreboard?dates=${d}`),
    ),
  );
  const matches = new Map<string, CricketMatch>();
  for (const payload of payloads) {
    const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
    for (const e of events) {
      const m = parseEvent(e, series);
      if (m && m.state === "post") matches.set(m.id, m);
    }
  }

  const table = new Map<string, CricketTableRow>();
  const row = (team: string, logo: string | null) => {
    const existing = table.get(team);
    if (existing) return existing;
    const fresh: CricketTableRow = {
      team,
      logo,
      rank: 0,
      played: 0,
      won: 0,
      lost: 0,
      points: 0,
      note: "",
    };
    table.set(team, fresh);
    return fresh;
  };

  for (const m of matches.values()) {
    if (m.teams.length < 2) continue;
    for (const side of m.teams) {
      if (!side.team) continue;
      const r = row(side.team, side.logo);
      r.played += 1;
      if (side.winner) {
        r.won += 1;
        r.points += 2;
      }
    }
    const decided = m.teams.some((t) => t.winner);
    if (decided) {
      for (const side of m.teams) {
        if (side.team && !side.winner) row(side.team, side.logo).lost += 1;
      }
    } else {
      // No result (tie, no-result, abandoned): a point each.
      for (const side of m.teams) if (side.team) row(side.team, side.logo).points += 1;
    }
  }

  return [...table.values()]
    .sort((a, b) => b.points - a.points || b.won - a.won || a.team.localeCompare(b.team))
    .map((r, i) => ({ ...r, rank: i + 1, note: "From results so far" }));
}

/** Cricket headlines from the wire covering the active series. */
export const fetchCricketNews = createServerFn({ method: "GET" }).handler(
  async (): Promise<CricketStory[]> => {
    const series = (await activeSeries(30)).slice(0, 3);
    const ids = series.length ? series.map((s) => s.id) : ["8048"];
    const chunks = await Promise.all(
      ids.map(async (id) => {
        const payload = await json(
          `https://site.api.espn.com/apis/site/v2/sports/cricket/${id}/news`,
        );
        const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];
        return articles.map((a, i): CricketStory => {
          const web = a?.links?.web?.href;
          return {
            id: `${id}-${a?.id ?? i}`,
            headline: typeof a?.headline === "string" ? a.headline : "",
            summary: typeof a?.description === "string" ? a.description : "",
            url: typeof web === "string" && web.startsWith("https://") ? web : "",
            published: typeof a?.published === "string" ? a.published : "",
          };
        });
      }),
    );
    const seen = new Set<string>();
    return chunks
      .flat()
      .filter((s) => s.headline && s.url && !seen.has(s.headline) && seen.add(s.headline))
      .sort((a, b) => b.published.localeCompare(a.published))
      .slice(0, 24);
  },
);
