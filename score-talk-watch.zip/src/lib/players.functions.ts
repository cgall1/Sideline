import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface PlayerStatRow {
  season: string;
  team: string;
  values: string[];
}

export interface PlayerStatCategory {
  name: string;
  labels: string[];
  rows: PlayerStatRow[];
}

export interface PlayerProfile {
  id: string;
  league: LeagueId;
  name: string;
  jersey: string;
  position: string;
  team: string;
  teamId: string;
  headshot: string | null;
  height: string;
  weight: string;
  age: string;
  birthPlace: string;
  college: string;
  experience: string;
  draft: string;
  status: string;
  link: string | null;
  summary: { label: string; value: string }[];
  categories: PlayerStatCategory[];
}

export interface InjuryEntry {
  team: string;
  teamId: string;
  player: string;
  playerId: string;
  position: string;
  status: string;
  detail: string;
  date: string;
  link: string | null;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/eng.1",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

/* eslint-disable @typescript-eslint/no-explicit-any */

/** One player's bio and season-by-season stat lines. */
export const fetchPlayerProfile = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; playerId?: unknown } | undefined;
    return {
      league: asLeague(raw?.league),
      playerId: typeof raw?.playerId === "string" ? raw.playerId : "",
    };
  })
  .handler(async ({ data }): Promise<PlayerProfile | null> => {
    const path = ESPN_PATH[data.league];
    const base = `https://site.web.api.espn.com/apis/common/v3/sports/${path}/athletes/${encodeURIComponent(data.playerId)}`;
    const [bioRes, statsRes] = await Promise.all([
      fetch(base, { headers: { accept: "application/json" } }).catch(() => null),
      fetch(`${base}/stats`, { headers: { accept: "application/json" } }).catch(() => null),
    ]);
    if (!bioRes || !bioRes.ok) return null;
    const bioPayload: any = await bioRes.json().catch(() => null);
    const a: any = bioPayload?.athlete;
    if (!a) return null;

    const statsPayload: any = statsRes && statsRes.ok ? await statsRes.json().catch(() => null) : null;
    const teams: Record<string, any> = statsPayload?.teams ?? {};
    const teamNameById = new Map<string, string>();
    for (const value of Object.values(teams)) {
      const t: any = value;
      if (t?.id) teamNameById.set(String(t.id), str(t?.displayName, str(t?.abbreviation, "")));
    }

    const categories: PlayerStatCategory[] = (Array.isArray(statsPayload?.categories)
      ? statsPayload.categories
      : []
    )
      .map((c: any): PlayerStatCategory => ({
        name: str(c?.displayName, str(c?.name, "Stats")),
        labels: Array.isArray(c?.labels) ? c.labels.map((l: any) => String(l)) : [],
        rows: (Array.isArray(c?.statistics) ? c.statistics : [])
          .map((s: any): PlayerStatRow => ({
            season: str(s?.season?.displayName, str(s?.season?.year ? String(s.season.year) : "")),
            team: teamNameById.get(String(s?.teamId)) ?? "",
            values: Array.isArray(s?.stats) ? s.stats.map((v: any) => String(v)) : [],
          }))
          .filter((r: PlayerStatRow) => r.season.length > 0)
          .reverse(),
      }))
      .filter((c: PlayerStatCategory) => c.rows.length > 0);

    const summary = (Array.isArray(a?.statsSummary?.statistics) ? a.statsSummary.statistics : []).map(
      (s: any) => ({ label: str(s?.displayName, str(s?.name, "")), value: str(s?.displayValue, "—") }),
    );

    return {
      id: str(a?.id, data.playerId),
      league: data.league,
      name: str(a?.displayName, str(a?.fullName, "Player")),
      jersey: str(a?.displayJersey, a?.jersey ? `#${a.jersey}` : "—"),
      position: str(a?.position?.displayName, str(a?.position?.abbreviation, "—")),
      team: str(a?.team?.displayName, ""),
      teamId: str(a?.team?.id ? String(a.team.id) : ""),
      headshot: str(a?.headshot?.href) || null,
      height: str(a?.displayHeight, "—"),
      weight: str(a?.displayWeight, "—"),
      age: typeof a?.age === "number" ? String(a.age) : "—",
      birthPlace: str(a?.displayBirthPlace, "—"),
      college: str(a?.college?.name, str(a?.collegeTeam?.displayName, "—")),
      experience: str(a?.displayExperience, "—"),
      draft: str(a?.displayDraft, "—"),
      status: str(a?.status?.name, a?.active ? "Active" : "—"),
      link:
        str(
          (Array.isArray(a?.links) ? a.links : []).find((l: any) => typeof l?.href === "string")?.href,
        ) || null,
      summary,
      categories,
    };
  });

/** Every current injury in a league, grouped-ready by team. */
export const fetchLeagueInjuries = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown } | undefined;
    return { league: asLeague(raw?.league) };
  })
  .handler(async ({ data }): Promise<InjuryEntry[]> => {
    const path = ESPN_PATH[data.league];
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${path}/injuries`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return [];
    const payload: any = await res.json().catch(() => null);
    const teams: any[] = Array.isArray(payload?.injuries) ? payload.injuries : [];
    const out: InjuryEntry[] = [];
    for (const team of teams) {
      const teamName = str(team?.displayName, "Team");
      const teamId = str(team?.id ? String(team.id) : "");
      for (const inj of Array.isArray(team?.injuries) ? team.injuries : []) {
        const athlete: any = inj?.athlete;
        const name = str(athlete?.displayName);
        if (!name) continue;
        out.push({
          team: teamName,
          teamId,
          player: name,
          playerId: str(athlete?.id ? String(athlete.id) : ""),
          position: str(athlete?.position?.abbreviation, str(athlete?.position?.displayName, "—")),
          status: str(inj?.status, "—"),
          detail: str(inj?.longComment, str(inj?.shortComment, "")),
          date: str(inj?.date, ""),
          link:
            str(
              (Array.isArray(athlete?.links) ? athlete.links : []).find(
                (l: any) => typeof l?.href === "string",
              )?.href,
            ) || null,
        });
      }
    }
    return out.sort((a, b) => a.team.localeCompare(b.team) || a.player.localeCompare(b.player));
  });
