import { getMyFanStanding } from "@/lib/standing.functions";
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { publicCounts } from "@/lib/public-counts.functions";

export interface Debate {
  id: string;
  date: string;
  question: string;
  context: string;
  sideA: string;
  sideB: string;
  league: string | null;
  source: string;
  link: string | null;
  suggestedBy: string | null;
  votesA: number;
  votesB: number;
  myVote: "a" | "b" | null;
}

async function loadDebates(userId: string | null): Promise<Debate[]> {
  const [rowsRes, countsRes, mineRes] = await Promise.all([
    supabase
      .from("daily_debates")
      .select("id, debate_date, question, context, side_a, side_b, league, source, link, suggested_by")
      .order("debate_date", { ascending: false })
      .limit(30),
    (publicCounts({ data: { fn: "debate_vote_counts" } }) as Promise<{ data: any[] | null; error: any }>),
    userId
      ? supabase.from("debate_votes").select("debate_id, side").eq("user_id", userId)
      : Promise.resolve({ data: [] as { debate_id: string; side: string }[], error: null }),
  ]);
  if (rowsRes.error) throw rowsRes.error;

  const counts = new Map<string, { a: number; b: number }>();
  for (const row of countsRes.data ?? []) {
    const entry = counts.get(row.debate_id) ?? { a: 0, b: 0 };
    if (row.side === "a") entry.a = Number(row.total);
    else entry.b = Number(row.total);
    counts.set(row.debate_id, entry);
  }
  const mine = new Map<string, "a" | "b">();
  for (const row of mineRes.data ?? []) mine.set(row.debate_id, row.side === "b" ? "b" : "a");

  return (rowsRes.data ?? []).map((r) => ({
    id: r.id,
    date: r.debate_date,
    question: r.question,
    context: r.context,
    sideA: r.side_a,
    sideB: r.side_b,
    league: r.league,
    source: r.source,
    link: r.link,
    suggestedBy: r.suggested_by,
    votesA: counts.get(r.id)?.a ?? 0,
    votesB: counts.get(r.id)?.b ?? 0,
    myVote: mine.get(r.id) ?? null,
  }));
}

export const debatesQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["debates", userId ?? "anon"],
    queryFn: () => loadDebates(userId),
    staleTime: 30_000,
  });

/** Records a day of activity and re-checks badges. Safe to call after any write. */
export async function recordFanActivity() {
  await supabase.rpc("record_fan_activity");
  await supabase.rpc("refresh_fan_badges");
}

export async function voteDebate(debateId: string, userId: string, side: "a" | "b") {
  const { error } = await supabase
    .from("debate_votes")
    .upsert({ debate_id: debateId, user_id: userId, side }, { onConflict: "debate_id,user_id" });
  if (error) throw error;
  await recordFanActivity();
}

export interface FanStanding {
  currentDays: number;
  longestDays: number;
  badges: string[];
}

export const BADGE_LABELS: Record<string, string> = {
  first_post: "First post",
  ten_posts: "10 posts",
  ten_replies: "10 replies",
  gallery: "Gallery contributor",
  debater: "Debater",
  debate_regular: "Debate regular",
  picker: "Predictor",
  five_teams: "Five clubs followed",
  week_streak: "7-day streak",
  debate_picked: "Debate picked",
  deep_dive_chosen: "Deep dive chosen",
  top_question: "Top question",
  month_streak: "30-day streak",
  fan_of_week: "Fan of the week",
  best_predictor_week: "Best predictor of the week",
};

async function loadFanStanding(_userId: string): Promise<FanStanding> {
  // Streaks are private: the server only ever returns the signed-in fan's own.
  const { data } = await getMyFanStanding();
  const row = data?.[0];
  return {
    currentDays: row?.current_days ?? 0,
    longestDays: row?.longest_days ?? 0,
    badges: row?.badges ?? [],
  };
}

export const fanStandingQueryOptions = (userId: string) =>
  queryOptions({
    queryKey: ["fan-standing", userId],
    queryFn: () => loadFanStanding(userId),
    staleTime: 60_000,
  });

export interface FanNotification {
  id: string;
  kind: string;
  actor: string;
  body: string;
  postId: string | null;
  read: boolean;
  createdAt: string;
}

async function loadNotifications(userId: string | null): Promise<FanNotification[]> {
  if (!userId) return [];
  const { data, error } = await supabase
    .from("space_notifications")
    .select("id, kind, actor_name, body, post_id, read, created_at")
    .order("created_at", { ascending: false })
    .limit(30);
  if (error) throw error;
  return (data ?? []).map((n) => ({
    id: n.id,
    kind: n.kind,
    actor: n.actor_name,
    body: n.body,
    postId: n.post_id,
    read: n.read,
    createdAt: n.created_at,
  }));
}

export const notificationsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["notifications", userId ?? "anon"],
    queryFn: () => loadNotifications(userId),
    staleTime: 30_000,
    refetchInterval: 60_000,
  });

export async function markNotificationsRead(userId: string) {
  await supabase
    .from("space_notifications")
    .update({ read: true })
    .eq("user_id", userId)
    .eq("read", false);
}
