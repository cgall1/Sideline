/**
 * ESPN identifiers are short, opaque slugs. Callers can only ever ask for a
 * value that looks like one, so a public page can never steer our outbound
 * requests at some other resource or host.
 */
const ESPN_ID = /^[A-Za-z0-9._~-]{1,40}$/;

export function safeEspnId(value: unknown): string {
  const id = typeof value === "string" ? value.trim() : "";
  return ESPN_ID.test(id) ? id : "";
}
