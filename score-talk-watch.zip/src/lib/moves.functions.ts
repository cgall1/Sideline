import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface MoveItem {
  id: string;
  headline: string;
  summary: string;
  url: string;
  published: string;
  kind: string;
}

const ESPN_PATH: Record<string, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/eng.1",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
};

const KINDS: Array<{ kind: string; words: string[] }> = [
  { kind: "Trade", words: ["trade", "traded", "trades", "deal for", "acquire", "acquired"] },
  { kind: "Signing", words: ["sign", "signs", "signed", "signing", "contract", "extension", "re-sign"] },
  { kind: "Transfer", words: ["transfer", "loan", "move to"] },
  { kind: "Release", words: ["waive", "waived", "release", "released", "cut", "claim"] },
  { kind: "Roster move", words: ["call-up", "activated", "injured reserve", "roster", "promoted"] },
];

/** Trades, signings and other roster moves reported across a league. */
export const fetchLeagueMoves = createServerFn({ method: "GET" })
  .inputValidator((input: { league: string }) => input)
  .handler(async ({ data }): Promise<MoveItem[]> => {
    const path = ESPN_PATH[data.league] ?? ESPN_PATH["nfl"]!;
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${path}/news?limit=50`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return [];
    /* eslint-disable @typescript-eslint/no-explicit-any */
    const payload: any = await res.json();
    const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];

    const items: MoveItem[] = [];
    for (const a of articles) {
      const headline = typeof a?.headline === "string" ? a.headline : "";
      const summary = typeof a?.description === "string" ? a.description : "";
      const url =
        typeof a?.links?.web?.href === "string"
          ? a.links.web.href
          : typeof a?.links?.mobile?.href === "string"
            ? a.links.mobile.href
            : "";
      if (!headline || !url) continue;
      const haystack = `${headline} ${summary}`.toLowerCase();
      const match = KINDS.find((k) => k.words.some((w) => haystack.includes(w)));
      if (!match) continue;
      items.push({
        id: String(a?.id ?? headline),
        headline,
        summary,
        url,
        published: typeof a?.published === "string" ? a.published : "",
        kind: match.kind,
      });
    }
    return items.slice(0, 30);
  });
