import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface AlertPrefs {
  email: string;
  gameStart: boolean;
  finalScore: boolean;
  breakingNews: boolean;
  predictionsUpdates: boolean;
  weeklyRecap: boolean;
  leagues: string[];
  premiumInterest: boolean;
  /** Push a notification whenever the score changes in a followed game. */
  scoreUpdates: boolean;
  /** Hold notifications back overnight. */
  quietEnabled: boolean;
  quietStart: number;
  quietEnd: number;
  /** Minutes to add to UTC to reach the fan's local time. */
  tzOffset: number;
}

export const EMPTY_PREFS: AlertPrefs = {
  email: "",
  gameStart: true,
  finalScore: true,
  breakingNews: false,
  predictionsUpdates: true,
  weeklyRecap: false,
  leagues: [],
  premiumInterest: false,
  scoreUpdates: true,
  quietEnabled: false,
  quietStart: 22,
  quietEnd: 8,
  tzOffset: 0,
};

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapRow(row: any): AlertPrefs {
  return {
    email: row.email ?? "",
    gameStart: !!row.game_start,
    finalScore: !!row.final_score,
    breakingNews: !!row.breaking_news,
    predictionsUpdates: !!row.predictions_updates,
    weeklyRecap: !!row.weekly_recap,
    leagues: Array.isArray(row.leagues) ? row.leagues : [],
    premiumInterest: !!row.premium_interest,
    scoreUpdates: row.score_updates !== false,
    quietEnabled: !!row.quiet_enabled,
    quietStart: Number(row.quiet_start ?? 22),
    quietEnd: Number(row.quiet_end ?? 8),
    tzOffset: Number(row.tz_offset ?? 0),
  };
}

/** This fan's saved email alert preferences (null when they haven't set any). */
export const alertPrefsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["alert-prefs", userId ?? "anon"],
    queryFn: async (): Promise<AlertPrefs | null> => {
      if (!userId) return null;
      const { data, error } = await supabase
        .from("alert_preferences")
        .select("*")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) throw error;
      return data ? mapRow(data) : null;
    },
    staleTime: 60_000,
  });

export async function saveAlertPrefs(userId: string, prefs: AlertPrefs) {
  const { error } = await supabase.from("alert_preferences").upsert(
    {
      user_id: userId,
      email: prefs.email,
      game_start: prefs.gameStart,
      final_score: prefs.finalScore,
      breaking_news: prefs.breakingNews,
      predictions_updates: prefs.predictionsUpdates,
      weekly_recap: prefs.weeklyRecap,
      leagues: prefs.leagues,
      premium_interest: prefs.premiumInterest,
      score_updates: prefs.scoreUpdates,
      quiet_enabled: prefs.quietEnabled,
      quiet_start: prefs.quietStart,
      quiet_end: prefs.quietEnd,
      tz_offset: prefs.tzOffset,
    },
    { onConflict: "user_id" },
  );
  if (error) throw error;
}
