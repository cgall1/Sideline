import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface ScheduleGame {
  id: string;
  league: LeagueId;
  date: string; // ISO
  day: string; // YYYY-MM-DD
  name: string;
  home: string;
  away: string;
  homeAbbr: string;
  awayAbbr: string;
  homeScore: number | null;
  awayScore: number | null;
  status: "live" | "scheduled" | "final";
  statusLabel: string;
  venue: string;
  city: string;
  broadcast: string;
}

export interface VenueEntry {
  id: string;
  name: string;
  city: string;
  state: string;
  indoor: boolean;
  league: LeagueId;
  teams: string[];
  image: string | null;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function compact(day: string): string {
  return day.replace(/-/g, "");
}

/** "2026-02" -> { start, end } as YYYYMMDD. */
function monthRange(month: string): { start: string; end: string } {
  const [y, m] = month.split("-").map(Number);
  const year = y ?? new Date().getUTCFullYear();
  const mon = m ?? new Date().getUTCMonth() + 1;
  const last = new Date(Date.UTC(year, mon, 0)).getUTCDate();
  const pad = (n: number) => String(n).padStart(2, "0");
  return { start: `${year}${pad(mon)}01`, end: `${year}${pad(mon)}${pad(last)}` };
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapScheduleEvent(event: any, league: LeagueId): ScheduleGame | null {
  const comp = event?.competitions?.[0];
  if (!comp) return null;
  const competitors: any[] = Array.isArray(comp.competitors) ? comp.competitors : [];
  const home = competitors.find((c) => c?.homeAway === "home");
  const away = competitors.find((c) => c?.homeAway === "away");
  if (!home || !away) return null;

  const state = comp?.status?.type?.state;
  const status: ScheduleGame["status"] =
    comp?.status?.type?.completed === true || state === "post"
      ? "final"
      : state === "in"
        ? "live"
        : "scheduled";

  const iso = str(event?.date, new Date().toISOString());
  const score = (c: any): number | null => {
    const n = Number(c?.score);
    return Number.isFinite(n) && status !== "scheduled" ? n : null;
  };

  const venue = comp?.venue ?? {};
  const broadcasts: any[] = Array.isArray(comp?.broadcasts) ? comp.broadcasts : [];

  return {
    id: str(event?.id, iso),
    league,
    date: iso,
    day: iso.slice(0, 10),
    name: str(event?.name, `${str(away?.team?.displayName)} at ${str(home?.team?.displayName)}`),
    home: str(home?.team?.displayName, "Home"),
    away: str(away?.team?.displayName, "Away"),
    homeAbbr: str(home?.team?.abbreviation, "HOME"),
    awayAbbr: str(away?.team?.abbreviation, "AWAY"),
    homeScore: score(home),
    awayScore: score(away),
    status,
    statusLabel: str(comp?.status?.type?.shortDetail, str(event?.status?.type?.detail, "TBD")),
    venue: str(venue?.fullName, "TBD"),
    city: [str(venue?.address?.city), str(venue?.address?.state)].filter(Boolean).join(", "),
    broadcast: broadcasts.flatMap((b) => (Array.isArray(b?.names) ? b.names : [])).join(", "),
  };
}

async function fetchRange(league: LeagueId, start: string, end: string): Promise<any[]> {
  // A single day must be sent as one date; some feeds return nothing for "d-d".
  const dates = start === end ? start : `${start}-${end}`;
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard?dates=${dates}&limit=500`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) throw new Error(`Schedule ${league} ${res.status}`);
  const payload: any = await res.json();
  return Array.isArray(payload?.events) ? payload.events : [];
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/** A full month of one league's schedule, with venues and results. */
export const fetchMonthSchedule = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; month?: unknown } | undefined;
    const month =
      typeof raw?.month === "string" && /^\d{4}-\d{2}$/.test(raw.month)
        ? raw.month
        : new Date().toISOString().slice(0, 7);
    return { league: asLeague(raw?.league), month };
  })
  .handler(async ({ data }): Promise<{ league: LeagueId; month: string; games: ScheduleGame[] }> => {
    const { start, end } = monthRange(data.month);
    let events = await fetchRange(data.league, start, end).catch(() => []);

    // College feeds ignore date ranges, so walk the month a day at a time.
    if (events.length === 0) {
      const last = Number(end.slice(6));
      const days = Array.from(
        { length: last },
        (_, i) => `${start.slice(0, 6)}${String(i + 1).padStart(2, "0")}`,
      );
      const results = await Promise.allSettled(
        days.map((day) => fetchRange(data.league, day, day)),
      );
      events = results.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
    }

    const games = events
      .map((e) => mapScheduleEvent(e, data.league))
      .filter((g): g is ScheduleGame => g !== null)
      .sort((a, b) => a.date.localeCompare(b.date));
    return { league: data.league, month: data.month, games };
  });

/** One day of games for a league (used by the daily news pages). */
export const fetchDaySchedule = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; day?: unknown } | undefined;
    const day =
      typeof raw?.day === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw.day)
        ? raw.day
        : new Date().toISOString().slice(0, 10);
    return { league: asLeague(raw?.league), day };
  })
  .handler(async ({ data }): Promise<{ league: LeagueId; day: string; games: ScheduleGame[] }> => {
    const stamp = compact(data.day);
    const events = await fetchRange(data.league, stamp, stamp).catch(() => []);
    const games = events
      .map((e) => mapScheduleEvent(e, data.league))
      .filter((g): g is ScheduleGame => g !== null)
      .sort((a, b) => a.date.localeCompare(b.date));
    return { league: data.league, day: data.day, games };
  });

/** Cities and stadiums in use across every league we cover. */
export const fetchVenues = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ venues: VenueEntry[] }> => {
    const today = new Date();
    const shift = (days: number) => {
      const d = new Date(today.getTime() + days * 86_400_000);
      return d.toISOString().slice(0, 10).replace(/-/g, "");
    };
    const start = shift(-45);
    const end = shift(75);

    const results = await Promise.allSettled(
      LEAGUE_IDS.map(async (league) => ({
        league,
        events: await fetchRange(league, start, end),
      })),
    );

    const byKey = new Map<string, VenueEntry>();
    for (const result of results) {
      if (result.status !== "fulfilled") continue;
      const { league, events } = result.value;
      for (const event of events) {
        const game = mapScheduleEvent(event, league);
        if (!game || game.venue === "TBD") continue;
        const key = `${league}-${game.venue}`;
        const existing = byKey.get(key);
        if (existing) {
          if (!existing.teams.includes(game.home)) existing.teams.push(game.home);
          continue;
        }
        /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
        const venue: any = event?.competitions?.[0]?.venue ?? {};
        byKey.set(key, {
          id: str(venue?.id, key),
          name: game.venue,
          city: str(venue?.address?.city, game.city),
          state: str(venue?.address?.state),
          indoor: venue?.indoor === true,
          league,
          teams: [game.home],
          image: null,
        });
      }
    }

    const venues = [...byKey.values()].sort(
      (a, b) => a.city.localeCompare(b.city) || a.name.localeCompare(b.name),
    );
    return { venues };
  },
);
