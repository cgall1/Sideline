/**
 * API-SPORTS provider layer (server only).
 *
 * The subscription key lives in the API_SPORTS_KEY secret and is read inside
 * request handlers, never at module scope and never in browser code. Every
 * response is cached briefly so many visitors watching the same game cost one
 * provider call rather than one each.
 */
import type { Game, GameStatus, LeagueId, StandingRow } from "@/data/sports";

/* eslint-disable @typescript-eslint/no-explicit-any */

type Sport = "football" | "basketball" | "baseball" | "hockey" | "american-football";

const HOST: Record<Sport, string> = {
  football: "v3.football.api-sports.io",
  basketball: "v1.basketball.api-sports.io",
  baseball: "v1.baseball.api-sports.io",
  hockey: "v1.hockey.api-sports.io",
  "american-football": "v1.american-football.api-sports.io",
};

/** Which provider sport + competition each Sideline league maps to. */
export const PROVIDER_LEAGUE: Partial<Record<LeagueId, { sport: Sport; id: number }>> = {
  mls: { sport: "football", id: 253 },
  nwsl: { sport: "football", id: 254 },
  intl: { sport: "football", id: 2 },
  nba: { sport: "basketball", id: 12 },
  wnba: { sport: "basketball", id: 13 },
  nhl: { sport: "hockey", id: 57 },
  mlb: { sport: "baseball", id: 1 },
  nfl: { sport: "american-football", id: 1 },
  cfb: { sport: "american-football", id: 2 },
};

export function providerConfigured(): boolean {
  return Boolean(process.env["API_SPORTS_KEY"]);
}

/* ------------------------------------------------------------------ cache */

interface Entry {
  at: number;
  value: unknown;
}
const cache = new Map<string, Entry>();

export const TTL = {
  live: 25_000,
  standings: 5 * 60_000,
  fixtures: 60 * 60_000,
  reference: 12 * 60 * 60_000,
} as const;

function cached<T>(key: string, ttl: number): T | undefined {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttl) return hit.value as T;
  if (hit) cache.delete(key);
  return undefined;
}

/* --------------------------------------------------------------- spending */

/**
 * A hard ceiling on how many calls the site makes to the paid provider, no
 * matter how many visitors (or scripted requests) arrive. Cached answers are
 * served freely; once the budget for the current minute is spent, calls fall
 * back to the free feeds instead of burning subscription quota.
 */
const BUDGET_PER_MINUTE = 40;
let windowStart = 0;
let spentInWindow = 0;

function takeBudget(): boolean {
  const now = Date.now();
  if (now - windowStart >= 60_000) {
    windowStart = now;
    spentInWindow = 0;
  }
  if (spentInWindow >= BUDGET_PER_MINUTE) return false;
  spentInWindow += 1;
  return true;
}

/* ------------------------------------------------------------------ fetch */

export interface ProviderResult<T> {
  ok: boolean;
  data: T | null;
  error?: string;
}

/** One authenticated call to API-SPORTS, cached and never throwing. */
export async function providerGet<T = any>(
  sport: Sport,
  path: string,
  params: Record<string, string | number> = {},
  ttl: number = TTL.live,
): Promise<ProviderResult<T>> {
  const key = process.env["API_SPORTS_KEY"];
  if (!key) return { ok: false, data: null, error: "no-key" };

  const query = new URLSearchParams(
    Object.entries(params).map(([k, v]) => [k, String(v)]),
  ).toString();
  const url = `https://${HOST[sport]}/${path}${query ? `?${query}` : ""}`;

  const hit = cached<T>(url, ttl);
  if (hit !== undefined) return { ok: true, data: hit };

  if (!takeBudget()) {
    console.warn(`API-SPORTS budget exhausted; skipping ${sport}/${path}`);
    return { ok: false, data: null, error: "budget" };
  }


  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    const res = await fetch(url, {
      headers: { "x-apisports-key": key, accept: "application/json" },
      signal: controller.signal,
    });
    clearTimeout(timer);
    if (!res.ok) {
      console.error(`API-SPORTS ${sport}/${path} failed [${res.status}]: ${await res.text()}`);
      return { ok: false, data: null, error: `http-${res.status}` };
    }
    const body: any = await res.json();
    const errors = body?.errors;
    if (errors && ((Array.isArray(errors) && errors.length) || Object.keys(errors ?? {}).length)) {
      console.error(`API-SPORTS ${sport}/${path} error: ${JSON.stringify(errors)}`);
      return { ok: false, data: null, error: JSON.stringify(errors).slice(0, 200) };
    }
    const response = body?.response as T;
    cache.set(url, { at: Date.now(), value: response });
    return { ok: true, data: response };
  } catch (err) {
    console.error(`API-SPORTS ${sport}/${path} threw: ${String(err)}`);
    return { ok: false, data: null, error: "unreachable" };
  }
}

/* ------------------------------------------------------------- normalising */

function num(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function abbr(name: string): string {
  const clean = name.trim();
  if (!clean) return "—";
  const words = clean.split(/\s+/);
  return (words.length > 1 ? words.map((w) => w[0]).join("") : clean.slice(0, 3)).toUpperCase().slice(0, 4);
}

function startLabel(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "TBD";
  return (
    new Intl.DateTimeFormat("en-US", {
      weekday: "short",
      hour: "numeric",
      minute: "2-digit",
      timeZone: "America/New_York",
    }).format(date) + " ET"
  );
}

const LIVE_SHORT = new Set(["1H", "2H", "HT", "ET", "BT", "P", "LIVE", "Q1", "Q2", "Q3", "Q4", "OT", "IN", "INTR", "PST_LIVE"]);
const FINAL_SHORT = new Set(["FT", "AET", "PEN", "AOT", "AP", "POST", "FIN", "ENDED"]);

function statusFrom(short: string, long: string): GameStatus {
  const s = short.toUpperCase();
  if (FINAL_SHORT.has(s) || /finish|final|ended|after/i.test(long)) return "final";
  if (LIVE_SHORT.has(s) || /play|live|half|quarter|period|break/i.test(long)) return "live";
  return "scheduled";
}

/** Soccer fixtures (v3.football) → Sideline games. */
function mapFootball(fixture: any, league: LeagueId): Game | null {
  const f = fixture?.fixture;
  const teams = fixture?.teams;
  if (!f || !teams) return null;
  const iso = str(f?.date);
  const short = str(f?.status?.short, "NS");
  const status = statusFrom(short, str(f?.status?.long));
  const elapsed = f?.status?.elapsed;
  const homeName = str(teams?.home?.name, "TBD");
  const awayName = str(teams?.away?.name, "TBD");

  return {
    id: `${league}-as-${str(f?.id, "0")}`,
    league,
    home: { name: homeName, abbr: abbr(homeName), record: "" },
    away: { name: awayName, abbr: abbr(awayName), record: "" },
    homeScore: num(fixture?.goals?.home),
    awayScore: num(fixture?.goals?.away),
    status,
    clock:
      status === "live"
        ? elapsed
          ? `${elapsed}'`
          : "Live"
        : status === "final"
          ? "Final"
          : startLabel(iso),
    venue: str(f?.venue?.name, "TBD"),
    startLabel: startLabel(iso),
    startISO: iso || undefined,
    broadcasters: [],
    headline: "",
  };
}

/** Basketball / baseball / hockey / American football games → Sideline games. */
function mapGeneric(game: any, league: LeagueId): Game | null {
  const teams = game?.teams;
  if (!teams) return null;
  const iso = str(game?.date);
  const short = str(game?.status?.short, "NS");
  const status = statusFrom(short, str(game?.status?.long));
  const homeName = str(teams?.home?.name, "TBD");
  const awayName = str(teams?.away?.name, "TBD");
  const scores = game?.scores;
  const score = (side: "home" | "away") => {
    const raw = scores?.[side];
    if (raw && typeof raw === "object") return num(raw.total ?? raw.points ?? raw.hits);
    return num(raw);
  };

  return {
    id: `${league}-as-${str(game?.id, String(game?.id ?? "0"))}`,
    league,
    home: { name: homeName, abbr: abbr(homeName), record: "" },
    away: { name: awayName, abbr: abbr(awayName), record: "" },
    homeScore: score("home"),
    awayScore: score("away"),
    status,
    clock:
      status === "live"
        ? str(game?.status?.long, "Live")
        : status === "final"
          ? "Final"
          : startLabel(iso),
    venue: str(game?.venue, "TBD"),
    startLabel: startLabel(iso),
    startISO: iso || undefined,
    broadcasters: [],
    headline: "",
  };
}

function seasonFor(sport: Sport): string {
  const now = new Date();
  const year = now.getUTCFullYear();
  if (sport === "football") {
    // Soccer seasons are labelled by their starting year.
    return String(now.getUTCMonth() + 1 >= 7 ? year : year - 1);
  }
  if (sport === "basketball" || sport === "hockey") {
    const start = now.getUTCMonth() + 1 >= 9 ? year : year - 1;
    return `${start}-${start + 1}`;
  }
  return String(year);
}

/** Today's games for a league, or null when the provider can't serve it. */
export async function providerGames(league: LeagueId): Promise<Game[] | null> {
  const map = PROVIDER_LEAGUE[league];
  if (!map) return null;
  const date = new Date().toISOString().slice(0, 10);
  const season = seasonFor(map.sport);

  if (map.sport === "football") {
    const res = await providerGet<any[]>(
      "football",
      "fixtures",
      { league: map.id, season, date },
      TTL.live,
    );
    if (!res.ok || !Array.isArray(res.data)) return null;
    return res.data.map((f) => mapFootball(f, league)).filter((g): g is Game => g !== null);
  }

  const res = await providerGet<any[]>(map.sport, "games", { league: map.id, season, date }, TTL.live);
  if (!res.ok || !Array.isArray(res.data)) return null;
  return res.data.map((g) => mapGeneric(g, league)).filter((g): g is Game => g !== null);
}

/** League table for a league, or null when the provider can't serve it. */
export async function providerStandings(
  league: LeagueId,
): Promise<{ group: string; rows: StandingRow[] } | null> {
  const map = PROVIDER_LEAGUE[league];
  if (!map) return null;
  const season = seasonFor(map.sport);
  const res = await providerGet<any>(
    map.sport,
    "standings",
    { league: map.id, season },
    TTL.standings,
  );
  if (!res.ok || !res.data) return null;

  // Both shapes come back as nested arrays of entries.
  const flat: any[] = Array.isArray(res.data) ? res.data.flat(2) : [];
  const rows: StandingRow[] = flat
    .map((entry) => {
      const name = str(entry?.team?.name, "");
      if (!name) return null;
      const games = entry?.games ?? {};
      const wins = num(games?.win?.total ?? entry?.all?.win ?? entry?.win?.total);
      const losses = num(games?.lose?.total ?? entry?.all?.lose ?? entry?.lose?.total);
      const otl = num(games?.lose?.overtime?.total ?? entry?.overtime?.lose);
      const played = wins + losses + otl;
      return {
        team: name,
        w: wins,
        l: losses,
        otl: otl || undefined,
        pct: played ? (wins / played).toFixed(3) : ".000",
        streak: str(entry?.form, "").slice(-5) || "—",
      } as StandingRow;
    })
    .filter((r): r is StandingRow => r !== null);

  if (!rows.length) return null;
  return { group: "League table", rows };
}

/** Which leagues the current subscription actually answers for. */
export async function providerHealth(): Promise<{
  configured: boolean;
  leagues: { league: LeagueId; ok: boolean; games: number; error?: string }[];
}> {
  if (!providerConfigured()) return { configured: false, leagues: [] };
  const entries = Object.keys(PROVIDER_LEAGUE) as LeagueId[];
  const leagues = await Promise.all(
    entries.map(async (league) => {
      try {
        const games = await providerGames(league);
        return games
          ? { league, ok: true, games: games.length }
          : { league, ok: false, games: 0, error: "not available on this plan" };
      } catch {
        return { league, ok: false, games: 0, error: "request failed" };
      }
    }),
  );
  return { configured: true, leagues };
}
