/**
 * Minimal Web Push sender for the Worker runtime.
 *
 * We send "tickle" pushes with no payload: the browser wakes our service
 * worker, which then fetches the pending alerts over HTTPS. That avoids
 * payload encryption entirely while still reaching a closed phone.
 */

function b64url(bytes: ArrayBuffer | Uint8Array): string {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let s = "";
  for (const b of view) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function utf8(input: string): Uint8Array {
  return new TextEncoder().encode(input);
}

async function vapidToken(audience: string): Promise<string> {
  const jwk = JSON.parse(process.env["VAPID_PRIVATE_JWK"]!) as JsonWebKey;
  const key = await crypto.subtle.importKey(
    "jwk",
    jwk,
    { name: "ECDSA", namedCurve: "P-256" },
    false,
    ["sign"],
  );
  const header = b64url(utf8(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const claims = b64url(
    utf8(
      JSON.stringify({
        aud: audience,
        exp: Math.floor(Date.now() / 1000) + 12 * 3600,
        sub: "https://score-talk-watch.lovable.app",
      }),
    ),
  );
  const signature = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    key,
    utf8(`${header}.${claims}`) as unknown as BufferSource,
  );
  return `${header}.${claims}.${b64url(signature)}`;
}

/** Wake one subscribed device. Returns false when the subscription is dead. */
export async function sendTickle(endpoint: string): Promise<boolean> {
  let audience: string;
  try {
    audience = new URL(endpoint).origin;
  } catch {
    return false;
  }
  const jwt = await vapidToken(audience);
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      TTL: "3600",
      Urgency: "high",
      "Content-Length": "0",
      Authorization: `vapid t=${jwt}, k=${process.env["VAPID_PUBLIC_KEY"]!}`,
    },
  }).catch(() => null);
  if (!res) return true; // transient network trouble; keep the subscription
  return res.status !== 404 && res.status !== 410;
}
