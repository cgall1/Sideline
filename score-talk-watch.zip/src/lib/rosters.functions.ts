import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";
import { safeEspnId } from "@/lib/espn-id";

export interface RosterPlayer {
  id: string;
  name: string;
  jersey: string;
  position: string;
  positionGroup: string;
  age: string;
  height: string;
  weight: string;
  headshot: string | null;
  link: string | null;
}

export interface RosterMove {
  id: string;
  headline: string;
  summary: string;
  url: string;
  published: string;
}

export interface TeamRoster {
  league: LeagueId;
  teamId: string;
  team: string;
  abbr: string;
  logo: string | null;
  record: string;
  standing: string;
  venue: string;
  players: RosterPlayer[];
  moves: RosterMove[];
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/eng.1",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

/** Headlines that count as roster moves (trades, signings, call-ups). */
const MOVE_WORDS = [
  "trade",
  "traded",
  "sign",
  "signs",
  "signed",
  "signing",
  "acquire",
  "acquired",
  "waive",
  "waived",
  "release",
  "released",
  "claim",
  "deal",
  "contract",
  "extension",
  "transfer",
  "loan",
  "call-up",
  "activated",
  "injured reserve",
  "roster",
];

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapPlayer(raw: any, group: string): RosterPlayer | null {
  const name = str(raw?.displayName, str(raw?.fullName));
  if (!name) return null;
  const position = str(raw?.position?.displayName, str(raw?.position?.abbreviation, "—"));
  return {
    id: str(raw?.id, name),
    name,
    jersey: str(raw?.jersey, "—"),
    position,
    positionGroup: group || str(raw?.position?.parent?.displayName, position),
    age: typeof raw?.age === "number" ? String(raw.age) : "—",
    height: str(raw?.displayHeight, "—"),
    weight: str(raw?.displayWeight, "—"),
    headshot: str(raw?.headshot?.href) || null,
    link:
      str(
        (Array.isArray(raw?.links) ? raw.links : []).find((l: any) => typeof l?.href === "string")
          ?.href,
      ) || null,
  };
}

async function fetchPlayers(path: string, teamId: string): Promise<RosterPlayer[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/teams/${encodeURIComponent(teamId)}/roster`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const athletes: any[] = Array.isArray(payload?.athletes) ? payload.athletes : [];
  const players: RosterPlayer[] = [];
  for (const entry of athletes) {
    if (Array.isArray(entry?.items)) {
      const group = str(entry?.position, "Squad");
      for (const item of entry.items) {
        const p = mapPlayer(item, group.charAt(0).toUpperCase() + group.slice(1));
        if (p) players.push(p);
      }
    } else {
      const p = mapPlayer(entry, "");
      if (p) players.push(p);
    }
  }
  return players;
}

async function fetchTeamInfo(path: string, teamId: string) {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/teams/${encodeURIComponent(teamId)}`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return null;
  const payload: any = await res.json();
  return payload?.team ?? null;
}

async function fetchMoves(path: string, teamName: string): Promise<RosterMove[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/news?limit=50`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];
  const nameWords = teamName
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 3);

  return articles
    .map((a): RosterMove | null => {
      const headline = str(a?.headline);
      const url = str(a?.links?.web?.href, str(a?.links?.mobile?.href));
      if (!headline || !url) return null;
      return {
        id: str(a?.id ? String(a.id) : "", url),
        headline,
        summary: str(a?.description),
        url,
        published: str(a?.published, new Date().toISOString()),
      };
    })
    .filter((m): m is RosterMove => m !== null)
    .filter((m) => {
      const text = `${m.headline} ${m.summary}`.toLowerCase();
      const aboutTeam = nameWords.length === 0 || nameWords.some((w) => text.includes(w));
      return aboutTeam && MOVE_WORDS.some((w) => text.includes(w));
    })
    .sort((a, b) => b.published.localeCompare(a.published))
    .slice(0, 8);
}

/** One team's full roster, its record and its latest trades and signings. */
export const fetchTeamRoster = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; teamId?: unknown } | undefined;
    return {
      league: asLeague(raw?.league),
      teamId: safeEspnId(raw?.teamId),
    };
  })
  .handler(async ({ data }): Promise<TeamRoster> => {
    const path = ESPN_PATH[data.league];
    const info = data.teamId ? await fetchTeamInfo(path, data.teamId) : null;
    const team = str(info?.displayName, "Team");
    const [players, moves] = await Promise.all([
      fetchPlayers(path, data.teamId).catch(() => [] as RosterPlayer[]),
      fetchMoves(path, team).catch(() => [] as RosterMove[]),
    ]);
    const logos: any[] = Array.isArray(info?.logos) ? info.logos : [];
    const recordItem = (Array.isArray(info?.record?.items) ? info.record.items : []).find(
      (i: any) => typeof i?.summary === "string",
    );

    return {
      league: data.league,
      teamId: data.teamId,
      team,
      abbr: str(info?.abbreviation, team.slice(0, 3).toUpperCase()),
      logo: str(logos.find((l) => typeof l?.href === "string")?.href) || null,
      record: str(recordItem?.summary, "—"),
      standing: str(info?.standingSummary, ""),
      venue: str(info?.franchise?.venue?.fullName, ""),
      players,
      moves,
    };
  });
