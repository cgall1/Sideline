import { createServerFn } from "@tanstack/react-start";

/** The public half of the notification signing key, safe to hand to browsers. */
export const getPushPublicKey = createServerFn({ method: "GET" }).handler(async () => ({
  key: process.env["VAPID_PUBLIC_KEY"] ?? "",
}));
