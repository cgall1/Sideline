import { useQuery } from "@tanstack/react-query";
import type { Game, LeagueId, StandingRow } from "@/data/sports";
import { raceRule } from "@/data/why";
import {
  gameSummaryQueryOptions,
  monthScheduleQueryOptions,
  standingsQueryOptions,
} from "@/lib/feed";
import { supabase } from "@/integrations/supabase/client";

export type WhyKind = "standings" | "next" | "race" | "player" | "talk";

export interface WhyLine {
  kind: WhyKind;
  text: string;
}

function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
}

/** Loose team-name match: "Boston Celtics" also matches "Celtics". */
function same(a: string, b: string): boolean {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  if (x === y) return true;
  const nick = y.split(" ").slice(-1)[0] ?? "";
  return nick.length > 3 && x.includes(nick);
}

function gamesBehind(leader: StandingRow, row: StandingRow): number {
  return Math.max(0, (leader.w - row.w + (row.l - leader.l)) / 2);
}

function gbLabel(gb: number): string {
  if (gb === 0) return "level with the leaders";
  if (gb === 0.5) return "half a game behind the leaders";
  return `${gb % 1 === 0 ? gb : gb.toFixed(1)} games behind the leaders`;
}

function monthKey(offset: number): string {
  const d = new Date();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + offset);
  return d.toISOString().slice(0, 7);
}

function dayLabel(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

/**
 * Turns a result into plain-English context: where it leaves both teams in the
 * table, what's next, which race it affects, who stood out, and how busy the
 * match thread is. Every line is computed from live data — nothing invented.
 */
export function useWhyItMatters(league: LeagueId, game: Game): {
  lines: WhyLine[];
  loading: boolean;
} {
  const rule = raceRule(league);
  const { data: standings, isLoading: sLoading } = useQuery(standingsQueryOptions(league));
  const { data: summary } = useQuery(gameSummaryQueryOptions(league, game.id));
  const { data: thisMonth } = useQuery(monthScheduleQueryOptions(league, monthKey(0)));
  const { data: nextMonth } = useQuery(monthScheduleQueryOptions(league, monthKey(1)));
  const { data: talkCount } = useQuery({
    queryKey: ["why-talk", game.id],
    queryFn: async () => {
      const { count } = await supabase
        .from("community_posts")
        .select("id", { count: "exact", head: true })
        .eq("game_id", game.id);
      return count ?? 0;
    },
    staleTime: 60_000,
  });

  const rows: StandingRow[] = standings?.rows ?? [];
  const lines: WhyLine[] = [];

  const finished = game.status === "final";
  const winner =
    finished && game.homeScore !== game.awayScore
      ? game.homeScore > game.awayScore
        ? game.home
        : game.away
      : null;

  const focus = winner ?? game.home;
  const idx = rows.findIndex((r) => same(r.team, focus.name));

  if (idx >= 0) {
    const row = rows[idx]!;
    const leader = rows[0]!;
    const place = ordinal(idx + 1);
    const record = `${row.w}-${row.l}${row.otl ? `-${row.otl}` : ""}`;
    const gb = rule.soccer ? null : gamesBehind(leader, row);
    lines.push({
      kind: "standings",
      text:
        idx === 0
          ? `${focus.name} sit top of ${rule.table} at ${record}${row.streak ? ` (${row.streak})` : ""}.`
          : `${focus.name} are ${place} in ${rule.table} at ${record}${
              gb !== null ? `, ${gbLabel(gb)}` : ""
            }${row.streak ? ` — ${row.streak}` : ""}.`,
    });

    const spotsOut = idx + 1 - rule.cut;
    lines.push({
      kind: "race",
      text:
        spotsOut <= 0
          ? `That keeps them inside ${rule.cutLabel}, ${place} overall.`
          : `They sit ${spotsOut} ${spotsOut === 1 ? "spot" : "spots"} outside ${rule.cutLabel}.`,
    });

    if (rule.second) {
      const secondIn = idx + 1 <= rule.second.cut;
      lines.push({
        kind: "race",
        text: secondIn
          ? `They are also inside ${rule.second.label}.`
          : `${rule.second.label} are ${idx + 1 - rule.second.cut} ${
              idx + 1 - rule.second.cut === 1 ? "place" : "places"
            } away.`,
      });
    }
  }

  const fixtures = [...(thisMonth?.games ?? []), ...(nextMonth?.games ?? [])]
    .filter((g) => g.status === "scheduled" && (same(g.home, focus.name) || same(g.away, focus.name)))
    .filter((g) => new Date(g.date).getTime() > Date.now())
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 3);

  if (fixtures.length) {
    const first = fixtures[0]!;
    const opponent = same(first.home, focus.name) ? first.away : first.home;
    lines.push({
      kind: "next",
      text:
        fixtures.length === 1
          ? `Next up: ${opponent}, ${dayLabel(first.date)}.`
          : `Next up: ${opponent} on ${dayLabel(first.date)}, then ${fixtures
              .slice(1)
              .map((g) => (same(g.home, focus.name) ? g.away : g.home))
              .join(" and ")}.`,
    });
  }

  const leaders = summary?.leaders ?? [];
  if (leaders.length) {
    const top = leaders[0]!;
    lines.push({
      kind: "player",
      text: `${top.name} (${top.team}) led the way: ${top.value}.`,
    });
  }

  if (talkCount && talkCount > 0) {
    lines.push({
      kind: "talk",
      text: `${talkCount} ${talkCount === 1 ? "fan has" : "fans have"} posted in the match thread.`,
    });
  }

  return { lines, loading: sLoading && lines.length === 0 };
}
