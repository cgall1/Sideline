import { createServerFn } from "@tanstack/react-start";

export interface WeeklyAwards {
  weekStart: string;
  weekEnd: string;
  fanOfWeek: { userId: string; name: string; postId: string; title: string; votes: number } | null;
  bestPredictor: { userId: string; name: string; correct: number; total: number } | null;
  hottestDebate: { date: string; question: string; votes: number } | null;
}

/** Last completed Monday–Sunday week (UTC). */
function lastWeek() {
  const now = new Date();
  const thisMonday = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  thisMonday.setUTCDate(thisMonday.getUTCDate() - ((thisMonday.getUTCDay() + 6) % 7));
  const start = new Date(thisMonday);
  start.setUTCDate(start.getUTCDate() - 7);
  return { start, end: thisMonday };
}

/** Weekly fan awards, computed from real posts, votes and predictions. Winners get a badge. */
export const fetchWeeklyAwards = createServerFn({ method: "GET" }).handler(async (): Promise<WeeklyAwards> => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { start, end } = lastWeek();
  const s = start.toISOString();
  const e = end.toISOString();
  const endDay = new Date(end.getTime() - 86400000).toISOString().slice(0, 10);
  const out: WeeklyAwards = { weekStart: s.slice(0, 10), weekEnd: endDay, fanOfWeek: null, bestPredictor: null, hottestDebate: null };

  try {
    const [{ data: posts }, { data: votes }] = await Promise.all([
      supabaseAdmin.from("space_posts").select("id,user_id,author_name,title")
        .gte("created_at", s).lt("created_at", e).eq("hidden", false),
      supabaseAdmin.rpc("space_vote_counts"),
    ]);
    const vm = new Map((votes ?? []).filter((v) => v.post_id).map((v) => [v.post_id as string, Number(v.total)]));
    const best = (posts ?? []).map((p) => ({ p, v: vm.get(p.id) ?? 0 })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v)[0];
    if (best) out.fanOfWeek = { userId: best.p.user_id, name: best.p.author_name, postId: best.p.id, title: best.p.title, votes: best.v };
  } catch { /* leave empty */ }

  try {
    const { data: preds } = await supabaseAdmin.from("predictions").select("user_id,correct")
      .eq("resolved", true).gte("created_at", s).lt("created_at", e);
    const tally = new Map<string, { c: number; t: number }>();
    for (const p of preds ?? []) {
      const t = tally.get(p.user_id) ?? { c: 0, t: 0 };
      t.t += 1; if (p.correct) t.c += 1;
      tally.set(p.user_id, t);
    }
    const top = [...tally.entries()].filter(([, t]) => t.c > 0).sort((a, b) => b[1].c - a[1].c || a[1].t - b[1].t)[0];
    if (top) {
      const { data: prof } = await supabaseAdmin.from("profiles").select("display_name").eq("id", top[0]).maybeSingle();
      out.bestPredictor = { userId: top[0], name: prof?.display_name ?? "A Sideline fan", correct: top[1].c, total: top[1].t };
    }
  } catch { /* leave empty */ }

  try {
    const [{ data: debates }, { data: dv }] = await Promise.all([
      supabaseAdmin.from("daily_debates").select("id,debate_date,question")
        .gte("debate_date", s.slice(0, 10)).lte("debate_date", endDay),
      supabaseAdmin.rpc("debate_vote_counts"),
    ]);
    const dm = new Map<string, number>();
    for (const r of dv ?? []) dm.set(r.debate_id, (dm.get(r.debate_id) ?? 0) + Number(r.total));
    const hot = (debates ?? []).map((d) => ({ d, v: dm.get(d.id) ?? 0 })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v)[0];
    if (hot) out.hottestDebate = { date: hot.d.debate_date, question: hot.d.question, votes: hot.v };
  } catch { /* leave empty */ }

  const badges = [
    out.fanOfWeek && { user_id: out.fanOfWeek.userId, badge: "fan_of_week" },
    out.bestPredictor && { user_id: out.bestPredictor.userId, badge: "best_predictor_week" },
  ].filter(Boolean) as { user_id: string; badge: string }[];
  if (badges.length) {
    await supabaseAdmin.from("fan_badges").upsert(badges, { onConflict: "user_id,badge", ignoreDuplicates: true });
  }
  return out;
});
