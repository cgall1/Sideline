import { createServerFn } from "@tanstack/react-start";

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface TennisRank {
  rank: number;
  previous: number;
  points: number;
  player: string;
  country: string;
}

export interface TennisRankings {
  tour: "atp" | "wta";
  name: string;
  ranks: TennisRank[];
}

async function tourRankings(tour: "atp" | "wta"): Promise<TennisRankings> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/tennis/${tour}/rankings`,
    { headers: { accept: "application/json" } },
  ).catch(() => null);
  const empty: TennisRankings = { tour, name: tour.toUpperCase(), ranks: [] };
  if (!res || !res.ok) return empty;
  const payload: any = await res.json().catch(() => null);
  const group = Array.isArray(payload?.rankings) ? payload.rankings[0] : null;
  const ranks: any[] = Array.isArray(group?.ranks) ? group.ranks : [];
  return {
    tour,
    name: typeof group?.name === "string" ? group.name : tour.toUpperCase(),
    ranks: ranks
      .map((r): TennisRank | null => {
        const player =
          typeof r?.athlete?.displayName === "string" ? r.athlete.displayName : "";
        if (!player) return null;
        return {
          rank: Number(r?.current) || 0,
          previous: Number(r?.previous) || 0,
          points: Number(r?.points) || 0,
          player,
          country:
            typeof r?.athlete?.flag?.alt === "string"
              ? r.athlete.flag.alt
              : typeof r?.athlete?.citizenship === "string"
                ? r.athlete.citizenship
                : "",
        };
      })
      .filter((r): r is TennisRank => r !== null)
      .slice(0, 50),
  };
}

/** Current ATP and WTA world rankings — the tennis equivalent of a league table. */
export const fetchTennisRankings = createServerFn({ method: "GET" }).handler(
  async (): Promise<TennisRankings[]> =>
    Promise.all([tourRankings("atp"), tourRankings("wta")]),
);
