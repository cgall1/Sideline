import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface BoardEntry {
  userId: string;
  name: string;
  picks: number;
  correct: number;
  accuracy: number;
}

export interface StreakEntry {
  userId: string;
  name: string;
  current: number;
  best: number;
}

export interface PredictionBoard {
  overall: BoardEntry[];
  byLeague: Record<string, BoardEntry[]>;
  streaks: StreakEntry[];
  resolved: number;
}

/**
 * Public leaderboard figures.
 *
 * Individual picks are private to the fan who made them, so the board is built
 * server-side from the raw rows. Only aggregate records leave the server —
 * never which team a fan picked in which game.
 */
export const fetchPredictionBoard = createServerFn({ method: "GET" }).handler(
  async (): Promise<PredictionBoard> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data, error } = await supabaseAdmin
      .from("predictions")
      .select("user_id,league,correct,resolved")
      .order("created_at", { ascending: true })
      .limit(5000);
    if (error) throw new Error(error.message);
    const rows = data ?? [];
    if (rows.length === 0) return { overall: [], byLeague: {}, streaks: [], resolved: 0 };

    const userIds = [...new Set(rows.map((r) => r.user_id))];
    const { data: profiles } = await supabaseAdmin
      .from("profiles")
      .select("id,display_name")
      .in("id", userIds);
    const names = new Map<string, string>();
    for (const p of profiles ?? []) names.set(p.id, p.display_name ?? "Fan");

    const tally = (subset: typeof rows): BoardEntry[] => {
      const map = new Map<string, BoardEntry>();
      for (const row of subset) {
        const entry = map.get(row.user_id) ?? {
          userId: row.user_id,
          name: names.get(row.user_id) ?? "Fan",
          picks: 0,
          correct: 0,
          accuracy: 0,
        };
        entry.picks += 1;
        if (row.correct) entry.correct += 1;
        map.set(row.user_id, entry);
      }
      const list = [...map.values()];
      for (const e of list) e.accuracy = e.picks ? Math.round((e.correct / e.picks) * 100) : 0;
      return list.sort((a, b) => b.correct - a.correct || b.accuracy - a.accuracy);
    };

    const byLeague: Record<string, BoardEntry[]> = {};
    for (const league of new Set(rows.map((r) => r.league))) {
      byLeague[league] = tally(rows.filter((r) => r.league === league)).slice(0, 5);
    }

    const streaks: StreakEntry[] = userIds
      .map((userId) => {
        let current = 0;
        let best = 0;
        for (const row of rows.filter((r) => r.user_id === userId && r.resolved)) {
          if (row.correct) {
            current += 1;
            best = Math.max(best, current);
          } else current = 0;
        }
        return { userId, name: names.get(userId) ?? "Fan", current, best };
      })
      .filter((e) => e.best > 0)
      .sort((a, b) => b.current - a.current || b.best - a.best);

    return {
      overall: tally(rows),
      byLeague,
      streaks,
      resolved: rows.filter((r) => r.resolved).length,
    };
  },
);

/** ESPN scoreboard paths, mirrored here so grading never trusts the browser. */
const ESPN_PATH: Record<string, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function compactDate(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** Real winners per game id for one league, from the official feed. */
async function leagueWinners(league: string): Promise<Map<string, string | null>> {
  const path = ESPN_PATH[league];
  const winners = new Map<string, string | null>();
  if (!path) return winners;

  const dates = [0, -1, -2, -3, -4, -5, -6, -7].map(compactDate);
  const pages = await Promise.allSettled(
    dates.map(async (date) => {
      const res = await fetch(
        `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${date}&limit=200`,
        { headers: { accept: "application/json" } },
      );
      if (!res.ok) throw new Error(`ESPN ${res.status}`);
      return (await res.json()) as any;
    }),
  );

  for (const page of pages) {
    if (page.status !== "fulfilled") continue;
    for (const event of (page.value?.events ?? []) as any[]) {
      const comp = event?.competitions?.[0];
      const completed = comp?.status?.type?.completed === true;
      if (!completed) continue;
      const teams = (comp?.competitors ?? []) as any[];
      const scored = teams.map((t) => ({
        name: String(t?.team?.displayName ?? t?.team?.name ?? ""),
        score: Number(t?.score ?? 0),
      }));
      if (scored.length !== 2) continue;
      const [a, b] = scored as [{ name: string; score: number }, { name: string; score: number }];
      const winner = a.score === b.score ? null : a.score > b.score ? a.name : b.name;
      winners.set(String(event?.id ?? comp?.id ?? ""), winner);
    }
  }
  return winners;
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/**
 * Grade the signed-in fan's unresolved picks whose games have finished.
 *
 * Results are decided here, against the official feed — fans can no longer
 * write the correct/resolved columns themselves, so the leaderboard is honest.
 * The caller must be signed in, and only their own rows are ever touched.
 */
export const gradePredictions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ graded: number }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userId = context.userId;

    const { data, error } = await supabaseAdmin
      .from("predictions")
      .select("id,league,game_id,pick")
      .eq("user_id", userId)
      .eq("resolved", false)
      .limit(500);
    if (error) throw new Error(error.message);
    const pending = data ?? [];
    if (pending.length === 0) return { graded: 0 };

    const leagues = [...new Set(pending.map((p) => p.league))];
    const tables = new Map<string, Map<string, string | null>>();
    await Promise.all(
      leagues.map(async (league) => tables.set(league, await leagueWinners(league))),
    );

    let graded = 0;
    for (const pick of pending) {
      const winner = tables.get(pick.league)?.get(pick.game_id);
      if (winner === undefined || winner === null) continue;
      const { error: updateError } = await supabaseAdmin
        .from("predictions")
        .update({ correct: winner === pick.pick, resolved: true })
        .eq("id", pick.id);
      if (!updateError) graded += 1;
    }
    return { graded };
  });
