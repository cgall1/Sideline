import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fetchProfileNames } from "@/lib/community-counts.functions";

export interface ChatMessage {
  id: string;
  league: string;
  userId: string;
  name: string;
  body: string;
  createdAt: string;
}

/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Messages in a league's private predictions room.
 *
 * The table only allows signed-in fans to read, so this returns nothing for
 * visitors who aren't signed in. Profiles are private to their owner, so
 * display names are resolved by a trusted server lookup.
 */
export const predictionChatQueryOptions = (league: string, enabled: boolean) =>
  queryOptions({
    queryKey: ["prediction-chat", league],
    enabled,
    queryFn: async (): Promise<ChatMessage[]> => {
      const { data, error } = await supabase
        .from("prediction_chat")
        .select("id, league, user_id, body, created_at")
        .eq("league", league)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      const rows = (data ?? []) as any[];

      const ids = [...new Set(rows.map((r) => r.user_id as string))];
      const profiles = await fetchProfileNames({ data: { ids } });
      const names = new Map(profiles.map((p) => [p.id, p.display_name]));

      return rows.map((row) => ({
        id: row.id,
        league: row.league,
        userId: row.user_id,
        name: names.get(row.user_id) ?? "Fan",
        body: row.body,
        createdAt: row.created_at,
      }));
    },
    refetchInterval: 20_000,
    staleTime: 10_000,
  });

/** Post a message into a league's private predictions room. */
export async function sendPredictionChat(userId: string, league: string, body: string) {
  const { error } = await supabase
    .from("prediction_chat")
    .insert({ user_id: userId, league, body });
  if (error) throw error;
}

/** Remove one of your own messages. */
export async function deletePredictionChat(id: string) {
  const { error } = await supabase.from("prediction_chat").delete().eq("id", id);
  if (error) throw error;
}
