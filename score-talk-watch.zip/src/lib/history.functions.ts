import { createServerFn } from "@tanstack/react-start";

export interface HistoryEvent {
  year: string;
  text: string;
  url: string | null;
  thumbnail: string | null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */

const SPORT_WORDS = [
  "football",
  "baseball",
  "basketball",
  "hockey",
  "soccer",
  "olympic",
  "world cup",
  "super bowl",
  "world series",
  "stanley cup",
  "nba",
  "nfl",
  "nhl",
  "mlb",
  "fifa",
  "tennis",
  "golf",
  "boxing",
  "nascar",
  "grand prix",
  "marathon",
  "championship",
  "athlete",
  "sprinter",
  "pitcher",
  "quarterback",
  "medal",
  "cricket",
  "rugby",
  "ufc",
  "boxing",
  "heavyweight",
  "wimbledon",
  "the masters",
  "premier league",
  "formula one",
  "tour de france",
  "tournament",
  "stadium",
  "athletics",
  "sporting",
  "sports",
  "swimmer",
  "cyclist",
  "wrestling",
  "motorsport",
  "racing",
  "derby",
  "playoff",
  "gold medal",
];

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

/** Sports moments that happened on a given calendar day, from Wikipedia. */
export const fetchOnThisDay = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { month?: unknown; day?: unknown } | undefined;
    const now = new Date();
    const month = typeof raw?.month === "number" ? raw.month : now.getUTCMonth() + 1;
    const day = typeof raw?.day === "number" ? raw.day : now.getUTCDate();
    return {
      month: Math.min(12, Math.max(1, Math.round(month))),
      day: Math.min(31, Math.max(1, Math.round(day))),
    };
  })
  .handler(async ({ data }): Promise<HistoryEvent[]> => {
    const res = await fetch(
      `https://api.wikimedia.org/feed/v1/wikipedia/en/onthisday/events/${pad(data.month)}/${pad(data.day)}`,
      { headers: { accept: "application/json", "user-agent": "Sideline/1.0 (sports history)" } },
    ).catch(() => null);
    if (!res || !res.ok) return [];
    const payload: any = await res.json().catch(() => null);
    const events: any[] = Array.isArray(payload?.events) ? payload.events : [];

    return events
      .map((e: any): HistoryEvent | null => {
        const text = typeof e?.text === "string" ? e.text : "";
        if (!text) return null;
        const page: any = Array.isArray(e?.pages) ? e.pages[0] : undefined;
        const haystack = `${text} ${page?.title ?? ""}`.toLowerCase();
        if (!SPORT_WORDS.some((w) => haystack.includes(w))) return null;
        return {
          year: e?.year ? String(e.year) : "",
          text,
          url: typeof page?.content_urls?.desktop?.page === "string" ? page.content_urls.desktop.page : null,
          thumbnail: typeof page?.thumbnail?.source === "string" ? page.thumbnail.source : null,
        };
      })
      .filter((e: HistoryEvent | null): e is HistoryEvent => e !== null)
      .sort((a, b) => Number(b.year) - Number(a.year));
  });
