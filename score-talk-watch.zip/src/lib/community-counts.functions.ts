import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";


export interface PostLikeCount {
  post_id: string;
  likes: number;
}

export interface GameReactionCount {
  game_id: string;
  emoji: string;
  total: number;
}

export interface ProfileName {
  id: string;
  display_name: string;
  favorite_team: string | null;
}

/**
 * Display names for the authors of posts and chat messages on screen.
 *
 * Profiles are private to their owner, so the server only resolves a name when
 * that person actually authored visible community content (or is the caller
 * themselves). Nothing else about a profile ever leaves the server.
 */
export const fetchProfileNames = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => {
    const raw = (data as { ids?: unknown } | undefined)?.ids;
    const ids = (Array.isArray(raw) ? raw : [])
      .filter((v): v is string => typeof v === "string" && /^[0-9a-f-]{36}$/i.test(v))
      .slice(0, 300);
    return { ids };
  })
  .handler(async ({ data, context }): Promise<ProfileName[]> => {
    if (!data.ids.length) return [];
    const { supabase, userId } = context;

    // Only authors of content the caller can already see are resolvable: these
    // reads go through the caller's own session, so the database's visibility
    // rules decide which authors are in scope.
    const [posts, chat] = await Promise.all([
      supabase.from("community_posts").select("user_id").in("user_id", data.ids),
      supabase.from("prediction_chat").select("user_id").in("user_id", data.ids),
    ]);
    if (posts.error || chat.error) {
      console.error("fetchProfileNames author lookup failed", posts.error ?? chat.error);
      return [];
    }
    const allowed = new Set<string>([userId]);
    for (const r of posts.data ?? []) allowed.add(r.user_id);
    for (const r of chat.data ?? []) allowed.add(r.user_id);
    const ids = data.ids.filter((id) => allowed.has(id));
    if (!ids.length) return [];

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin
      .from("profiles")
      .select("id, display_name")
      .in("id", ids);
    if (error) {
      console.error("fetchProfileNames profile lookup failed", error);
      return [];
    }
    return (rows ?? []).map((r) => ({
      id: r.id,
      display_name: r.display_name ?? "Fan",
      favorite_team: null,
    }));
  });

export interface PollVoteCount {
  poll_id: string;
  option_id: string;
  total: number;
}

/**
 * Aggregate community counters.
 *
 * The underlying tables only let a signed-in fan read their own rows, so the
 * totals are produced by trusted server-side aggregates. Only anonymous counts
 * leave the server — never who liked, reacted or voted.
 */
export const fetchPostLikeCounts = createServerFn({ method: "GET" }).handler(
  async (): Promise<PostLikeCount[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("post_like_counts");
    if (error) {
      console.error("fetchPostLikeCounts failed", error);
      throw new Error("Could not load like counts");
    }
    return (data ?? []).map((r) => ({ post_id: r.post_id, likes: Number(r.likes) }));
  },
);

export const fetchGameReactionCounts = createServerFn({ method: "GET" }).handler(
  async (): Promise<GameReactionCount[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("game_reaction_counts");
    if (error) {
      console.error("fetchGameReactionCounts failed", error);
      throw new Error("Could not load reaction counts");
    }
    return (data ?? []).map((r) => ({
      game_id: r.game_id,
      emoji: r.emoji,
      total: Number(r.total),
    }));
  },
);

export const fetchPollVoteCounts = createServerFn({ method: "GET" }).handler(
  async (): Promise<PollVoteCount[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("poll_vote_counts");
    if (error) {
      console.error("fetchPollVoteCounts failed", error);
      throw new Error("Could not load poll results");
    }
    return (data ?? []).map((r) => ({
      poll_id: r.poll_id,
      option_id: r.option_id,
      total: Number(r.total),
    }));
  },
);
