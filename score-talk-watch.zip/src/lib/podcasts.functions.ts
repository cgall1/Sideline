import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface PodcastShow {
  id: string;
  league: LeagueId;
  title: string;
  publisher: string;
  summary: string;
  artwork: string | null;
  feedUrl: string;
  siteUrl: string | null;
  episodeCount: number;
}

export interface PodcastEpisode {
  id: string;
  title: string;
  summary: string;
  published: string;
  duration: string;
  audioUrl: string;
  pageUrl: string | null;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs"];

const SEARCH_TERMS: Record<LeagueId, string[]> = {
  nfl: ["NFL football podcast", "fantasy football podcast", "NFL draft podcast"],
  nba: ["NBA basketball podcast", "NBA fantasy basketball podcast", "NBA trade rumors podcast"],
  wnba: ["WNBA podcast", "women's basketball podcast", "WNBA news podcast"],
  nwsl: ["NWSL podcast", "women's soccer podcast", "NWSL news podcast"],
  sball: ["college softball podcast", "NCAA softball podcast", "softball podcast"],
  vball: ["college volleyball podcast", "NCAA volleyball podcast", "volleyball podcast"],
  nhl: ["NHL hockey podcast", "fantasy hockey podcast", "Stanley Cup hockey podcast"],

  mlb: [
    "MLB baseball podcast",
    "baseball podcast",
    "fantasy baseball podcast",
    "World Series baseball podcast",
  ],
  mls: ["MLS soccer podcast", "American soccer podcast", "Major League Soccer podcast"],
  intl: [
    "Champions League soccer podcast",
    "Premier League football podcast",
    "world football soccer podcast",
  ],
  cfb: ["college football podcast", "CFB playoff podcast", "college football recruiting podcast"],

  cbb: [
    "college basketball podcast",
    "college hoops podcast",
    "NCAA basketball podcast",
    "March Madness podcast",
    "college basketball recruiting podcast",
  ],
  chk: [
    "college hockey podcast",
    "NCAA hockey podcast",
    "Frozen Four hockey podcast",
    "college hockey recruiting podcast",
  ],
  cbs: [
    "college baseball podcast",
    "NCAA baseball podcast",
    "College World Series podcast",
    "college baseball recruiting podcast",
  ],
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function stripTags(html: string): string {
  return html
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function tag(xml: string, name: string): string {
  const match = xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, "i"));
  return match?.[1] ? stripTags(match[1]) : "";
}

function attr(xml: string, tagName: string, attribute: string): string {
  const el = xml.match(new RegExp(`<${tagName}[^>]*>`, "i"))?.[0] ?? "";
  const value = el.match(new RegExp(`${attribute}\\s*=\\s*"([^"]*)"`, "i"))?.[1] ?? "";
  return value.replace(/&amp;/g, "&");
}

/** Turn "1789" or "01:29:49" into a readable "29 min" / "1 hr 29 min". */
function formatDuration(raw: string): string {
  if (!raw) return "";
  let seconds = 0;
  if (/^\d+$/.test(raw)) seconds = Number(raw);
  else {
    const parts = raw.split(":").map(Number);
    if (parts.some((n) => !Number.isFinite(n))) return raw;
    seconds = parts.reduce((total, part) => total * 60 + part, 0);
  }
  if (!seconds) return "";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.round((seconds % 3600) / 60);
  return hours ? `${hours} hr ${minutes} min` : `${minutes} min`;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/** Sports podcast shows for one league, from the public podcast directory. */
export const fetchPodcastShows = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }): Promise<{ league: LeagueId; shows: PodcastShow[] }> => {
    const league = data.league;
    const responses = await Promise.allSettled(
      SEARCH_TERMS[league].map(async (term) => {
        const res = await fetch(
          `https://itunes.apple.com/search?term=${encodeURIComponent(
            term,
          )}&media=podcast&entity=podcast&limit=24`,
          { headers: { accept: "application/json" } },
        );
        if (!res.ok) throw new Error(`Podcast directory ${res.status}`);
        const payload: any = await res.json();
        return Array.isArray(payload?.results) ? (payload.results as any[]) : [];
      }),
    );
    const results = responses.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
    if (!results.length && responses.every((r) => r.status === "rejected")) {
      throw new Error("Podcast directory unavailable");
    }

    const shows = results
      .map((r): PodcastShow | null => {
        const feedUrl = str(r?.feedUrl);
        const title = str(r?.collectionName ?? r?.trackName);
        if (!feedUrl || !title) return null;
        return {
          id: String(r?.collectionId ?? feedUrl),
          league,
          title,
          publisher: str(r?.artistName, "Independent"),
          summary: (Array.isArray(r?.genres) ? r.genres : []).join(" · ") || "Sports podcast",
          artwork: str(r?.artworkUrl600 ?? r?.artworkUrl100) || null,
          feedUrl,
          siteUrl: str(r?.collectionViewUrl) || null,
          episodeCount: Number(r?.trackCount) || 0,
        };
      })
      .filter((s): s is PodcastShow => s !== null);

    const seen = new Set<string>();
    const unique = shows.filter((s) => {
      const key = s.feedUrl.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    return { league, shows: unique };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */

/** Hosts that are never valid podcast feeds — internal, loopback or metadata addresses. */
const BLOCKED_HOST = /^(localhost$|.*\.local$|.*\.internal$|\[?::1\]?$|0\.0\.0\.0$)/i;
const PRIVATE_IPV4 =
  /^(10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)/;

/** Upgrade legacy plain-http feed addresses to https before validating. */
function httpsFirst(raw: string): string {
  return raw.replace(/^http:\/\//i, "https://");
}

/**
 * Reject anything that isn't a plain public host, so this endpoint can't
 * be used to make the server reach internal services or cloud metadata.
 * `scheme` locks the protocol: https for new inputs, http only for the
 * legacy-feed retry, and "any" for where a redirect chain lands.
 */
function safeFeedHost(raw: string, scheme: "https" | "http" | "any"): string {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("A podcast feed address is required.");
  }
  const host = url.hostname.toLowerCase();
  if (
    (scheme === "https" && url.protocol !== "https:") ||
    (scheme === "http" && url.protocol !== "http:") ||
    url.port !== "" ||
    url.username ||
    url.password ||
    !host.includes(".") ||
    BLOCKED_HOST.test(host) ||
    PRIVATE_IPV4.test(host) ||
    host.startsWith("[") ||
    /^\d+\.\d+\.\d+\.\d+$/.test(host)
  ) {
    throw new Error("That podcast feed address isn't allowed.");
  }
  return url.toString();
}

function safeFeedUrl(raw: string): string {
  return safeFeedHost(raw, "https");
}

/**
 * Latest playable episodes for a podcast show.
 *
 * The caller sends only the show's directory ID; the server looks up the
 * feed address from the podcast directory itself, so visitors can never
 * point this endpoint at an address of their choosing.
 */
export const fetchPodcastEpisodes = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = str((data as { showId?: unknown } | undefined)?.showId);
    if (!/^\d{1,20}$/.test(raw)) throw new Error("A podcast show is required.");
    return { showId: raw };
  })
  .handler(async ({ data }): Promise<{ episodes: PodcastEpisode[] }> => {
    // Resolve the feed address from the directory — never from the caller.
    const lookup = await fetch(
      `https://itunes.apple.com/lookup?id=${data.showId}&entity=podcast`,
      { headers: { accept: "application/json" } },
    );
    if (!lookup.ok) throw new Error("Podcast directory unavailable");
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    const payload: any = await lookup.json();
    const feedUrl = str(payload?.results?.[0]?.feedUrl);
    if (!feedUrl) throw new Error("That podcast has no playable feed.");

    const attempts = [safeFeedUrl(httpsFirst(feedUrl))];
    if (/^http:\/\//i.test(feedUrl)) attempts.push(safeFeedHost(feedUrl, "http"));
    let res: Response | null = null;
    let failure: unknown = null;
    for (const url of attempts) {
      try {
        const attempt = await fetch(url, {
          redirect: "follow",
          headers: {
            accept: "application/rss+xml, application/xml, text/xml",
            "user-agent": "Sideline/1.0",
          },
        });
        // A redirect chain must also land on a public host.
        safeFeedHost(attempt.url || url, "any");
        if (attempt.ok) {
          res = attempt;
          break;
        }
        failure = new Error(`Podcast feed ${attempt.status}`);
      } catch (err) {
        failure = err;
      }
    }
    if (!res) {
      throw failure instanceof Error ? failure : new Error("Podcast feed unavailable");
    }
    const xml = await res.text();
    const items = xml.match(/<item[\s\S]*?<\/item>/gi) ?? [];

    const episodes = items
      .slice(0, 12)
      .map((item, index): PodcastEpisode | null => {
        const audioUrl = attr(item, "enclosure", "url");
        const title = tag(item, "title");
        if (!audioUrl || !title) return null;
        const description = tag(item, "description") || tag(item, "itunes:summary");
        return {
          id: tag(item, "guid") || `${index}-${audioUrl}`,
          title,
          summary: description.slice(0, 320),
          published: tag(item, "pubDate"),
          duration: formatDuration(tag(item, "itunes:duration")),
          audioUrl,
          pageUrl: tag(item, "link") || null,
        };
      })
      .filter((e): e is PodcastEpisode => e !== null);

    return { episodes };
  });
