import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { publicCounts } from "@/lib/public-counts.functions";
import { recordFanActivity } from "@/lib/daily";

/** A fan community: a team, a league, a sport, or an open topic. */
export interface Space {
  id: string;
  slug: string;
  name: string;
  kind: string;
  league: string | null;
  teamId: string | null;
  description: string;
  members: number;
  posts: number;
  joined: boolean;
}

export interface SpacePost {
  id: string;
  spaceId: string;
  spaceSlug: string;
  spaceName: string;
  userId: string;
  author: string;
  title: string;
  body: string;
  kind: string;
  createdAt: string;
  votes: number;
  votedByMe: boolean;
  replies: number;
}

export interface SpaceReply {
  id: string;
  postId: string;
  parentId: string | null;
  userId: string;
  author: string;
  body: string;
  createdAt: string;
  votes: number;
  votedByMe: boolean;
}

export const POST_KINDS = [
  { id: "discussion", label: "Discussion" },
  { id: "debate", label: "Debate" },
  { id: "question", label: "Question" },
  { id: "opinion", label: "Opinion" },
  { id: "poll", label: "Poll" },
  { id: "hottake", label: "Hot take" },
] as const;

export type PostKind = (typeof POST_KINDS)[number]["id"];

export function kindLabel(id: string): string {
  return POST_KINDS.find((k) => k.id === id)?.label ?? "Discussion";
}

export type SortMode = "hot" | "new" | "top";

export function relativeTime(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (diff < 1) return "just now";
  if (diff < 60) return `${diff}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return `${Math.floor(diff / 1440)}d ago`;
}

/** Upvotes and replies, decayed by age — computed client-side, no cron needed. */
function hotScore(p: SpacePost): number {
  const hours = (Date.now() - new Date(p.createdAt).getTime()) / 3600000;
  return (p.votes * 2 + p.replies * 3 + 1) / Math.pow(hours + 2, 1.3);
}

export function sortPosts(posts: SpacePost[], mode: SortMode): SpacePost[] {
  const list = [...posts];
  if (mode === "new")
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (mode === "top") return list.sort((a, b) => b.votes - a.votes);
  return list.sort((a, b) => hotScore(b) - hotScore(a));
}

const BLOCKED = ["fuck", "shit", "bitch", "cunt", "nigger", "faggot", "retard"];

/** Light-touch filter so spaces stay usable; masks rather than rejects. */
export function cleanText(text: string): string {
  let out = text;
  for (const word of BLOCKED) {
    out = out.replace(new RegExp(word, "gi"), (m) => "*".repeat(m.length));
  }
  return out;
}

interface SpaceRow {
  id: string;
  slug: string;
  name: string;
  kind: string;
  league: string | null;
  team_id: string | null;
  description: string;
}

async function loadSpaces(userId: string | null): Promise<Space[]> {
  const [spacesRes, memberCountsRes, myMembershipsRes, postsRes] = await Promise.all([
    supabase
      .from("spaces")
      .select("id, slug, name, kind, league, team_id, description")
      .order("name"),
    (publicCounts({ data: { fn: "space_member_counts" } }) as Promise<{ data: any[] | null; error: any }>),
    userId
      ? supabase.from("space_members").select("space_id").eq("user_id", userId)
      : Promise.resolve({ data: [] as { space_id: string }[], error: null }),
    supabase.from("space_posts").select("space_id"),
  ]);
  if (spacesRes.error) throw spacesRes.error;

  const postRows = postsRes.data ?? [];
  const counts = new Map<string, number>();
  for (const row of memberCountsRes.data ?? []) counts.set(row.space_id, Number(row.total));
  const postCounts = new Map<string, number>();
  for (const p of postRows) postCounts.set(p.space_id, (postCounts.get(p.space_id) ?? 0) + 1);
  const mine = new Set((myMembershipsRes.data ?? []).map((m) => m.space_id));

  return (spacesRes.data ?? []).map((s: SpaceRow) => ({
    id: s.id,
    slug: s.slug,
    name: s.name,
    kind: s.kind,
    league: s.league,
    teamId: s.team_id,
    description: s.description,
    members: counts.get(s.id) ?? 0,
    posts: postCounts.get(s.id) ?? 0,
    joined: mine.has(s.id),
  }));
}

export const spacesQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "list", userId ?? "anon"],
    queryFn: () => loadSpaces(userId),
    staleTime: 30_000,
  });

interface PostRow {
  id: string;
  space_id: string;
  user_id: string;
  author_name: string;
  title: string;
  body: string;
  kind: string;
  created_at: string;
}

async function loadPosts(
  userId: string | null,
  filter?: { spaceId?: string; authorId?: string },
): Promise<SpacePost[]> {
  let query = supabase
    .from("space_posts")
    .select("id, space_id, user_id, author_name, title, body, kind, created_at")
    .order("created_at", { ascending: false })
    .limit(200);
  if (filter?.spaceId) query = query.eq("space_id", filter.spaceId);
  if (filter?.authorId) query = query.eq("user_id", filter.authorId);

  const [postsRes, spacesRes, voteCountsRes, myVotesRes, repliesRes] = await Promise.all([
    query,
    supabase.from("spaces").select("id, slug, name"),
    (publicCounts({ data: { fn: "space_vote_counts" } }) as Promise<{ data: any[] | null; error: any }>),
    userId
      ? supabase.from("space_votes").select("post_id").not("post_id", "is", null)
      : Promise.resolve({ data: [] as { post_id: string | null }[], error: null }),
    supabase.from("space_replies").select("post_id"),
  ]);
  if (postsRes.error) throw postsRes.error;

  const spaceMap = new Map(
    (spacesRes.data ?? []).map((s) => [s.id, { slug: s.slug, name: s.name }]),
  );
  const votes = new Map<string, number>();
  for (const v of voteCountsRes.data ?? []) {
    if (v.post_id) votes.set(v.post_id, Number(v.total));
  }
  const mine = new Set<string>();
  for (const v of myVotesRes.data ?? []) {
    if (v.post_id) mine.add(v.post_id);
  }
  const replies = new Map<string, number>();
  for (const r of repliesRes.data ?? [])
    replies.set(r.post_id, (replies.get(r.post_id) ?? 0) + 1);

  return (postsRes.data ?? []).map((p: PostRow) => ({
    id: p.id,
    spaceId: p.space_id,
    spaceSlug: spaceMap.get(p.space_id)?.slug ?? "",
    spaceName: spaceMap.get(p.space_id)?.name ?? "Sideline",
    userId: p.user_id,
    author: p.author_name,
    title: p.title,
    body: p.body,
    kind: p.kind,
    createdAt: p.created_at,
    votes: votes.get(p.id) ?? 0,
    votedByMe: mine.has(p.id),
    replies: replies.get(p.id) ?? 0,
  }));
}

export const feedQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "feed", userId ?? "anon"],
    queryFn: () => loadPosts(userId),
    staleTime: 15_000,
  });

export const spacePostsQueryOptions = (spaceId: string, userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "posts", spaceId, userId ?? "anon"],
    queryFn: () => loadPosts(userId, { spaceId }),
    staleTime: 15_000,
  });

export const fanPostsByAuthorQueryOptions = (authorId: string, userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "author", authorId, userId ?? "anon"],
    queryFn: () => loadPosts(userId, { authorId }),
    staleTime: 15_000,
  });

export const postQueryOptions = (postId: string, userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "post", postId, userId ?? "anon"],
    queryFn: async (): Promise<SpacePost | null> => {
      const all = await loadPosts(userId);
      const found = all.find((p) => p.id === postId);
      if (found) return found;
      // Older post outside the recent window — fetch it directly.
      const { data } = await supabase
        .from("space_posts")
        .select("id, space_id, user_id, author_name, title, body, kind, created_at")
        .eq("id", postId)
        .maybeSingle();
      if (!data) return null;
      const { data: space } = await supabase
        .from("spaces")
        .select("slug, name")
        .eq("id", data.space_id)
        .maybeSingle();
      return {
        id: data.id,
        spaceId: data.space_id,
        spaceSlug: space?.slug ?? "",
        spaceName: space?.name ?? "Sideline",
        userId: data.user_id,
        author: data.author_name,
        title: data.title,
        body: data.body,
        kind: data.kind,
        createdAt: data.created_at,
        votes: 0,
        votedByMe: false,
        replies: 0,
      };
    },
  });

export const repliesQueryOptions = (postId: string, userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "replies", postId, userId ?? "anon"],
    queryFn: async (): Promise<SpaceReply[]> => {
      const [repliesRes, voteCountsRes, myVotesRes] = await Promise.all([
        supabase
          .from("space_replies")
          .select("id, post_id, parent_id, user_id, author_name, body, created_at")
          .eq("post_id", postId)
          .order("created_at"),
        (publicCounts({ data: { fn: "space_vote_counts" } }) as Promise<{ data: any[] | null; error: any }>),
        userId
          ? supabase.from("space_votes").select("reply_id").not("reply_id", "is", null)
          : Promise.resolve({ data: [] as { reply_id: string | null }[], error: null }),
      ]);
      if (repliesRes.error) throw repliesRes.error;
      const votes = new Map<string, number>();
      for (const v of voteCountsRes.data ?? []) {
        if (v.reply_id) votes.set(v.reply_id, Number(v.total));
      }
      const mine = new Set<string>();
      for (const v of myVotesRes.data ?? []) {
        if (v.reply_id) mine.add(v.reply_id);
      }
      return (repliesRes.data ?? []).map((r) => ({
        id: r.id,
        postId: r.post_id,
        parentId: r.parent_id,
        userId: r.user_id,
        author: r.author_name,
        body: r.body,
        createdAt: r.created_at,
        votes: votes.get(r.id) ?? 0,
        votedByMe: mine.has(r.id),
      }));
    },
    staleTime: 10_000,
  });

export interface PollOption {
  id: string;
  label: string;
  votes: number;
}

export const pollQueryOptions = (postId: string, userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "poll", postId, userId ?? "anon"],
    queryFn: async (): Promise<{ options: PollOption[]; mine: string | null }> => {
      const [optionsRes, countsRes, myVoteRes] = await Promise.all([
        supabase
          .from("space_poll_options")
          .select("id, label, position")
          .eq("post_id", postId)
          .order("position"),
        (publicCounts({ data: { fn: "space_poll_option_counts", args: { _post: postId } } }) as Promise<{ data: any[] | null; error: any }>),
        userId
          ? supabase.from("space_poll_votes").select("option_id").eq("post_id", postId)
          : Promise.resolve({ data: [] as { option_id: string }[], error: null }),
      ]);
      const tally = new Map<string, number>();
      for (const row of countsRes.data ?? []) tally.set(row.option_id, Number(row.total));
      const mine: string | null = myVoteRes.data?.[0]?.option_id ?? null;
      return {
        options: (optionsRes.data ?? []).map((o) => ({
          id: o.id,
          label: o.label,
          votes: tally.get(o.id) ?? 0,
        })),
        mine,
      };
    },
    staleTime: 10_000,
  });

export const fanFollowsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["spaces", "follows", userId ?? "anon"],
    queryFn: async (): Promise<{ following: string[]; followers: Record<string, number> }> => {
      const [countsRes, mineRes] = await Promise.all([
        (publicCounts({ data: { fn: "space_follower_counts" } }) as Promise<{ data: any[] | null; error: any }>),
        userId
          ? supabase.from("space_follows").select("followee_id").eq("follower_id", userId)
          : Promise.resolve({ data: [] as { followee_id: string }[], error: null }),
      ]);
      const followers: Record<string, number> = {};
      for (const row of countsRes.data ?? []) followers[row.followee_id] = Number(row.total);
      const following: string[] = (mineRes.data ?? []).map((r) => r.followee_id);
      return { following, followers };
    },
    staleTime: 30_000,
  });

/* ---------------------------------------------------------------- actions */

export async function joinSpace(spaceId: string, userId: string, joined: boolean) {
  if (joined) {
    await supabase.from("space_members").delete().eq("space_id", spaceId).eq("user_id", userId);
  } else {
    await supabase.from("space_members").insert({ space_id: spaceId, user_id: userId });
  }
}

export async function createSpacePost(input: {
  spaceId: string;
  userId: string;
  author: string;
  title: string;
  body: string;
  kind: PostKind;
  pollOptions?: string[];
}): Promise<string> {
  const { data, error } = await supabase
    .from("space_posts")
    .insert({
      space_id: input.spaceId,
      user_id: input.userId,
      author_name: input.author,
      title: cleanText(input.title.slice(0, 160)),
      body: cleanText(input.body.slice(0, 4000)),
      kind: input.kind,
    })
    .select("id")
    .single();
  if (error) throw error;
  const options = (input.pollOptions ?? []).map((l) => l.trim()).filter(Boolean).slice(0, 4);
  if (options.length >= 2) {
    await supabase.from("space_poll_options").insert(
      options.map((label, i) => ({ post_id: data.id, label: cleanText(label.slice(0, 80)), position: i })),
    );
  }
  await recordFanActivity();
  return data.id;
}

export async function deleteSpacePost(id: string) {
  await supabase.from("space_posts").delete().eq("id", id);
}

export async function addReply(input: {
  postId: string;
  parentId: string | null;
  userId: string;
  author: string;
  body: string;
}) {
  const { error } = await supabase.from("space_replies").insert({
    post_id: input.postId,
    parent_id: input.parentId,
    user_id: input.userId,
    author_name: input.author,
    body: cleanText(input.body.slice(0, 2000)),
  });
  if (error) throw error;
  await recordFanActivity();
}

export async function deleteReply(id: string) {
  await supabase.from("space_replies").delete().eq("id", id);
}

export async function toggleVote(
  target: { postId?: string; replyId?: string },
  userId: string,
  voted: boolean,
) {
  if (voted) {
    let q = supabase.from("space_votes").delete().eq("user_id", userId);
    q = target.postId ? q.eq("post_id", target.postId) : q.eq("reply_id", target.replyId!);
    await q;
  } else {
    await supabase.from("space_votes").insert({
      user_id: userId,
      post_id: target.postId ?? null,
      reply_id: target.replyId ?? null,
    });
  }
  await recordFanActivity();
}

export async function castPollVote(postId: string, userId: string, optionId: string) {
  await supabase
    .from("space_poll_votes")
    .upsert({ post_id: postId, user_id: userId, option_id: optionId }, { onConflict: "post_id,user_id" });
}

export async function toggleFanFollow(followerId: string, followeeId: string, following: boolean) {
  if (following) {
    await supabase
      .from("space_follows")
      .delete()
      .eq("follower_id", followerId)
      .eq("followee_id", followeeId);
  } else {
    await supabase.from("space_follows").insert({
      follower_id: followerId,
      followee_id: followeeId,
    });
  }
}

export async function reportContent(
  target: { postId?: string; replyId?: string },
  userId: string,
  reason: string,
) {
  await supabase.from("space_reports").insert({
    user_id: userId,
    post_id: target.postId ?? null,
    reply_id: target.replyId ?? null,
    reason: reason.slice(0, 300),
  });
}

/** Simple flood guard: at most 5 posts or replies a minute, per device. */
const RATE_KEY = "sideline.space.rate";

export function rateLimited(): boolean {
  if (typeof window === "undefined") return false;
  const now = Date.now();
  let stamps: number[] = [];
  try {
    stamps = JSON.parse(window.localStorage.getItem(RATE_KEY) ?? "[]") as number[];
  } catch {
    stamps = [];
  }
  stamps = stamps.filter((t) => now - t < 60_000);
  if (stamps.length >= 5) return true;
  stamps.push(now);
  window.localStorage.setItem(RATE_KEY, JSON.stringify(stamps));
  return false;
}
