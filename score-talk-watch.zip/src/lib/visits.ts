import { useEffect } from "react";
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface HubVisitRow {
  path: string;
  label: string;
  total: number;
  last7: number;
  lastVisit: string | null;
}

/** Record one visit to a hub page. Fire-and-forget; failures never block the page. */
export async function recordHubVisit(path: string, label: string): Promise<void> {
  try {
    await supabase.from("hub_views").insert({ path, label });
  } catch {
    // analytics is best-effort
  }
}

/** Log a visit once per mount. */
export function useTrackHubVisit(path: string, label: string): void {
  useEffect(() => {
    void recordHubVisit(path, label);
  }, [path, label]);
}

export const hubVisitsQueryOptions = () =>
  queryOptions({
    queryKey: ["hub-visits"],
    staleTime: 30_000,
    refetchInterval: 60_000,
    queryFn: async (): Promise<HubVisitRow[]> => {
      const since = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
      const { data, error } = await supabase
        .from("hub_views")
        .select("path, label, created_at")
        .gte("created_at", since)
        .order("created_at", { ascending: false })
        .limit(5000);
      if (error) throw new Error(error.message);

      const weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
      const byPath = new Map<string, HubVisitRow>();
      for (const row of data ?? []) {
        const current = byPath.get(row.path) ?? {
          path: row.path,
          label: row.label,
          total: 0,
          last7: 0,
          lastVisit: null,
        };
        current.total += 1;
        if (new Date(row.created_at).getTime() >= weekAgo) current.last7 += 1;
        if (!current.lastVisit) current.lastVisit = row.created_at;
        byPath.set(row.path, current);
      }
      return [...byPath.values()].sort((a, b) => b.total - a.total);
    },
  });
