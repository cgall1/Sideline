import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Row = { current_days: number; longest_days: number; badges: string[] };

/** The signed-in fan's own streak and badges — never another fan's. */
export const getMyFanStanding = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ data: Row[] | null }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.rpc("fan_standing", { _user: context.userId });
    if (error) {
      console.error("fan standing failed", error);
      return { data: null };
    }
    return { data: (data as Row[]) ?? [] };
  });
