import { createServerFn } from "@tanstack/react-start";

export interface LeagueVideo {
  id: string;
  title: string;
  url: string;
  embedUrl: string;
  thumbnail: string;
  published: string;
  channel: string;
  description: string;
}

/** Official league video channels (YouTube feeds — no key needed, always current). */
const CHANNELS: Record<string, { channelId: string; channel: string }[]> = {
  nhl: [
    { channelId: "UCqFMzb-4AUf6WAIbl132QKA", channel: "NHL" },
    { channelId: "UCkBY0aHJP9BwjZLDYxAQrKg", channel: "Sportsnet NHL" },
  ],
  nfl: [{ channelId: "UCDVYQ4Zhbm3S2dlz7P1GBDg", channel: "NFL" }],
  nba: [{ channelId: "UCWJ2lWNubArHWmf3FIHbfcQ", channel: "NBA" }],
  mlb: [{ channelId: "UCoLrcjPV5PbUrUyXq5mjc_A", channel: "MLB" }],
  mls: [{ channelId: "UCAgGTgxJTW9d4wQHlcOJhCA", channel: "Major League Soccer" }],
  cfb: [
    { channelId: "UCzRWWsFjqHk1an4OnVPsl9g", channel: "ESPN College Football" },
    { channelId: "UC0nOdMq78X8ifkIxnIoqfHQ", channel: "NCAA" },
  ],
  cbb: [
    { channelId: "UC0nOdMq78X8ifkIxnIoqfHQ", channel: "NCAA" },
    { channelId: "UCYbbpwosQ0a2d3ygPpruJ1w", channel: "NCAA Championships" },
  ],
  chk: [
    { channelId: "UCYbbpwosQ0a2d3ygPpruJ1w", channel: "NCAA Championships" },
    { channelId: "UC0nOdMq78X8ifkIxnIoqfHQ", channel: "NCAA" },
  ],
  epl: [{ channelId: "UCG5qGWdu8nIRZqJ_GgDwQ-w", channel: "Premier League" }],
  laliga: [{ channelId: "UCTv-XvfzLX3i4IGWAm4sbmA", channel: "LALIGA EA SPORTS" }],
  bundesliga: [{ channelId: "UC6UL29enLNe4mqwTfAyeNuw", channel: "Bundesliga" }],
  seriea: [{ channelId: "UCBJeMCIeLQos7wacox4hmLQ", channel: "Serie A" }],
  ligue1: [{ channelId: "UCQsH5XtIc9hONE1BQjucM0g", channel: "Ligue 1" }],
  ucl: [{ channelId: "UCyGa1YEx9ST66rYrJTGIKOw", channel: "UEFA" }],
  tennis: [
    { channelId: "UCY_5h5zaSwN7Or4kIJDYNXA", channel: "ATP Tour" },
    { channelId: "UCaBIVVpHjq6j3tSyxwTE-8Q", channel: "WTA" },
    { channelId: "UCNa8NxMgSm7m4Ii9d4QGk1Q", channel: "Wimbledon" },
  ],
  ufc: [{ channelId: "UCvgfXK4nTYKudb0rFR6noLA", channel: "UFC" }],
  boxing: [{ channelId: "UCiWLfSweyRNmLpgEHekhoAg", channel: "ESPN Boxing" }],
  golf: [{ channelId: "UCKwGZZMrhNYKzucCtTPY2Nw", channel: "PGA TOUR" }],
  nascar: [{ channelId: "UCuN9hYw2RpoAW8rZ3VK3isA", channel: "NASCAR" }],
};

function tag(xml: string, name: string): string {
  const match = new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`).exec(xml);
  return match?.[1] ?? "";
}

function decode(text: string): string {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .trim();
}

async function fetchChannel(channelId: string, channel: string): Promise<LeagueVideo[]> {
  const res = await fetch(
    `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`,
    { headers: { accept: "application/atom+xml" } },
  );
  if (!res.ok) return [];
  const xml = await res.text();
  const entries = xml.split("<entry>").slice(1);
  const videos: LeagueVideo[] = [];
  for (const entry of entries) {
    const id = decode(tag(entry, "yt:videoId"));
    const title = decode(tag(entry, "title"));
    if (!id || !title) continue;
    const thumb = /<media:thumbnail url="([^"]+)"/.exec(entry)?.[1];
    videos.push({
      id,
      title,
      url: `https://www.youtube.com/watch?v=${id}`,
      embedUrl: `https://www.youtube-nocookie.com/embed/${id}`,
      thumbnail: thumb ?? `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      published: decode(tag(entry, "published")) || new Date().toISOString(),
      channel,
      description: decode(tag(entry, "media:description")).slice(0, 240),
    });
  }
  return videos;
}

/** Title keywords used to keep multi-sport channels on topic. */
const KEYWORDS: Record<string, string[]> = {
  boxing: ["boxing", "knockout", " vs ", "fight", "pound-for-pound", "top rank"],
  chk: ["ice hockey", "frozen four", "men's hockey", "women's hockey", "puck"],
  cbb: ["basketball", "march madness", "final four", "hoops"],
  cfb: ["football", "bowl", "touchdown"],
};

/** Match-clip keywords floated to the top of a reel (soccer channels post shorts too). */
const PREFER: Record<string, string[]> = {
  epl: ["highlights", "matchday", " vs ", " v ", "goals", "recap", "match"],
  laliga: ["highlights", "resumen", "jornada", " vs ", "goals", "goles", "match"],
  bundesliga: ["highlights", "matchday", " vs ", " - ", "goals", "match"],
  seriea: ["highlights", "goals", " vs ", "matchday", "match"],
  ligue1: ["highlights", "goals", " vs ", "matchday", "match"],
  ucl: ["highlights", "goals", " vs ", "matchday", "match"],
};

/** Title keywords that disqualify a clip for a league. */
const EXCLUDE: Record<string, string[]> = {
  chk: ["field hockey", "ncaafh", "lacrosse", "tennis", "track", "volleyball", "soccer"],
  cbb: ["women's volleyball", "football", "soccer", "lacrosse"],
  cfb: ["flag football", "soccer", "basketball"],
};

/** Latest real highlight clips from a league's official video channels. */
export const fetchLeagueVideos = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const league = (data as { league?: unknown } | undefined)?.league;
    return { league: typeof league === "string" && CHANNELS[league] ? league : "nhl" };
  })
  .handler(async ({ data }): Promise<{ league: string; videos: LeagueVideo[] }> => {
    const sources = CHANNELS[data.league] ?? [];
    const lists = await Promise.all(
      sources.map((s) => fetchChannel(s.channelId, s.channel).catch(() => [] as LeagueVideo[])),
    );
    const seen = new Set<string>();
    const all = lists
      .flat()
      .filter((v) => (seen.has(v.id) ? false : (seen.add(v.id), true)))
      .sort((a, b) => b.published.localeCompare(a.published));
    const words = KEYWORDS[data.league];
    const banned = EXCLUDE[data.league] ?? [];
    const onTopic = words
      ? all.filter((v) => {
          const text = `${v.title} ${v.description}`.toLowerCase();
          if (banned.some((w) => text.includes(w))) return false;
          return words.some((w) => text.includes(w));
        })
      : all;
    const preferred = PREFER[data.league];
    const ranked = preferred
      ? [...onTopic].sort((a, b) => {
          const score = (v: (typeof onTopic)[number]) =>
            preferred.some((w) => v.title.toLowerCase().includes(w)) ? 0 : 1;
          return score(a) - score(b) || b.published.localeCompare(a.published);
        })
      : onTopic;
    const videos = ranked.slice(0, 24);
    return { league: data.league, videos };
  });
