import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { fetchGameSummary } from "@/lib/gamedata.functions";

async function writeWithAi(facts: string, key: string): Promise<string | null> {
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": key,
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        stream: true,
        store: false,
        reasoning: { effort: "low" },
        instructions:
          "You write the story of a finished sports game in 90-140 words, plain text, 2 short paragraphs: how it unfolded, the turning point, the standout. Use ONLY the facts given. Never invent stats, quotes, minutes or names.",
        input: facts,
      }),
    });
    if (!res.ok || !res.body) return null;
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    let text = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        try {
          const ev = JSON.parse(line.slice(5).trim()) as { type?: string; delta?: string };
          if (ev.type === "response.output_text.delta" && ev.delta) text += ev.delta;
        } catch {
          /* keep-alive */
        }
      }
    }
    return text.trim() || null;
  } catch {
    return null;
  }
}

/** The written story of a finished game — built once from the real box score, then cached. */
export const getGameStory = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) =>
    z.object({ league: z.string().max(40), gameId: z.string().max(80) }).parse(d),
  )
  .handler(async ({ data }): Promise<{ body: string | null }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: cached } = await supabaseAdmin
      .from("game_stories")
      .select("body")
      .eq("game_id", data.gameId)
      .maybeSingle();
    if (cached?.body) return { body: cached.body };

    const s = await fetchGameSummary({ data: { league: data.league, gameId: data.gameId } } as never).catch(() => null);
    if (!s || s.state !== "post") return { body: null };

    const winner = s.homeScore >= s.awayScore ? s.home : s.away;
    const loser = winner === s.home ? s.away : s.home;
    const facts = [
      `FINAL: ${s.away} ${s.awayScore}, ${s.home} ${s.homeScore}${s.venue ? ` at ${s.venue}` : ""}.`,
      ...s.recap.slice(0, 4).map((r) => `RECAP: ${r}`),
      ...s.timeline.slice(0, 20).map((t) => `PLAY: ${JSON.stringify(t)}`),
      ...s.leaders.slice(0, 6).map((l) => `LEADER: ${l.name} (${l.team}) ${l.category}: ${l.value}`),
      ...s.stats.slice(0, 8).map((st) => `STAT: ${JSON.stringify(st)}`),
    ].join("\n");

    const star = s.leaders[0];
    const fallback =
      `${winner} beat ${loser} ${Math.max(s.homeScore, s.awayScore)}–${Math.min(s.homeScore, s.awayScore)}${s.venue ? ` at ${s.venue}` : ""}.` +
      (star ? ` ${star.name} led the way for ${star.team} with ${star.value} (${star.category}).` : "") +
      (s.recap[0] ? `\n\n${s.recap[0]}` : "");

    // Hard daily ceiling on AI-written stories so public page views can't run up
    // the AI bill; past it, the plain box-score summary is used instead.
    const since = new Date(Date.now() - 86_400_000).toISOString();
    const { count } = await supabaseAdmin
      .from("game_stories")
      .select("game_id", { count: "exact", head: true })
      .gte("created_at", since);
    const underCap = (count ?? 0) < 150;
    const key = process.env["LOVABLE_API_KEY"];
    const body = (key && underCap ? await writeWithAi(facts, key) : null) ?? fallback;
    await supabaseAdmin.from("game_stories").upsert({ game_id: data.gameId, league: data.league, body });
    return { body };
  });
