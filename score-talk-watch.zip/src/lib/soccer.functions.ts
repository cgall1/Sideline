import { createServerFn } from "@tanstack/react-start";
import { ESPN_LEAGUE_SLUGS } from "@/data/soccer-league-ids";
import { SOCCER_COMPETITIONS } from "@/data/soccer";

export interface SoccerMatch {
  id: string;
  date: string;
  dayLabel: string;
  monthKey: string;
  home: string;
  away: string;
  homeScore: string;
  awayScore: string;
  status: "live" | "final" | "scheduled";
  detail: string;
  venue: string;
  city: string;
  highlightUrl: string;
}

export interface SoccerStory {
  id: string;
  headline: string;
  summary: string;
  url: string;
  image: string | null;
  published: string;
  type: string;
}

export interface SoccerHighlightsData {
  slug: string;
  matches: SoccerMatch[];
  stories: SoccerStory[];
}

function compact(d: Date): string {
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapMatch(event: any, competition: string): SoccerMatch | null {
  const comp = event?.competitions?.[0];
  const teams: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
  const home = teams.find((t) => t?.homeAway === "home");
  const away = teams.find((t) => t?.homeAway === "away");
  const homeName: string = home?.team?.displayName ?? "";
  const awayName: string = away?.team?.displayName ?? "";
  if (!homeName || !awayName) return null;

  const state: string = comp?.status?.type?.state ?? "pre";
  const date: string = typeof event?.date === "string" ? event.date : "";
  const when = date ? new Date(date) : new Date();

  return {
    id: String(event?.id ?? `${homeName}-${awayName}-${date}`),
    date,
    dayLabel: when.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    }),
    monthKey: date.slice(0, 7),
    home: homeName,
    away: awayName,
    homeScore: String(home?.score ?? ""),
    awayScore: String(away?.score ?? ""),
    status: state === "in" ? "live" : state === "post" ? "final" : "scheduled",
    detail: String(comp?.status?.type?.shortDetail ?? ""),
    venue: String(comp?.venue?.fullName ?? ""),
    city: String(comp?.venue?.address?.city ?? ""),
    highlightUrl: `https://www.youtube.com/results?search_query=${encodeURIComponent(
      `${awayName} vs ${homeName} ${competition} highlights`,
    )}`,
  };
}

async function fetchYear(
  path: string,
  competition: string,
  year: number,
): Promise<SoccerMatch[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${year}&limit=1000`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
  return events.map((e) => mapMatch(e, competition)).filter((m): m is SoccerMatch => m !== null);
}

/**
 * Matches inside a window around today. The upstream feed rejects explicit
 * date ranges, so we pull whole calendar years and filter locally.
 */
async function fetchMatches(
  path: string,
  competition: string,
  backDays = 21,
  forwardDays = 14,
): Promise<SoccerMatch[]> {
  const now = Date.now();
  const from = new Date(now - backDays * 864e5);
  const to = new Date(now + forwardDays * 864e5);
  const years: number[] = [];
  for (let y = from.getUTCFullYear(); y <= to.getUTCFullYear(); y += 1) years.push(y);

  const chunks = await Promise.all(
    years.map((y) => fetchYear(path, competition, y).catch(() => [] as SoccerMatch[])),
  );

  const fromIso = from.toISOString();
  const toIso = to.toISOString();
  const byId = new Map<string, SoccerMatch>();
  for (const m of chunks.flat()) {
    if (m.date >= fromIso && m.date <= toIso) byId.set(m.id, m);
  }
  return [...byId.values()].sort((a, b) => b.date.localeCompare(a.date));
}

async function fetchStories(path: string): Promise<SoccerStory[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${path}/news?limit=20`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];
  return articles
    .map((a): SoccerStory | null => {
      const url: string = a?.links?.web?.href ?? a?.links?.mobile?.href ?? "";
      const headline: string = typeof a?.headline === "string" ? a.headline : "";
      if (!url || !headline) return null;
      return {
        id: String(a?.id ?? url),
        headline,
        summary: typeof a?.description === "string" ? a.description : "",
        url,
        image: Array.isArray(a?.images)
          ? (a.images.find((i: any) => typeof i?.url === "string")?.url ?? null)
          : null,
        published: typeof a?.published === "string" ? a.published : new Date().toISOString(),
        type: typeof a?.type === "string" ? a.type : "Story",
      };
    })
    .filter((s): s is SoccerStory => s !== null);
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/** Recent matches and video stories for one soccer competition. */
export const fetchSoccerHighlights = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const slug = (data as { slug?: unknown } | undefined)?.slug;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === slug);
    return { slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug };
  })
  .handler(async ({ data }): Promise<SoccerHighlightsData> => {
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const hlPath = await resolvePath(comp);
    const [matches, stories] = await Promise.all([
      fetchMatches(hlPath, comp.name).catch(() => [] as SoccerMatch[]),
      fetchStories(hlPath).catch(() => [] as SoccerStory[]),
    ]);
    return { slug: comp.slug, matches, stories };
  });

export interface SoccerTableRow {
  team: string;
  logo: string | null;
  rank: number;
  gp: number;
  w: number;
  d: number;
  l: number;
  points: number;
  gf: number;
  ga: number;
  note: string;
}

export interface SoccerTable {
  slug: string;
  season: string;
  rows: SoccerTableRow[];
  /** Where the table came from: the official standings feed, or built from played results. */
  source: "standings" | "results" | "none";
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function statValue(stats: any[], name: string): number {
  const stat = stats.find((s) => s?.name === name);
  const value = stat?.value;
  return typeof value === "number" ? value : Number(stat?.displayValue ?? 0) || 0;
}

/** Live league table for one soccer competition. */
export const fetchSoccerTable = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const slug = (data as { slug?: unknown } | undefined)?.slug;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === slug);
    return { slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug };
  })
  .handler(async ({ data }): Promise<SoccerTable> => {
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const path = await resolvePath(comp);
    const res = await fetch(
      `https://site.api.espn.com/apis/v2/sports/${path}/standings`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return tableFromResults(comp.slug, path, comp.name);
    const payload: any = await res.json();
    const children: any[] = Array.isArray(payload?.children) ? payload.children : [];
    const entries: any[] = children.length
      ? children.flatMap((c) => (Array.isArray(c?.standings?.entries) ? c.standings.entries : []))
      : Array.isArray(payload?.standings?.entries)
        ? payload.standings.entries
        : [];

    const rows: SoccerTableRow[] = entries
      .map((entry): SoccerTableRow | null => {
        const team = typeof entry?.team?.displayName === "string" ? entry.team.displayName : "";
        if (!team) return null;
        const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
        const logos: any[] = Array.isArray(entry?.team?.logos) ? entry.team.logos : [];
        return {
          team,
          logo:
            typeof logos.find((l) => typeof l?.href === "string")?.href === "string"
              ? logos.find((l) => typeof l?.href === "string").href
              : null,
          rank: statValue(stats, "rank"),
          gp: statValue(stats, "gamesPlayed"),
          w: statValue(stats, "wins"),
          d: statValue(stats, "ties"),
          l: statValue(stats, "losses"),
          points: statValue(stats, "points"),
          gf: statValue(stats, "pointsFor"),
          ga: statValue(stats, "pointsAgainst"),
          note: typeof entry?.note?.description === "string" ? entry.note.description : "",
        };
      })
      .filter((r): r is SoccerTableRow => r !== null)
      .sort((a, b) => b.points - a.points || b.gf - b.ga - (a.gf - a.ga) || a.team.localeCompare(b.team));

    // No official table yet (new league, pre-season, feed not publishing).
    // Build one from the results feed so the page fills in as soon as matches are played.
    if (!rows.length) return tableFromResults(comp.slug, path, comp.name);

    return {
      slug: comp.slug,
      season: typeof payload?.season?.displayName === "string" ? payload.season.displayName : "",
      rows,
      source: "standings",
    };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */

/**
 * Build a league table out of the results feed.
 * Used when the official standings feed has nothing yet, so a league's table
 * appears automatically as soon as its first results land.
 */
async function tableFromResults(
  slug: string,
  path: string,
  competition: string,
): Promise<SoccerTable> {
  const matches = await fetchMatches(path, competition, 340, 0).catch(() => [] as SoccerMatch[]);
  const played = matches.filter(
    (m) => m.status === "final" && m.homeScore !== "" && m.awayScore !== "",
  );
  if (!played.length) return { slug, season: "", rows: [], source: "none" };

  const table = new Map<string, SoccerTableRow>();
  const row = (team: string): SoccerTableRow => {
    const existing = table.get(team);
    if (existing) return existing;
    const fresh: SoccerTableRow = {
      team,
      logo: null,
      rank: 0,
      gp: 0,
      w: 0,
      d: 0,
      l: 0,
      points: 0,
      gf: 0,
      ga: 0,
      note: "",
    };
    table.set(team, fresh);
    return fresh;
  };

  for (const m of played) {
    const hs = Number(m.homeScore);
    const as = Number(m.awayScore);
    if (!Number.isFinite(hs) || !Number.isFinite(as)) continue;
    const home = row(m.home);
    const away = row(m.away);
    home.gp += 1;
    away.gp += 1;
    home.gf += hs;
    home.ga += as;
    away.gf += as;
    away.ga += hs;
    if (hs > as) {
      home.w += 1;
      home.points += 3;
      away.l += 1;
    } else if (as > hs) {
      away.w += 1;
      away.points += 3;
      home.l += 1;
    } else {
      home.d += 1;
      away.d += 1;
      home.points += 1;
      away.points += 1;
    }
  }

  const rows = [...table.values()].sort(
    (a, b) => b.points - a.points || b.gf - b.ga - (a.gf - a.ga) || a.team.localeCompare(b.team),
  );
  rows.forEach((r, i) => {
    r.rank = i + 1;
  });

  return { slug, season: "", rows, source: "results" };
}

export interface SoccerFixtureDay {
  /** ISO date (YYYY-MM-DD) */
  date: string;
  label: string;
  matches: SoccerMatch[];
}

export interface SoccerCalendar {
  slug: string;
  days: SoccerFixtureDay[];
}

/** Every match date for one competition — past results and upcoming fixtures. */
export const fetchSoccerCalendar = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const slug = (data as { slug?: unknown } | undefined)?.slug;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === slug);
    return { slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug };
  })
  .handler(async ({ data }): Promise<SoccerCalendar> => {
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const calPath = await resolvePath(comp);
    const chunks = await Promise.all([
      fetchMatches(calPath, comp.name, 180, -60).catch(() => [] as SoccerMatch[]),
      fetchMatches(calPath, comp.name, 60, 60).catch(() => [] as SoccerMatch[]),
      fetchMatches(calPath, comp.name, -60, 180).catch(() => [] as SoccerMatch[]),
    ]);

    const byId = new Map<string, SoccerMatch>();
    for (const m of chunks.flat()) byId.set(m.id, m);

    const byDate = new Map<string, SoccerMatch[]>();
    for (const m of [...byId.values()]) {
      const key = m.date.slice(0, 10);
      if (!key) continue;
      const list = byDate.get(key);
      if (list) list.push(m);
      else byDate.set(key, [m]);
    }

    const days: SoccerFixtureDay[] = [...byDate.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, matches]) => ({
        date,
        label: new Date(`${date}T12:00:00Z`).toLocaleDateString("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric",
          timeZone: "UTC",
        }),
        matches: matches.sort((a, b) => a.date.localeCompare(b.date)),
      }));

    return { slug: comp.slug, days };
  });

export interface LiveSoccerMatch {
  id: string;
  league: string;
  leagueSlug: string | null;
  home: string;
  away: string;
  homeLogo: string | null;
  awayLogo: string | null;
  homeScore: string;
  awayScore: string;
  clock: string;
  detail: string;
  status: "live" | "final" | "scheduled";
  kickoff: string;
  scorers: string[];
}

export interface LiveSoccerBoard {
  updated: string;
  matches: LiveSoccerMatch[];
}

function prettyLeague(slug: string): string {
  return slug
    .replace(/^\d{4}(-\d{2})?-/, "")
    .split("-")
    .map((w) => (w.length > 3 ? w[0]!.toUpperCase() + w.slice(1) : w.toUpperCase()))
    .join(" ");
}

/** Today's soccer matches across every competition the live feed carries. */
export const fetchLiveSoccer = createServerFn({ method: "GET" }).handler(
  async (): Promise<LiveSoccerBoard> => {
    const res = await fetch(
      "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard",
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return { updated: new Date().toISOString(), matches: [] };
    const payload: any = await res.json();
    const events: any[] = Array.isArray(payload?.events) ? payload.events : [];

    const matches = events
      .map((event): LiveSoccerMatch | null => {
        const comp = event?.competitions?.[0];
        const teams: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
        const home = teams.find((t) => t?.homeAway === "home");
        const away = teams.find((t) => t?.homeAway === "away");
        if (!home?.team?.displayName || !away?.team?.displayName) return null;

        const leagueId = String(/l:(\d+)/.exec(String(event?.uid ?? ""))?.[1] ?? "");
        const compSlug = ESPN_LEAGUE_SLUGS[leagueId] ?? null;
        const known = compSlug
          ? SOCCER_COMPETITIONS.find((c) => c.slug === compSlug)
          : undefined;

        const state: string = comp?.status?.type?.state ?? "pre";
        const details: any[] = Array.isArray(comp?.details) ? comp.details : [];
        const scorers = details
          .filter((d) => d?.scoringPlay)
          .map((d) => {
            const who = d?.athletesInvolved?.[0]?.shortName ?? "";
            const when = d?.clock?.displayValue ?? "";
            return who ? `${who} ${when}`.trim() : "";
          })
          .filter(Boolean);

        return {
          id: String(event?.id ?? ""),
          league: known?.name ?? prettyLeague(String(event?.season?.slug ?? "Soccer")),
          leagueSlug: known?.slug ?? null,
          home: String(home.team.displayName),
          away: String(away.team.displayName),
          homeLogo: typeof home?.team?.logo === "string" ? home.team.logo : null,
          awayLogo: typeof away?.team?.logo === "string" ? away.team.logo : null,
          homeScore: String(home?.score ?? ""),
          awayScore: String(away?.score ?? ""),
          clock: String(comp?.status?.displayClock ?? ""),
          detail: String(comp?.status?.type?.shortDetail ?? ""),
          status: state === "in" ? "live" : state === "post" ? "final" : "scheduled",
          kickoff: typeof event?.date === "string" ? event.date : "",
          scorers,
        };
      })
      .filter((m): m is LiveSoccerMatch => m !== null)
      .sort((a, b) => {
        const order = { live: 0, scheduled: 1, final: 2 } as const;
        return order[a.status] - order[b.status] || a.kickoff.localeCompare(b.kickoff);
      });

    return { updated: new Date().toISOString(), matches };
  },
);
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface TimelineTeam {
  team: string;
  points: number[];
  ranks: number[];
}

export interface SoccerTimeline {
  slug: string;
  stages: string[];
  teams: TimelineTeam[];
}

/**
 * Season progression: where each club sat after every matchday, built from the
 * results feed so it fills in on its own as matches are played.
 */
export const fetchSoccerTimeline = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const slug = (data as { slug?: unknown } | undefined)?.slug;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === slug);
    return { slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug };
  })
  .handler(async ({ data }): Promise<SoccerTimeline> => {
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const tlPath = await resolvePath(comp);
    const matches = await fetchMatches(tlPath, comp.name, 340, 0).catch(
      () => [] as SoccerMatch[],
    );
    const played = matches
      .filter((m) => m.status === "final" && m.homeScore !== "" && m.awayScore !== "")
      .sort((a, b) => a.date.localeCompare(b.date));
    if (played.length < 4) return { slug: comp.slug, stages: [], teams: [] };

    const dates = [...new Set(played.map((m) => m.date.slice(0, 10)))];
    // Keep the chart readable: at most 14 snapshots, evenly spaced, always ending on the latest.
    const step = Math.max(1, Math.ceil(dates.length / 14));
    const stageDates = dates.filter((_, i) => i % step === 0 || i === dates.length - 1);

    const points = new Map<string, number>();
    const snapshots: Map<string, number>[] = [];
    const stageLabels: string[] = [];
    let cursor = 0;

    for (const stage of stageDates) {
      while (cursor < played.length && played[cursor]!.date.slice(0, 10) <= stage) {
        const m = played[cursor]!;
        cursor += 1;
        const hs = Number(m.homeScore);
        const as = Number(m.awayScore);
        if (!Number.isFinite(hs) || !Number.isFinite(as)) continue;
        points.set(m.home, (points.get(m.home) ?? 0) + (hs > as ? 3 : hs === as ? 1 : 0));
        points.set(m.away, (points.get(m.away) ?? 0) + (as > hs ? 3 : hs === as ? 1 : 0));
      }
      snapshots.push(new Map(points));
      stageLabels.push(
        new Date(`${stage}T12:00:00Z`).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
          timeZone: "UTC",
        }),
      );
    }

    const order = (snapshot: Map<string, number>): string[] =>
      [...snapshot.entries()]
        .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
        .map(([team]) => team);

    const teams: TimelineTeam[] = [...points.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 6)
      .map(([team]) => ({
        team,
        points: snapshots.map((snap) => snap.get(team) ?? 0),
        ranks: snapshots.map((snap) => {
          const idx = order(snap).indexOf(team);
          return idx === -1 ? snap.size + 1 : idx + 1;
        }),
      }));

    return { slug: comp.slug, stages: stageLabels, teams };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */

/* ------------------------------------------------------------------ *
 * Feed address resolution
 *
 * Some competitions are not carried by the upstream feed under the slug
 * we expect (or not carried at all yet). Rather than leaving those tables
 * permanently empty, we probe the expected address and — when it fails —
 * look the competition up in the feed's own league directory by name.
 * As soon as coverage appears, the table and calendar fill themselves in.
 * ------------------------------------------------------------------ */

interface DirectoryLeague {
  slug: string;
  name: string;
}

const PATH_TTL = 10 * 60_000;
const pathCache = new Map<string, { path: string; at: number }>();
let directoryCache: { leagues: DirectoryLeague[]; at: number } | null = null;

function normalizeName(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, "");
}

async function espnSoccerDirectory(): Promise<DirectoryLeague[]> {
  if (directoryCache && Date.now() - directoryCache.at < PATH_TTL) return directoryCache.leagues;
  try {
    const res = await fetch(
      "https://site.web.api.espn.com/apis/site/v2/leagues/dropdown?lang=en&region=us&calendartype=whitelist&limit=500&sport=soccer",
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return directoryCache?.leagues ?? [];
    const payload: any = await res.json();
    const leagues: DirectoryLeague[] = (Array.isArray(payload?.leagues) ? payload.leagues : [])
      .map((l: any) => ({
        slug: typeof l?.slug === "string" ? l.slug : "",
        name: typeof l?.name === "string" ? l.name : "",
      }))
      .filter((l: DirectoryLeague) => l.slug && l.name);
    directoryCache = { leagues, at: Date.now() };
    return leagues;
  } catch {
    return directoryCache?.leagues ?? [];
  }
}

async function pathWorks(path: string): Promise<boolean> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard`,
      { headers: { accept: "application/json" } },
    );
    return res.ok;
  } catch {
    return false;
  }
}

/** The feed address to use for a competition right now. */
async function resolvePath(comp: { slug: string; path: string; name: string }): Promise<string> {
  const cached = pathCache.get(comp.slug);
  if (cached && Date.now() - cached.at < PATH_TTL) return cached.path;

  let resolved = comp.path;
  if (!(await pathWorks(comp.path))) {
    const directory = await espnSoccerDirectory();
    const target = normalizeName(comp.name);
    const hit =
      directory.find((l) => normalizeName(l.name) === target) ??
      directory.find((l) => {
        const name = normalizeName(l.name);
        return name.includes(target) || target.includes(name);
      });
    if (hit) resolved = `soccer/${hit.slug}`;
  }

  pathCache.set(comp.slug, { path: resolved, at: Date.now() });
  return resolved;
}

export interface SeasonStanding {
  season: string;
  label: string;
  rows: { team: string; points: number; rank: number; gp: number }[];
}

export interface SeasonHistoryTeam {
  team: string;
  /** Points per season, aligned with `seasons`; null when the club was absent. */
  points: (number | null)[];
  ranks: (number | null)[];
}

export interface SoccerSeasonHistory {
  slug: string;
  seasons: string[];
  teams: SeasonHistoryTeam[];
}

async function standingsForSeason(path: string, season: number): Promise<SeasonStanding | null> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/v2/sports/${path}/standings?season=${season}`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return null;
    const payload: any = await res.json();
    const children: any[] = Array.isArray(payload?.children) ? payload.children : [];
    const entries: any[] = children.length
      ? children.flatMap((c) => (Array.isArray(c?.standings?.entries) ? c.standings.entries : []))
      : Array.isArray(payload?.standings?.entries)
        ? payload.standings.entries
        : [];
    if (!entries.length) return null;

    const rows = entries
      .map((entry) => {
        const team = typeof entry?.team?.displayName === "string" ? entry.team.displayName : "";
        if (!team) return null;
        const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
        return {
          team,
          points: statValue(stats, "points"),
          rank: statValue(stats, "rank"),
          gp: statValue(stats, "gamesPlayed"),
        };
      })
      .filter((r): r is { team: string; points: number; rank: number; gp: number } => r !== null)
      .sort((a, b) => b.points - a.points || a.team.localeCompare(b.team))
      .map((r, i) => ({ ...r, rank: r.rank || i + 1 }));

    if (!rows.length) return null;
    const label =
      typeof payload?.season?.displayName === "string" && payload.season.displayName
        ? payload.season.displayName
        : String(season);
    return { season: String(season), label, rows };
  } catch {
    return null;
  }
}

/** Where each club finished over the last few seasons, for year-on-year comparison. */
export const fetchSoccerSeasonHistory = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const slug = (data as { slug?: unknown } | undefined)?.slug;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === slug);
    return { slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug };
  })
  .handler(async ({ data }): Promise<SoccerSeasonHistory> => {
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const path = await resolvePath(comp);
    const current = new Date().getUTCFullYear();
    const years = [current - 4, current - 3, current - 2, current - 1, current];

    const results = (await Promise.all(years.map((y) => standingsForSeason(path, y)))).filter(
      (s): s is SeasonStanding => s !== null,
    );
    if (!results.length) return { slug: comp.slug, seasons: [], teams: [] };

    const seasons = results.map((s) => s.label);
    const latest = results[results.length - 1]!;
    const featured = latest.rows.slice(0, 6).map((r) => r.team);

    const teams: SeasonHistoryTeam[] = featured.map((team) => ({
      team,
      points: results.map((s) => s.rows.find((r) => r.team === team)?.points ?? null),
      ranks: results.map((s) => s.rows.find((r) => r.team === team)?.rank ?? null),
    }));

    return { slug: comp.slug, seasons, teams };
  });

export interface SoccerTopTable {
  slug: string;
  name: string;
  short: string;
  source: SoccerTable["source"];
  rows: SoccerTableRow[];
}

const WIDGET_SLUGS = [
  "premier-league-highlights",
  "laliga-highlights",
  "serie-a-highlights",
  "bundesliga-highlights",
  "ligue-1-highlights",
  "liga-mx-highlights",
];

/** Top of the table for the headline competitions, for the World Soccer overview. */
export const fetchTopSoccerTables = createServerFn({ method: "GET" }).handler(
  async (): Promise<SoccerTopTable[]> => {
    const comps = WIDGET_SLUGS.map((slug) =>
      SOCCER_COMPETITIONS.find((c) => c.slug === slug),
    ).filter((c): c is (typeof SOCCER_COMPETITIONS)[number] => Boolean(c));

    const tables = await Promise.all(
      comps.map(async (comp) => {
        const table = await fetchSoccerTable({ data: { slug: comp.slug } }).catch(() => null);
        return {
          slug: comp.slug,
          name: comp.name,
          short: comp.short,
          source: table?.source ?? "none",
          rows: (table?.rows ?? []).slice(0, 5),
        } satisfies SoccerTopTable;
      }),
    );

    return tables.filter((t) => t.rows.length > 0);
  },
);

export interface SoccerNewsItem {
  id: string;
  headline: string;
  summary: string;
  url: string;
  image: string | null;
  published: string;
  competition: string;
  category: "transfers" | "injuries" | "matchday";
}

export interface SoccerNewsFeed {
  updated: string;
  items: SoccerNewsItem[];
}

const NEWS_SLUGS = [
  "premier-league-highlights",
  "laliga-highlights",
  "serie-a-highlights",
  "bundesliga-highlights",
  "ligue-1-highlights",
  "champions-league-highlights",
  "liga-mx-highlights",
  "brasileirao-highlights",
];

const TRANSFER_WORDS =
  /\b(transfer|sign(ed|ing|s)?|deal|move|loan|contract|extension|fee|bid|swoop|join(s|ed|ing)?|window|release[d]?|agent)\b/i;
const INJURY_WORDS =
  /\b(injur(y|ed|ies)|fitness|knock|hamstring|acl|surgery|sidelined|out for|doubtful|recovery|return(s|ed)? to training|ruled out|suspend(ed|ion))\b/i;

function categorize(text: string): SoccerNewsItem["category"] {
  if (TRANSFER_WORDS.test(text)) return "transfers";
  if (INJURY_WORDS.test(text)) return "injuries";
  return "matchday";
}

/** Transfers, injuries and matchday news pulled from the major competitions. */
export const fetchSoccerNews = createServerFn({ method: "GET" }).handler(
  async (): Promise<SoccerNewsFeed> => {
    const comps = NEWS_SLUGS.map((slug) =>
      SOCCER_COMPETITIONS.find((c) => c.slug === slug),
    ).filter((c): c is (typeof SOCCER_COMPETITIONS)[number] => Boolean(c));

    const chunks = await Promise.all(
      comps.map(async (comp) => {
        const stories = await fetchStories(comp.path).catch(() => [] as SoccerStory[]);
        return stories.map(
          (s): SoccerNewsItem => ({
            id: `${comp.slug}-${s.id}`,
            headline: s.headline,
            summary: s.summary,
            url: s.url,
            image: s.image,
            published: s.published,
            competition: comp.name,
            category: categorize(`${s.headline} ${s.summary}`),
          }),
        );
      }),
    );

    const byUrl = new Map<string, SoccerNewsItem>();
    for (const item of chunks.flat()) if (!byUrl.has(item.url)) byUrl.set(item.url, item);

    const items = [...byUrl.values()].sort((a, b) => b.published.localeCompare(a.published));
    return { updated: new Date().toISOString(), items };
  },
);
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface MatchEvent {
  id: string;
  clock: string;
  type: string;
  text: string;
  team: string;
  scoring: boolean;
}

export interface MatchPlayer {
  id: string;
  name: string;
  position: string;
  starter: boolean;
  goals: number;
  assists: number;
  shots: number;
  saves: number;
  yellow: number;
  red: number;
}

export interface MatchSide {
  team: string;
  logo: string | null;
  score: string;
  players: MatchPlayer[];
}

export interface SoccerMatchCentre {
  id: string;
  slug: string;
  competition: string;
  status: "live" | "final" | "scheduled";
  detail: string;
  clock: string;
  kickoff: string;
  venue: string;
  home: MatchSide;
  away: MatchSide;
  events: MatchEvent[];
  stats: { label: string; home: string; away: string }[];
  recap: string;
}

const statVal = (stats: any[], name: string): number => {
  const hit = (Array.isArray(stats) ? stats : []).find((s) => s?.name === name);
  const n = Number(hit?.value ?? 0);
  return Number.isFinite(n) ? n : 0;
};

function side(roster: any, competitor: any): MatchSide {
  const players: MatchPlayer[] = (Array.isArray(roster?.roster) ? roster.roster : [])
    .map((entry: any): MatchPlayer | null => {
      const name = typeof entry?.athlete?.displayName === "string" ? entry.athlete.displayName : "";
      if (!name) return null;
      const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
      return {
        id: String(entry?.athlete?.id ?? name),
        name,
        position:
          typeof entry?.position?.abbreviation === "string"
            ? entry.position.abbreviation
            : String(entry?.position?.displayName ?? ""),
        starter: entry?.starter === true,
        goals: statVal(stats, "totalGoals"),
        assists: statVal(stats, "goalAssists"),
        shots: statVal(stats, "totalShots"),
        saves: statVal(stats, "saves"),
        yellow: statVal(stats, "yellowCards"),
        red: statVal(stats, "redCards"),
      };
    })
    .filter((p: MatchPlayer | null): p is MatchPlayer => p !== null)
    .sort((a: MatchPlayer, b: MatchPlayer) => Number(b.starter) - Number(a.starter));

  const team = roster?.team ?? competitor?.team ?? {};
  return {
    team: String(team?.displayName ?? competitor?.team?.displayName ?? "Team"),
    logo: typeof team?.logo === "string" ? team.logo : (competitor?.team?.logos?.[0]?.href ?? null),
    score: String(competitor?.score ?? ""),
    players,
  };
}

/** Full match centre for one soccer fixture: events, lineups and team stats. */
export const fetchSoccerMatchCentre = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { slug?: unknown; matchId?: unknown } | undefined;
    const found = SOCCER_COMPETITIONS.find((c) => c.slug === raw?.slug);
    const id = String(raw?.matchId ?? "");
    return {
      slug: found?.slug ?? SOCCER_COMPETITIONS[0]!.slug,
      matchId: /^[0-9]{1,12}$/.test(id) ? id : "",
    };
  })
  .handler(async ({ data }): Promise<SoccerMatchCentre | null> => {
    if (!data.matchId) return null;
    const comp = SOCCER_COMPETITIONS.find((c) => c.slug === data.slug)!;
    const path = await resolvePath(comp);
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${path}/summary?event=${data.matchId}`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return null;
    const payload: any = await res.json().catch(() => null);
    if (!payload) return null;

    const header: any = payload?.header?.competitions?.[0];
    const competitors: any[] = Array.isArray(header?.competitors) ? header.competitors : [];
    const homeC = competitors.find((c) => c?.homeAway === "home") ?? competitors[0];
    const awayC = competitors.find((c) => c?.homeAway === "away") ?? competitors[1];
    if (!homeC || !awayC) return null;

    const rosters: any[] = Array.isArray(payload?.rosters) ? payload.rosters : [];
    const rosterFor = (c: any) =>
      rosters.find((r) => String(r?.team?.id ?? "") === String(c?.team?.id ?? "-")) ?? null;

    const events: MatchEvent[] = (Array.isArray(payload?.keyEvents) ? payload.keyEvents : [])
      .map((e: any, i: number): MatchEvent => ({
        id: String(e?.id ?? `event-${i}`),
        clock: String(e?.clock?.displayValue ?? ""),
        type: String(e?.type?.text ?? ""),
        text: String(
          e?.text ??
            [
              e?.type?.text,
              (e?.athletesInvolved ?? []).map((a: any) => a?.displayName).filter(Boolean).join(", "),
            ]
              .filter(Boolean)
              .join(" — "),
        ),
        team: String(e?.team?.displayName ?? e?.team?.abbreviation ?? ""),
        scoring: e?.scoringPlay === true || String(e?.type?.text ?? "").startsWith("Goal"),
      }))
      .filter((e: MatchEvent) => e.text.length > 0);

    const boxTeams: any[] = Array.isArray(payload?.boxscore?.teams) ? payload.boxscore.teams : [];
    const homeBox = boxTeams.find((t) => String(t?.team?.id) === String(homeC?.team?.id));
    const awayBox = boxTeams.find((t) => String(t?.team?.id) === String(awayC?.team?.id));
    const stats = (Array.isArray(homeBox?.statistics) ? homeBox.statistics : [])
      .slice(0, 12)
      .map((s: any) => ({
        label: String(s?.label ?? s?.name ?? ""),
        home: String(s?.displayValue ?? "—"),
        away: String(
          (Array.isArray(awayBox?.statistics) ? awayBox.statistics : []).find(
            (a: any) => a?.name === s?.name,
          )?.displayValue ?? "—",
        ),
      }))
      .filter((s: { label: string }) => s.label.length > 0);

    const state = String(header?.status?.type?.state ?? "pre");
    const status: SoccerMatchCentre["status"] =
      state === "in" ? "live" : state === "post" ? "final" : "scheduled";
    const home = side(rosterFor(homeC), homeC);
    const away = side(rosterFor(awayC), awayC);
    const hs = Number(home.score || 0);
    const as = Number(away.score || 0);
    const scorers = events
      .filter((e) => e.scoring)
      .map((e) => e.text)
      .slice(0, 6);

    const recap =
      status === "final"
        ? hs === as
          ? `${home.team} and ${away.team} shared the points, ${hs}-${as}.${scorers.length ? ` Goals: ${scorers.join("; ")}.` : ""}`
          : `${hs > as ? home.team : away.team} beat ${hs > as ? away.team : home.team} ${Math.max(hs, as)}-${Math.min(hs, as)}.${scorers.length ? ` Goals: ${scorers.join("; ")}.` : ""}`
        : status === "live"
          ? `${home.team} ${hs}-${as} ${away.team}, live now.`
          : `${away.team} visit ${home.team} in the ${comp.name}.`;

    return {
      id: data.matchId,
      slug: comp.slug,
      competition: comp.name,
      status,
      detail: String(header?.status?.type?.shortDetail ?? ""),
      clock: String(header?.status?.displayClock ?? ""),
      kickoff: String(payload?.header?.competitions?.[0]?.date ?? ""),
      venue: String(payload?.gameInfo?.venue?.fullName ?? ""),
      home,
      away,
      events,
      stats,
      recap,
    };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */
