import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const PATHS: Record<string, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  nwsl: "soccer/usa.nwsl",
};

export interface PickTeam {
  id: string;
  name: string;
  logo: string | null;
}

/** Every club in a league, for the first-visit "pick your teams" screen. */
export const fetchLeagueTeams = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ league: z.enum(Object.keys(PATHS) as [string, ...string[]]) }).parse(d))
  .handler(async ({ data }): Promise<PickTeam[]> => {
    try {
      const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${PATHS[data.league]}/teams?limit=100`);
      if (!r.ok) return [];
      const j = (await r.json()) as {
        sports?: { leagues?: { teams?: { team?: { id?: string; displayName?: string; logos?: { href?: string }[] } }[] }[] }[];
      };
      return (j.sports?.[0]?.leagues?.[0]?.teams ?? [])
        .map((t) => t.team)
        .filter((t): t is NonNullable<typeof t> => Boolean(t?.id && t.displayName))
        .map((t) => ({ id: t.id!, name: t.displayName!, logo: t.logos?.[0]?.href ?? null }))
        .sort((a, b) => a.name.localeCompare(b.name));
    } catch {
      return [];
    }
  });
