export const SITE = "https://score-talk-watch.lovable.app";
const OG_IMAGE = `${SITE}/og-cover.jpg`;

/** League-specific social share image (1200x630) for hubs and stories. */
const OG_BY_LEAGUE: Record<string, string> = {
  nfl: "nfl",
  nba: "nba",
  wnba: "wnba",
  nhl: "nhl",
  mlb: "mlb",
  mls: "mls",
  nwsl: "nwsl",
  boxing: "boxing",
  cfb: "college-football",
  cbb: "college-basketball",
  cbs: "mlb",
  ncaaf: "college-football",
  ncaam: "college-basketball",
  ncaaw: "college-basketball",
  ncaah: "college-hockey",
  intl: "soccer",
  soccer: "soccer",
  epl: "soccer",
  laliga: "soccer",
  seriea: "soccer",
  bundesliga: "soccer",
  ligue1: "soccer",
  ucl: "soccer",
};

export function leagueOgImage(league: string): string {
  const key = league.toLowerCase();
  const direct = OG_BY_LEAGUE[key];
  if (direct) return `${SITE}/og/${direct}.jpg`;
  if (key.includes("hockey")) return `${SITE}/og/college-hockey.jpg`;
  if (key.includes("basketball")) return `${SITE}/og/college-basketball.jpg`;
  if (key.includes("football")) return `${SITE}/og/college-football.jpg`;
  if (key.includes("soccer")) return `${SITE}/og/soccer.jpg`;
  return OG_IMAGE;
}

/** Standard head metadata for a public leaf route. */
export function pageHead({
  path,
  title,
  description,
  type = "website",
  image = OG_IMAGE,
  noindex = false,
}: {
  path: string;
  title: string;
  description: string;
  type?: string;
  image?: string;
  noindex?: boolean;
}) {
  const url = `${SITE}${path}`;
  return {
    meta: [
      { title },
      { name: "description", content: description },
      ...(noindex ? [{ name: "robots", content: "noindex, follow" }] : []),
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: type },
      { property: "og:url", content: url },
      { property: "og:image", content: image },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      {
        property: "og:image:alt",
        content: "Sideline — live sports scores, standings, highlights and fan chat",
      },
      { name: "twitter:image", content: image },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
    links: [{ rel: "canonical", href: url }],
  };
}
