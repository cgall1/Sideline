import { ToolError, defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { ARTICLES } from "@/data/sports";

export default defineTool({
  name: "get_story",
  title: "Get a story",
  description: "Return the full text of one story, looked up by its slug from list_stories.",
  inputSchema: { slug: z.string().trim().min(1).describe("Story slug, e.g. chiefs-bills-fourth-quarter.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ slug }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const story = ARTICLES.find((a) => a.slug === slug);
    if (!story) throw new ToolError(`No story found with slug "${slug}".`);
    return {
      content: [{ type: "text", text: `${story.title}\n\n${story.dek}\n\n${story.body.join("\n\n")}` }],
    };
  },
});
