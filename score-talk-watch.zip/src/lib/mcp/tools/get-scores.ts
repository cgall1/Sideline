import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { fetchLiveGames } from "@/lib/live-sports.functions";
import type { GameStatus, LeagueId } from "@/data/sports";

const leagues = ["nfl", "nhl", "nba", "mlb", "mls", "intl"] as const;

export default defineTool({
  name: "get_scores",
  title: "Get scores and schedules",
  description:
    "List games with live scores, game clock, venue, kickoff time and broadcasters. Filter by league or status.",
  inputSchema: {
    league: z.enum(["all", ...leagues]).optional().describe("League filter; defaults to all leagues."),
    status: z.enum(["all", "live", "scheduled", "final"]).optional().describe("Game status filter."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ league, status }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const { games: all } = await fetchLiveGames({
      data: { league: (league ?? "all") as LeagueId | "all" },
    });
    const games = (!status || status === "all" ? all : all.filter((g) => g.status === (status as GameStatus))).map(
      (g) => ({
        id: g.id,
        league: g.league,
        status: g.status,
        clock: g.clock,
        startLabel: g.startLabel,
        venue: g.venue,
        headline: g.headline,
        broadcasters: g.broadcasters,
        home: { team: g.home.name, abbr: g.home.abbr, record: g.home.record, score: g.homeScore },
        away: { team: g.away.name, abbr: g.away.abbr, record: g.away.record, score: g.awayScore },
      }),
    );
    return {
      content: [{ type: "text", text: JSON.stringify(games, null, 2) }],
    };
  },
});
