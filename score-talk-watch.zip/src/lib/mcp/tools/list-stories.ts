import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { ARTICLES } from "@/data/sports";

const leagues = ["nfl", "nhl", "nba", "mlb", "mls", "intl"] as const;

export default defineTool({
  name: "list_stories",
  title: "List stories and highlights",
  description: "List news, analysis and video highlight items. Returns summaries, not full article text.",
  inputSchema: {
    league: z.enum(["all", ...leagues]).optional().describe("League filter; defaults to all leagues."),
    kind: z.enum(["all", "news", "analysis", "video"]).optional().describe("Content type filter."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ league, kind }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const stories = ARTICLES.filter(
      (a) => (!league || league === "all" || a.league === league) && (!kind || kind === "all" || a.kind === kind),
    ).map(({ slug, kind: k, league: l, title, dek, author, published, readTime, duration }) => ({
      slug,
      kind: k,
      league: l,
      title,
      dek,
      author,
      published,
      readTime,
      duration,
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(stories, null, 2) }],
    };
  },
});
