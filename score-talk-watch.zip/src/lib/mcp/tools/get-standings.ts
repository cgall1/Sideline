import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { LEADERS, STANDINGS, type LeagueId } from "@/data/sports";

const leagues = ["nfl", "nhl", "nba", "mlb", "mls", "intl"] as const;

export default defineTool({
  name: "get_standings",
  title: "Get standings and stat leaders",
  description: "Return the league table and the statistical leaders for one league.",
  inputSchema: { league: z.enum(leagues).describe("League to read standings for.") },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ league }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const table = STANDINGS[league as LeagueId];
    const leaders = LEADERS.filter((l) => l.league === league);
    const payload = { league, group: table.group, rows: table.rows, leaders };
    return { content: [{ type: "text", text: JSON.stringify(payload, null, 2) }] };
  },
});
