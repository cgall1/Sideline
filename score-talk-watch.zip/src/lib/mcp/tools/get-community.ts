import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { POLLS, POSTS } from "@/data/sports";

export default defineTool({
  name: "get_community",
  title: "Get fan community activity",
  description: "Return fan game-thread posts and the current fan poll results, optionally filtered to one game.",
  inputSchema: {
    gameId: z.string().trim().min(1).optional().describe("Game id from get_scores, e.g. nfl-1."),
    include: z.enum(["all", "posts", "polls"]).optional().describe("Limit the response to posts or polls."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ gameId, include }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Not authenticated" }], isError: true };
    }
    const want = include ?? "all";
    const posts = want === "polls" ? [] : POSTS.filter((p) => !gameId || p.gameId === gameId);
    const polls =
      want === "posts"
        ? []
        : POLLS.map((p) => ({
            ...p,
            options: p.options.map((o) => ({ ...o })),
            totalVotes: p.options.reduce((sum, o) => sum + o.votes, 0),
          }));
    const payload = { posts, polls };
    return { content: [{ type: "text", text: JSON.stringify(payload, null, 2) }] };
  },
});
