import { auth, defineMcp } from "@lovable.dev/mcp-js";
import getScores from "./tools/get-scores";
import getStandings from "./tools/get-standings";
import listStories from "./tools/list-stories";
import getStory from "./tools/get-story";
import getCommunity from "./tools/get-community";

// The OAuth issuer must be the direct Supabase auth host; the project ref is the
// only value that survives publish unchanged.
const projectRef = import.meta.env['VITE_SUPABASE_PROJECT_ID'] ?? "project-ref-unset";

export default defineMcp({
  name: "game-day-hub",
  title: "Game Day Hub",
  version: "0.1.0",
  instructions:
    "Tools for Sideline, a sports network covering NFL, NHL, NBA, MLB, MLS and international soccer. Use `get_scores` for live scores and schedules, `get_standings` for league tables and stat leaders, `list_stories` / `get_story` for news, analysis and highlights, and `get_community` for fan game threads and poll results.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [getScores, getStandings, listStories, getStory, getCommunity],
});
