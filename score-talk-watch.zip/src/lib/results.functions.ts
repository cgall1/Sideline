import { createServerFn } from "@tanstack/react-start";
import { LEAGUES, type LeagueId } from "@/data/sports";

const LEAGUE_IDS: LeagueId[] = LEAGUES.map((l) => l.id);

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

export type ResultRow = {
  team: string;
  w: number;
  l: number;
  t: number;
  gp: number;
  pct: string;
  points: number | null;
  pointsFor: number;
  pointsAgainst: number;
  streak: string;
};

export type ResultGroup = { name: string; rows: ResultRow[] };

function num(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function statOf(entry: any, name: string): any {
  return (Array.isArray(entry?.stats) ? entry.stats : []).find((s: any) => s?.name === name);
}

function mapRow(entry: any): ResultRow {
  const overall = str(statOf(entry, "overall")?.displayValue, "");
  const parsed = /^(\d+)-(\d+)(?:-(\d+))?$/.exec(overall);
  const winsStat = statOf(entry, "wins");
  const lossesStat = statOf(entry, "losses");
  const tiesStat = statOf(entry, "ties");
  const w = winsStat ? num(winsStat.value) : parsed ? Number(parsed[1]) : 0;
  const l = lossesStat ? num(lossesStat.value) : parsed ? Number(parsed[2]) : 0;
  const t = tiesStat ? num(tiesStat.value) : parsed?.[3] ? Number(parsed[3]) : 0;
  const pointsStat = statOf(entry, "points");
  const pctStat = statOf(entry, "winPercent");
  const gp = w + l + t;
  const pct = pctStat ? num(pctStat.value) : gp > 0 ? (w + t * 0.5) / gp : 0;

  return {
    team: str(entry?.team?.displayName, "—"),
    w,
    l,
    t,
    gp,
    pct: pct.toFixed(3).replace(/^0/, ""),
    points: pointsStat ? num(pointsStat.value) : null,
    pointsFor: num(statOf(entry, "pointsFor")?.value),
    pointsAgainst: num(statOf(entry, "pointsAgainst")?.value),
    streak: str(statOf(entry, "streak")?.displayValue, "—"),
  };
}

function collect(node: any, inherited = ""): ResultGroup[] {
  if (!node) return [];
  const name = str(node?.name, inherited);
  const entries: any[] = Array.isArray(node?.standings?.entries) ? node.standings.entries : [];
  const own: ResultGroup[] = entries.length
    ? [{ name: name || "Overall", rows: entries.map(mapRow) }]
    : [];
  const children: any[] = Array.isArray(node?.children) ? node.children : [];
  return [...own, ...children.flatMap((c) => collect(c, name))];
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/** Full-season results table for one league, straight from the public league feed. */
export const fetchSeasonResults = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(
    async ({
      data,
    }): Promise<{ league: LeagueId; season: number | null; live: boolean; groups: ResultGroup[] }> => {
      try {
        const res = await fetch(
          `https://site.api.espn.com/apis/v2/sports/${ESPN_PATH[data.league]}/standings`,
          { headers: { accept: "application/json" } },
        );
        if (!res.ok) throw new Error(`feed ${res.status}`);
        const payload = await res.json();
        const groups = collect(payload).filter((g) => g.rows.length > 0);
        for (const group of groups) {
          group.rows.sort((a, b) => {
            if (a.points !== null && b.points !== null && a.points !== b.points) {
              return b.points - a.points;
            }
            return parseFloat(b.pct) - parseFloat(a.pct);
          });
        }
        const season = Number(payload?.season?.year ?? payload?.season);
        return {
          league: data.league,
          season: Number.isFinite(season) ? season : null,
          live: groups.length > 0,
          groups,
        };
      } catch {
        return { league: data.league, season: null, live: false, groups: [] };
      }
    },
  );
