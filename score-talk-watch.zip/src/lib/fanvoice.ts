import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { publicCounts } from "@/lib/public-counts.functions";
import { recordFanActivity } from "@/lib/daily";

export type SuggestionKind = "debate" | "deep_dive" | "athlete_question";

export interface Suggestion {
  id: string;
  userId: string;
  author: string;
  kind: SuggestionKind;
  title: string;
  body: string;
  target: string | null;
  status: string;
  answer: string | null;
  createdAt: string;
  votes: number;
  votedByMe: boolean;
}

export const suggestionsQueryOptions = (kind: SuggestionKind, userId: string | null) =>
  queryOptions({
    queryKey: ["fan-voice", kind, userId ?? "anon"],
    queryFn: async (): Promise<Suggestion[]> => {
      const { data, error } = await supabase
        .from("topic_suggestions")
        .select("id,user_id,author_name,kind,title,body,target,status,answer,created_at")
        .eq("kind", kind)
        .eq("hidden", false)
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw new Error("Couldn't load ideas right now.");
      const { data: counts } = await (publicCounts({ data: { fn: "topic_vote_counts" } }) as Promise<{ data: any[] | null; error: any }>);
      const countMap = new Map((counts ?? []).map((c) => [c.suggestion_id, Number(c.total)]));
      let mine = new Set<string>();
      if (userId) {
        const { data: v } = await supabase.from("topic_votes").select("suggestion_id").eq("user_id", userId);
        mine = new Set((v ?? []).map((r) => r.suggestion_id));
      }
      return (data ?? [])
        .map((r) => ({
          id: r.id,
          userId: r.user_id,
          author: r.author_name,
          kind: r.kind as SuggestionKind,
          title: r.title,
          body: r.body,
          target: r.target,
          status: r.status,
          answer: r.answer,
          createdAt: r.created_at,
          votes: countMap.get(r.id) ?? 0,
          votedByMe: mine.has(r.id),
        }))
        .sort((a, b) => b.votes - a.votes || b.createdAt.localeCompare(a.createdAt));
    },
  });

export async function addSuggestion(input: {
  userId: string;
  author: string;
  kind: SuggestionKind;
  title: string;
  body: string;
  target: string | null;
}) {
  const { error } = await supabase.from("topic_suggestions").insert({
    user_id: input.userId,
    author_name: input.author.slice(0, 60) || "Fan",
    kind: input.kind,
    title: input.title.trim().slice(0, 200),
    body: input.body.trim().slice(0, 1000),
    target: input.target?.trim().slice(0, 120) || null,
  });
  if (error) throw new Error("Couldn't save your idea. Titles need at least 5 characters.");
  void recordFanActivity();
}

export async function toggleSuggestionVote(id: string, userId: string, voted: boolean) {
  const q = voted
    ? supabase.from("topic_votes").delete().eq("suggestion_id", id).eq("user_id", userId)
    : supabase.from("topic_votes").insert({ suggestion_id: id, user_id: userId });
  const { error } = await q;
  if (error) throw new Error("Couldn't record your vote.");
  if (!voted) void recordFanActivity();
}

export async function deleteSuggestion(id: string) {
  const { error } = await supabase.from("topic_suggestions").delete().eq("id", id);
  if (error) throw new Error("Couldn't delete that idea.");
}

export type Stance = "agree" | "disagree" | "unsure";

export const pulseQueryOptions = (type: string, id: string, userId: string | null) =>
  queryOptions({
    queryKey: ["pulse", type, id, userId ?? "anon"],
    queryFn: async () => {
      const { data } = await (publicCounts({ data: { fn: "issue_pulse_counts", args: { _type: type, _id: id } } }) as Promise<{ data: any[] | null; error: any }>);
      const counts: Record<Stance, number> = { agree: 0, disagree: 0, unsure: 0 };
      for (const r of data ?? []) counts[r.stance as Stance] = Number(r.total);
      let mine: Stance | null = null;
      if (userId) {
        const { data: m } = await supabase
          .from("issue_pulse")
          .select("stance")
          .eq("subject_type", type)
          .eq("subject_id", id)
          .eq("user_id", userId)
          .maybeSingle();
        mine = (m?.stance as Stance) ?? null;
      }
      return { counts, mine };
    },
  });

export async function setPulse(type: string, id: string, userId: string, stance: Stance) {
  const { error } = await supabase
    .from("issue_pulse")
    .upsert({ subject_type: type, subject_id: id, user_id: userId, stance }, { onConflict: "subject_type,subject_id,user_id" });
  if (error) throw new Error("Couldn't save your answer.");
  void recordFanActivity();
}
