import { sendLovableEmail } from "@lovable.dev/email-js";
import { leagueById } from "@/data/sports";

const SITE = "https://score-talk-watch.lovable.app";

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/**
 * Welcome email for a brand new newsletter subscriber.
 *
 * Silently does nothing until a sender domain is configured, so signup never
 * fails because email sending isn't switched on yet.
 */
export async function sendWelcomeEmail(email: string, leagues: string[]): Promise<boolean> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  const senderDomain = process.env["SIDELINE_SENDER_DOMAIN"];
  if (!apiKey || !senderDomain) return false;

  const names = leagues.map((id) => leagueById(id)?.name ?? id).filter(Boolean);
  const following = names.length ? names.join(", ") : "every league we cover";

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#111;">
      <h1 style="font-size:24px;text-transform:uppercase;letter-spacing:2px;">Welcome to Sideline</h1>
      <p>Your newsletter account is set up — everything is working.</p>
      <p><strong>You're following:</strong> ${esc(following)}</p>
      <p>Every Monday morning you'll get the week's results, the headlines that mattered, the games
      coming up and how your predictions picks did.</p>
      <p>While you wait:</p>
      <ul style="padding-left:18px;">
        <li><a href="${SITE}/predictions">Make your picks for this week's games</a></li>
        <li><a href="${SITE}/leaderboard">See the fan leaderboard</a></li>
        <li><a href="${SITE}/scores">Live scores across every league</a></li>
      </ul>
      <hr style="margin:32px 0;border:none;border-top:1px solid #ddd;" />
      <p style="font-size:12px;color:#888;">You're getting this because you joined the Sideline newsletter.</p>
    </div>`;

  const text = [
    "WELCOME TO SIDELINE",
    "",
    "Your newsletter account is set up — everything is working.",
    `You're following: ${following}`,
    "",
    "Every Monday morning you'll get the week's results, the headlines that mattered,",
    "the games coming up and how your predictions picks did.",
    "",
    `Make your picks: ${SITE}/predictions`,
    `Fan leaderboard: ${SITE}/leaderboard`,
    `Live scores: ${SITE}/scores`,
  ].join("\n");

  await sendLovableEmail(
    {
      to: email,
      from: `Sideline <newsletter@${senderDomain}>`,
      sender_domain: senderDomain,
      subject: "Welcome to Sideline — your newsletter is live",
      html,
      text,
      purpose: "transactional",
      label: "newsletter-welcome",
      idempotency_key: `newsletter-welcome-${email}`,
    },
    { apiKey },
  );
  return true;
}
