import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { FANTASY_SPORTS } from "@/lib/fantasy.functions";

/* eslint-disable @typescript-eslint/no-explicit-any */

/** Sideline soccer scoring — the same rules for every fantasy soccer league. */
export const SOCCER_SCORING = [
  { label: "Played in a match", points: 2 },
  { label: "Goal", points: 6 },
  { label: "Assist", points: 3 },
  { label: "Clean sheet (GK or defender)", points: 4 },
  { label: "Every 3 saves", points: 1 },
  { label: "Yellow card", points: -1 },
  { label: "Red card", points: -3 },
  { label: "Own goal", points: -2 },
] as const;

export interface PlayerScore {
  playerId: string;
  playerName: string;
  position: string;
  teamName: string;
  memberId: string;
  appearances: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  saves: number;
  yellow: number;
  red: number;
  ownGoals: number;
  points: number;
  followed: boolean;
  /** Human stat line for sports that aren't soccer (e.g. "18 pts · 7 reb"). */
  statLine?: string | undefined;
}

export interface TeamScore {
  memberId: string;
  teamName: string;
  ownerName: string;
  points: number;
  rank: number;
  isMe: boolean;
  players: PlayerScore[];
}

export interface ScoringRule {
  label: string;
  points: number;
}

export interface FantasyScoreboard {
  supported: boolean;
  sport: string;
  matchesCounted: number;
  updated: string;
  teams: TeamScore[];
  /** The scoring rules that produced these points, for display. */
  rules: ScoringRule[];
}

/** Scoring rules for the US leagues, applied to real box-score lines. */
export const US_SCORING: Record<string, ScoringRule[]> = {
  nba: [
    { label: "Point", points: 1 },
    { label: "Rebound", points: 1.2 },
    { label: "Assist", points: 1.5 },
    { label: "Steal", points: 3 },
    { label: "Block", points: 3 },
    { label: "Turnover", points: -1 },
  ],
  nfl: [
    { label: "25 passing yards", points: 1 },
    { label: "Passing TD", points: 4 },
    { label: "Interception thrown", points: -2 },
    { label: "10 rushing/receiving yards", points: 1 },
    { label: "Rushing/receiving TD", points: 6 },
    { label: "Reception", points: 1 },
    { label: "Fumble lost", points: -2 },
    { label: "Kicking point", points: 1 },
  ],
  nhl: [
    { label: "Goal", points: 6 },
    { label: "Assist", points: 4 },
    { label: "Shot on goal", points: 0.5 },
    { label: "Blocked shot", points: 0.5 },
    { label: "Save", points: 0.2 },
    { label: "Goal against (goalie)", points: -1 },
  ],
  mlb: [
    { label: "Hit", points: 3 },
    { label: "Run", points: 2 },
    { label: "RBI", points: 2 },
    { label: "Home run", points: 4 },
    { label: "Walk", points: 1 },
    { label: "Strikeout (pitching)", points: 2 },
    { label: "Earned run allowed", points: -2 },
  ],
};

interface Tally {
  appearances: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  saves: number;
  yellow: number;
  red: number;
  ownGoals: number;
}

const emptyTally = (): Tally => ({
  appearances: 0,
  goals: 0,
  assists: 0,
  cleanSheets: 0,
  saves: 0,
  yellow: 0,
  red: 0,
  ownGoals: 0,
});

const statVal = (stats: any[], name: string): number => {
  const hit = (Array.isArray(stats) ? stats : []).find((s) => s?.name === name);
  const n = Number(hit?.value ?? 0);
  return Number.isFinite(n) ? n : 0;
};

const pointsFor = (t: Tally): number =>
  t.appearances * 2 +
  t.goals * 6 +
  t.assists * 3 +
  t.cleanSheets * 4 +
  Math.floor(t.saves / 3) +
  t.yellow * -1 +
  t.red * -3 +
  t.ownGoals * -2;

/** Finished match ids for a competition inside the last `days` days. */
async function recentMatchIds(path: string, days: number, cap: number): Promise<string[]> {
  const now = Date.now();
  const from = new Date(now - days * 864e5).toISOString();
  const years = new Set([new Date(now).getUTCFullYear(), new Date(now - days * 864e5).getUTCFullYear()]);
  const out: { id: string; date: string }[] = [];
  await Promise.all(
    [...years].map(async (y) => {
      const res = await fetch(
        `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${y}&limit=1000`,
        { headers: { accept: "application/json" } },
      ).catch(() => null);
      if (!res || !res.ok) return;
      const payload: any = await res.json().catch(() => null);
      for (const e of Array.isArray(payload?.events) ? payload.events : []) {
        const state = e?.competitions?.[0]?.status?.type?.state;
        const date = typeof e?.date === "string" ? e.date : "";
        if (state !== "post" || !date || date < from) continue;
        out.push({ id: String(e?.id ?? ""), date });
      }
    }),
  );
  return out
    .filter((e) => e.id)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, cap)
    .map((e) => e.id);
}

/** Per-player tallies across a set of finished matches. */
async function tallyMatches(path: string, ids: string[]): Promise<Map<string, Tally>> {
  const byPlayer = new Map<string, Tally>();
  const batchSize = 6;
  for (let i = 0; i < ids.length; i += batchSize) {
    const batch = ids.slice(i, i + batchSize);
    const payloads = await Promise.all(
      batch.map(async (id) => {
        const res = await fetch(
          `https://site.api.espn.com/apis/site/v2/sports/${path}/summary?event=${id}`,
          { headers: { accept: "application/json" } },
        ).catch(() => null);
        if (!res || !res.ok) return null;
        return (await res.json().catch(() => null)) as any;
      }),
    );
    for (const payload of payloads) {
      if (!payload) continue;
      const competitors: any[] = payload?.header?.competitions?.[0]?.competitors ?? [];
      const scoreOf = (teamId: string) =>
        Number(competitors.find((c) => String(c?.team?.id) === teamId)?.score ?? 0);
      for (const roster of Array.isArray(payload?.rosters) ? payload.rosters : []) {
        const teamId = String(roster?.team?.id ?? "");
        const opponent = competitors.find((c) => String(c?.team?.id) !== teamId);
        const conceded = Number(opponent?.score ?? 0);
        for (const entry of Array.isArray(roster?.roster) ? roster.roster : []) {
          const id = entry?.athlete?.id != null ? String(entry.athlete.id) : "";
          if (!id) continue;
          const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
          const appearances = statVal(stats, "appearances");
          if (appearances <= 0) continue;
          const tally = byPlayer.get(id) ?? emptyTally();
          const pos = String(entry?.position?.abbreviation ?? entry?.position?.displayName ?? "");
          const defensive = /^(G|GK|D|CB|LB|RB)/i.test(pos) || /goalkeep|defend/i.test(pos);
          tally.appearances += 1;
          tally.goals += statVal(stats, "totalGoals");
          tally.assists += statVal(stats, "goalAssists");
          tally.saves += statVal(stats, "saves");
          tally.yellow += statVal(stats, "yellowCards");
          tally.red += statVal(stats, "redCards");
          tally.ownGoals += statVal(stats, "ownGoals");
          if (defensive && conceded === 0) tally.cleanSheets += 1;
          byPlayer.set(id, tally);
          void scoreOf;
        }
      }
    }
  }
  return byPlayer;
}

interface UsLine {
  games: number;
  points: number;
  line: string;
}

const num = (raw: unknown): number => {
  const first = String(raw ?? "").split(/[-/]/)[0];
  const n = Number(first);
  return Number.isFinite(n) ? n : 0;
};

/** Per-player box-score points across a set of finished US-sport games. */
async function tallyUsMatches(
  sport: string,
  path: string,
  ids: string[],
): Promise<Map<string, UsLine>> {
  const byPlayer = new Map<string, UsLine>();
  const batchSize = 6;
  for (let i = 0; i < ids.length; i += batchSize) {
    const payloads = await Promise.all(
      ids.slice(i, i + batchSize).map(async (id) => {
        const res = await fetch(
          `https://site.api.espn.com/apis/site/v2/sports/${path}/summary?event=${id}`,
          { headers: { accept: "application/json" } },
        ).catch(() => null);
        if (!res || !res.ok) return null;
        return (await res.json().catch(() => null)) as any;
      }),
    );
    for (const payload of payloads) {
      if (!payload) continue;
      for (const team of Array.isArray(payload?.boxscore?.players) ? payload.boxscore.players : []) {
        for (const group of Array.isArray(team?.statistics) ? team.statistics : []) {
          const keys: string[] = Array.isArray(group?.keys) ? group.keys : [];
          const groupName = String(group?.name ?? "");
          // MLB ships batting and pitching as unnamed blocks — tell them apart by keys.
          const bucket =
            sport === "mlb"
              ? keys.includes("earnedRuns")
                ? "pitching"
                : "batting"
              : groupName;
          for (const entry of Array.isArray(group?.athletes) ? group.athletes : []) {
            const id = entry?.athlete?.id != null ? String(entry.athlete.id) : "";
            if (!id) continue;
            const values: string[] = Array.isArray(entry?.stats) ? entry.stats : [];
            const stat: Record<string, number> = {};
            keys.forEach((k, idx) => {
              stat[k] = num(values[idx]);
            });
            const g = (k: string): number => stat[k] ?? 0;

            let points = 0;
            let line = "";
            if (sport === "nba") {
              points =
                g("points") * 1 +
                g("rebounds") * 1.2 +
                g("assists") * 1.5 +
                g("steals") * 3 +
                g("blocks") * 3 -
                g("turnovers");
              line = `${g("points")} pts · ${g("rebounds")} reb · ${g("assists")} ast`;
            } else if (sport === "nfl") {
              if (bucket === "passing") {
                points =
                  g("passingYards") / 25 +
                  g("passingTouchdowns") * 4 -
                  g("interceptions") * 2;
                line = `${g("passingYards")} pass yds · ${g("passingTouchdowns")} TD`;
              } else if (bucket === "rushing") {
                points = g("rushingYards") / 10 + g("rushingTouchdowns") * 6;
                line = `${g("rushingYards")} rush yds · ${g("rushingTouchdowns")} TD`;
              } else if (bucket === "receiving") {
                points =
                  g("receptions") +
                  g("receivingYards") / 10 +
                  g("receivingTouchdowns") * 6;
                line = `${g("receptions")} rec · ${g("receivingYards")} yds`;
              } else if (bucket === "fumbles") {
                points = -2 * g("fumblesLost");
                line = "";
              } else if (bucket === "kicking") {
                points = g("totalKickingPoints");
                line = `${g("totalKickingPoints")} kicking pts`;
              } else {
                continue;
              }
            } else if (sport === "nhl") {
              if (bucket === "goalies") {
                points = g("saves") * 0.2 - g("goalsAgainst");
                line = `${g("saves")} saves`;
              } else {
                points =
                  g("goals") * 6 +
                  g("assists") * 4 +
                  g("shotsTotal") * 0.5 +
                  g("blockedShots") * 0.5;
                line = `${g("goals")} G · ${g("assists")} A`;
              }
            } else if (sport === "mlb") {
              if (bucket === "pitching") {
                points = g("strikeouts") * 2 - g("earnedRuns") * 2;
                line = `${g("strikeouts")} K`;
              } else {
                points =
                  g("hits") * 3 +
                  g("runs") * 2 +
                  g("RBIs") * 2 +
                  g("homeRuns") * 4 +
                  g("walks");
                line = `${g("hits")} H · ${g("RBIs")} RBI · ${g("homeRuns")} HR`;
              }
            } else {
              continue;
            }

            const prev = byPlayer.get(id) ?? { games: 0, points: 0, line: "" };
            byPlayer.set(id, {
              games: prev.games + 1,
              points: prev.points + points,
              line: line || prev.line,
            });
          }
        }
      }
    }
  }
  for (const [id, v] of byPlayer) {
    byPlayer.set(id, { ...v, points: Math.round(v.points * 10) / 10 });
  }
  return byPlayer;
}

/**
 * Live fantasy points and league table for one fantasy league, built from real
 * match stats — soccer match reports and US-league box scores.
 */
export const fetchFantasyScoreboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => ({
    leagueId: String((data as { leagueId?: unknown } | undefined)?.leagueId ?? ""),
  }))
  .handler(async ({ data, context }): Promise<FantasyScoreboard> => {
    const { supabase, userId } = context;
    const empty: FantasyScoreboard = {
      supported: false,
      sport: "",
      matchesCounted: 0,
      updated: new Date().toISOString(),
      teams: [],
      rules: [],
    };

    const { data: league } = await supabase
      .from("fantasy_leagues")
      .select("id,sport")
      .eq("id", data.leagueId)
      .maybeSingle();
    if (!league) return empty;

    const sportDef = FANTASY_SPORTS.find((s) => s.id === league.sport);
    const path = sportDef?.path ?? "";
    const isSoccer = path.startsWith("soccer/");
    const usRules = US_SCORING[league.sport];
    if (!isSoccer && !usRules) return { ...empty, sport: league.sport };

    const [{ data: members }, { data: picks }, { data: followed }] = await Promise.all([
      supabase.from("fantasy_members").select("id,user_id,team_name").eq("league_id", league.id),
      supabase
        .from("fantasy_picks")
        .select("id,member_id,player_id,player_name,position,team_name,dropped")
        .eq("league_id", league.id),
      supabase.from("followed_teams").select("name").eq("user_id", userId),
    ]);

    const ids = await recentMatchIds(path, isSoccer ? 45 : 14, isSoccer ? 40 : 30);
    const tallies = isSoccer ? await tallyMatches(path, ids) : new Map<string, Tally>();
    const usLines = isSoccer
      ? new Map<string, UsLine>()
      : await tallyUsMatches(league.sport, path, ids);

    const ownerNames = new Map<string, string>();
    const userIds = (members ?? []).map((m) => m.user_id);
    if (userIds.length) {
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id,display_name")
        .in("id", userIds);
      for (const p of profiles ?? []) ownerNames.set(p.id, p.display_name);
    }

    const followedNames = new Set((followed ?? []).map((f) => f.name.toLowerCase()));

    const teams: TeamScore[] = (members ?? []).map((m) => {
      const players: PlayerScore[] = (picks ?? [])
        .filter((p) => p.member_id === m.id && !p.dropped)
        .map((p) => {
          const t = tallies.get(p.player_id) ?? emptyTally();
          const us = usLines.get(p.player_id);
          return {
            statLine: isSoccer ? undefined : (us?.line ?? "No games yet"),
            playerId: p.player_id,
            playerName: p.player_name,
            position: p.position,
            teamName: p.team_name,
            memberId: m.id,
            appearances: isSoccer ? t.appearances : (us?.games ?? 0),
            goals: t.goals,
            assists: t.assists,
            cleanSheets: t.cleanSheets,
            saves: t.saves,
            yellow: t.yellow,
            red: t.red,
            ownGoals: t.ownGoals,
            points: isSoccer ? pointsFor(t) : (us?.points ?? 0),
            followed: followedNames.has(p.team_name.toLowerCase()),
          };
        })
        .sort((a, b) => b.points - a.points);

      return {
        memberId: m.id,
        teamName: m.team_name,
        ownerName: ownerNames.get(m.user_id) ?? "Fan",
        points: Math.round(players.reduce((sum, p) => sum + p.points, 0) * 10) / 10,
        rank: 0,
        isMe: m.user_id === userId,
        players,
      };
    });

    teams.sort((a, b) => b.points - a.points || a.teamName.localeCompare(b.teamName));
    teams.forEach((t, i) => {
      t.rank = i + 1;
    });

    return {
      supported: true,
      sport: league.sport,
      matchesCounted: ids.length,
      updated: new Date().toISOString(),
      teams,
      rules: isSoccer ? [...SOCCER_SCORING] : (usRules ?? []),
    };
  });
export interface H2HTeam {
  memberId: string;
  teamName: string;
  ownerName: string;
  points: number;
  isMe: boolean;
  top: { playerName: string; points: number; statLine?: string | undefined } | null;
}

export interface H2HMatchup {
  home: H2HTeam;
  away: H2HTeam | null;
  winner: "home" | "away" | "tie" | null;
}

export interface FantasyWeek {
  supported: boolean;
  sport: string;
  weekOffset: number;
  weekLabel: string;
  start: string;
  end: string;
  gamesCounted: number;
  matchups: H2HMatchup[];
  /** Commissioner-style write-up of the week, generated from the real results. */
  recap: string[];
}

/** Monday-to-Sunday window for a week, `offset` weeks back from this one. */
function weekWindow(offset: number): { start: Date; end: Date } {
  const now = new Date();
  const day = (now.getUTCDay() + 6) % 7; // 0 = Monday
  const start = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - day - offset * 7),
  );
  const end = new Date(start.getTime() + 7 * 864e5);
  return { start, end };
}

/** Finished match ids for a competition inside one date window. */
async function matchIdsBetween(path: string, start: Date, end: Date): Promise<string[]> {
  const years = new Set([start.getUTCFullYear(), end.getUTCFullYear()]);
  const out: string[] = [];
  await Promise.all(
    [...years].map(async (y) => {
      const res = await fetch(
        `https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${y}&limit=1000`,
        { headers: { accept: "application/json" } },
      ).catch(() => null);
      if (!res || !res.ok) return;
      const payload: any = await res.json().catch(() => null);
      for (const e of Array.isArray(payload?.events) ? payload.events : []) {
        const state = e?.competitions?.[0]?.status?.type?.state;
        const date = typeof e?.date === "string" ? new Date(e.date) : null;
        if (state !== "post" || !date || Number.isNaN(date.getTime())) continue;
        if (date < start || date >= end) continue;
        out.push(String(e?.id ?? ""));
      }
    }),
  );
  return out.filter(Boolean).slice(0, 60);
}

/** Round-robin pairings (circle method) for one week. */
function pairingsFor(ids: string[], week: number): [string, string | null][] {
  const list = [...ids];
  if (list.length % 2 === 1) list.push("BYE");
  const n = list.length;
  if (n < 2) return list[0] ? [[list[0], null]] : [];
  const fixed = list[0]!;
  const rotating = list.slice(1);
  const shift = ((week % (n - 1)) + (n - 1)) % (n - 1);
  const rot = [...rotating.slice(shift), ...rotating.slice(0, shift)];
  const round: [string, string | null][] = [];
  const order = [fixed, ...rot];
  for (let i = 0; i < n / 2; i++) {
    const a = order[i]!;
    const b = order[n - 1 - i]!;
    if (a === "BYE") round.push([b, null]);
    else if (b === "BYE") round.push([a, null]);
    else round.push([a, b]);
  }
  return round;
}

const fmtDate = (d: Date) =>
  d.toLocaleDateString("en-US", { month: "short", day: "numeric", timeZone: "UTC" });

/**
 * One week of head-to-head fantasy: every team's points from matches played in
 * that week only, paired off round-robin, plus a written recap of the week.
 */
export const fetchFantasyWeek = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => {
    const raw = data as { leagueId?: unknown; weekOffset?: unknown } | undefined;
    const n = Number(raw?.weekOffset ?? 0);
    return {
      leagueId: String(raw?.leagueId ?? ""),
      weekOffset: Number.isFinite(n) ? Math.min(20, Math.max(0, Math.trunc(n))) : 0,
    };
  })
  .handler(async ({ data, context }): Promise<FantasyWeek> => {
    const { supabase, userId } = context;
    const { start, end } = weekWindow(data.weekOffset);
    const empty: FantasyWeek = {
      supported: false,
      sport: "",
      weekOffset: data.weekOffset,
      weekLabel: `${fmtDate(start)} – ${fmtDate(new Date(end.getTime() - 864e5))}`,
      start: start.toISOString(),
      end: end.toISOString(),
      gamesCounted: 0,
      matchups: [],
      recap: [],
    };

    const { data: league } = await supabase
      .from("fantasy_leagues")
      .select("id,sport")
      .eq("id", data.leagueId)
      .maybeSingle();
    if (!league) return empty;

    const sportDef = FANTASY_SPORTS.find((s) => s.id === league.sport);
    const path = sportDef?.path ?? "";
    const isSoccer = path.startsWith("soccer/");
    const usRules = US_SCORING[league.sport];
    if (!path || (!isSoccer && !usRules)) return { ...empty, sport: league.sport };

    const [{ data: members }, { data: picks }] = await Promise.all([
      supabase
        .from("fantasy_members")
        .select("id,user_id,team_name,created_at")
        .eq("league_id", league.id)
        .order("created_at", { ascending: true }),
      supabase
        .from("fantasy_picks")
        .select("member_id,player_id,player_name,dropped")
        .eq("league_id", league.id),
    ]);

    const ids = await matchIdsBetween(path, start, end);
    const tallies = isSoccer ? await tallyMatches(path, ids) : new Map<string, Tally>();
    const usLines = isSoccer
      ? new Map<string, UsLine>()
      : await tallyUsMatches(league.sport, path, ids);

    const ownerNames = new Map<string, string>();
    const userIds = (members ?? []).map((m) => m.user_id);
    if (userIds.length) {
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id,display_name")
        .in("id", userIds);
      for (const p of profiles ?? []) ownerNames.set(p.id, p.display_name);
    }

    const teamById = new Map<string, H2HTeam>();
    for (const m of members ?? []) {
      const roster = (picks ?? []).filter((p) => p.member_id === m.id && !p.dropped);
      let total = 0;
      let top: H2HTeam["top"] = null;
      for (const p of roster) {
        const pts = isSoccer
          ? pointsFor(tallies.get(p.player_id) ?? emptyTally())
          : (usLines.get(p.player_id)?.points ?? 0);
        total += pts;
        if (pts > 0 && (!top || pts > top.points)) {
          top = {
            playerName: p.player_name,
            points: Math.round(pts * 10) / 10,
            statLine: isSoccer ? undefined : usLines.get(p.player_id)?.line,
          };
        }
      }
      teamById.set(m.id, {
        memberId: m.id,
        teamName: m.team_name,
        ownerName: ownerNames.get(m.user_id) ?? "Fan",
        points: Math.round(total * 10) / 10,
        isMe: m.user_id === userId,
        top,
      });
    }

    const memberIds = (members ?? []).map((m) => m.id);
    const matchups: H2HMatchup[] = pairingsFor(memberIds, data.weekOffset)
      .map(([a, b]) => {
        const home = teamById.get(a);
        if (!home) return null;
        const away = b ? (teamById.get(b) ?? null) : null;
        const winner = !away
          ? null
          : home.points > away.points
            ? ("home" as const)
            : away.points > home.points
              ? ("away" as const)
              : ("tie" as const);
        return { home, away, winner };
      })
      .filter((m): m is H2HMatchup => !!m);

    const recap: string[] = [];
    const scored = [...teamById.values()].sort((a, b) => b.points - a.points);
    const best = scored[0];
    if (ids.length === 0) {
      recap.push("No games in the books for this week yet — check back once the fixtures are played.");
    } else if (best && best.points > 0) {
      recap.push(
        `${best.teamName} led the week with ${best.points} points${best.top ? `, powered by ${best.top.playerName} (${best.top.points})` : ""}.`,
      );
      const blowout = matchups
        .filter((m) => m.away)
        .sort(
          (x, y) =>
            Math.abs(y.home.points - (y.away?.points ?? 0)) -
            Math.abs(x.home.points - (x.away?.points ?? 0)),
        )[0];
      if (blowout?.away) {
        const win = blowout.home.points >= blowout.away.points ? blowout.home : blowout.away;
        const lose = win === blowout.home ? blowout.away : blowout.home;
        recap.push(
          `Biggest win: ${win.teamName} ${win.points} — ${lose.points} ${lose.teamName}.`,
        );
      }
      const closest = matchups
        .filter((m) => m.away)
        .sort(
          (x, y) =>
            Math.abs(x.home.points - (x.away?.points ?? 0)) -
            Math.abs(y.home.points - (y.away?.points ?? 0)),
        )[0];
      if (closest?.away && closest !== blowout) {
        recap.push(
          `Closest call: ${closest.home.teamName} ${closest.home.points} — ${closest.away.points} ${closest.away.teamName}.`,
        );
      }
      const quiet = scored[scored.length - 1];
      if (quiet && quiet !== best) {
        recap.push(`Quietest week: ${quiet.teamName} on ${quiet.points}. There's always next week.`);
      }
    } else {
      recap.push("Plenty of games played, but nobody's roster troubled the scorers this week.");
    }

    return {
      supported: true,
      sport: league.sport,
      weekOffset: data.weekOffset,
      weekLabel: `${fmtDate(start)} – ${fmtDate(new Date(end.getTime() - 864e5))}`,
      start: start.toISOString(),
      end: end.toISOString(),
      gamesCounted: ids.length,
      matchups,
      recap,
    };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */
