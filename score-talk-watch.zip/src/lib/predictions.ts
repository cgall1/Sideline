import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fetchPredictionBoard } from "@/lib/predictions.functions";

export interface PredictionRow {
  id: string;
  userId: string;
  league: string;
  gameId: string;
  gameLabel: string;
  pick: string;
  correct: boolean | null;
  resolved: boolean;
}

export interface LeaderboardEntry {
  userId: string;
  name: string;
  picks: number;
  correct: number;
  accuracy: number;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapRow(row: any): PredictionRow {
  return {
    id: row.id,
    userId: row.user_id,
    league: row.league,
    gameId: row.game_id,
    gameLabel: row.game_label,
    pick: row.pick,
    correct: row.correct,
    resolved: row.resolved,
  };
}

/**
 * A fan's own picks, newest first. Picks are private to the fan who made them;
 * the public leaderboard is built from server-side aggregates instead.
 */
export const predictionsQueryOptions = (userId?: string) =>
  queryOptions({
    queryKey: ["predictions", userId ?? "anon"],
    enabled: !!userId,
    queryFn: async (): Promise<PredictionRow[]> => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("predictions")
        .select("id,user_id,league,game_id,game_label,pick,correct,resolved")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw error;
      return (data ?? []).map(mapRow);
    },
    staleTime: 30_000,
  });

/** Public leaderboard totals, prepared server-side from every fan's record. */
export const predictionBoardQueryOptions = () =>
  queryOptions({
    queryKey: ["prediction-board"],
    queryFn: () => fetchPredictionBoard(),
    staleTime: 60_000,
  });

/** Save or change a fan's pick for one game. */
export async function savePick(input: {
  userId: string;
  league: string;
  gameId: string;
  gameLabel: string;
  pick: string;
  kickoff?: string | null;
}) {
  const { error } = await supabase.from("predictions").upsert(
    {
      user_id: input.userId,
      league: input.league,
      game_id: input.gameId,
      game_label: input.gameLabel,
      pick: input.pick,
      kickoff: input.kickoff ?? null,
    },
    { onConflict: "user_id,game_id" },
  );
  if (error) throw error;
}

/*
 * Picks are graded only by the trusted server pass in predictions.functions.ts
 * (gradePredictions), which checks the real result from the official feed.
 * The browser cannot write the correct/resolved columns.
 */

export function buildLeaderboard(
  rows: PredictionRow[],
  names: Record<string, string>,
): LeaderboardEntry[] {
  const map = new Map<string, LeaderboardEntry>();
  for (const row of rows) {
    const entry =
      map.get(row.userId) ??
      { userId: row.userId, name: names[row.userId] ?? "Fan", picks: 0, correct: 0, accuracy: 0 };
    entry.picks += 1;
    if (row.correct) entry.correct += 1;
    map.set(row.userId, entry);
  }
  const list = [...map.values()];
  for (const entry of list) {
    entry.accuracy = entry.picks > 0 ? Math.round((entry.correct / entry.picks) * 100) : 0;
  }
  return list.sort((a, b) => b.correct - a.correct || b.accuracy - a.accuracy);
}

export interface FanStreak {
  current: number;
  best: number;
  badges: string[];
}

/**
 * Current and best correct-pick streaks for one fan, plus the badges earned.
 * `rows` arrive newest-first, so they are walked in reverse for chronology.
 */
export function buildStreak(rows: PredictionRow[], userId: string): FanStreak {
  const mine = rows.filter((r) => r.userId === userId && r.resolved).slice().reverse();
  let current = 0;
  let best = 0;
  let correct = 0;
  for (const row of mine) {
    if (row.correct) {
      current += 1;
      correct += 1;
      best = Math.max(best, current);
    } else {
      current = 0;
    }
  }
  const leagues = new Set(rows.filter((r) => r.userId === userId).map((r) => r.league));
  const badges: string[] = [];
  if (mine.length >= 1) badges.push("First pick");
  if (mine.length >= 25) badges.push("25 picks");
  if (mine.length >= 100) badges.push("Century club");
  if (best >= 3) badges.push("Hat trick — 3 in a row");
  if (best >= 5) badges.push("On fire — 5 in a row");
  if (best >= 10) badges.push("Perfect ten");
  if (leagues.size >= 3) badges.push("Multi-sport fan");
  if (leagues.size >= 6) badges.push("Every sport");
  if (mine.length >= 10 && correct / mine.length >= 0.6) badges.push("Sharp — 60% accuracy");
  return { current, best, badges };
}

/** Best current streaks across all fans, for the leaderboard. */
export function buildStreakBoard(
  rows: PredictionRow[],
  names: Record<string, string>,
): { userId: string; name: string; current: number; best: number }[] {
  const users = [...new Set(rows.map((r) => r.userId))];
  return users
    .map((userId) => {
      const s = buildStreak(rows, userId);
      return { userId, name: names[userId] ?? "Fan", current: s.current, best: s.best };
    })
    .filter((e) => e.best > 0)
    .sort((a, b) => b.current - a.current || b.best - a.best);
}
