import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";
import { safeEspnId } from "@/lib/espn-id";

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

export interface TimelineEntry {
  id: string;
  period: string;
  clock: string;
  text: string;
  team: string;
  awayScore: number;
  homeScore: number;
}

export interface StatCompare {
  label: string;
  away: string;
  home: string;
}

export interface GameLeader {
  category: string;
  name: string;
  team: string;
  value: string;
  playerId: string;
}

export interface LineupPlayer {
  name: string;
  position: string;
  starter: boolean;
}

export interface LineupTeam {
  team: string;
  players: LineupPlayer[];
}

export interface GameSummary {
  id: string;
  away: string;
  home: string;
  awayAbbr: string;
  homeAbbr: string;
  awayScore: number;
  homeScore: number;
  state: string;
  status: string;
  venue: string;
  recap: string[];
  timeline: TimelineEntry[];
  stats: StatCompare[];
  leaders: GameLeader[];
  winProbability: number[];
  lineups: LineupTeam[];
}

/* eslint-disable @typescript-eslint/no-explicit-any */

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function buildRecap(s: Omit<GameSummary, "recap">): string[] {
  const out: string[] = [];
  const done = s.state === "post";
  const winner = s.homeScore === s.awayScore ? null : s.homeScore > s.awayScore ? s.home : s.away;
  const loser = winner === s.home ? s.away : s.home;
  const margin = Math.abs(s.homeScore - s.awayScore);
  const high = Math.max(s.homeScore, s.awayScore);
  const low = Math.min(s.homeScore, s.awayScore);

  if (done && winner) {
    const verb = margin >= 17 ? "rolled past" : margin <= 3 ? "edged" : "beat";
    out.push(
      `${winner} ${verb} ${loser} ${high}-${low}${s.venue ? ` at ${s.venue}` : ""}. ` +
        (margin <= 3
          ? "It came down to the closing minutes."
          : margin >= 17
            ? "The result was never in doubt after the middle stretch."
            : "The winners controlled the run of play for long spells."),
    );
  } else if (done) {
    out.push(`${s.away} and ${s.home} finished level at ${s.homeScore}-${s.homeScore}.`);
  } else if (s.state === "in") {
    out.push(
      `${s.away} ${s.awayScore}, ${s.home} ${s.homeScore} — live now${s.status ? ` (${s.status})` : ""}.`,
    );
  } else {
    out.push(
      `${s.away} visit ${s.home}${s.venue ? ` at ${s.venue}` : ""}. A full recap appears here once the game ends.`,
    );
  }

  if (s.leaders.length) {
    const top = s.leaders
      .slice(0, 3)
      .map((l) => `${l.name} (${l.team}) ${l.value}`)
      .join("; ");
    out.push(`Leading performances: ${top}.`);
  }

  if (s.timeline.length) {
    const last = s.timeline[s.timeline.length - 1]!;
    out.push(`Latest score: ${last.text} (${last.period}, ${last.clock}).`);
  }

  return out;
}

/** Box score, scoring timeline, leaders and an auto-written recap for one game. */
export const fetchGameSummary = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; gameId?: unknown } | undefined;
    return { league: asLeague(raw?.league), gameId: String(raw?.gameId ?? "") };
  })
  .handler(async ({ data }): Promise<GameSummary | null> => {
    const eventId = safeEspnId(data.gameId.replace(/^[a-z]+-/, ""));
    if (!eventId) return null;
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[data.league]}/summary?event=${encodeURIComponent(eventId)}`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return null;
    const payload: any = await res.json().catch(() => null);
    if (!payload) return null;

    const comp: any = payload?.header?.competitions?.[0];
    const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
    const homeC = competitors.find((c: any) => c?.homeAway === "home") ?? competitors[0];
    const awayC = competitors.find((c: any) => c?.homeAway === "away") ?? competitors[1];
    if (!homeC || !awayC) return null;

    const name = (c: any) =>
      str(c?.team?.displayName, str([c?.team?.location, c?.team?.name].filter(Boolean).join(" "), "Team"));

    const timeline: TimelineEntry[] = (Array.isArray(payload?.scoringPlays) ? payload.scoringPlays : [])
      .map((p: any, i: number) => ({
        id: str(p?.id, `play-${i}`),
        period: `P${p?.period?.number ?? ""}`,
        clock: str(p?.clock?.displayValue, ""),
        text: str(p?.text, ""),
        team: str(p?.team?.abbreviation, ""),
        awayScore: Number(p?.awayScore ?? 0),
        homeScore: Number(p?.homeScore ?? 0),
      }))
      .filter((p: TimelineEntry) => p.text.length > 0);

    const boxTeams: any[] = Array.isArray(payload?.boxscore?.teams) ? payload.boxscore.teams : [];
    const awayBox = boxTeams.find((t: any) => String(t?.team?.id) === String(awayC?.team?.id));
    const homeBox = boxTeams.find((t: any) => String(t?.team?.id) === String(homeC?.team?.id));
    const stats: StatCompare[] = [];
    const awayStats: any[] = Array.isArray(awayBox?.statistics) ? awayBox.statistics : [];
    for (const s of awayStats.slice(0, 14)) {
      const match = (Array.isArray(homeBox?.statistics) ? homeBox.statistics : []).find(
        (h: any) => h?.name === s?.name,
      );
      stats.push({
        label: str(s?.label, str(s?.name, "")),
        away: str(s?.displayValue, "—"),
        home: str(match?.displayValue, "—"),
      });
    }

    const leaders: GameLeader[] = [];
    for (const group of Array.isArray(payload?.leaders) ? payload.leaders : []) {
      const teamName = str(group?.team?.abbreviation, str(group?.team?.displayName, ""));
      for (const cat of Array.isArray(group?.leaders) ? group.leaders : []) {
        const entry = Array.isArray(cat?.leaders) ? cat.leaders[0] : null;
        if (!entry?.athlete) continue;
        leaders.push({
          category: str(cat?.displayName, str(cat?.name, "")),
          name: str(entry.athlete?.displayName, "Player"),
          team: teamName,
          value: str(entry?.displayValue, ""),
          playerId: String(entry.athlete?.id ?? ""),
        });
      }
    }

    const winProbability: number[] = (Array.isArray(payload?.winprobability) ? payload.winprobability : [])
      .map((w: any) => Math.round(Number(w?.homeWinPercentage ?? 0) * 100))
      .filter((n: number) => Number.isFinite(n));

    // Lineups: soccer summaries expose `rosters`, US sports use boxscore players.
    const lineups: LineupTeam[] = [];
    for (const group of Array.isArray(payload?.rosters) ? payload.rosters : []) {
      const players: LineupPlayer[] = (Array.isArray(group?.roster) ? group.roster : [])
        .map((entry: any) => ({
          name: str(entry?.athlete?.displayName, ""),
          position: str(entry?.position?.abbreviation, str(entry?.position?.displayName, "")),
          starter: entry?.starter === true,
        }))
        .filter((p: LineupPlayer) => p.name.length > 0);
      if (players.length) {
        players.sort((a, b) => Number(b.starter) - Number(a.starter));
        lineups.push({
          team: str(group?.team?.displayName, str(group?.team?.abbreviation, "")),
          players: players.slice(0, 24),
        });
      }
    }
    if (lineups.length === 0) {
      for (const group of Array.isArray(payload?.boxscore?.players)
        ? payload.boxscore.players
        : []) {
        const seen = new Set<string>();
        const players: LineupPlayer[] = [];
        for (const block of Array.isArray(group?.statistics) ? group.statistics : []) {
          for (const entry of Array.isArray(block?.athletes) ? block.athletes : []) {
            const nm = str(entry?.athlete?.displayName, "");
            if (!nm || seen.has(nm)) continue;
            seen.add(nm);
            players.push({
              name: nm,
              position: str(entry?.athlete?.position?.abbreviation, str(block?.name, "")),
              starter: entry?.starter === true,
            });
          }
        }
        if (players.length) {
          lineups.push({
            team: str(group?.team?.displayName, str(group?.team?.abbreviation, "")),
            players: players.slice(0, 24),
          });
        }
      }
    }

    const base = {
      id: data.gameId,
      away: name(awayC),
      home: name(homeC),
      awayAbbr: str(awayC?.team?.abbreviation, ""),
      homeAbbr: str(homeC?.team?.abbreviation, ""),
      awayScore: Number(awayC?.score ?? 0),
      homeScore: Number(homeC?.score ?? 0),
      state: str(comp?.status?.type?.state, "pre"),
      status: str(comp?.status?.type?.shortDetail, ""),
      venue: str(payload?.gameInfo?.venue?.fullName, ""),
      timeline,
      stats,
      leaders: leaders.slice(0, 8),
      winProbability: winProbability.slice(-60),
      lineups,
    };

    return { ...base, recap: buildRecap(base) };
  });

export interface StatLeader {
  name: string;
  position: string;
  playerId: string;
  value: string;
}

export interface LeaderCategory {
  name: string;
  entries: StatLeader[];
}

/** Season stat leaders per category (best players by position) for one league. */
export const fetchLeagueLeaders = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }): Promise<LeaderCategory[]> => {
    const [sport, key] = ESPN_PATH[data.league].split("/");
    const year = new Date().getUTCFullYear();
    let categories: any[] = [];
    for (const season of [year, year + 1, year - 1]) {
      const res = await fetch(
        `https://sports.core.api.espn.com/v2/sports/${sport}/leagues/${key}/seasons/${season}/types/2/leaders?limit=5`,
        { headers: { accept: "application/json" } },
      ).catch(() => null);
      if (!res || !res.ok) continue;
      const payload: any = await res.json().catch(() => null);
      const found: any[] = Array.isArray(payload?.categories) ? payload.categories : [];
      if (found.some((c: any) => Array.isArray(c?.leaders) && c.leaders.length)) {
        categories = found;
        break;
      }
    }
    if (!categories.length) return [];

    const cache = new Map<string, Promise<any>>();
    const load = (url: string) => {
      const safe = url.replace(/^http:/, "https:");
      if (!cache.has(safe)) {
        cache.set(
          safe,
          fetch(safe, { headers: { accept: "application/json" } })
            .then((r) => (r.ok ? r.json() : null))
            .catch(() => null),
        );
      }
      return cache.get(safe)!;
    };

    const picked = categories.filter((c: any) => Array.isArray(c?.leaders) && c.leaders.length).slice(0, 8);

    const out: LeaderCategory[] = await Promise.all(
      picked.map(async (cat: any) => {
        const entries = await Promise.all(
          cat.leaders.slice(0, 5).map(async (l: any) => {
            const ref = str(l?.athlete?.$ref, "");
            const athlete = ref ? await load(ref) : null;
            return {
              name: str(athlete?.displayName, "Player"),
              position: str(athlete?.position?.abbreviation, ""),
              playerId: String(athlete?.id ?? ""),
              value: str(l?.displayValue, String(l?.value ?? "")),
            };
          }),
        );
        return {
          name: str(cat?.displayName, str(cat?.name, "Category")),
          entries: entries.filter((e) => e.playerId.length > 0),
        };
      }),
    );

    return out.filter((c) => c.entries.length > 0);
  });
