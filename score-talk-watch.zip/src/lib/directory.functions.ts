import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface DirectoryTeam {
  id: string;
  slug: string;
  name: string;
  abbr: string;
  logo: string | null;
  link: string | null;
}

export interface DirectoryGroup {
  name: string;
  abbr: string;
  divisions: { name: string; teams: DirectoryTeam[] }[];
}

export interface LeagueDirectory {
  league: LeagueId;
  groups: DirectoryGroup[];
  teamCount: number;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapTeam(raw: any): DirectoryTeam | null {
  const name = str(raw?.displayName, str(raw?.name));
  if (!name) return null;
  const logos: any[] = Array.isArray(raw?.logos) ? raw.logos : [];
  const links: any[] = Array.isArray(raw?.links) ? raw.links : [];
  return {
    id: str(raw?.id, name),
    slug: str(raw?.slug, name.toLowerCase().replace(/[^a-z0-9]+/g, "-")),
    name,
    abbr: str(raw?.abbreviation, name.slice(0, 3).toUpperCase()),
    logo: str(logos.find((l) => typeof l?.href === "string")?.href) || null,
    link: str(links.find((l) => typeof l?.href === "string")?.href) || null,
  };
}

function mapGroup(raw: any): DirectoryGroup | null {
  const name = str(raw?.name);
  if (!name) return null;
  const children: any[] = Array.isArray(raw?.children) ? raw.children : [];
  const divisions = children.length
    ? children.map((child) => ({
        name: str(child?.name, "Division"),
        teams: (Array.isArray(child?.teams) ? child.teams : [])
          .map(mapTeam)
          .filter((t: DirectoryTeam | null): t is DirectoryTeam => t !== null),
      }))
    : [
        {
          name,
          teams: (Array.isArray(raw?.teams) ? raw.teams : [])
            .map(mapTeam)
            .filter((t: DirectoryTeam | null): t is DirectoryTeam => t !== null),
        },
      ];
  const withTeams = divisions.filter((d) => d.teams.length > 0);
  if (!withTeams.length) return null;
  return { name, abbr: str(raw?.abbreviation, name.slice(0, 4).toUpperCase()), divisions: withTeams };
}

async function fetchGroups(league: LeagueId): Promise<DirectoryGroup[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/groups`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const groups: any[] = Array.isArray(payload?.groups) ? payload.groups : [];
  return groups.map(mapGroup).filter((g): g is DirectoryGroup => g !== null);
}

async function fetchFlatTeams(league: LeagueId): Promise<DirectoryGroup[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/teams?limit=500`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) return [];
  const payload: any = await res.json();
  const entries: any[] = payload?.sports?.[0]?.leagues?.[0]?.teams ?? [];
  const teams = entries
    .map((e) => mapTeam(e?.team))
    .filter((t): t is DirectoryTeam => t !== null)
    .sort((a, b) => a.name.localeCompare(b.name));
  if (!teams.length) return [];
  return [{ name: "All clubs", abbr: "ALL", divisions: [{ name: "Clubs", teams }] }];
}

/** International soccer has no single team list, so aggregate the big competitions. */
const INTL_COMPETITIONS: { path: string; name: string; abbr: string }[] = [
  { path: "soccer/eng.1", name: "Premier League", abbr: "EPL" },
  { path: "soccer/esp.1", name: "LaLiga", abbr: "LIGA" },
  { path: "soccer/ita.1", name: "Serie A", abbr: "SERA" },
  { path: "soccer/ger.1", name: "Bundesliga", abbr: "BUND" },
  { path: "soccer/fra.1", name: "Ligue 1", abbr: "LIG1" },
  { path: "soccer/mex.1", name: "Liga MX", abbr: "MX" },
  { path: "soccer/fifa.world", name: "FIFA World Cup nations", abbr: "FIFA" },
];

async function fetchIntlTeams(): Promise<DirectoryGroup[]> {
  const results = await Promise.allSettled(
    INTL_COMPETITIONS.map(async (comp) => {
      const res = await fetch(
        `https://site.api.espn.com/apis/site/v2/sports/${comp.path}/teams?limit=500`,
        { headers: { accept: "application/json" } },
      );
      if (!res.ok) return null;
      const payload: any = await res.json();
      const entries: any[] = payload?.sports?.[0]?.leagues?.[0]?.teams ?? [];
      const teams = entries
        .map((e) => mapTeam(e?.team))
        .filter((t): t is DirectoryTeam => t !== null)
        .sort((a, b) => a.name.localeCompare(b.name));
      if (!teams.length) return null;
      return {
        name: comp.name,
        abbr: comp.abbr,
        divisions: [{ name: "Clubs", teams }],
      } as DirectoryGroup;
    }),
  );
  return results.flatMap((r) => (r.status === "fulfilled" && r.value ? [r.value] : []));
}
/* eslint-enable @typescript-eslint/no-explicit-any */

async function loadGroups(league: LeagueId): Promise<DirectoryGroup[]> {
  if (league === "intl") return fetchIntlTeams().catch(() => [] as DirectoryGroup[]);
  let groups = await fetchGroups(league).catch(() => [] as DirectoryGroup[]);
  if (!groups.length) groups = await fetchFlatTeams(league).catch(() => [] as DirectoryGroup[]);
  return groups;
}

/** Conferences, divisions and teams for one league, from public league data. */
export const fetchLeagueDirectory = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }): Promise<LeagueDirectory> => {
    const league = data.league;
    const groups = await loadGroups(league);
    const teamCount = groups.reduce(
      (sum, g) => sum + g.divisions.reduce((s, d) => s + d.teams.length, 0),
      0,
    );
    return { league, groups, teamCount };
  });

/** Team counts for every league, used by the directory index. */
export const fetchDirectoryOverview = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ league: LeagueId; teamCount: number; groups: string[] }[]> => {
    const results = await Promise.allSettled(
      LEAGUE_IDS.map(async (league) => {
        const groups = await loadGroups(league);
        return {
          league,
          teamCount: groups.reduce(
            (sum, g) => sum + g.divisions.reduce((s, d) => s + d.teams.length, 0),
            0,
          ),
          groups: groups.map((g) => g.name).slice(0, 6),
        };
      }),
    );
    return results.flatMap((r) => (r.status === "fulfilled" ? [r.value] : []));
  },
);
