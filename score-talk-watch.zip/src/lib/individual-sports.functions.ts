import { createServerFn } from "@tanstack/react-start";

export type SportId = "tennis" | "ufc" | "boxing" | "golf" | "nascar" | "f1";

export interface SportMeta {
  id: SportId;
  name: string;
  short: string;
  blurb: string;
  /** ESPN scoreboard path. Empty when the sport has no scoreboard feed (events show an honest empty state). */
  espnPath: string;
  /** ESPN news path. Empty when headlines come from rssPath instead. */
  newsPath: string;
  /** Fallback RSS feed for headlines when ESPN has no news API for the sport. */
  rssPath?: string;
  rssFallback?: string;
  youtubeChannel: string | null;
}

export const INDIVIDUAL_SPORTS: SportMeta[] = [
  {
    id: "tennis",
    name: "Tennis",
    short: "ATP & WTA",
    blurb:
      "Live ATP and WTA results, Grand Slam draws, tournament schedules, news and fan talk.",
    espnPath: "tennis/atp",
    newsPath: "tennis/atp",
    youtubeChannel: "UCY_5h5zaSwN7Or4kIJDYNXA",
  },
  {
    id: "ufc",
    name: "UFC & MMA",
    short: "UFC",
    blurb:
      "Fight cards, live results, main-event breakdowns, rankings and fight-night fan chat.",
    espnPath: "mma/ufc",
    newsPath: "mma/ufc",
    youtubeChannel: "UCvgfXK4nTYKudb0rFR6noLA",
  },
  {
    id: "boxing",
    name: "Boxing",
    short: "Boxing",
    blurb:
      "Fight schedules and results, official highlight clips, boxing headlines from the wire, trivia and ringside fan chat.",
    espnPath: "",
    newsPath: "",
    rssPath: "https://sports.yahoo.com/boxing/rss.xml",
    rssFallback: "https://www.espn.com/espn/rss/boxing/news",
    youtubeChannel: "UCiWLfSweyRNmLpgEHekhoAg",
  },
  {
    id: "golf",
    name: "Golf",
    short: "PGA Tour",
    blurb:
      "PGA Tour leaderboards, major championship coverage, tee times, news and fan reaction.",
    espnPath: "golf/pga",
    newsPath: "golf/pga",
    youtubeChannel: "UCKwGZZMrhNYKzucCtTPY2Nw",
  },
  {
    id: "nascar",
    name: "NASCAR",
    short: "NASCAR",
    blurb:
      "Cup Series race results, the full race calendar, driver standings, news and race-day chat.",
    espnPath: "racing/nascar-premier",
    newsPath: "racing/nascar-premier",
    youtubeChannel: "UCuN9hYw2RpoAW8rZ3VK3isA",
  },
  {
    id: "f1",
    name: "Formula 1",
    short: "F1",
    blurb:
      "Live Formula 1 race results, the full grand prix schedule, driver and constructor standings, news and race-weekend fan chat.",
    espnPath: "racing/f1",
    newsPath: "racing/f1",
    youtubeChannel: "UCB_qr75-ydFVKSF9Dmo6izg",
  },
];

export function sportById(id: string): SportMeta | undefined {
  return INDIVIDUAL_SPORTS.find((s) => s.id === id);
}

export interface SportEvent {
  id: string;
  name: string;
  shortName: string;
  date: string;
  status: string;
  state: string;
  venue: string;
  location: string;
  note: string;
  link: string | null;
  competitors: { name: string; detail: string; winner: boolean }[];
}

export interface SportHeadline {
  id: string;
  headline: string;
  description: string;
  url: string;
  published: string;
  image: string | null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function asSport(value: unknown): SportMeta {
  return sportById(typeof value === "string" ? value : "") ?? INDIVIDUAL_SPORTS[0]!;
}

function tag(xml: string, name: string): string {
  const match = new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`).exec(xml);
  return match?.[1]?.trim() ?? "";
}

function decodeXml(value: string): string {
  return value
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, "&")
    .trim();
}

function mapEvent(raw: any): SportEvent | null {
  const name = str(raw?.name, str(raw?.shortName));
  if (!name) return null;
  const comp: any = Array.isArray(raw?.competitions) ? raw.competitions[0] : undefined;
  const competitors = (Array.isArray(comp?.competitors) ? comp.competitors : [])
    .map((c: any) => ({
      name: str(
        c?.athlete?.displayName,
        str(c?.team?.displayName, str(c?.displayName, str(c?.roster?.[0]?.athlete?.displayName))),
      ),
      detail: str(
        c?.score ? String(c.score) : "",
        str(c?.linescores?.map((l: any) => l?.value).join(" ") || "", str(c?.order ? `#${c.order}` : "")),
      ),
      winner: c?.winner === true,
    }))
    .filter((c: { name: string }) => c.name.length > 0)
    .slice(0, 8);

  return {
    id: str(raw?.id, name),
    name,
    shortName: str(raw?.shortName, name),
    date: str(raw?.date, ""),
    status: str(raw?.status?.type?.detail, str(raw?.status?.type?.description, "Scheduled")),
    state: str(raw?.status?.type?.state, "pre"),
    venue: str(comp?.venue?.fullName, ""),
    location: [str(comp?.venue?.address?.city), str(comp?.venue?.address?.state)]
      .filter(Boolean)
      .join(", "),
    note: str(comp?.notes?.[0]?.headline, str(raw?.season?.slug, "")),
    link:
      str((Array.isArray(raw?.links) ? raw.links : []).find((l: any) => typeof l?.href === "string")?.href) ||
      null,
    competitors,
  };
}

/** Current events (matches, fight cards, tournaments, races) for one sport. */
export const fetchSportEvents = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { sport?: unknown } | undefined;
    return { sport: asSport(raw?.sport).id };
  })
  .handler(async ({ data }): Promise<SportEvent[]> => {
    const meta = sportById(data.sport)!;
    if (!meta.espnPath) return [];
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${meta.espnPath}/scoreboard`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return [];
    const payload: any = await res.json().catch(() => null);
    const payloads: any[] = [payload];
    if (data.sport === "tennis") {
      const wta = await fetch(
        "https://site.api.espn.com/apis/site/v2/sports/tennis/wta/scoreboard",
        { headers: { accept: "application/json" } },
      ).catch(() => null);
      if (wta && wta.ok) {
        const extra = await wta.json().catch(() => null);
        if (extra) payloads.push(extra);
      }
    }

    const out: SportEvent[] = [];
    for (const source of payloads) {
      const raw: any[] = Array.isArray(source?.events) ? source.events : [];
      for (const event of raw) {
        const groupings: any[] = Array.isArray(event?.groupings) ? event.groupings : [];
        if (groupings.length > 0) {
          for (const group of groupings) {
            const label = str(group?.grouping?.displayName, "Draw");
            for (const comp of Array.isArray(group?.competitions) ? group.competitions : []) {
              const mapped = mapEvent({
                ...event,
                id: str(comp?.id, event?.id),
                name: `${str(event?.name, "Tournament")} — ${label}`,
                shortName: str(event?.shortName, ""),
                date: str(comp?.date, event?.date),
                status: comp?.status,
                competitions: [comp],
              });
              if (mapped) {
                mapped.note = str(comp?.notes?.[0]?.text, label);
                out.push(mapped);
              }
            }
          }
        } else {
          const mapped = mapEvent(event);
          if (mapped) out.push(mapped);
        }
      }
    }
    return out
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 60);
  });

/** Latest headlines for one sport. */
export const fetchSportNews = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { sport?: unknown } | undefined;
    return { sport: asSport(raw?.sport).id };
  })
  .handler(async ({ data }): Promise<SportHeadline[]> => {
    const meta = sportById(data.sport)!;

    // Sports with no ESPN news API (boxing) read the wire's RSS feeds instead.
    if (!meta.newsPath) {
      const feeds = [meta.rssPath, meta.rssFallback].filter((f): f is string => typeof f === "string");
      for (const feedUrl of feeds) {
        const rss = await fetch(feedUrl, {
          headers: { accept: "application/rss+xml, application/xml, text/xml", "user-agent": "Mozilla/5.0 (compatible; SidelineApp/1.0)" },
        }).catch(() => null);
        if (!rss || !rss.ok) continue;
        const xml = await rss.text().catch(() => "");
        const items = xml.split(/<item[\s>]/).slice(1);
        const mapped = items
          .map((item, index): SportHeadline | null => {
            const headline = decodeXml(tag(item, "title"));
            const url = decodeXml(tag(item, "link"));
            if (!headline || !url || !/^https?:\/\//.test(url)) return null;
            return {
              id: `rss-${index}-${url}`,
              headline,
              description: decodeXml(tag(item, "description")).replace(/<[^>]*>/g, ""),
              url,
              published: decodeXml(tag(item, "pubDate")),
              image: null,
            };
          })
          .filter((a): a is SportHeadline => a !== null)
          .slice(0, 24);
        if (mapped.length > 0) return mapped;
      }
      return [];
    }

    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${meta.newsPath}/news?limit=24`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return [];
    const payload: any = await res.json().catch(() => null);
    const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];
    return articles
      .map((a: any): SportHeadline | null => {
        const headline = str(a?.headline);
        const url = str(a?.links?.web?.href, str(a?.links?.mobile?.href));
        if (!headline || !url) return null;
        return {
          id: str(a?.id ? String(a.id) : "", url),
          headline,
          description: str(a?.description),
          url,
          published: str(a?.published, ""),
          image: str((Array.isArray(a?.images) ? a.images : [])[0]?.url) || null,
        };
      })
      .filter((a: SportHeadline | null): a is SportHeadline => a !== null);
  });
