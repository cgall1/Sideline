import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const FANTASY_SPORTS = [
  { id: "nfl", label: "NFL", path: "football/nfl" },
  { id: "nba", label: "NBA", path: "basketball/nba" },
  { id: "nhl", label: "NHL", path: "hockey/nhl" },
  { id: "mlb", label: "MLB", path: "baseball/mlb" },
  { id: "mls", label: "MLS", path: "soccer/usa.1" },
  { id: "intl", label: "Premier League", path: "soccer/eng.1" },
  { id: "esp", label: "LaLiga", path: "soccer/esp.1" },
  { id: "ita", label: "Serie A", path: "soccer/ita.1" },
  { id: "ger", label: "Bundesliga", path: "soccer/ger.1" },
  { id: "fra", label: "Ligue 1", path: "soccer/fra.1" },
  { id: "ucl", label: "Champions League", path: "soccer/uefa.champions" },
] as const;

export type FantasySport = (typeof FANTASY_SPORTS)[number]["id"];

const SPORT_PATH: Record<string, string> = Object.fromEntries(
  FANTASY_SPORTS.map((s) => [s.id, s.path]),
);

export interface FantasyLeagueSummary {
  id: string;
  name: string;
  sport: string;
  status: string;
  memberCount: number;
  rosterSize: number;
  isCommissioner: boolean;
  inviteCode: string;
}

export interface FantasyMember {
  id: string;
  userId: string;
  teamName: string;
  ownerName: string;
}

export interface FantasyPick {
  id: string;
  memberId: string;
  playerId: string;
  playerName: string;
  position: string;
  teamName: string;
  round: number;
  dropped: boolean;
}

export interface FantasyLeagueDetail {
  id: string;
  name: string;
  sport: string;
  status: "open" | "drafting" | "done";
  rosterSize: number;
  inviteCode: string;
  commissionerId: string;
  draftOrder: string[];
  draftTurn: number;
  members: FantasyMember[];
  picks: FantasyPick[];
}

export interface PoolPlayer {
  id: string;
  name: string;
  position: string;
  teamName: string;
}

const asSport = (v: unknown): FantasySport => {
  const s = typeof v === "string" ? v : "nfl";
  return (SPORT_PATH[s] ? s : "nfl") as FantasySport;
};

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
/** Invite codes grant league access, so they come from a cryptographic source. */
const inviteCode = () => {
  const bytes = new Uint32Array(10);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
  return out;
};

export const createFantasyLeague = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => {
    const raw = data as { name?: unknown; sport?: unknown; teamName?: unknown } | undefined;
    const name = typeof raw?.name === "string" ? raw.name.trim() : "";
    const teamName = typeof raw?.teamName === "string" ? raw.teamName.trim() : "";
    if (name.length < 3 || name.length > 60) throw new Error("League name must be 3-60 characters");
    if (teamName.length < 2 || teamName.length > 40) throw new Error("Team name must be 2-40 characters");
    return { name, sport: asSport(raw?.sport), teamName };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    // The league SELECT policy requires membership, which does not exist yet,
    // so generate the id here instead of relying on an insert…returning read.
    const leagueId = crypto.randomUUID();
    const { error } = await supabase.from("fantasy_leagues").insert({
      id: leagueId,
      name: data.name,
      sport: data.sport,
      commissioner_id: userId,
      invite_code: inviteCode(),
    });
    if (error) {
      console.error("fantasy league insert failed", error);
      throw new Error("Couldn't create the league. Please try again.");
    }
    const { error: mErr } = await supabase
      .from("fantasy_members")
      .insert({ league_id: leagueId, user_id: userId, team_name: data.teamName });
    if (mErr) {
      console.error("fantasy member insert failed", mErr);
      throw new Error("Couldn't create the league. Please try again.");
    }
    return { leagueId };
  });

export const joinFantasyLeague = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => {
    const raw = data as { inviteCode?: unknown; teamName?: unknown } | undefined;
    const inviteCode = typeof raw?.inviteCode === "string" ? raw.inviteCode.trim().toUpperCase() : "";
    const teamName = typeof raw?.teamName === "string" ? raw.teamName.trim() : "";
    if (!inviteCode) throw new Error("Enter an invite code");
    if (teamName.length < 2 || teamName.length > 40) throw new Error("Team name must be 2-40 characters");
    return { inviteCode, teamName };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: league, error } = await supabaseAdmin
      .from("fantasy_leagues")
      .select("id,status")
      .eq("invite_code", data.inviteCode)
      .maybeSingle();
    if (error || !league) throw new Error("No league found with that invite code");
    if (league.status !== "open") throw new Error("That league has already drafted — no new teams");
    const { error: mErr } = await supabase
      .from("fantasy_members")
      .insert({ league_id: league.id, user_id: userId, team_name: data.teamName });
    if (mErr) {
      if (mErr.message.includes("duplicate") || mErr.code === "23505")
        throw new Error("You are already in that league");
      throw new Error(mErr.message);
    }
    return { leagueId: league.id as string };
  });

export const myFantasyLeagues = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<FantasyLeagueSummary[]> => {
    const { supabase, userId } = context;
    const { data: memberships, error } = await supabase
      .from("fantasy_members")
      .select("league_id")
      .eq("user_id", userId);
    if (error) {
      console.error("myFantasyLeagues memberships failed", error);
      throw new Error("We couldn't load your leagues. Please try again.");
    }
    const ids = (memberships ?? []).map((m) => m.league_id);
    if (ids.length === 0) return [];
    const { data: leagues, error: lErr } = await supabase
      .from("fantasy_leagues")
      .select("id,name,sport,status,roster_size,commissioner_id,invite_code")
      .in("id", ids)
      .order("created_at", { ascending: false });
    if (lErr) {
      console.error("myFantasyLeagues leagues failed", lErr);
      throw new Error("We couldn't load your leagues. Please try again.");
    }
    const { data: allMembers, error: cErr } = await supabase
      .from("fantasy_members")
      .select("league_id")
      .in("league_id", ids);
    if (cErr) {
      console.error("myFantasyLeagues member counts failed", cErr);
      throw new Error("We couldn't load your leagues. Please try again.");
    }
    const counts = new Map<string, number>();
    for (const m of allMembers ?? []) counts.set(m.league_id, (counts.get(m.league_id) ?? 0) + 1);
    return (leagues ?? []).map((l) => ({
      id: l.id,
      name: l.name,
      sport: l.sport,
      status: l.status,
      memberCount: counts.get(l.id) ?? 0,
      rosterSize: l.roster_size,
      isCommissioner: l.commissioner_id === userId,
      inviteCode: l.invite_code,
    }));
  });

export const getFantasyLeague = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => ({
    leagueId: String((data as { leagueId?: unknown } | undefined)?.leagueId ?? ""),
  }))
  .handler(async ({ data, context }): Promise<FantasyLeagueDetail> => {
    const { supabase } = context;
    const { data: league, error } = await supabase
      .from("fantasy_leagues")
      .select("id,name,sport,status,roster_size,invite_code,commissioner_id,draft_order,draft_turn")
      .eq("id", data.leagueId)
      .maybeSingle();
    if (error) {
      console.error("getFantasyLeague league failed", error);
      throw new Error("We couldn't load that league. Please try again.");
    }
    if (!league) throw new Error("League not found — are you a member?");
    const { data: members, error: mErr } = await supabase
      .from("fantasy_members")
      .select("id,user_id,team_name,created_at")
      .eq("league_id", league.id)
      .order("created_at", { ascending: true });
    if (mErr) {
      console.error("getFantasyLeague members failed", mErr);
      throw new Error("We couldn't load that league. Please try again.");
    }
    const { data: picks, error: pErr } = await supabase
      .from("fantasy_picks")
      .select("id,member_id,player_id,player_name,position,team_name,round,dropped")
      .eq("league_id", league.id)
      .order("picked_at", { ascending: true });
    if (pErr) {
      console.error("getFantasyLeague picks failed", pErr);
      throw new Error("We couldn't load that league. Please try again.");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profiles } = await supabaseAdmin
      .from("profiles")
      .select("id,display_name")
      .in("id", (members ?? []).map((m) => m.user_id));
    const names = new Map((profiles ?? []).map((p) => [p.id, p.display_name ?? "Fan"]));

    return {
      id: league.id,
      name: league.name,
      sport: league.sport,
      status: league.status as FantasyLeagueDetail["status"],
      rosterSize: league.roster_size,
      inviteCode: league.invite_code,
      commissionerId: league.commissioner_id,
      draftOrder: (league.draft_order ?? []) as string[],
      draftTurn: league.draft_turn,
      members: (members ?? []).map((m) => ({
        id: m.id,
        userId: m.user_id,
        teamName: m.team_name,
        ownerName: names.get(m.user_id) ?? "Fan",
      })),
      picks: (picks ?? []).map((p) => ({
        id: p.id,
        memberId: p.member_id,
        playerId: p.player_id,
        playerName: p.player_name,
        position: p.position,
        teamName: p.team_name,
        round: p.round,
        dropped: p.dropped,
      })),
    };
  });

const shuffle = <T>(arr: T[]): T[] => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = a[i]!;
    a[i] = a[j]!;
    a[j] = tmp;
  }
  return a;
};

export const startFantasyDraft = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => ({
    leagueId: String((data as { leagueId?: unknown } | undefined)?.leagueId ?? ""),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: league } = await supabase
      .from("fantasy_leagues")
      .select("id,commissioner_id,status")
      .eq("id", data.leagueId)
      .maybeSingle();
    if (!league) throw new Error("League not found");
    if (league.commissioner_id !== userId) throw new Error("Only the commissioner can start the draft");
    if (league.status !== "open") throw new Error("The draft has already started");
    const { data: members } = await supabase
      .from("fantasy_members")
      .select("id")
      .eq("league_id", league.id);
    const ids = (members ?? []).map((m) => m.id);
    if (ids.length < 2) throw new Error("You need at least 2 teams to draft — share your invite code");
    // League settings (status, draft order, roster size) are server-owned: no
    // one can write them straight through the table, so the verified
    // commissioner's start-draft is applied with a trusted client.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("fantasy_leagues")
      .update({ status: "drafting", draft_order: shuffle(ids), draft_turn: 0 })
      .eq("id", league.id)
      .eq("commissioner_id", userId)
      .eq("status", "open");
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Snake-draft pick: whose turn it is at pick number `turn`. */
export const memberOnClock = (order: string[], turn: number): string | null => {
  const n = order.length;
  if (n === 0) return null;
  const round = Math.floor(turn / n);
  const pos = turn % n;
  const idx = round % 2 === 0 ? pos : n - 1 - pos;
  return order[idx] ?? null;
};

export const makeDraftPick = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => {
    const raw = data as { leagueId?: unknown; player?: { id?: unknown } } | undefined;
    return {
      leagueId: String(raw?.leagueId ?? ""),
      playerId: String(raw?.player?.id ?? "").slice(0, 40),
    };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    if (!data.playerId) throw new Error("Pick a player first");
    const { data: league } = await supabase
      .from("fantasy_leagues")
      .select("id,sport,status,draft_order,draft_turn,roster_size")
      .eq("id", data.leagueId)
      .maybeSingle();
    if (!league) throw new Error("League not found");
    if (league.status !== "drafting") throw new Error("The draft is not live");
    const { data: me } = await supabase
      .from("fantasy_members")
      .select("id")
      .eq("league_id", league.id)
      .eq("user_id", userId)
      .maybeSingle();
    if (!me) throw new Error("You are not in this league");
    const order = (league.draft_order ?? []) as string[];
    const onClock = memberOnClock(order, league.draft_turn);
    if (onClock !== me.id) throw new Error("It is not your turn to pick");
    const total = order.length * league.roster_size;
    if (league.draft_turn >= total) throw new Error("The draft is complete");
    const round = Math.floor(league.draft_turn / order.length) + 1;
    // Only the caller's player id is trusted: the name, position and team are
    // taken from the official roster feed so picks cannot be invented.
    const pool = await fetchFantasyPlayerPool({ data: { sport: league.sport } });
    const player = pool.find((p) => p.id === data.playerId);
    if (!player) throw new Error("That player is not in this league's pool");
    // Picks are server-written only (no direct table inserts), after the turn
    // and player checks above.
    const { supabaseAdmin: pickAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await pickAdmin.from("fantasy_picks").insert({
      league_id: league.id,
      member_id: me.id,
      player_id: player.id,
      player_name: player.name,
      position: player.position,
      team_name: player.teamName,
      round,
    });
    if (error) {
      if (error.code === "23505" || error.message.includes("duplicate"))
        throw new Error("That player was just taken — pick someone else");
      throw new Error(error.message);
    }
    const nextTurn = league.draft_turn + 1;
    const done = nextTurn >= total;
    // Only the commissioner may update the league row under RLS, but every
    // drafter has to advance the clock — do it with a trusted client after
    // verifying above that this caller really was on the clock.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: tErr } = await supabaseAdmin
      .from("fantasy_leagues")
      .update({ draft_turn: nextTurn, ...(done ? { status: "done" } : {}) })
      .eq("id", league.id)
      .eq("draft_turn", league.draft_turn);
    if (tErr) throw new Error(tErr.message);
    return { ok: true, done };
  });

export const dropFantasyPlayer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => ({
    pickId: String((data as { pickId?: unknown } | undefined)?.pickId ?? ""),
  }))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("fantasy_picks")
      .update({ dropped: true })
      .eq("id", data.pickId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Real player pool for the draft, pulled from the official rosters feed.
 * Public read — no private data involved.
 */
export const fetchFantasyPlayerPool = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    sport: asSport((data as { sport?: unknown } | undefined)?.sport),
  }))
  .handler(async ({ data }): Promise<PoolPlayer[]> => {
    const path = SPORT_PATH[data.sport];
    const base = `https://site.api.espn.com/apis/site/v2/sports/${path}`;
    const res = await fetch(`${base}/teams?limit=100`, { headers: { accept: "application/json" } });
    if (!res.ok) return [];
    const payload: any = await res.json();
    const teams: any[] = (payload?.sports?.[0]?.leagues?.[0]?.teams ?? [])
      .map((t: any) => t?.team)
      .filter(Boolean)
      .slice(0, 40);
    const players: PoolPlayer[] = [];
    await Promise.all(
      teams.map(async (team: any) => {
        try {
          const r = await fetch(`${base}/teams/${team.id}/roster`, {
            headers: { accept: "application/json" },
          });
          if (!r.ok) return;
          const rp: any = await r.json();
          const groups: any[] = Array.isArray(rp?.athletes) ? rp.athletes : [];
          // Rosters arrive grouped by unit (offense/defense/…), each with items.
          const athletes: any[] = groups.flatMap((g) =>
            Array.isArray(g?.items) ? g.items : g?.displayName ? [g] : [],
          );
          for (const a of athletes) {
            const name = typeof a?.displayName === "string" ? a.displayName : "";
            const id = a?.id != null ? String(a.id) : "";
            if (!name || !id) continue;
            players.push({
              id,
              name,
              position: typeof a?.position?.abbreviation === "string" ? a.position.abbreviation : "",
              teamName: typeof team?.displayName === "string" ? team.displayName : "",
            });
          }
        } catch {
          /* skip failed team */
        }
      }),
    );
    return players.sort((a, b) => a.name.localeCompare(b.name));
  });

export interface MyFantasyPlayer {
  leagueId: string;
  leagueName: string;
  playerName: string;
  position: string;
  teamName: string;
}

/** Every player this fan has on a fantasy roster, across all of their leagues. */
export const myFantasyPlayers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MyFantasyPlayer[]> => {
    const { supabase, userId } = context;
    const { data: members } = await supabase
      .from("fantasy_members")
      .select("id,league_id")
      .eq("user_id", userId);
    if (!members?.length) return [];
    const { data: leagues } = await supabase
      .from("fantasy_leagues")
      .select("id,name")
      .in("id", members.map((m) => m.league_id));
    const names = new Map((leagues ?? []).map((l) => [l.id, l.name]));
    const { data: picks } = await supabase
      .from("fantasy_picks")
      .select("member_id,league_id,player_name,position,team_name,dropped")
      .in("member_id", members.map((m) => m.id));
    return (picks ?? [])
      .filter((p) => !p.dropped)
      .map((p) => ({
        leagueId: p.league_id,
        leagueName: names.get(p.league_id) ?? "Fantasy",
        playerName: p.player_name,
        position: p.position,
        teamName: p.team_name,
      }));
  });
