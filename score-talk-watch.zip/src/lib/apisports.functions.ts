import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { LeagueId } from "@/data/sports";

export interface ProviderHealthRow {
  league: LeagueId;
  ok: boolean;
  games: number;
  error?: string;
}

/**
 * Public: only whether the live data subscription is connected. Never calls
 * the paid provider, so anonymous visitors can't spend the quota.
 */
export const fetchProviderStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ configured: boolean }> => {
    const { providerConfigured } = await import("@/lib/apisports.server");
    return { configured: providerConfigured() };
  },
);

/**
 * Admin-only: per-league health check. This queries the paid provider, so it
 * requires a signed-in admin.
 */
export const fetchProviderHealth = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ configured: boolean; leagues: ProviderHealthRow[] }> => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Response("Forbidden", { status: 403 });
    const { providerHealth } = await import("@/lib/apisports.server");
    return providerHealth();
  });
