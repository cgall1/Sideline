import { queryOptions } from "@tanstack/react-query";
import { ARTICLES, POLLS, POSTS, type Game, type LeagueId } from "@/data/sports";
import { fetchLiveGames, fetchLiveStandings } from "@/lib/live-sports.functions";
import { fetchNews } from "@/lib/news.functions";
import { fetchDirectoryOverview, fetchLeagueDirectory } from "@/lib/directory.functions";
import { fetchPodcastEpisodes, fetchPodcastShows } from "@/lib/podcasts.functions";
import { fetchDaySchedule, fetchMonthSchedule, fetchVenues } from "@/lib/schedule.functions";
import { fetchSeasonResults } from "@/lib/results.functions";
import {
  fetchLiveSoccer,
  fetchSoccerCalendar,
  fetchSoccerHighlights,
  fetchSoccerTable,
  fetchSoccerTimeline,
  fetchSoccerMatchCentre,
  fetchSoccerNews,
  fetchSoccerSeasonHistory,
  fetchTopSoccerTables,
} from "@/lib/soccer.functions";
import { fetchTeamRoster } from "@/lib/rosters.functions";
import { fetchLeagueVideos } from "@/lib/videos.functions";
import { fetchLeagueInjuries, fetchPlayerProfile } from "@/lib/players.functions";
import { fetchSportEvents, fetchSportNews } from "@/lib/individual-sports.functions";
import { fetchOnThisDay } from "@/lib/history.functions";
import { fetchLeagueOdds } from "@/lib/odds.functions";
import { fetchTeamHub } from "@/lib/teams.functions";
import { fetchLeagueMoves } from "@/lib/moves.functions";
import { fetchGameSummary, fetchLeagueLeaders } from "@/lib/gamedata.functions";
import { fetchAdvancedTeamStats } from "@/lib/teamstats.functions";
import {
  fetchCricketBoard,
  fetchCricketNews,
  fetchCricketSeries,
  fetchCricketStandings,
} from "@/lib/cricket.functions";
import { fetchTennisRankings } from "@/lib/tennis.functions";

/** Win probabilities and betting lines per game for one league. */
export const leagueOddsQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["league-odds", league],
    queryFn: () => fetchLeagueOdds({ data: { league } }),
    staleTime: 60_000,
    refetchInterval: 120_000,
  });

/** Real highlight clips from a league's official video channels. */
export const leagueVideosQueryOptions = (league: string) =>
  queryOptions({
    queryKey: ["league-videos", league],
    queryFn: () => fetchLeagueVideos({ data: { league } }),
    staleTime: 10 * 60_000,
    refetchInterval: 30 * 60_000,
  });

/** Recent matches and stories for one soccer competition. */
export const soccerHighlightsQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["soccer-highlights", slug],
    queryFn: () => fetchSoccerHighlights({ data: { slug } }),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });


/** Live league table for one soccer competition. */
export const soccerTableQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["soccer-table", slug],
    queryFn: () => fetchSoccerTable({ data: { slug } }),
    staleTime: 10_000,
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
  });

/** How the table moved, matchday by matchday, for one competition. */
export const soccerTimelineQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["soccer-timeline", slug],
    queryFn: () => fetchSoccerTimeline({ data: { slug } }),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });

/** Every match date for one soccer competition. */
export const soccerCalendarQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["soccer-calendar", slug],
    queryFn: () => fetchSoccerCalendar({ data: { slug } }),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });

/** Season-by-season finishes for one competition. */
export const soccerSeasonHistoryQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["soccer-season-history", slug],
    queryFn: () => fetchSoccerSeasonHistory({ data: { slug } }),
    staleTime: 60 * 60_000,
  });

/** Top of the table for the headline competitions. */
export const topSoccerTablesQueryOptions = () =>
  queryOptions({
    queryKey: ["soccer-top-tables"],
    queryFn: () => fetchTopSoccerTables(),
    staleTime: 30_000,
    refetchInterval: 60_000,
  });

/** Transfers, injuries and matchday news across the major competitions. */
export const soccerNewsQueryOptions = () =>
  queryOptions({
    queryKey: ["soccer-news"],
    queryFn: () => fetchSoccerNews(),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });

/** Match centre for one soccer fixture — events, lineups and stats. */
export const soccerMatchQueryOptions = (slug: string, matchId: string) =>
  queryOptions({
    queryKey: ["soccer-match", slug, matchId],
    queryFn: () => fetchSoccerMatchCentre({ data: { slug, matchId } }),
    staleTime: 15_000,
    refetchInterval: 20_000,
  });

/** Today's soccer matches across every competition, refreshed while you watch. */
export const liveSoccerQueryOptions = () =>
  queryOptions({
    queryKey: ["soccer-live"],
    queryFn: () => fetchLiveSoccer(),
    staleTime: 20_000,
    refetchInterval: 30_000,
  });

/** One team's roster, record and latest roster moves. */
export const teamRosterQueryOptions = (league: LeagueId, teamId: string) =>
  queryOptions({
    queryKey: ["team-roster", league, teamId],
    queryFn: () => fetchTeamRoster({ data: { league, teamId } }),
    staleTime: 30 * 60_000,
    enabled: teamId.length > 0,
  });

/** Full-season results (wins, losses, points) for one league. */
export const seasonResultsQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["season-results", league],
    queryFn: () => fetchSeasonResults({ data: { league } }),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
  });


/** A league's full month of fixtures with venues and results. */
export const monthScheduleQueryOptions = (league: LeagueId, month: string) =>
  queryOptions({
    queryKey: ["schedule-month", league, month],
    queryFn: () => fetchMonthSchedule({ data: { league, month } }),
    staleTime: 5 * 60_000,
  });

/** One league day, used by the daily news pages. */
export const dayScheduleQueryOptions = (league: LeagueId, day: string) =>
  queryOptions({
    queryKey: ["schedule-day", league, day],
    queryFn: () => fetchDaySchedule({ data: { league, day } }),
    staleTime: 60_000,
    refetchInterval: 120_000,
  });

/** Cities and stadiums across every league. */
export const venuesQueryOptions = () =>
  queryOptions({
    queryKey: ["venues"],
    queryFn: () => fetchVenues(),
    staleTime: 6 * 60 * 60_000,
  });

/** Live scores, refreshed from the sports feed on an interval. */
export const gamesQueryOptions = (league: LeagueId | "all") =>
  queryOptions({
    queryKey: ["games", league],
    queryFn: async (): Promise<Game[]> => {
      const result = await fetchLiveGames({ data: { league } });
      return result.games;
    },
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 15_000,
  });

export const standingsQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["standings", league],
    queryFn: () => fetchLiveStandings({ data: { league } }),
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
    staleTime: 15_000,
  });

/** Latest sports headlines, refreshed every few minutes. */
export const newsQueryOptions = (league: LeagueId | "all") =>
  queryOptions({
    queryKey: ["news", league],
    queryFn: () => fetchNews({ data: { league } }),
    refetchInterval: 300_000,
    staleTime: 120_000,
  });

/** League, conference and team directory. */
export const directoryQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["directory", league],
    queryFn: () => fetchLeagueDirectory({ data: { league } }),
    staleTime: 60 * 60_000,
  });

export const directoryOverviewQueryOptions = () =>
  queryOptions({
    queryKey: ["directory-overview"],
    queryFn: () => fetchDirectoryOverview(),
    staleTime: 60 * 60_000,
  });

/** Sports podcast shows and their latest episodes. */
export const podcastShowsQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["podcast-shows", league],
    queryFn: () => fetchPodcastShows({ data: { league } }),
    staleTime: 30 * 60_000,
  });

export const podcastEpisodesQueryOptions = (showId: string) =>
  queryOptions({
    queryKey: ["podcast-episodes", showId],
    queryFn: () => fetchPodcastEpisodes({ data: { showId } }),
    staleTime: 15 * 60_000,
    enabled: showId.length > 0,
  });

export const articlesQueryOptions = () =>
  queryOptions({ queryKey: ["articles"], queryFn: () => ARTICLES });

export const pollsQueryOptions = () => queryOptions({ queryKey: ["polls"], queryFn: () => POLLS });

export const postsQueryOptions = () => queryOptions({ queryKey: ["posts"], queryFn: () => POSTS });

/** One player's bio and career stat lines. */
export const playerProfileQueryOptions = (league: LeagueId, playerId: string) =>
  queryOptions({
    queryKey: ["player-profile", league, playerId],
    queryFn: () => fetchPlayerProfile({ data: { league, playerId } }),
    staleTime: 30 * 60_000,
    enabled: playerId.length > 0,
  });

/** Current injury report for one league. */
export const leagueInjuriesQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["league-injuries", league],
    queryFn: () => fetchLeagueInjuries({ data: { league } }),
    staleTime: 10 * 60_000,
    refetchInterval: 15 * 60_000,
  });

/** Trades, signings and roster moves across one league. */
export const leagueMovesQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["league-moves", league],
    queryFn: () => fetchLeagueMoves({ data: { league } }),
    staleTime: 5 * 60_000,
    refetchInterval: 15 * 60_000,
  });

/** Schedule, record and news for one team's hub page. */
export const teamHubQueryOptions = (league: LeagueId, teamId: string) =>
  queryOptions({
    queryKey: ["team-hub", league, teamId],
    queryFn: () => fetchTeamHub({ data: { league, teamId } }),
    staleTime: 5 * 60_000,
    refetchInterval: 10 * 60_000,
    enabled: teamId.length > 0,
  });

/** Events for tennis, UFC, golf or NASCAR. */
export const sportEventsQueryOptions = (sport: string) =>
  queryOptions({
    queryKey: ["sport-events", sport],
    queryFn: () => fetchSportEvents({ data: { sport } }),
    staleTime: 60_000,
    refetchInterval: 120_000,
  });

/** Headlines for tennis, UFC, golf or NASCAR. */
export const sportNewsQueryOptions = (sport: string) =>
  queryOptions({
    queryKey: ["sport-news", sport],
    queryFn: () => fetchSportNews({ data: { sport } }),
    staleTime: 10 * 60_000,
    refetchInterval: 15 * 60_000,
  });

/** Box score, scoring timeline, leaders and auto recap for one game. */
export const gameSummaryQueryOptions = (league: LeagueId, gameId: string) =>
  queryOptions({
    queryKey: ["game-summary", league, gameId],
    queryFn: () => fetchGameSummary({ data: { league, gameId } }),
    staleTime: 10_000,
    refetchInterval: 20_000,
    refetchOnWindowFocus: true,
    enabled: gameId.length > 0,
  });

/** Season stat leaders (best players by position) for one league. */
export const leagueLeadersQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["league-leaders", league],
    queryFn: () => fetchLeagueLeaders({ data: { league } }),
    staleTime: 30 * 60_000,
  });

/** Sports moments from this calendar day in history. */
export const onThisDayQueryOptions = (month: number, day: number) =>
  queryOptions({
    queryKey: ["on-this-day", month, day],
    queryFn: () => fetchOnThisDay({ data: { month, day } }),
    staleTime: 6 * 60 * 60_000,
  });

/** Advanced per-game team stats (scoring, margin, splits) for one league. */
export const advancedTeamStatsQueryOptions = (league: LeagueId) =>
  queryOptions({
    queryKey: ["advanced-team-stats", league],
    queryFn: () => fetchAdvancedTeamStats({ data: { league } }),
    staleTime: 10 * 60_000,
  });

/** Live, recent and upcoming cricket matches across the active series. */
export const cricketBoardQueryOptions = () =>
  queryOptions({
    queryKey: ["cricket-board"],
    queryFn: () => fetchCricketBoard(),
    staleTime: 30_000,
    refetchInterval: 60_000,
  });

/** Cricket series running right now. */
export const cricketSeriesQueryOptions = () =>
  queryOptions({
    queryKey: ["cricket-series"],
    queryFn: () => fetchCricketSeries(),
    staleTime: 30 * 60_000,
  });

/** League table for one cricket series — refreshes as results land. */
export const cricketStandingsQueryOptions = (seriesId: string) =>
  queryOptions({
    queryKey: ["cricket-standings", seriesId],
    queryFn: () => fetchCricketStandings({ data: { seriesId } }),
    staleTime: 15_000,
    refetchInterval: 15_000,
  });

/** Cricket headlines from the wire. */
export const cricketNewsQueryOptions = () =>
  queryOptions({
    queryKey: ["cricket-news"],
    queryFn: () => fetchCricketNews(),
    staleTime: 10 * 60_000,
    refetchInterval: 15 * 60_000,
  });

/** ATP and WTA world rankings. */
export const tennisRankingsQueryOptions = () =>
  queryOptions({
    queryKey: ["tennis-rankings"],
    queryFn: () => fetchTennisRankings(),
    staleTime: 60_000,
    refetchInterval: 5 * 60_000,
    refetchOnWindowFocus: true,
  });
