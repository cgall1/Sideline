import { createServerFn } from "@tanstack/react-start";

/**
 * Public, anonymous aggregate counters (votes, members, followers, streaks).
 * The database helpers behind these are server-only; this proxy whitelists
 * exactly which ones may run and validates their arguments.
 */
const ALLOWED = {
  debate_vote_counts: [],
  topic_vote_counts: [],
  space_member_counts: [],
  space_vote_counts: [],
  space_follower_counts: [],
  space_poll_option_counts: ["_post"],
  rumor_vote_counts: ["_post"],
  issue_pulse_counts: ["_type", "_id"],
  game_mood_counts: ["_game"],
  crew_preview: ["_code"],
} as const;

type Fn = keyof typeof ALLOWED;

export const publicCounts = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const d = (data ?? {}) as { fn?: unknown; args?: Record<string, unknown> };
    if (typeof d.fn !== "string" || !(d.fn in ALLOWED)) throw new Error("Unknown counter");
    const fn = d.fn as Fn;
    const args: Record<string, string> = {};
    for (const key of ALLOWED[fn]) {
      const v = d.args?.[key];
      if (typeof v !== "string" || v.length > 300) throw new Error("Bad argument");
      args[key] = v;
    }
    return { fn, args };
  })
  .handler(async ({ data }): Promise<{ data: any[] | null; error: null | { message: string } }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const rpc = supabaseAdmin.rpc.bind(supabaseAdmin) as unknown as (
      fn: string,
      args?: Record<string, string>,
    ) => Promise<{ data: unknown; error: unknown }>;
    const { data: rows, error } = await rpc(data.fn, data.args);
    if (error) {
      console.error("publicCounts failed", data.fn, error);
      return { data: null, error: { message: "Couldn't load counts" } };
    }
    return { data: (rows as any[]) ?? [], error: null };
  });
