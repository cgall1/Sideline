import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { fetchFanImageUrls, fetchFanPostLikeCounts } from "@/lib/fan-gallery.functions";

export const FAN_CATEGORIES = [
  { id: "art", label: "Art & drawings" },
  { id: "gear", label: "Gear & collection" },
  { id: "moment", label: "Favorite moment" },
  { id: "matchday", label: "Matchday photo" },
  { id: "other", label: "Other" },
] as const;

export type FanCategory = (typeof FAN_CATEGORIES)[number]["id"];

export function categoryLabel(id: string): string {
  return FAN_CATEGORIES.find((c) => c.id === id)?.label ?? "Other";
}

export interface FanPost {
  id: string;
  userId: string;
  author: string;
  caption: string;
  category: string;
  team: string | null;
  league: string | null;
  imageUrl: string | null;
  createdAt: string;
  likes: number;
  likedByMe: boolean;
}

export interface FanComment {
  id: string;
  postId: string;
  userId: string;
  author: string;
  body: string;
  createdAt: string;
}

const BUCKET = "fan-gallery";

/** Every shared fan post, newest first, with a viewable image link. */
export const fanPostsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["fan-gallery", "posts", userId ?? "anon"],
    queryFn: async (): Promise<FanPost[]> => {
      const [postsRes, counts, mineRes] = await Promise.all([
        supabase
          .from("fan_posts")
          .select("id, user_id, author_name, caption, category, team, league, image_path, created_at")
          .order("created_at", { ascending: false })
          .limit(120),
        fetchFanPostLikeCounts(),
        userId
          ? supabase.from("fan_post_likes").select("post_id").eq("user_id", userId)
          : Promise.resolve({ data: [] as { post_id: string }[], error: null }),
      ]);
      if (postsRes.error) throw postsRes.error;
      if (mineRes.error) throw mineRes.error;

      const rows = postsRes.data ?? [];
      const paths = rows.map((r) => r.image_path);
      const urls = new Map<string, string>();
      if (paths.length) {
        const signed = await fetchFanImageUrls({ data: { paths } });
        for (const [path, url] of Object.entries(signed)) urls.set(path, url);
      }

      const likeMap = new Map(counts.map((c) => [c.post_id, c.likes]));
      const mine = new Set((mineRes.data ?? []).map((r) => r.post_id));

      return rows.map((r) => ({
        id: r.id,
        userId: r.user_id,
        author: r.author_name,
        caption: r.caption,
        category: r.category,
        team: r.team,
        league: r.league,
        imageUrl: urls.get(r.image_path) ?? null,
        createdAt: r.created_at,
        likes: likeMap.get(r.id) ?? 0,
        likedByMe: mine.has(r.id),
      }));
    },
    refetchInterval: 30_000,
  });

export const fanCommentsQueryOptions = () =>
  queryOptions({
    queryKey: ["fan-gallery", "comments"],
    queryFn: async (): Promise<FanComment[]> => {
      const { data, error } = await supabase
        .from("fan_post_comments")
        .select("id, post_id, user_id, author_name, body, created_at")
        .order("created_at", { ascending: true })
        .limit(600);
      if (error) throw error;
      return (data ?? []).map((r) => ({
        id: r.id,
        postId: r.post_id,
        userId: r.user_id,
        author: r.author_name,
        body: r.body,
        createdAt: r.created_at,
      }));
    },
    refetchInterval: 30_000,
  });

export async function uploadFanPost(input: {
  userId: string;
  authorName: string;
  file: File;
  caption: string;
  category: string;
  team: string;
  league: string | null;
}) {
  const ext = (input.file.name.split(".").pop() ?? "jpg").toLowerCase().slice(0, 5);
  const path = `${input.userId}/${crypto.randomUUID()}.${ext}`;
  const up = await supabase.storage
    .from(BUCKET)
    .upload(path, input.file, { contentType: input.file.type, upsert: false });
  if (up.error) throw up.error;

  const { error } = await supabase.from("fan_posts").insert({
    user_id: input.userId,
    author_name: input.authorName,
    caption: input.caption,
    category: input.category,
    team: input.team || null,
    league: input.league,
    image_path: path,
  });
  if (error) {
    await supabase.storage.from(BUCKET).remove([path]);
    throw error;
  }
}

export async function deleteFanPost(id: string) {
  const { error } = await supabase.from("fan_posts").delete().eq("id", id);
  if (error) throw error;
}

export async function toggleFanLike(postId: string, userId: string, liked: boolean) {
  const { error } = liked
    ? await supabase.from("fan_post_likes").delete().eq("post_id", postId).eq("user_id", userId)
    : await supabase.from("fan_post_likes").insert({ post_id: postId, user_id: userId });
  if (error) throw error;
}

export async function addFanComment(
  postId: string,
  userId: string,
  authorName: string,
  body: string,
) {
  const { error } = await supabase
    .from("fan_post_comments")
    .insert({ post_id: postId, user_id: userId, author_name: authorName, body });
  if (error) throw error;
}

export async function deleteFanComment(id: string) {
  const { error } = await supabase.from("fan_post_comments").delete().eq("id", id);
  if (error) throw error;
}
