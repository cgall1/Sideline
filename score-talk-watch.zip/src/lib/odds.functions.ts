import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface OddsTeam {
  name: string;
  abbreviation: string;
  logo: string | null;
  moneyline: number | null;
  winProbability: number;
  home: boolean;
}

export interface GameOdds {
  id: string;
  name: string;
  date: string;
  status: string;
  state: string;
  venue: string;
  provider: string;
  spread: string;
  overUnder: string;
  teams: OddsTeam[];
  link: string | null;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/eng.1",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

/** American moneyline to implied probability (0-1), before removing the book's margin. */
function implied(ml: number | null): number | null {
  if (ml === null || Number.isNaN(ml)) return null;
  return ml < 0 ? -ml / (-ml + 100) : 100 / (ml + 100);
}

function num(value: unknown): number | null {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = Number(value.replace(/[^0-9+-.]/g, ""));
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

/* eslint-disable @typescript-eslint/no-explicit-any */

/** Win probabilities per game, derived from the published moneylines. */
export const fetchLeagueOdds = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown } | undefined;
    return { league: asLeague(raw?.league) };
  })
  .handler(async ({ data }): Promise<GameOdds[]> => {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[data.league]}/scoreboard?limit=100`,
      { headers: { accept: "application/json" } },
    ).catch(() => null);
    if (!res || !res.ok) return [];
    const payload: any = await res.json().catch(() => null);
    const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
    const out: GameOdds[] = [];

    for (const event of events) {
      const comp: any = event?.competitions?.[0];
      if (!comp) continue;
      const odds: any = Array.isArray(comp?.odds) ? comp.odds[0] : null;
      const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
      if (competitors.length < 2) continue;

      const mlHome =
        num(odds?.homeTeamOdds?.moneyLine) ?? num(odds?.moneyline?.home?.close?.odds) ??
        num(odds?.moneyline?.home?.open?.odds);
      const mlAway =
        num(odds?.awayTeamOdds?.moneyLine) ?? num(odds?.moneyline?.away?.close?.odds) ??
        num(odds?.moneyline?.away?.open?.odds);

      const pHome = implied(mlHome);
      const pAway = implied(mlAway);
      const total = (pHome ?? 0) + (pAway ?? 0);

      const teams: OddsTeam[] = competitors.map((c: any) => {
        const isHome = c?.homeAway === "home";
        const raw = isHome ? pHome : pAway;
        const probability = raw !== null && total > 0 ? raw / total : 0.5;
        return {
          name: String(c?.team?.displayName ?? c?.team?.name ?? "Team"),
          abbreviation: String(c?.team?.abbreviation ?? ""),
          logo: typeof c?.team?.logo === "string" ? c.team.logo : null,
          moneyline: isHome ? mlHome : mlAway,
          winProbability: Math.round(probability * 100),
          home: isHome,
        };
      });

      out.push({
        id: String(event?.id ?? ""),
        name: String(event?.name ?? ""),
        date: String(event?.date ?? ""),
        status: String(comp?.status?.type?.shortDetail ?? event?.status?.type?.shortDetail ?? ""),
        state: String(comp?.status?.type?.state ?? "pre"),
        venue: String(comp?.venue?.fullName ?? ""),
        provider: String(odds?.provider?.displayName ?? ""),
        spread: String(odds?.details ?? ""),
        overUnder: odds?.overUnder !== undefined && odds?.overUnder !== null ? `O/U ${odds.overUnder}` : "",
        teams,
        link: typeof event?.links?.[0]?.href === "string" ? event.links[0].href : null,
      });
    }

    return out;
  });
