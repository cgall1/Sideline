import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

export interface NewsItem {
  id: string;
  league: LeagueId;
  headline: string;
  summary: string;
  published: string;
  url: string;
  image: string | null;
  type: string;
  byline: string;
}

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

/* eslint-disable @typescript-eslint/no-explicit-any */
async function fetchLeagueNews(league: LeagueId): Promise<NewsItem[]> {
  const res = await fetch(
    `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/news?limit=20`,
    { headers: { accept: "application/json" } },
  );
  if (!res.ok) throw new Error(`ESPN news ${league} ${res.status}`);
  const payload: any = await res.json();
  const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];

  return articles
    .map((a): NewsItem | null => {
      const url: string =
        typeof a?.links?.web?.href === "string"
          ? a.links.web.href
          : typeof a?.links?.mobile?.href === "string"
            ? a.links.mobile.href
            : "";
      const headline: string = typeof a?.headline === "string" ? a.headline : "";
      if (!url || !headline) return null;
      const image = Array.isArray(a?.images)
        ? (a.images.find((i: any) => typeof i?.url === "string")?.url ?? null)
        : null;
      return {
        id: `${league}-${String(a?.id ?? url)}`,
        league,
        headline,
        summary: typeof a?.description === "string" ? a.description : "",
        published: typeof a?.published === "string" ? a.published : new Date().toISOString(),
        url,
        image,
        type: typeof a?.type === "string" ? a.type : "Story",
        byline: typeof a?.byline === "string" ? a.byline : "ESPN",
      };
    })
    .filter((n): n is NewsItem => n !== null);
}
/* eslint-enable @typescript-eslint/no-explicit-any */

function asLeague(value: unknown): LeagueId | "all" {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "all";
}

/** Latest sports headlines across every league we cover (public league newsfeed). */
export const fetchNews = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }): Promise<{ items: NewsItem[]; updatedAt: string }> => {
    const leagues = data.league === "all" ? LEAGUE_IDS : [data.league];
    const results = await Promise.allSettled(leagues.map(fetchLeagueNews));
    const seen = new Set<string>();
    const items = results
      .flatMap((r) => (r.status === "fulfilled" ? r.value : []))
      .filter((item) => {
        const key = item.headline.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => new Date(b.published).getTime() - new Date(a.published).getTime())
      .slice(0, 60);

    return { items, updatedAt: new Date().toISOString() };
  });
