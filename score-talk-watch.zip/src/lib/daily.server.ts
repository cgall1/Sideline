import { RIVALRIES, HALL_OF_FAME } from "@/data/legacy";
import { SPORT_HISTORY } from "@/data/history";

export interface DebateDraft {
  question: string;
  context: string;
  sideA: string;
  sideB: string;
  league: string | null;
  source: string;
  link: string | null;
}

/** Stable per-day index so everyone sees the same debate on the same date. */
function daySeed(date: string): number {
  let hash = 0;
  for (const ch of date) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return hash;
}

function rivalryDebate(seed: number): DebateDraft {
  const r = RIVALRIES[seed % RIVALRIES.length]!;
  const [a, b] = r.name.split(/\s+vs\s+/i);
  return {
    question: `${r.name} — who owns this rivalry?`,
    context: r.summary,
    sideA: a?.trim() || "Side A",
    sideB: b?.trim() || "Side B",
    league: r.league,
    source: "rivalry",
    link: `/rivalries/${r.slug}`,
  };
}

function hallOfFameDebate(seed: number): DebateDraft {
  const sport = HALL_OF_FAME[seed % HALL_OF_FAME.length]!;
  const members = sport.members;
  const first = members[seed % members.length]!;
  const second = members[(seed + 3) % members.length]!;
  const other = second.name === first.name ? members[(seed + 1) % members.length]! : second;
  return {
    question: `${sport.name} greats: ${first.name} or ${other.name}?`,
    context: `${first.name} — ${first.note} ${other.name} — ${other.note}`,
    sideA: first.name,
    sideB: other.name,
    league: sport.name,
    source: "hall-of-fame",
    link: `/hall-of-fame`,
  };
}

function milestoneDebate(seed: number): DebateDraft {
  const sport = SPORT_HISTORY[seed % SPORT_HISTORY.length]!;
  const m = sport.milestones[seed % sport.milestones.length]!;
  return {
    question: `${sport.name}, ${m.year}: ${m.title} — biggest change the sport ever made?`,
    context: m.detail,
    sideA: "Biggest change",
    sideB: "Overrated moment",
    league: sport.name,
    source: "history",
    link: `/history/${sport.slug}`,
  };
}

function dynastyDebate(seed: number): DebateDraft {
  const sport = SPORT_HISTORY[(seed + 5) % SPORT_HISTORY.length]!;
  const dynasties = sport.dynasties;
  const a = dynasties[seed % dynasties.length]!;
  const b = dynasties[(seed + 1) % dynasties.length]!;
  if (a.name === b.name) return milestoneDebate(seed);
  return {
    question: `${sport.name} dynasties: ${a.name} or ${b.name}?`,
    context: `${a.name} — ${a.note} ${b.name} — ${b.note}`,
    sideA: a.name,
    sideB: b.name,
    league: sport.name,
    source: "history",
    link: `/history/${sport.slug}`,
  };
}

/**
 * One debate per calendar day, built only from curated reference data —
 * nothing here is invented at runtime.
 */
export function buildDebate(date: string): DebateDraft {
  const seed = daySeed(date);
  const pick = seed % 4;
  if (pick === 0) return rivalryDebate(seed);
  if (pick === 1) return hallOfFameDebate(seed);
  if (pick === 2) return dynastyDebate(seed);
  return milestoneDebate(seed);
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
