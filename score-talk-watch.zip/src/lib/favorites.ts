import { useCallback, useEffect, useState } from "react";
import type { LeagueId } from "@/data/sports";
import type { SportId } from "@/lib/individual-sports.functions";
import { supabase } from "@/integrations/supabase/client";

/** A club, or an athlete in an individual sport (golf, tennis, UFC…). */
export type FollowId = LeagueId | SportId;

export interface FavoriteTeam {
  league: FollowId;
  teamId: string;
  name: string;
  logo?: string | null;
}

const STORAGE_KEY = "sideline.favorites";
const EVENT = "sideline:favorites";

function read(): FavoriteTeam[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as FavoriteTeam[]) : [];
  } catch {
    return [];
  }
}

function write(list: FavoriteTeam[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch {
    /* storage unavailable */
  }
  window.dispatchEvent(new Event(EVENT));
}

function key(f: { league: string; teamId: string }) {
  return `${f.league}:${f.teamId}`;
}

/** Pull the account's followed teams and merge any device-only stars into it. */
async function syncFromAccount(userId: string): Promise<FavoriteTeam[] | null> {
  const { data, error } = await supabase
    .from("followed_teams")
    .select("league, team_id, name, logo")
    .eq("user_id", userId);
  if (error) return null;

  const remote: FavoriteTeam[] = (data ?? []).map((r) => ({
    league: r.league as FollowId,
    teamId: r.team_id,
    name: r.name,
    logo: r.logo,
  }));
  const remoteKeys = new Set(remote.map(key));
  const localOnly = read().filter((f) => !remoteKeys.has(key(f)));

  if (localOnly.length) {
    await supabase.from("followed_teams").insert(
      localOnly.map((f) => ({
        user_id: userId,
        league: f.league,
        team_id: f.teamId,
        name: f.name,
        logo: f.logo ?? null,
      })),
    );
  }
  return [...remote, ...localOnly];
}

export function useFavorites() {
  const [favorites, setFavorites] = useState<FavoriteTeam[]>([]);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const sync = () => setFavorites(read());
    sync();
    window.addEventListener(EVENT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVENT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  // Keep the list tied to the signed-in fan, so stars follow them across devices.
  useEffect(() => {
    let cancelled = false;
    const apply = async (id: string | null) => {
      setUserId(id);
      if (!id) return;
      const merged = await syncFromAccount(id);
      if (!cancelled && merged) write(merged);
    };
    void supabase.auth.getSession().then(({ data }) => apply(data.session?.user.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      void apply(session?.user.id ?? null);
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  const isFavorite = useCallback(
    (league: FollowId, teamId: string) =>
      favorites.some((f) => f.league === league && f.teamId === teamId),
    [favorites],
  );

  const toggle = useCallback(
    (team: FavoriteTeam) => {
      const current = read();
      const exists = current.some((f) => f.league === team.league && f.teamId === team.teamId);
      write(
        exists
          ? current.filter((f) => !(f.league === team.league && f.teamId === team.teamId))
          : [...current, team],
      );

      if (!userId) return;
      void (async () => {
        if (exists) {
          await supabase
            .from("followed_teams")
            .delete()
            .eq("user_id", userId)
            .eq("league", team.league)
            .eq("team_id", team.teamId);
        } else {
          await supabase.from("followed_teams").insert({
            user_id: userId,
            league: team.league,
            team_id: team.teamId,
            name: team.name,
            logo: team.logo ?? null,
          });
        }
      })();
    },
    [userId],
  );

  return { favorites, isFavorite, toggle, synced: Boolean(userId) };
}
