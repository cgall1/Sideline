import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";
import { safeEspnId } from "@/lib/espn-id";

export interface TeamGame {
  id: string;
  date: string;
  name: string;
  shortName: string;
  venue: string;
  broadcast: string;
  status: string;
  score: string;
  completed: boolean;
  week: string;
  link: string | null;
}

export interface TeamStory {
  id: string;
  headline: string;
  summary: string;
  url: string;
  published: string;
  image: string | null;
}

export interface TeamHub {
  league: LeagueId;
  teamId: string;
  team: string;
  abbr: string;
  logo: string | null;
  color: string | null;
  record: string;
  standing: string;
  venue: string;
  season: string;
  games: TeamGame[];
  news: TeamStory[];
}

const LEAGUE_IDS: LeagueId[] = [
  "nfl",
  "nba",
  "wnba",
  "nhl",
  "mlb",
  "mls",
  "intl",
  "cfb",
  "cbb",
  "chk",
  "nwsl",
  "sball",
  "vball",
];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/eng.1",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapGame(raw: any): TeamGame | null {
  const comp: any = Array.isArray(raw?.competitions) ? raw.competitions[0] : null;
  const name = str(raw?.name);
  if (!name) return null;
  const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
  const scored = competitors.filter((c) => str(c?.score?.displayValue, str(c?.score)));
  const score =
    scored.length === 2
      ? scored
          .map(
            (c) =>
              `${str(c?.team?.abbreviation, str(c?.team?.displayName))} ${str(
                c?.score?.displayValue,
                str(c?.score),
              )}`,
          )
          .join(" – ")
      : "";
  const state = str(comp?.status?.type?.state, "pre");
  return {
    id: str(raw?.id, name),
    date: str(raw?.date),
    name,
    shortName: str(raw?.shortName, name),
    venue: str(comp?.venue?.fullName, "—"),
    broadcast: str(
      (Array.isArray(comp?.broadcasts) ? comp.broadcasts : [])
        .flatMap((b: any) => (Array.isArray(b?.media?.shortName) ? b.media.shortName : [b?.media?.shortName]))
        .filter(Boolean)
        .join(", "),
      "—",
    ),
    status: str(comp?.status?.type?.shortDetail, str(comp?.status?.type?.description, "Scheduled")),
    score,
    completed: state === "post",
    week: str(raw?.week?.text, ""),
    link:
      str(
        (Array.isArray(raw?.links) ? raw.links : []).find((l: any) => typeof l?.href === "string")
          ?.href,
      ) || null,
  };
}

async function getJSON(url: string): Promise<any | null> {
  try {
    const res = await fetch(url, { headers: { accept: "application/json" } });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

/** Everything for one team's hub page: record, schedule and news. */
export const fetchTeamHub = createServerFn({ method: "GET" })
  .inputValidator((input: { league: string; teamId: string }) => ({
    league: String(input?.league ?? ""),
    teamId: safeEspnId(input?.teamId),
  }))
  .handler(async ({ data }): Promise<TeamHub> => {
    const league = asLeague(data.league);
    const path = ESPN_PATH[league];
    const teamId = data.teamId;

    const [schedule, news, info] = teamId
      ? await Promise.all([
          getJSON(`https://site.api.espn.com/apis/site/v2/sports/${path}/teams/${teamId}/schedule`),
          getJSON(`https://site.api.espn.com/apis/site/v2/sports/${path}/news?limit=30&team=${teamId}`),
          getJSON(`https://site.api.espn.com/apis/site/v2/sports/${path}/teams/${teamId}`),
        ])
      : [null, null, null];


    const team = schedule?.team ?? info?.team ?? {};
    const events: any[] = Array.isArray(schedule?.events) ? schedule.events : [];
    const games = events
      .map(mapGame)
      .filter((g): g is TeamGame => Boolean(g))
      .sort((a, b) => a.date.localeCompare(b.date));

    const articles: any[] = Array.isArray(news?.articles) ? news.articles : [];
    const stories: TeamStory[] = articles
      .map((a): TeamStory | null => {
        const headline = str(a?.headline);
        const url = str(a?.links?.web?.href, str(a?.links?.mobile?.href));
        if (!headline || !url) return null;
        return {
          id: str(a?.id, headline),
          headline,
          summary: str(a?.description),
          url,
          published: str(a?.published),
          image:
            str((Array.isArray(a?.images) ? a.images : []).find((i: any) => i?.url)?.url) || null,
        };
      })
      .filter((s): s is TeamStory => Boolean(s))
      .slice(0, 12);

    const record =
      str(team?.recordSummary) ||
      str(
        (Array.isArray(team?.record?.items) ? team.record.items : [])[0]?.summary,
        "—",
      );

    return {
      league,
      teamId: data.teamId,
      team: str(team?.displayName, "Team"),
      abbr: str(team?.abbreviation, ""),
      logo: str(team?.logo, str((Array.isArray(team?.logos) ? team.logos : [])[0]?.href)) || null,
      color: str(team?.color) || null,
      record,
      standing: str(team?.standingSummary, ""),
      venue: str(team?.franchise?.venue?.fullName, ""),
      season: str(schedule?.season?.displayName, ""),
      games,
      news: stories,
    };
  });
