import { createServerFn } from "@tanstack/react-start";

export interface F1StandingRow {
  id: string;
  rank: number;
  name: string;
  detail: string;
  points: string;
  wins: string;
}

export interface F1Standings {
  season: number | null;
  drivers: F1StandingRow[];
  constructors: F1StandingRow[];
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function statValue(stats: any[], keys: string[]): string {
  for (const key of keys) {
    const hit = stats.find((s) => s?.name === key || s?.abbreviation === key || s?.shortDisplayName === key);
    const value = hit?.displayValue ?? hit?.value;
    if (value !== undefined && value !== null && `${value}`.length > 0) return `${value}`;
  }
  return "—";
}

function rows(group: any): F1StandingRow[] {
  const entries: any[] = group?.standings?.entries ?? [];
  return entries.map((entry, index) => {
    const stats: any[] = Array.isArray(entry?.stats) ? entry.stats : [];
    const subject = entry?.athlete ?? entry?.team ?? {};
    const rankValue = Number(statValue(stats, ["rank", "position"]).replace(/[^\d]/g, ""));
    return {
      id: `${subject?.id ?? index}`,
      rank: Number.isFinite(rankValue) && rankValue > 0 ? rankValue : index + 1,
      name: subject?.displayName ?? subject?.name ?? "Unknown",
      detail:
        subject?.team?.displayName ??
        entry?.team?.displayName ??
        subject?.flag?.alt ??
        subject?.shortName ??
        "",
      points: statValue(stats, ["points", "championshipPts", "PTS"]),
      wins: statValue(stats, ["wins", "W"]),
    };
  });
}

function pickGroup(children: any[], needle: string): any {
  return children.find((c) => `${c?.name ?? ""}`.toLowerCase().includes(needle));
}

/** Live Formula 1 driver and constructor championship standings from the public ESPN feed. */
export const fetchF1Standings = createServerFn({ method: "GET" }).handler(
  async (): Promise<F1Standings> => {
    const season = new Date().getUTCFullYear();
    const url = `https://site.web.api.espn.com/apis/v2/sports/racing/f1/standings?season=${season}`;
    try {
      const response = await fetch(url, { headers: { accept: "application/json" } });
      if (!response.ok) return { season: null, drivers: [], constructors: [] };
      const data: any = await response.json();
      const children: any[] = Array.isArray(data?.children) ? data.children : [];
      const driverGroup = pickGroup(children, "driver");
      const teamGroup = pickGroup(children, "constructor") ?? pickGroup(children, "team");
      return {
        season: driverGroup?.standings?.season ?? season,
        drivers: driverGroup ? rows(driverGroup) : [],
        constructors: teamGroup ? rows(teamGroup) : [],
      };
    } catch (error) {
      console.error("F1 standings fetch failed", error);
      return { season: null, drivers: [], constructors: [] };
    }
  },
);

export const f1StandingsQueryOptions = () => ({
  queryKey: ["f1", "standings"] as const,
  queryFn: () => fetchF1Standings(),
  staleTime: 5 * 60 * 1000,
});
