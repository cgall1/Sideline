import { createServerFn } from "@tanstack/react-start";

export interface LeaderRow {
  user_id: string;
  display_name: string;
  points: number;
  correct_picks: number;
  posts: number;
  upvotes: number;
  thread_posts: number;
}

/** Public Diehard leaderboard (last N days), optionally for fans of one team. */
export const getDiehardLeaderboard = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => {
    const x = (d ?? {}) as { team?: unknown; days?: unknown };
    const team = typeof x.team === "string" && x.team.length > 0 && x.team.length < 80 ? x.team : null;
    const days = typeof x.days === "number" && x.days >= 1 && x.days <= 365 ? Math.round(x.days) : 30;
    return { team, days };
  })
  .handler(async ({ data }): Promise<LeaderRow[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin.rpc("diehard_leaderboard" as never, {
      _team: data.team,
      _days: data.days,
    } as never);
    if (error) {
      console.error("leaderboard failed", error);
      return [];
    }
    return ((rows as unknown as LeaderRow[]) ?? []).map((r) => ({
      ...r,
      points: Number(r.points),
      correct_picks: Number(r.correct_picks),
      posts: Number(r.posts),
      upvotes: Number(r.upvotes),
      thread_posts: Number(r.thread_posts),
    }));
  });
