import { createServerFn } from "@tanstack/react-start";
import { getRequestHeaders } from "@tanstack/react-start/server";
import { z } from "zod";
import { LEAGUES } from "@/data/sports";

const VALID_LEAGUES = new Set<string>(LEAGUES.map((l) => l.id));

const inputSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(320),
  leagues: z.array(z.string()).max(LEAGUES.length).default([]),
});

/** Max signups allowed from one network address per hour. */
const SIGNUP_LIMIT_PER_HOUR = 5;

/** Hash the caller's network address so we never store raw IPs. */
async function hashIp(ip: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`sideline-signup:${ip}`));
  return Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

function callerIp(): string {
  const headers = getRequestHeaders();
  const forwarded = headers.get("x-forwarded-for") ?? headers.get("cf-connecting-ip") ?? "";
  return (forwarded.split(",")[0] ?? "").trim() || "unknown";
}

/**
 * Public newsletter signup — stores the fan's email and chosen leagues.
 * Throttled per network address so the form can't be used to send welcome
 * emails to long lists of strangers.
 */
export const subscribeToNewsletter = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }) => {
    const leagues = data.leagues.filter((id) => VALID_LEAGUES.has(id));
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Throttle: too many recent signups from this network address → silently
    // accept (same response, no record, no email) so abusers get no signal.
    const ipHash = await hashIp(callerIp());
    const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const { count } = await supabaseAdmin
      .from("newsletter_signup_attempts")
      .select("id", { count: "exact", head: true })
      .eq("ip_hash", ipHash)
      .gte("created_at", since);
    if ((count ?? 0) >= SIGNUP_LIMIT_PER_HOUR) return { ok: true as const };
    await supabaseAdmin.from("newsletter_signup_attempts").insert({ ip_hash: ipHash });

    // Only welcome fans who are new to the list.
    const { data: existing } = await supabaseAdmin
      .from("newsletter_subscribers")
      .select("email,leagues")
      .eq("email", data.email)
      .maybeSingle();

    // Anyone can type someone else's address, so a public signup never modifies
    // an existing subscriber's record — their choices stay exactly as they set
    // them. Changing preferences requires the one-click unsubscribe/manage link.
    if (!existing) {
      const { error } = await supabaseAdmin
        .from("newsletter_subscribers")
        .insert({ email: data.email, leagues });
      if (error) throw new Error(error.message);
    }

    if (!existing) {
      try {
        const { sendWelcomeEmail } = await import("@/lib/welcome-email.server");
        await sendWelcomeEmail(data.email, leagues);
      } catch {
        // Signing up must never fail because the welcome email couldn't send.
      }
    }

    // The response is identical whether or not the address was already on the
    // list, so a public caller cannot probe who is subscribed.
    return { ok: true as const };
  });
