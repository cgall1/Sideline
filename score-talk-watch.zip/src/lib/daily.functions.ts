import { createServerFn } from "@tanstack/react-start";

export interface DebateRow {
  id: string;
  debate_date: string;
  question: string;
  context: string;
  side_a: string;
  side_b: string;
  league: string | null;
  source: string;
  link: string | null;
}

/**
 * Makes sure today's debate exists, then returns the most recent ones.
 * Safe to call from any page — inserting twice is a no-op.
 */
export const ensureDailyDebates = createServerFn({ method: "GET" }).handler(
  async (): Promise<DebateRow[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { buildDebate, todayISO } = await import("@/lib/daily.server");

    const today = todayISO();
    const draft = buildDebate(today);

    const { error: insertError } = await supabaseAdmin
      .from("daily_debates")
      .upsert(
        {
          debate_date: today,
          question: draft.question,
          context: draft.context,
          side_a: draft.sideA,
          side_b: draft.sideB,
          league: draft.league,
          source: draft.source,
          link: draft.link,
        },
        { onConflict: "debate_date", ignoreDuplicates: true },
      );
    if (insertError) console.error("daily debate insert failed", insertError);

    const { data, error } = await supabaseAdmin
      .from("daily_debates")
      .select("id, debate_date, question, context, side_a, side_b, league, source, link")
      .order("debate_date", { ascending: false })
      .limit(30);
    if (error) {
      console.error("daily debate read failed", error);
      return [];
    }
    return (data ?? []) as DebateRow[];
  },
);
