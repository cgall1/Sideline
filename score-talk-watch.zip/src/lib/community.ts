import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchGameReactionCounts,
  fetchPollVoteCounts,
  fetchPostLikeCounts,
  fetchProfileNames,
} from "@/lib/community-counts.functions";

export interface ThreadPost {
  id: string;
  gameId: string;
  userId: string;
  author: string;
  team: string;
  body: string;
  createdAt: string;
  likes: number;
  likedByMe: boolean;
}

function minutesAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (diff < 1) return "just now";
  if (diff < 60) return `${diff}m ago`;
  if (diff < 1440) return `${Math.floor(diff / 60)}h ago`;
  return `${Math.floor(diff / 1440)}d ago`;
}

export const relativeTime = minutesAgo;

/**
 * Every saved game-thread post, with author names and like counts.
 * Like counts come from an anonymous aggregate; who liked what stays private
 * (each signed-in fan can only read their own likes).
 */
export const threadPostsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["community", "posts", userId ?? "anon"],
    queryFn: async (): Promise<ThreadPost[]> => {
      // Signed-out visitors read the conversation itself; author identity and
      // profile details are reserved for signed-in fans. Profiles are private
      // to their owner, so names are resolved by a trusted server lookup.
      const [postsRes, countsRes, mineRes] = await Promise.all([
        supabase
          .from("community_posts")
          .select("id, game_id, user_id, body, created_at")
          .order("created_at", { ascending: false })
          .limit(300),
        fetchPostLikeCounts(),
        userId
          ? supabase.from("post_likes").select("post_id").eq("user_id", userId)
          : Promise.resolve({ data: [] as { post_id: string }[], error: null }),
      ]);
      if (postsRes.error) throw postsRes.error;
      if (mineRes.error) throw mineRes.error;

      interface PostRow {
        id: string;
        game_id: string;
        user_id: string;
        body: string;
        created_at: string;
      }

      const rows = (postsRes.data ?? []) as PostRow[];

      const names = new Map<string, { display_name: string; favorite_team: string | null }>();
      if (userId) {
        const ids = [...new Set(rows.map((r) => r.user_id))];
        const profiles = await fetchProfileNames({ data: { ids } });
        for (const p of profiles) names.set(p.id, p);
      }

      const counts = new Map<string, number>(
        countsRes.map((r) => [r.post_id, r.likes]),
      );
      const mine = new Set((mineRes.data ?? []).map((r) => r.post_id));

      return rows.map((row) => ({
        id: row.id,
        gameId: row.game_id,
        userId: row.user_id,
        author: names.get(row.user_id)?.display_name ?? "Fan",
        team: names.get(row.user_id)?.favorite_team ?? "—",
        body: row.body,
        createdAt: row.created_at,
        likes: counts.get(row.id) ?? 0,
        likedByMe: mine.has(row.id),
      }));
    },
    refetchInterval: 20_000,
  });

/** Emoji reaction totals per game (anonymous), plus this fan's own pick. */
export const reactionsQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["community", "reactions", userId ?? "anon"],
    queryFn: async () => {
      const [countsRes, mineRes] = await Promise.all([
        fetchGameReactionCounts(),
        userId
          ? supabase.from("game_reactions").select("game_id, emoji").eq("user_id", userId)
          : Promise.resolve({ data: [] as { game_id: string; emoji: string }[], error: null }),
      ]);
      if (mineRes.error) throw mineRes.error;

      const totals: Record<string, Record<string, number>> = {};
      for (const row of countsRes) {
        const perGame = (totals[row.game_id] ??= {});
        perGame[row.emoji] = row.total;
      }
      const mine: Record<string, string> = {};
      for (const row of mineRes.data ?? []) mine[row.game_id] = row.emoji;
      return { totals, mine };
    },
    refetchInterval: 20_000,
  });

/** Poll tallies from real votes (anonymous), plus this fan's own choice. */
export const pollVotesQueryOptions = (userId: string | null) =>
  queryOptions({
    queryKey: ["community", "poll-votes", userId ?? "anon"],
    queryFn: async () => {
      const [countsRes, mineRes] = await Promise.all([
        fetchPollVoteCounts(),
        userId
          ? supabase.from("poll_votes").select("poll_id, option_id").eq("user_id", userId)
          : Promise.resolve({ data: [] as { poll_id: string; option_id: string }[], error: null }),
      ]);
      if (mineRes.error) throw mineRes.error;

      const totals: Record<string, Record<string, number>> = {};
      for (const row of countsRes) {
        const perPoll = (totals[row.poll_id] ??= {});
        perPoll[row.option_id] = row.total;
      }
      const mine: Record<string, string> = {};
      for (const row of mineRes.data ?? []) mine[row.poll_id] = row.option_id;
      return { totals, mine };
    },
    refetchInterval: 20_000,
  });

export async function createPost(userId: string, gameId: string, body: string) {
  const { error } = await supabase.from("community_posts").insert({ user_id: userId, game_id: gameId, body });
  if (error) throw error;
}

export async function deletePost(id: string) {
  const { error } = await supabase.from("community_posts").delete().eq("id", id);
  if (error) throw error;
}

export async function toggleLike(postId: string, userId: string, liked: boolean) {
  const { error } = liked
    ? await supabase.from("post_likes").delete().eq("post_id", postId).eq("user_id", userId)
    : await supabase.from("post_likes").insert({ post_id: postId, user_id: userId });
  if (error) throw error;
}

export async function setReaction(gameId: string, userId: string, emoji: string | null) {
  const { error } = emoji
    ? await supabase.from("game_reactions").upsert(
        { game_id: gameId, user_id: userId, emoji },
        { onConflict: "game_id,user_id" },
      )
    : await supabase.from("game_reactions").delete().eq("game_id", gameId).eq("user_id", userId);
  if (error) throw error;
}

export async function castVote(pollId: string, userId: string, optionId: string) {
  const { error } = await supabase
    .from("poll_votes")
    .upsert({ poll_id: pollId, user_id: userId, option_id: optionId }, { onConflict: "poll_id,user_id" });
  if (error) throw error;
}
