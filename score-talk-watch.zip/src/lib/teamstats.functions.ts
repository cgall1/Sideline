import { createServerFn } from "@tanstack/react-start";
import type { LeagueId } from "@/data/sports";

/* eslint-disable @typescript-eslint/no-explicit-any */

const LEAGUE_IDS: LeagueId[] = [
  "nfl",
  "nba",
  "wnba",
  "nhl",
  "mlb",
  "mls",
  "intl",
  "cfb",
  "cbb",
  "chk",
  "nwsl",
  "sball",
  "vball",
];

const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

export interface AdvancedTeamRow {
  team: string;
  abbr: string;
  games: number;
  wins: number;
  losses: number;
  /** Points / goals / runs / sets scored per game. */
  scoredAvg: string;
  /** Points allowed per game. */
  allowedAvg: string;
  /** Scoring margin per game (positive is good). */
  margin: string;
  homeRecord: string;
  awayRecord: string;
  /** Share of games decided by one score / one goal / one set. */
  closeGames: string;
}

export interface AdvancedStats {
  league: LeagueId;
  scoreLabel: string;
  window: string;
  rows: AdvancedTeamRow[];
}

const SCORE_LABEL: Record<LeagueId, string> = {
  nfl: "Points",
  nba: "Points",
  wnba: "Points",
  nhl: "Goals",
  mlb: "Runs",
  mls: "Goals",
  intl: "Goals",
  cfb: "Points",
  cbb: "Points",
  chk: "Goals",
  cbs: "Runs",
  nwsl: "Goals",
  sball: "Runs",
  vball: "Sets",
};

/** Margin under which a game counts as "close" for each sport. */
const CLOSE_MARGIN: Record<LeagueId, number> = {
  nfl: 8,
  nba: 6,
  wnba: 6,
  nhl: 1,
  mlb: 1,
  mls: 1,
  intl: 1,
  cfb: 8,
  cbb: 6,
  chk: 1,
  cbs: 1,
  nwsl: 1,
  sball: 1,
  vball: 1,
};

interface Tally {
  team: string;
  abbr: string;
  games: number;
  wins: number;
  losses: number;
  scored: number;
  allowed: number;
  homeW: number;
  homeL: number;
  awayW: number;
  awayL: number;
  close: number;
}

function compactDate(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

async function fetchDay(league: LeagueId, compact: string): Promise<any[]> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard?dates=${compact}&limit=300`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return [];
    const payload: any = await res.json();
    return Array.isArray(payload?.events) ? payload.events : [];
  } catch {
    return [];
  }
}

/**
 * Advanced team stats derived from every completed game in the recent window:
 * scoring for and against, margin, home/away splits and close-game share.
 * Built from the public scoreboard feed so it works for every league we cover.
 */
export const fetchAdvancedTeamStats = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }): Promise<AdvancedStats> => {
    const league = data.league;
    const days = Array.from({ length: 45 }, (_, i) => compactDate(-i));
    const batches = await Promise.allSettled(days.map((d) => fetchDay(league, d)));
    const events = batches.flatMap((b) => (b.status === "fulfilled" ? b.value : []));

    const tallies = new Map<string, Tally>();
    const bump = (
      id: string,
      team: string,
      abbr: string,
      scored: number,
      allowed: number,
      home: boolean,
      close: boolean,
    ) => {
      const t =
        tallies.get(id) ??
        ({
          team,
          abbr,
          games: 0,
          wins: 0,
          losses: 0,
          scored: 0,
          allowed: 0,
          homeW: 0,
          homeL: 0,
          awayW: 0,
          awayL: 0,
          close: 0,
        } satisfies Tally);
      const won = scored > allowed;
      t.games += 1;
      t.scored += scored;
      t.allowed += allowed;
      if (won) t.wins += 1;
      else if (scored < allowed) t.losses += 1;
      if (home) {
        if (won) t.homeW += 1;
        else t.homeL += 1;
      } else if (won) t.awayW += 1;
      else t.awayL += 1;
      if (close) t.close += 1;
      tallies.set(id, t);
    };

    const seen = new Set<string>();
    for (const event of events) {
      const comp = event?.competitions?.[0];
      if (!comp || comp?.status?.type?.completed !== true) continue;
      const eid = String(event?.id ?? "");
      if (eid && seen.has(eid)) continue;
      if (eid) seen.add(eid);
      const competitors: any[] = Array.isArray(comp.competitors) ? comp.competitors : [];
      const home = competitors.find((c) => c?.homeAway === "home");
      const away = competitors.find((c) => c?.homeAway === "away");
      if (!home || !away) continue;
      const hs = Number(home.score);
      const as = Number(away.score);
      if (!Number.isFinite(hs) || !Number.isFinite(as)) continue;
      const close = Math.abs(hs - as) <= CLOSE_MARGIN[league];
      const nameOf = (c: any) => String(c?.team?.displayName ?? c?.team?.name ?? "—");
      const abbrOf = (c: any) => String(c?.team?.abbreviation ?? "—");
      bump(String(home.team?.id ?? nameOf(home)), nameOf(home), abbrOf(home), hs, as, true, close);
      bump(String(away.team?.id ?? nameOf(away)), nameOf(away), abbrOf(away), as, hs, false, close);
    }

    const rows: AdvancedTeamRow[] = [...tallies.values()]
      .filter((t) => t.games > 0)
      .map((t) => ({
        team: t.team,
        abbr: t.abbr,
        games: t.games,
        wins: t.wins,
        losses: t.losses,
        scoredAvg: (t.scored / t.games).toFixed(1),
        allowedAvg: (t.allowed / t.games).toFixed(1),
        margin: ((t.scored - t.allowed) / t.games).toFixed(1),
        homeRecord: `${t.homeW}-${t.homeL}`,
        awayRecord: `${t.awayW}-${t.awayL}`,
        closeGames: `${Math.round((t.close / t.games) * 100)}%`,
      }))
      .sort((a, b) => Number(b.margin) - Number(a.margin));

    return {
      league,
      scoreLabel: SCORE_LABEL[league],
      window: "Last 45 days",
      rows,
    };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */
