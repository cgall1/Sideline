import { supabase } from "@/integrations/supabase/client";
import { getPushPublicKey } from "@/lib/push.functions";

const TOKEN_CACHE = "sideline-push";
const TOKEN_URL = "/__sideline-push-token";

function urlBase64ToUint8Array(base64: string): Uint8Array {
  const padded = (base64 + "=".repeat((4 - (base64.length % 4)) % 4))
    .replace(/-/g, "+")
    .replace(/_/g, "/");
  const raw = atob(padded);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) out[i] = raw.charCodeAt(i);
  return out;
}

function newToken(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

export function pushSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    typeof Notification !== "undefined"
  );
}

/**
 * Subscribe this device for background alerts: register the worker, ask the
 * browser for a push subscription, and store it against the signed-in fan.
 */
export async function subscribeToPush(userId: string): Promise<"ok" | "denied" | "unsupported"> {
  if (!pushSupported()) return "unsupported";
  const permission = await Notification.requestPermission();
  if (permission !== "granted") return "denied";

  const registration = await navigator.serviceWorker.register("/sw.js");
  await navigator.serviceWorker.ready;

  const { key } = await getPushPublicKey();
  if (!key) return "unsupported";

  const existing = await registration.pushManager.getSubscription();
  const subscription =
    existing ??
    (await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(key) as BufferSource,
    }));

  const token = newToken();
  const cache = await caches.open(TOKEN_CACHE);
  await cache.put(TOKEN_URL, new Response(token));

  const { error } = await supabase
    .from("push_subscriptions")
    .insert({ user_id: userId, endpoint: subscription.endpoint, token });
  if (error && !error.message.includes("duplicate")) {
    // An endpoint already registered for this fan is fine; refresh its token.
    await supabase.from("push_subscriptions").delete().eq("endpoint", subscription.endpoint);
    await supabase
      .from("push_subscriptions")
      .insert({ user_id: userId, endpoint: subscription.endpoint, token });
  }
  return "ok";
}

/** Stop background alerts on this device. */
export async function unsubscribeFromPush(): Promise<void> {
  if (!pushSupported()) return;
  const registration = await navigator.serviceWorker.getRegistration();
  const subscription = await registration?.pushManager.getSubscription();
  if (subscription) {
    await supabase.from("push_subscriptions").delete().eq("endpoint", subscription.endpoint);
    await subscription.unsubscribe();
  }
  const cache = await caches.open(TOKEN_CACHE);
  await cache.delete(TOKEN_URL);
}

export async function pushActive(): Promise<boolean> {
  if (!pushSupported() || Notification.permission !== "granted") return false;
  const registration = await navigator.serviceWorker.getRegistration();
  return Boolean(await registration?.pushManager.getSubscription());
}
