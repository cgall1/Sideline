/* eslint-disable @typescript-eslint/no-explicit-any */
import { LEAGUES, leagueById, type LeagueId } from "@/data/sports";

const ESPN_PATH: Record<string, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

export interface LeagueIssue {
  league: LeagueId;
  name: string;
  results: string[];
  upcoming: string[];
  headlines: Array<{ title: string; url: string }>;
}

function compactDate(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

async function fetchScoreboardDay(league: string, compact: string): Promise<string[]> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard?dates=${compact}&limit=200`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return [];
    const data: any = await res.json();
    const events: any[] = Array.isArray(data?.events) ? data.events : [];
    return events
      .map((e) => {
        const comp = e?.competitions?.[0];
        const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
        const home = competitors.find((c) => c?.homeAway === "home");
        const away = competitors.find((c) => c?.homeAway === "away");
        if (!home || !away) return null;
        const homeName = home?.team?.displayName ?? "Home";
        const awayName = away?.team?.displayName ?? "Away";
        const state = comp?.status?.type?.state;
        if (state === "post") {
          return `${awayName} ${away?.score ?? 0} – ${home?.score ?? 0} ${homeName} (final)`;
        }
        const date = typeof e?.date === "string" ? new Date(e.date) : null;
        const when = date
          ? date.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
          : "TBD";
        return `${awayName} at ${homeName} — ${when}`;
      })
      .filter((l): l is string => l !== null);
  } catch {
    return [];
  }
}

async function fetchHeadlines(league: string): Promise<Array<{ title: string; url: string }>> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/news?limit=10`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return [];
    const payload: any = await res.json();
    const articles: any[] = Array.isArray(payload?.articles) ? payload.articles : [];
    return articles
      .map((a) => {
        const url: string =
          typeof a?.links?.web?.href === "string"
            ? a.links.web.href
            : typeof a?.links?.mobile?.href === "string"
              ? a.links.mobile.href
              : "";
        const title: string = typeof a?.headline === "string" ? a.headline : "";
        return url && title ? { title, url } : null;
      })
      .filter((h): h is { title: string; url: string } => h !== null)
      .slice(0, 4);
  } catch {
    return [];
  }
}

/** Builds one league's weekly issue: last 7 days of results, next 7 days of games, top headlines. */
export async function buildLeagueIssue(league: LeagueId): Promise<LeagueIssue> {
  const pastDays = Array.from({ length: 7 }, (_, i) => compactDate(-(i + 1)));
  const nextDays = Array.from({ length: 7 }, (_, i) => compactDate(i));

  const [pastResults, nextResults, headlines] = await Promise.all([
    Promise.all(pastDays.map((d) => fetchScoreboardDay(league, d))),
    Promise.all(nextDays.map((d) => fetchScoreboardDay(league, d))),
    fetchHeadlines(league),
  ]);

  const results = pastResults.flat().filter((l) => l.includes("(final)")).slice(0, 12);
  const upcoming = nextResults.flat().filter((l) => !l.includes("(final)")).slice(0, 8);

  return {
    league,
    name: leagueById(league)?.name ?? league,
    results,
    upcoming,
    headlines,
  };
}

/** Every league id, for "all leagues" subscribers. */
export const ALL_LEAGUE_IDS = LEAGUES.map((l) => l.id) as LeagueId[];

export interface PickRecap {
  gameLabel: string;
  pick: string;
  correct: boolean;
}

export interface SubscriberRecap {
  picks: PickRecap[];
  correct: number;
  total: number;
  current: number;
  best: number;
}

/**
 * How each subscriber's predictions picks did over the past week.
 *
 * Subscribers are matched to their Sideline account through the email on their
 * alert preferences; fans without an account simply get no results section.
 */
export async function buildPickRecaps(emails: string[]): Promise<Map<string, SubscriberRecap>> {
  const out = new Map<string, SubscriberRecap>();
  if (!emails.length) return out;

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: prefs } = await supabaseAdmin
    .from("alert_preferences")
    .select("user_id,email")
    .in("email", emails);
  if (!prefs?.length) return out;

  const byUser = new Map<string, string>();
  for (const row of prefs) byUser.set(row.user_id, row.email);

  const since = new Date(Date.now() - 8 * 86_400_000).toISOString();
  const { data: rows } = await supabaseAdmin
    .from("predictions")
    .select("user_id,game_label,pick,correct,resolved,created_at")
    .in("user_id", [...byUser.keys()])
    .eq("resolved", true)
    .order("created_at", { ascending: true });
  if (!rows?.length) return out;

  for (const [userId, email] of byUser) {
    const mine = rows.filter((r) => r.user_id === userId);
    if (!mine.length) continue;

    let current = 0;
    let best = 0;
    for (const row of mine) {
      if (row.correct) {
        current += 1;
        best = Math.max(best, current);
      } else current = 0;
    }

    const week = mine.filter((r) => (r.created_at ?? "") >= since);
    out.set(email, {
      picks: week.map((r) => ({
        gameLabel: r.game_label,
        pick: r.pick,
        correct: !!r.correct,
      })),
      correct: week.filter((r) => r.correct).length,
      total: week.length,
      current,
      best,
    });
  }
  return out;
}
