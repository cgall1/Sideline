import { createServerFn } from "@tanstack/react-start";
import {
  GAMES,
  LEADERS,
  STANDINGS,
  type Game,
  type GameStatus,
  type LeagueId,
  type StandingRow,
} from "@/data/sports";

const LEAGUE_IDS: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

/** ESPN public scoreboard paths (no API key required). */
const ESPN_PATH: Record<LeagueId, string> = {
  nfl: "football/nfl",
  nba: "basketball/nba",
  wnba: "basketball/wnba",
  nhl: "hockey/nhl",
  mlb: "baseball/mlb",
  mls: "soccer/usa.1",
  intl: "soccer/uefa.champions",
  cfb: "football/college-football",
  cbb: "basketball/mens-college-basketball",
  chk: "hockey/mens-college-hockey",
  cbs: "baseball/college-baseball",
  nwsl: "soccer/usa.nwsl",
  sball: "baseball/college-softball",
  vball: "volleyball/womens-college-volleyball",
};

/** Leagues whose standings ESPN exposes in the shape we map below. */
const STANDINGS_SUPPORTED: LeagueId[] = ["nfl", "nba", "wnba", "nhl", "mlb", "mls", "intl", "cfb", "cbb", "chk", "cbs", "nwsl", "sball", "vball"];

/** Leagues ranked on points rather than win percentage. */
const POINTS_LEAGUES: LeagueId[] = ["nhl", "mls", "intl", "nwsl"];

// The Champions League (intl) publishes no season table — its standings are
// computed from real results in fetchDerivedSoccerTable below.

function asLeague(value: unknown): LeagueId {
  return LEAGUE_IDS.includes(value as LeagueId) ? (value as LeagueId) : "nfl";
}

function num(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

function statusFrom(state: unknown, completed: unknown): GameStatus {
  if (completed === true || state === "post") return "final";
  if (state === "in") return "live";
  return "scheduled";
}

function startLabel(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "TBD";
  return new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  }).format(date) + " ET";
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function mapEvent(event: any, league: LeagueId): Game | null {
  const comp = event?.competitions?.[0];
  if (!comp) return null;
  const competitors: any[] = Array.isArray(comp.competitors) ? comp.competitors : [];
  const homeC = competitors.find((c) => c?.homeAway === "home") ?? competitors[0];
  const awayC = competitors.find((c) => c?.homeAway === "away") ?? competitors[1];
  if (!homeC || !awayC) return null;

  const team = (c: any) => ({
    name: str(c?.team?.displayName, str(c?.team?.name, "TBD")),
    abbr: str(c?.team?.abbreviation, str(c?.team?.shortDisplayName, "—")).slice(0, 4),
    record: str(c?.records?.[0]?.summary, ""),
  });

  const status = statusFrom(comp?.status?.type?.state, comp?.status?.type?.completed);
  const broadcasters: string[] = Array.isArray(comp?.broadcasts)
    ? comp.broadcasts.flatMap((b: any) => (Array.isArray(b?.names) ? b.names : [])).slice(0, 3)
    : [];

  return {
    id: `${league}-${str(event?.id, Math.random().toString(36).slice(2))}`,
    league,
    home: team(homeC),
    away: team(awayC),
    homeScore: num(homeC?.score),
    awayScore: num(awayC?.score),
    status,
    clock:
      status === "live"
        ? str(comp?.status?.type?.shortDetail, "Live")
        : status === "final"
          ? "Final"
          : startLabel(str(event?.date)),
    venue: str(comp?.venue?.fullName, "TBD"),
    startLabel: startLabel(str(event?.date)),
    startISO: str(event?.date) || undefined,
    broadcasters,
    headline: str(comp?.notes?.[0]?.headline, str(event?.name, "")),
  };
}

async function fetchScoreboard(league: LeagueId, date?: string): Promise<Game[]> {
  const url = `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard${
    date ? `?dates=${date}&limit=200` : ""
  }`;
  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (!res.ok) throw new Error(`ESPN ${league} ${res.status}`);
  const data: any = await res.json();
  const events: any[] = Array.isArray(data?.events) ? data.events : [];
  return events.map((e) => mapEvent(e, league)).filter((g): g is Game => g !== null);
}

function compactDate(offsetDays: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10).replace(/-/g, "");
}

function compactMonth(offsetMonths: number): string {
  const d = new Date();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + offsetMonths);
  return `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}

async function fetchLeagueGames(league: LeagueId): Promise<Game[]> {
  const today = await fetchScoreboard(league);
  if (today.length > 0) return today;

  // Out of season (common for college leagues): show the next slate so threads stay open.
  const probes = [
    ...Array.from({ length: 7 }, (_, i) => compactDate(i + 1)),
    ...Array.from({ length: 9 }, (_, i) => compactMonth(i)),
  ];
  const results = await Promise.allSettled(
    probes.map((probe) => fetchScoreboard(league, probe)),
  );
  const next = results.find((r) => r.status === "fulfilled" && r.value.length > 0);
  return next && next.status === "fulfilled" ? next.value.slice(0, 12) : [];
}

/**
 * Paid-provider results are shared through a short server cache so page
 * traffic can't multiply paid requests: at most one call per league per minute.
 */
async function cachedProviderGames(
  league: LeagueId,
  fetcher: (l: LeagueId) => Promise<Game[] | null>,
): Promise<Game[] | null> {
  const key = `apisports:games:${league}`;
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("provider_cache")
      .select("body, fetched_at")
      .eq("cache_key", key)
      .maybeSingle();
    if (row && Date.now() - new Date(row.fetched_at).getTime() < 60_000) {
      return (row.body as unknown as Game[] | null) ?? null;
    }
    // Claim the refresh slot first so concurrent requests reuse the old copy.
    await supabaseAdmin
      .from("provider_cache")
      .upsert({ cache_key: key, body: (row?.body ?? null) as never, fetched_at: new Date().toISOString() });
    const games = await fetcher(league);
    await supabaseAdmin
      .from("provider_cache")
      .upsert({ cache_key: key, body: (games ?? []) as never, fetched_at: new Date().toISOString() });
    return games;
  } catch {
    return null;
  }
}

const ORDER: Record<GameStatus, number> = { live: 0, scheduled: 1, final: 2 };

/** Live scores for one league (or every league) straight from the ESPN feed. */
export const fetchLiveGames = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const league = (data as { league?: unknown } | undefined)?.league;
    return { league: league === "all" || league === undefined ? ("all" as const) : asLeague(league) };
  })
  .handler(async ({ data }): Promise<{ games: Game[]; live: boolean; updatedAt: string }> => {
    const leagues = data.league === "all" ? LEAGUE_IDS : [data.league];

    // Paid provider first (when a key is configured); the free feed backs it up.
    const { providerConfigured, providerGames } = await import("@/lib/apisports.server");
    const fromProvider = new Map<LeagueId, Game[]>();
    if (providerConfigured()) {
      const provided = await Promise.allSettled(
        leagues.map(async (l) => [l, await cachedProviderGames(l, providerGames)] as const),
      );
      for (const p of provided) {
        if (p.status === "fulfilled" && p.value[1] && p.value[1].length > 0) {
          fromProvider.set(p.value[0], p.value[1]);
        }
      }
    }

    const remaining = leagues.filter((l) => !fromProvider.has(l));
    const results = await Promise.allSettled(remaining.map(fetchLeagueGames));
    const games = [
      ...[...fromProvider.values()].flat(),
      ...results.flatMap((r) => (r.status === "fulfilled" ? r.value : [])),
    ];
    const ok =
      fromProvider.size > 0 || results.some((r) => r.status === "fulfilled" && r.value.length > 0);

    if (!ok) {
      // Feed unreachable or no fixtures today: keep the page populated.
      const fallback =
        data.league === "all" ? GAMES : GAMES.filter((g) => g.league === data.league);
      return { games: fallback, live: false, updatedAt: new Date().toISOString() };
    }

    games.sort((a, b) => ORDER[a.status] - ORDER[b.status]);
    return { games, live: true, updatedAt: new Date().toISOString() };
  });

/** Standings groups can nest (college football: FBS → conferences → entries). */
function collectEntries(node: any): any[] {
  if (!node) return [];
  const own: any[] = Array.isArray(node?.standings?.entries) ? node.standings.entries : [];
  const children: any[] = Array.isArray(node?.children) ? node.children : [];
  return [...own, ...children.flatMap(collectEntries)];
}

function mapStandings(data: any, league: LeagueId): { group: string; rows: StandingRow[] } | null {
  const entries: any[] = collectEntries(data);
  if (!entries.length) return null;

  const stat = (entry: any, name: string): any =>
    (Array.isArray(entry?.stats) ? entry.stats : []).find((s: any) => s?.name === name);

  const rows: StandingRow[] = entries.map((entry) => {
    // Some leagues (college football) only publish the "overall" W-L summary.
    const overall = str(stat(entry, "overall")?.displayValue, "");
    const parsed = /^(\d+)-(\d+)(?:-(\d+))?$/.exec(overall);
    const winsStat = stat(entry, "wins");
    const lossesStat = stat(entry, "losses");
    const wins = winsStat ? num(winsStat.value) : parsed ? Number(parsed[1]) : 0;
    const losses = lossesStat ? num(lossesStat.value) : parsed ? Number(parsed[2]) : 0;
    const otl = stat(entry, "otLosses");
    const points = stat(entry, "points");
    const pct = stat(entry, "winPercent");
    const played = wins + losses;
    const computedPct = played > 0 ? wins / played : 0;
    return {
      team: str(entry?.team?.displayName, "—"),
      w: wins,
      l: losses,
      ...(otl ? { otl: num(otl.value) } : {}),
      pct:
        POINTS_LEAGUES.includes(league) && points
          ? `${num(points.value)} PTS`
          : (pct ? num(pct.value) : computedPct).toFixed(3).replace(/^0/, ""),
      streak: str(stat(entry, "streak")?.displayValue, "—"),
    };
  });

  const byPoints = POINTS_LEAGUES.includes(league);
  rows.sort((a, b) => {
    const av = byPoints ? parseInt(a.pct) || 0 : parseFloat(a.pct) || 0;
    const bv = byPoints ? parseInt(b.pct) || 0 : parseFloat(b.pct) || 0;
    return bv - av;
  });

  return { group: byPoints ? "Points leaders" : "Overall", rows: rows.slice(0, 12) };
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * College polls (AP Top 25). Used when the conference standings feed has no
 * games played yet, so the table still shows real ranked teams and records.
 */
async function fetchPollTable(
  league: LeagueId,
): Promise<{ group: string; rows: StandingRow[] } | null> {
  try {
    const res = await fetch(
      `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/rankings`,
      { headers: { accept: "application/json" } },
    );
    if (!res.ok) return null;
    const payload: any = await res.json();
    const poll: any = (Array.isArray(payload?.rankings) ? payload.rankings : []).find(
      (r: any) => Array.isArray(r?.ranks) && r.ranks.length > 0,
    );
    if (!poll) return null;
    const rows: StandingRow[] = poll.ranks.slice(0, 25).map((rank: any) => {
      const record = str(rank?.recordSummary, "");
      const parsed = /^(\d+)-(\d+)/.exec(record);
      const w = parsed ? Number(parsed[1]) : 0;
      const l = parsed ? Number(parsed[2]) : 0;
      const played = w + l;
      return {
        team: str(
          [rank?.team?.location, rank?.team?.name].filter(Boolean).join(" "),
          str(rank?.team?.nickname, "—"),
        ),
        w,
        l,
        pct: (played > 0 ? w / played : 0).toFixed(3).replace(/^0/, ""),
        streak: `AP #${num(rank?.current)}`,
      };
    });
    if (!rows.length) return null;
    return { group: str(poll?.name, "AP Top 25"), rows: rows.slice(0, 12) };
  } catch {
    return null;
  }
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * The Champions League publishes no season standings table, so the
 * world-soccer table is computed from the competition's actual results.
 */
async function fetchDerivedSoccerTable(
  league: LeagueId,
): Promise<{ group: string; rows: StandingRow[] } | null> {
  // This competition rejects ranged date queries, so results are probed day by day.
  const days = Array.from({ length: 22 }, (_, i) => compactDate(i - 21));
  try {
    const pages = await Promise.allSettled(
      days.map(async (day) => {
        const res = await fetch(
          `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard?dates=${day}&limit=200`,
          { headers: { accept: "application/json" } },
        );
        if (!res.ok) throw new Error(`ESPN ${res.status}`);
        return (await res.json()) as any;
      }),
    );
    const events = pages.flatMap((p) =>
      p.status === "fulfilled" ? ((p.value?.events ?? []) as any[]) : [],
    );

    interface Row {
      team: string;
      w: number;
      d: number;
      l: number;
      gf: number;
      ga: number;
    }
    const table = new Map<string, Row>();
    const entry = (name: string): Row => {
      let row = table.get(name);
      if (!row) {
        row = { team: name, w: 0, d: 0, l: 0, gf: 0, ga: 0 };
        table.set(name, row);
      }
      return row;
    };

    let played = 0;
    for (const event of events) {
      const comp = event?.competitions?.[0];
      if (comp?.status?.type?.completed !== true) continue;
      const competitors: any[] = Array.isArray(comp?.competitors) ? comp.competitors : [];
      const home = competitors.find((c) => c?.homeAway === "home");
      const away = competitors.find((c) => c?.homeAway === "away");
      const homeName = str(home?.team?.displayName, "");
      const awayName = str(away?.team?.displayName, "");
      if (!homeName || !awayName) continue;
      played += 1;
      const hs = num(home?.score);
      const as = num(away?.score);
      entry(homeName).gf += hs;
      entry(homeName).ga += as;
      entry(awayName).gf += as;
      entry(awayName).ga += hs;
      if (hs > as) {
        entry(homeName).w += 1;
        entry(awayName).l += 1;
      } else if (hs < as) {
        entry(awayName).w += 1;
        entry(homeName).l += 1;
      } else {
        entry(homeName).d += 1;
        entry(awayName).d += 1;
      }
    }
    if (!played) return null;

    const rows: StandingRow[] = [...table.values()]
      .map((t) => ({ ...t, pts: t.w * 3 + t.d, gd: t.gf - t.ga }))
      .sort((a, b) => b.pts - a.pts || b.gd - a.gd || b.gf - a.gf || a.team.localeCompare(b.team))
      .slice(0, 12)
      .map((t): StandingRow => ({
        team: t.team,
        w: t.w,
        l: t.l,
        pct: `${t.pts} PTS`,
        streak: t.d > 0 ? `${t.d} drawn` : "—",
      }));
    return { group: "Champions League — from results", rows };
  } catch {
    return null;
  }
}
/* eslint-enable @typescript-eslint/no-explicit-any */

/** Live league table; falls back to the editorial table when the feed is unavailable. */
export const fetchLiveStandings = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => ({
    league: asLeague((data as { league?: unknown } | undefined)?.league),
  }))
  .handler(async ({ data }) => {
    const league = data.league;
    const leaders = LEADERS.filter((l) => l.league === league);

    // Paid provider first (when a key is configured); the free feed backs it up.
    const { providerConfigured, providerStandings } = await import("@/lib/apisports.server");
    if (providerConfigured()) {
      try {
        const provided = await providerStandings(league);
        if (provided && provided.rows.length > 0) return { ...provided, leaders, live: true };
      } catch {
        // fall through to the existing feeds
      }
    }

    // The Champions League has no published season table — compute it from results.
    if (league === "intl") {
      const derived = await fetchDerivedSoccerTable(league);
      if (derived) return { ...derived, leaders, live: true };
      return { ...STANDINGS[league], leaders, live: false };
    }

    if (STANDINGS_SUPPORTED.includes(league)) {
      let mapped: { group: string; rows: StandingRow[] } | null = null;
      try {
        const res = await fetch(
          `https://site.api.espn.com/apis/v2/sports/${ESPN_PATH[league]}/standings`,
          { headers: { accept: "application/json" } },
        );
        if (res.ok) mapped = mapStandings(await res.json(), league);
      } catch {
        // fall through to the poll table / editorial data
      }

      const hasPlayedGames = mapped?.rows.some((r) => r.w + r.l > 0) ?? false;
      if (mapped && hasPlayedGames) return { ...mapped, leaders, live: true };

      if (league === "cbb" || league === "cfb" || league === "sball" || league === "vball") {
        const poll = await fetchPollTable(league);
        if (poll) return { ...poll, leaders, live: true };
      }
      if (mapped) return { ...mapped, leaders, live: true };
    }

    return { ...STANDINGS[league], leaders, live: false };
  });

/* eslint-disable @typescript-eslint/no-explicit-any */
/** Games for a specific calendar day (YYYY-MM-DD) across every league. */
export const fetchGamesByDate = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = (data as { date?: unknown } | undefined)?.date;
    const date =
      typeof raw === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw)
        ? raw
        : new Date().toISOString().slice(0, 10);
    return { date };
  })
  .handler(async ({ data }): Promise<{ date: string; games: Game[] }> => {
    const compact = data.date.replace(/-/g, "");
    const results = await Promise.allSettled(
      LEAGUE_IDS.map(async (league) => {
        const res = await fetch(
          `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[league]}/scoreboard?dates=${compact}`,
          { headers: { accept: "application/json" } },
        );
        if (!res.ok) throw new Error(`ESPN ${league} ${res.status}`);
        const payload: any = await res.json();
        const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
        return events.map((e) => mapEvent(e, league)).filter((g): g is Game => g !== null);
      }),
    );
    const games = results.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
    games.sort((a, b) => ORDER[a.status] - ORDER[b.status]);
    return { date: data.date, games };
  });
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */
/** Games for one league on a specific calendar day (YYYY-MM-DD). */
export const fetchLeagueGamesByDate = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => {
    const raw = data as { league?: unknown; date?: unknown } | undefined;
    const date =
      typeof raw?.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(raw.date)
        ? raw.date
        : new Date().toISOString().slice(0, 10);
    return { league: asLeague(raw?.league), date };
  })
  .handler(async ({ data }): Promise<{ date: string; league: LeagueId; games: Game[] }> => {
    const compact = data.date.replace(/-/g, "");
    try {
      const res = await fetch(
        `https://site.api.espn.com/apis/site/v2/sports/${ESPN_PATH[data.league]}/scoreboard?dates=${compact}&limit=200`,
        { headers: { accept: "application/json" } },
      );
      if (!res.ok) throw new Error(`ESPN ${data.league} ${res.status}`);
      const payload: any = await res.json();
      const events: any[] = Array.isArray(payload?.events) ? payload.events : [];
      const games = events
        .map((e) => mapEvent(e, data.league))
        .filter((g): g is Game => g !== null)
        .sort((a, b) => ORDER[a.status] - ORDER[b.status]);
      return { date: data.date, league: data.league, games };
    } catch {
      return { date: data.date, league: data.league, games: [] };
    }
  });
/* eslint-enable @typescript-eslint/no-explicit-any */
