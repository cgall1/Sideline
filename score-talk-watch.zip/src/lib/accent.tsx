import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/** A fan-chosen colour scheme: a followed team's colours, or a preset palette. */
export interface AccentChoice {
  /** "team" when taken from a club, "preset" for one of the built-in palettes. */
  kind: "team" | "preset";
  /** Stable id: `${league}:${teamId}` for teams, the preset id otherwise. */
  id: string;
  label: string;
  /** Base colour as a hex string. */
  hex: string;
}

export interface AccentPreset {
  id: string;
  label: string;
  hex: string;
}

export const ACCENT_PRESETS: AccentPreset[] = [
  { id: "coral", label: "Coral Heat", hex: "#ff5a5f" },
  { id: "cyan", label: "Cyan Surge", hex: "#06b6d4" },
  { id: "pitch", label: "Pitch Green", hex: "#16a34a" },
  { id: "gold", label: "Gold Rush", hex: "#f59e0b" },
  { id: "royal", label: "Royal Blue", hex: "#2563eb" },
  { id: "hotpink", label: "Hot Pink", hex: "#db2777" },
];

const STORAGE_KEY = "sideline.accent";

interface AccentValue {
  accent: AccentChoice | null;
  setAccent: (choice: AccentChoice | null) => void;
}

const AccentContext = createContext<AccentValue>({ accent: null, setAccent: () => {} });

/* ---------- colour helpers ---------- */

function normalizeHex(input: string): string | null {
  const raw = input.trim().replace(/^#/, "");
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) return null;
  return `#${raw.toLowerCase()}`;
}

function toRgb(hex: string): [number, number, number] {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function toHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return `#${[clamp(r), clamp(g), clamp(b)].map((v) => v.toString(16).padStart(2, "0")).join("")}`;
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const l = (max + min) / 2;
  if (max === min) return [0, 0, l];
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h: number;
  if (max === rn) h = ((gn - bn) / d + (gn < bn ? 6 : 0)) / 6;
  else if (max === gn) h = ((bn - rn) / d + 2) / 6;
  else h = ((rn - gn) / d + 4) / 6;
  return [h, s, l];
}

function hslToHex(h: number, s: number, l: number): string {
  const hue = ((h % 1) + 1) % 1;
  if (s === 0) {
    const v = l * 255;
    return toHex(v, v, v);
  }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const channel = (t: number) => {
    let tt = t;
    if (tt < 0) tt += 1;
    if (tt > 1) tt -= 1;
    if (tt < 1 / 6) return p + (q - p) * 6 * tt;
    if (tt < 1 / 2) return q;
    if (tt < 2 / 3) return p + (q - p) * (2 / 3 - tt) * 6;
    return p;
  };
  return toHex(channel(hue + 1 / 3) * 255, channel(hue) * 255, channel(hue - 1 / 3) * 255);
}

/** Keep a club colour vivid and legible whether it started near-black or near-white. */
function brandColor(hex: string): string {
  const [r, g, b] = toRgb(hex);
  const [h, s, l] = rgbToHsl(r, g, b);
  const sat = Math.max(0.45, Math.min(0.95, s || 0.5));
  const light = Math.max(0.36, Math.min(0.6, l));
  return hslToHex(h, sat, light);
}

/** A complementary partner colour for highlights. */
function partnerColor(hex: string): string {
  const [r, g, b] = toRgb(hex);
  const [h, s, l] = rgbToHsl(r, g, b);
  return hslToHex(h + 0.42, Math.max(0.5, Math.min(0.92, s || 0.6)), Math.max(0.5, Math.min(0.66, l + 0.08)));
}

/** Black or white text, whichever reads better on the colour. */
function readableOn(hex: string): string {
  const [r, g, b] = toRgb(hex);
  const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return lum > 0.6 ? "#101018" : "#ffffff";
}

export function accentSwatches(hex: string): { base: string; partner: string } {
  const safe = normalizeHex(hex) ?? "#7c4dff";
  return { base: brandColor(safe), partner: partnerColor(brandColor(safe)) };
}

function apply(choice: AccentChoice | null) {
  const root = document.documentElement;
  if (!choice) {
    root.removeAttribute("data-accent");
    for (const v of ["--brand", "--brand-2", "--brand-fg", "--brand-2-fg"]) {
      root.style.removeProperty(v);
    }
    return;
  }
  const safe = normalizeHex(choice.hex) ?? "#7c4dff";
  const base = brandColor(safe);
  const partner = partnerColor(base);
  root.style.setProperty("--brand", base);
  root.style.setProperty("--brand-2", partner);
  root.style.setProperty("--brand-fg", readableOn(base));
  root.style.setProperty("--brand-2-fg", readableOn(partner));
  root.setAttribute("data-accent", "on");
}

export function AccentProvider({ children }: { children: ReactNode }) {
  const [accent, setState] = useState<AccentChoice | null>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as AccentChoice;
      if (parsed && typeof parsed.hex === "string") {
        setState(parsed);
        apply(parsed);
      }
    } catch {
      /* storage unavailable */
    }
  }, []);

  const setAccent = useCallback((choice: AccentChoice | null) => {
    setState(choice);
    apply(choice);
    try {
      if (choice) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(choice));
      else window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* storage unavailable */
    }
  }, []);

  const value = useMemo(() => ({ accent, setAccent }), [accent, setAccent]);
  return <AccentContext.Provider value={value}>{children}</AccentContext.Provider>;
}

export function useAccent() {
  return useContext(AccentContext);
}
