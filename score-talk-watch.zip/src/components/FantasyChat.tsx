import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  leagueId: string;
  /** Owner display names by auth user id, so the thread reads like a group chat. */
  names: Record<string, string>;
  userId: string;
}

interface Msg {
  id: string;
  user_id: string;
  body: string;
  created_at: string;
}

/** The league's trash-talk thread — members only, refreshed every few seconds. */
export function FantasyChat({ leagueId, names, userId }: Props) {
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  const { data: messages = [] } = useQuery({
    queryKey: ["fantasy", "chat", leagueId],
    queryFn: async (): Promise<Msg[]> => {
      const { data, error } = await supabase
        .from("fantasy_messages")
        .select("id,user_id,body,created_at")
        .eq("league_id", leagueId)
        .order("created_at", { ascending: true })
        .limit(200);
      if (error) throw new Error(error.message);
      return data ?? [];
    },
    refetchInterval: 8_000,
  });

  const send = useMutation({
    mutationFn: async (body: string) => {
      const { error } = await supabase
        .from("fantasy_messages")
        .insert({ league_id: leagueId, user_id: userId, body });
      if (error) throw new Error("Message didn't send — try again.");
    },
    onSuccess: () => {
      setDraft("");
      void queryClient.invalidateQueries({ queryKey: ["fantasy", "chat", leagueId] });
    },
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [messages.length]);

  return (
    <section className="mt-8">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">League chat</h2>
      <div className="mt-3 max-h-80 overflow-y-auto rounded-lg border border-border bg-card p-4">
        {messages.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No messages yet — start the trash talk.
          </p>
        ) : (
          <ul className="space-y-3">
            {messages.map((m) => (
              <li key={m.id} className="text-sm">
                <span className="font-semibold">
                  {names[m.user_id] ?? "Fan"}
                  {m.user_id === userId ? " (you)" : ""}
                </span>{" "}
                <span className="text-xs text-muted-foreground">
                  {new Date(m.created_at).toLocaleTimeString([], {
                    hour: "numeric",
                    minute: "2-digit",
                  })}
                </span>
                <p className="whitespace-pre-wrap break-words">{m.body}</p>
              </li>
            ))}
          </ul>
        )}
        <div ref={endRef} />
      </div>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const body = draft.trim();
          if (body) send.mutate(body);
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          maxLength={800}
          placeholder="Say something to the league…"
          className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm"
        />
        <button
          type="submit"
          disabled={send.isPending || draft.trim().length === 0}
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
        >
          Send
        </button>
      </form>
      {send.error && <p className="mt-1 text-sm text-destructive">{send.error.message}</p>}
    </section>
  );
}
