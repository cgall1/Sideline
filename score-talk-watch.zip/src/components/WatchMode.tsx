import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Game } from "@/data/sports";
import { cn } from "@/lib/utils";

const KEY = "sideline:watch-delay";
const MICRO = [
  { id: "cheer", emoji: "🙌", label: "Cheer" },
  { id: "facepalm", emoji: "🤦", label: "Facepalm" },
  { id: "ref", emoji: "😡", label: "Ref rage" },
  { id: "clutch", emoji: "🔥", label: "Clutch" },
] as const;

/** Spoiler-safe delay (seconds) stored on this device. 0 = off. */
export function useWatchDelay() {
  const [delay, setDelay] = useState(0);
  useEffect(() => {
    const v = Number(localStorage.getItem(KEY) ?? 0);
    if (v > 0 && v <= 120) setDelay(v);
  }, []);
  const update = (v: number) => {
    setDelay(v);
    localStorage.setItem(KEY, String(v));
  };
  return [delay, update] as const;
}

/** Returns the game as it looked `delaySec` ago, so scores match a delayed TV feed. */
export function useDelayedGame(game: Game, delaySec: number): Game {
  const history = useRef<{ t: number; g: Game }[]>([]);
  const [, tick] = useState(0);
  useEffect(() => {
    const h = history.current;
    const last = h[h.length - 1];
    if (!last || last.g.homeScore !== game.homeScore || last.g.awayScore !== game.awayScore || last.g.clock !== game.clock || last.g.status !== game.status) {
      h.push({ t: Date.now(), g: game });
      if (h.length > 200) h.shift();
    }
  }, [game]);
  useEffect(() => {
    if (!delaySec) return;
    const i = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(i);
  }, [delaySec]);
  if (!delaySec) return game;
  const cutoff = Date.now() - delaySec * 1000;
  const h = history.current;
  let shown = h[0]?.g ?? game;
  for (const s of h) if (s.t <= cutoff) shown = s.g;
  return shown;
}

interface Burst { key: number; emoji: string; left: number }

export function WatchMode({ gameId, live, delay, onDelay }: { gameId: string; live: boolean; delay: number; onDelay: (v: number) => void }) {
  const [bursts, setBursts] = useState<Burst[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const chan = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const delayRef = useRef(delay);
  delayRef.current = delay;

  const show = (id: string) => {
    const m = MICRO.find((x) => x.id === id);
    if (!m) return;
    const key = Date.now() + Math.random();
    setCounts((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
    setBursts((b) => [...b.slice(-20), { key, emoji: m.emoji, left: 10 + Math.random() * 80 }]);
    setTimeout(() => setBursts((b) => b.filter((x) => x.key !== key)), 1800);
  };

  useEffect(() => {
    const ch = supabase.channel(`watch-${gameId}`, { config: { broadcast: { self: false } } });
    ch.on("broadcast", { event: "react" }, ({ payload }) => {
      const id = String((payload as { id?: string }).id ?? "");
      // Hold other fans' reactions back by your delay so they don't spoil the play.
      setTimeout(() => show(id), delayRef.current * 1000);
    }).subscribe();
    chan.current = ch;
    return () => {
      void supabase.removeChannel(ch);
    };
  }, [gameId]);

  const react = (id: string) => {
    show(id);
    void chan.current?.send({ type: "broadcast", event: "react", payload: { id } });
  };

  return (
    <section className="relative mt-4 overflow-hidden rounded-md border border-border bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="scoreboard text-sm font-bold uppercase tracking-widest">Watch mode</h2>
        <span className="text-xs text-muted-foreground">{delay ? `Spoiler shield: ${delay}s behind live` : "Showing live"}</span>
      </div>
      <label className="mt-3 block text-xs text-muted-foreground">
        Match your TV delay — score, match thread and reactions wait this long
        <input
          type="range"
          min={0}
          max={90}
          step={5}
          value={delay}
          onChange={(e) => onDelay(Number(e.target.value))}
          className="mt-2 w-full accent-primary"
          aria-label="Broadcast delay in seconds"
        />
      </label>
      <div className="mt-3 flex flex-wrap gap-2">
        {MICRO.map((m) => (
          <button
            key={m.id}
            onClick={() => react(m.id)}
            disabled={!live}
            className={cn("rounded-full border border-border px-3 py-1.5 text-sm font-semibold hover:border-primary/50", !live && "opacity-50")}
          >
            <span aria-hidden className="mr-1">{m.emoji}</span>
            {m.label}
            {counts[m.id] ? <span className="scoreboard ml-1.5 tabular-nums text-muted-foreground">{counts[m.id]}</span> : null}
          </button>
        ))}
      </div>
      {!live && <p className="mt-2 text-xs text-muted-foreground">Live reactions open when the game starts.</p>}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        {bursts.map((b) => (
          <span key={b.key} className="watch-burst absolute bottom-2 text-2xl" style={{ left: `${b.left}%` }}>
            {b.emoji}
          </span>
        ))}
      </div>
    </section>
  );
}
