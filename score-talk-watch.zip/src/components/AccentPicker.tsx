import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ACCENT_PRESETS, accentSwatches, useAccent, type AccentChoice } from "@/lib/accent";
import { useFavorites } from "@/lib/favorites";
import { LEAGUES, type LeagueId } from "@/data/sports";
import { teamHubQueryOptions } from "@/lib/feed";

const LEAGUE_IDS = new Set<string>(LEAGUES.map((l) => l.id));

function Swatch({ hex, active }: { hex: string; active: boolean }) {
  const { base, partner } = accentSwatches(hex);
  return (
    <span
      aria-hidden
      className={`h-5 w-5 shrink-0 rounded-full border ${active ? "border-foreground" : "border-border"}`}
      style={{ background: `linear-gradient(135deg, ${base} 55%, ${partner} 55%)` }}
    />
  );
}

const optionClass =
  "scoreboard flex items-center gap-2 rounded-md border px-3 py-2 text-[11px] font-bold uppercase transition-colors";

/** Lets a fan wear a followed club's colours, or pick a preset palette. */
export function AccentPicker() {
  const { accent, setAccent } = useAccent();
  const { favorites } = useFavorites();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState<string | null>(null);
  const [failed, setFailed] = useState<string | null>(null);

  const clubs = favorites.filter((f) => LEAGUE_IDS.has(f.league));

  const pickTeam = async (league: LeagueId, teamId: string, name: string) => {
    const id = `${league}:${teamId}`;
    setLoading(id);
    setFailed(null);
    try {
      const hub = await queryClient.ensureQueryData(teamHubQueryOptions(league, teamId));
      if (!hub?.color) {
        setFailed(name);
        return;
      }
      const choice: AccentChoice = { kind: "team", id, label: name, hex: `#${hub.color.replace(/^#/, "")}` };
      setAccent(choice);
    } catch {
      setFailed(name);
    } finally {
      setLoading(null);
    }
  };

  return (
    <section className="rounded-lg border border-border bg-card p-5">
      <h2 className="scoreboard text-lg font-bold uppercase tracking-widest">Your colors</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Wear a club's colors across Sideline, or pick a palette you like. Saved on this device.
      </p>

      <h3 className="scoreboard mt-5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Your teams
      </h3>
      {clubs.length === 0 ? (
        <p className="mt-2 text-sm text-muted-foreground">
          Star a team anywhere on Sideline and its colors show up here.
        </p>
      ) : (
        <div className="mt-2 flex flex-wrap gap-2">
          {clubs.map((club) => {
            const id = `${club.league}:${club.teamId}`;
            const active = accent?.id === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => void pickTeam(club.league as LeagueId, club.teamId, club.name)}
                className={`${optionClass} ${
                  active ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:text-foreground"
                }`}
                aria-pressed={active}
              >
                {club.logo ? (
                  <img src={club.logo} alt="" aria-hidden className="h-5 w-5 object-contain" />
                ) : null}
                {club.name}
                {loading === id ? <span className="normal-case text-muted-foreground">…</span> : null}
              </button>
            );
          })}
        </div>
      )}
      {failed ? (
        <p className="mt-2 text-sm text-muted-foreground">
          We couldn't find official colors for {failed} — pick a palette below instead.
        </p>
      ) : null}

      <h3 className="scoreboard mt-5 text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Palettes
      </h3>
      <div className="mt-2 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setAccent(null)}
          aria-pressed={!accent}
          className={`${optionClass} ${
            !accent ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          Sideline default
        </button>
        {ACCENT_PRESETS.map((preset) => {
          const active = accent?.id === preset.id;
          return (
            <button
              key={preset.id}
              type="button"
              onClick={() => setAccent({ kind: "preset", id: preset.id, label: preset.label, hex: preset.hex })}
              aria-pressed={active}
              className={`${optionClass} ${
                active ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              <Swatch hex={preset.hex} active={active} />
              {preset.label}
            </button>
          );
        })}
      </div>
    </section>
  );
}
