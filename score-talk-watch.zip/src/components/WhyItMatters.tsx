import type { Game, LeagueId } from "@/data/sports";
import { useWhyItMatters, type WhyKind } from "@/lib/why";

const ICON: Record<WhyKind, string> = {
  standings: "📊",
  race: "🏁",
  next: "📅",
  player: "⭐",
  talk: "💬",
};

/** Plain-English context under a result: what it changed and what comes next. */
export function WhyItMatters({ league, game }: { league: LeagueId; game: Game }) {
  const { lines, loading } = useWhyItMatters(league, game);

  if (loading) {
    return (
      <section className="mt-4 rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">
        Working out what this result means…
      </section>
    );
  }
  if (!lines.length) return null;

  return (
    <section className="mt-4 rounded-md border border-primary/40 bg-card p-5">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-primary">
        Why it matters
      </h2>
      <ul className="mt-3 space-y-2">
        {lines.map((l, i) => (
          <li key={i} className="flex gap-2 text-sm leading-relaxed">
            <span aria-hidden="true">{ICON[l.kind]}</span>
            <span>{l.text}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
