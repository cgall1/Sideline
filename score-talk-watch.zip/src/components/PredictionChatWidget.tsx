import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { leagueById } from "@/data/sports";
import {
  deletePredictionChat,
  predictionChatQueryOptions,
  sendPredictionChat,
} from "@/lib/prediction-chat";

/**
 * Compact fans-only picks chat for a league hub.
 *
 * Reads are restricted to signed-in fans, so visitors see a sign-in prompt
 * rather than the conversation.
 */
export function PredictionChatWidget({ league }: { league: string }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: messages = [] } = useQuery(predictionChatQueryOptions(league, !!user));
  const name = leagueById(league)?.name ?? league.toUpperCase();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user || !body.trim() || busy) return;
    setBusy(true);
    try {
      await sendPredictionChat(user.id, league, body.trim().slice(0, 1000));
      setBody("");
      await queryClient.invalidateQueries({ queryKey: ["prediction-chat", league] });
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    await deletePredictionChat(id);
    await queryClient.invalidateQueries({ queryKey: ["prediction-chat", league] });
  }

  return (
    <section className="mt-12 rounded-md border border-border bg-card p-5">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
        {name} picks chat
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Fans-only room — talk through your {name} picks, streaks and results. Not visible on the
        public game threads.
      </p>

      {!user ? (
        <p className="mt-4 text-sm">
          <Link to="/auth" className="text-primary underline">
            Sign in
          </Link>{" "}
          to read and join this room.
        </p>
      ) : (
        <>
          <form onSubmit={submit} className="mt-4 flex gap-2">
            <input
              value={body}
              onChange={(e) => setBody(e.target.value)}
              maxLength={1000}
              placeholder={`Your ${name} picks…`}
              className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm"
              aria-label={`Your ${name} picks message`}
            />
            <button
              type="submit"
              disabled={busy || !body.trim()}
              className="rounded-md bg-primary px-4 py-2 text-xs font-semibold uppercase tracking-widest text-primary-foreground disabled:opacity-50"
            >
              Post
            </button>
          </form>

          <ul className="mt-4 space-y-3">
            {messages.length === 0 && (
              <li className="text-sm text-muted-foreground">
                No messages yet — start the conversation.
              </li>
            )}
            {messages.slice(0, 15).map((m) => (
              <li key={m.id} className="rounded-md border border-border/60 p-3 text-sm">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold uppercase tracking-widest">{m.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(m.createdAt).toLocaleString()}
                  </span>
                </div>
                <p className="mt-2 whitespace-pre-wrap">{m.body}</p>
                {m.userId === user.id && (
                  <button
                    type="button"
                    onClick={() => void remove(m.id)}
                    className="mt-2 text-xs uppercase tracking-widest text-muted-foreground underline"
                  >
                    Delete
                  </button>
                )}
              </li>
            ))}
          </ul>
        </>
      )}

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/predictions-chat" className="text-primary underline">
          All league rooms
        </Link>
        <Link to="/my-picks" className="text-primary underline">
          My results
        </Link>
      </div>
    </section>
  );
}
