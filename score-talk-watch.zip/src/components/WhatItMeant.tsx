import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import type { Game, LeagueId } from "@/data/sports";
import { raceRule } from "@/data/why";
import { standingsQueryOptions } from "@/lib/feed";

function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
}

function same(a: string, b: string): boolean {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  if (x === y) return true;
  const nick = y.split(" ").slice(-1)[0] ?? "";
  return nick.length > 3 && x.includes(nick);
}

function Line({ game, teamName }: { game: Game; teamName: string }) {
  const league = game.league as LeagueId;
  const { data: standings } = useQuery(standingsQueryOptions(league));
  const rows = standings?.rows ?? [];
  const idx = rows.findIndex((r) => same(r.team, teamName));
  const won =
    game.homeScore === game.awayScore
      ? null
      : (game.homeScore > game.awayScore ? game.home.name : game.away.name) === teamName;

  const rule = raceRule(league);
  const row = idx >= 0 ? rows[idx] : undefined;
  const text = row
    ? `${teamName} ${won === null ? "drew" : won ? "won" : "lost"} and sit ${ordinal(idx + 1)} at ${row.w}-${row.l}${
        row.otl ? `-${row.otl}` : ""
      } — ${idx + 1 <= rule.cut ? `inside ${rule.cutLabel}` : `outside ${rule.cutLabel}`}.`
    : `${teamName} ${won === null ? "drew" : won ? "won" : "lost"} ${game.away.abbr} ${game.awayScore}–${game.homeScore} ${game.home.abbr}.`;

  return (
    <li className="text-sm leading-relaxed">
      {text}{" "}
      <Link
        to="/game/$league/$gameId"
        params={{ league, gameId: game.id }}
        className="font-semibold text-primary underline"
      >
        Why it matters
      </Link>
    </li>
  );
}

/** What the latest finished results mean for the fan's followed teams. */
export function WhatItMeant({ games, names }: { games: Game[]; names: string[] }) {
  const done = games
    .filter((g) => g.status !== "live" && g.status !== "scheduled")
    .slice(0, 3)
    .map((g) => {
      const mine = [g.home.name, g.away.name].find((n) =>
        names.includes(n.toLowerCase()),
      );
      return mine ? { game: g, team: mine } : null;
    })
    .filter((x): x is { game: Game; team: string } => x !== null);

  if (!done.length) return null;

  return (
    <section className="mt-6 border border-primary/40 bg-card p-5">
      <p className="text-[10px] font-bold uppercase text-primary">
        What that meant for your teams
      </p>
      <ul className="mt-3 space-y-2">
        {done.map((d) => (
          <Line key={d.game.id} game={d.game} teamName={d.team} />
        ))}
      </ul>
    </section>
  );
}
