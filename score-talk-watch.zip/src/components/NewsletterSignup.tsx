import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { LEAGUES } from "@/data/sports";
import { subscribeToNewsletter } from "@/lib/newsletter.functions";

/**
 * Newsletter signup card — fans enter an email and pick leagues.
 * Sends once the sender domain is set up; signups are stored right away.
 */
export function NewsletterSignup({ defaultLeague }: { defaultLeague?: string }) {
  const subscribe = useServerFn(subscribeToNewsletter);
  const [email, setEmail] = useState("");
  const [leagues, setLeagues] = useState<string[]>(defaultLeague ? [defaultLeague] : []);
  const [state, setState] = useState<"idle" | "busy" | "done" | "error">("idle");

  const toggle = (id: string) =>
    setLeagues((cur) => (cur.includes(id) ? cur.filter((l) => l !== id) : [...cur, id]));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || state === "busy") return;
    setState("busy");
    try {
      await subscribe({ data: { email: email.trim(), leagues } });
      setState("done");
    } catch {
      setState("error");
    }
  }

  if (state === "done") {
    return (
      <section className="rounded-md border border-border bg-card p-5">
        <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">You're on the list</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          We'll email your weekly recap every Monday morning as soon as sending is switched on.
          Every email has a one-click unsubscribe.
        </p>
      </section>
    );
  }

  return (
    <section className="rounded-md border border-border bg-card p-5">
      <h2 className="scoreboard text-xl font-bold uppercase tracking-wide">
        Get the weekly recap by email
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Every Monday: the week's results, the headlines that mattered and the games coming up —
        for the leagues you pick.
      </p>
      <form onSubmit={submit} className="mt-4 space-y-3">
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
          aria-label="Email address"
        />
        <div className="flex flex-wrap gap-2">
          {LEAGUES.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => toggle(l.id)}
              className={`rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-widest ${
                leagues.includes(l.id)
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border text-muted-foreground"
              }`}
            >
              {l.short}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          {leagues.length === 0 ? "No leagues picked — you'll get every league." : ""}
        </p>
        {state === "error" && (
          <p className="text-xs text-destructive">Something went wrong — please try again.</p>
        )}
        <button
          type="submit"
          disabled={state === "busy"}
          className="rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
        >
          {state === "busy" ? "Joining…" : "Join the newsletter"}
        </button>
      </form>
    </section>
  );
}
