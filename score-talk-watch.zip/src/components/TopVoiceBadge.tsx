import { useQuery } from "@tanstack/react-query";
import { getDiehardLeaderboard } from "@/lib/leaderboard.functions";

/** Top 3 fans on the 30-day Diehard leaderboard wear the Top Voice flair. */
export function useTopVoices() {
  const { data } = useQuery({
    queryKey: ["top-voices"],
    queryFn: () => getDiehardLeaderboard({ data: { days: 30 } }),
    staleTime: 10 * 60 * 1000,
  });
  return new Set((data ?? []).slice(0, 3).filter((r) => r.points > 0).map((r) => r.user_id));
}

export function TopVoiceBadge({ userId, voices }: { userId?: string | null; voices: Set<string> }) {
  if (!userId || !voices.has(userId)) return null;
  return (
    <span className="ml-1.5 rounded-sm bg-primary px-1.5 py-0.5 align-middle text-[10px] font-bold uppercase text-primary-foreground">
      Top Voice
    </span>
  );
}
