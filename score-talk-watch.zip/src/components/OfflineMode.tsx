import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

const KEY = "sideline.offline-cache.v1";
const KEEP = ["games", "articles", "followed-teams", "favorites"];

/**
 * Saves the last-seen scores, headlines and followed teams on the device,
 * restores them when the connection drops, and shows an offline banner.
 */
export function OfflineMode() {
  const qc = useQueryClient();
  const [offline, setOffline] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  useEffect(() => {
    const restore = () => {
      try {
        const raw = localStorage.getItem(KEY);
        if (!raw) return;
        const snap = JSON.parse(raw) as { at: number; entries: { key: unknown[]; data: unknown }[] };
        setSavedAt(snap.at);
        for (const e of snap.entries) if (qc.getQueryData(e.key) === undefined) qc.setQueryData(e.key, e.data);
      } catch { /* ignore */ }
    };
    const save = () => {
      if (!navigator.onLine) return;
      try {
        const entries = qc.getQueryCache().getAll()
          .filter((q) => q.state.status === "success" && KEEP.some((k) => String(q.queryKey[0]).includes(k)))
          .map((q) => ({ key: q.queryKey as unknown[], data: q.state.data }));
        if (entries.length) localStorage.setItem(KEY, JSON.stringify({ at: Date.now(), entries }));
      } catch { /* storage full — skip */ }
    };
    const update = () => {
      setOffline(!navigator.onLine);
      if (!navigator.onLine) restore();
    };
    update();
    const timer = window.setInterval(save, 30_000);
    const t0 = window.setTimeout(save, 5_000);
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    window.addEventListener("pagehide", save);
    return () => {
      window.clearInterval(timer);
      window.clearTimeout(t0);
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
      window.removeEventListener("pagehide", save);
    };
  }, [qc]);

  if (!offline) return null;
  return (
    <div role="status" className="fixed inset-x-0 top-0 z-[60] bg-secondary px-3 py-1.5 text-center text-xs font-semibold text-secondary-foreground">
      You're offline — showing last-seen scores{savedAt ? ` from ${new Date(savedAt).toLocaleTimeString()}` : ""}. Everything refreshes when you're back.
    </div>
  );
}
