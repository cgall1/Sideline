import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { displayNameOf } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

const input = "rounded-md border border-border bg-background px-3 py-2 text-sm";
const STATUSES = [
  { id: "going", label: "Going" },
  { id: "maybe", label: "Maybe" },
  { id: "no", label: "Can't make it" },
] as const;

/** Crew watch parties with RSVPs and a map link. */
export function WatchParties({ crewId, user }: { crewId: string; user: User }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ title: "", game_label: "", venue: "", address: "", starts_at: "" });
  const [err, setErr] = useState("");

  const { data: parties = [] } = useQuery({
    queryKey: ["parties", crewId],
    queryFn: async () => {
      const since = new Date(Date.now() - 6 * 3600_000).toISOString();
      const { data } = await supabase
        .from("watch_parties")
        .select("id, title, game_label, venue, address, starts_at, created_by, watch_party_rsvps(user_id, display_name, status)")
        .eq("crew_id", crewId)
        .gte("starts_at", since)
        .order("starts_at");
      return data ?? [];
    },
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["parties", crewId] });

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    if (!f.title.trim() || !f.venue.trim() || !f.starts_at) return setErr("Add a title, place and start time.");
    const { error } = await supabase.from("watch_parties").insert({
      crew_id: crewId,
      created_by: user.id,
      title: f.title.trim(),
      game_label: f.game_label.trim(),
      venue: f.venue.trim(),
      address: f.address.trim(),
      starts_at: new Date(f.starts_at).toISOString(),
    });
    if (error) return setErr("Couldn't create the watch party.");
    setF({ title: "", game_label: "", venue: "", address: "", starts_at: "" });
    setOpen(false);
    refresh();
  }

  async function rsvp(partyId: string, status: string) {
    await supabase.from("watch_party_rsvps").upsert({ party_id: partyId, user_id: user.id, display_name: displayNameOf(user), status });
    refresh();
  }

  return (
    <section className="mt-6 rounded-lg border border-border p-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="scoreboard text-sm font-bold uppercase tracking-widest">Watch parties</h2>
        <button onClick={() => setOpen((o) => !o)} className="text-xs font-bold text-primary underline">
          {open ? "Cancel" : "Plan one"}
        </button>
      </div>

      {open && (
        <form onSubmit={create} className="mt-3 grid gap-2 sm:grid-cols-2">
          <input className={input} placeholder="Title (e.g. Derby day)" maxLength={100} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className={input} placeholder="Game (optional)" maxLength={120} value={f.game_label} onChange={(e) => setF({ ...f, game_label: e.target.value })} />
          <input className={input} placeholder="Where (bar, someone's place…)" maxLength={100} value={f.venue} onChange={(e) => setF({ ...f, venue: e.target.value })} />
          <input className={input} placeholder="Address (optional)" maxLength={160} value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
          <input type="datetime-local" className={`${input} sm:col-span-2`} value={f.starts_at} onChange={(e) => setF({ ...f, starts_at: e.target.value })} />
          {err && <p className="text-sm text-destructive sm:col-span-2">{err}</p>}
          <button className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground sm:col-span-2">Create watch party</button>
        </form>
      )}

      <ul className="mt-3 space-y-3">
        {parties.length === 0 && !open && <li className="text-sm text-muted-foreground">No upcoming watch parties. Plan one for the next big game.</li>}
        {parties.map((p) => {
          const rs = p.watch_party_rsvps ?? [];
          const mine = rs.find((r) => r.user_id === user.id)?.status;
          const going = rs.filter((r) => r.status === "going");
          return (
            <li key={p.id} className="rounded-md border border-border bg-card p-3">
              <p className="font-semibold">{p.title}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(p.starts_at).toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                {p.game_label && ` · ${p.game_label}`}
              </p>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${p.venue} ${p.address}`)}`}
                target="_blank"
                rel="noreferrer"
                className="text-sm underline"
              >
                {p.venue}{p.address && `, ${p.address}`}
              </a>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {STATUSES.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => rsvp(p.id, s.id)}
                    className={cn("rounded-sm border px-2 py-0.5 text-xs font-semibold", mine === s.id ? "border-foreground bg-foreground text-background" : "border-border text-muted-foreground")}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {going.length} going{going.length ? `: ${going.map((r) => r.display_name).join(", ")}` : ""}
              </p>
              {p.created_by === user.id && (
                <button
                  onClick={async () => {
                    await supabase.from("watch_parties").delete().eq("id", p.id);
                    refresh();
                  }}
                  className="mt-1 text-xs text-muted-foreground underline"
                >
                  Cancel party
                </button>
              )}
            </li>
          );
        })}
      </ul>
      <p className="mt-3 text-xs text-muted-foreground">
        After the game, share your photos in the <a href="/fan-gallery" className="underline">Fan Gallery</a>. Need a spot? Browse <a href="/fan-spots" className="underline">fan bars</a>.
      </p>
    </section>
  );
}
