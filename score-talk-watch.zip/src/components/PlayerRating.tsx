import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { castVote, pollVotesQueryOptions } from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

interface Props {
  league: string;
  playerId: string;
  playerName: string;
  signInNext: string;
}

const SCORES = ["1", "2", "3", "4", "5"];

/** Fan rating out of 5 for a player's current form, tallied from real votes. */
export function PlayerRating({ league, playerId, playerName, signInNext }: Props) {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const queryClient = useQueryClient();
  const { data } = useQuery(pollVotesQueryOptions(userId));

  const pollId = `player:${league}:${playerId}:rating`;
  const tallies = data?.totals[pollId] ?? {};
  const mine = data?.mine[pollId];
  const votes = SCORES.reduce((acc, s) => acc + (tallies[s] ?? 0), 0);
  const average =
    votes > 0
      ? SCORES.reduce((acc, s) => acc + Number(s) * (tallies[s] ?? 0), 0) / votes
      : 0;

  return (
    <section className="mt-8 rounded-md border border-border bg-card p-5">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Fan rating</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        How is {playerName} playing right now? Rate 1 to 5 — the average updates live.
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        {SCORES.map((s) => (
          <button
            key={s}
            disabled={!userId}
            onClick={async () => {
              if (!userId) return;
              await castVote(pollId, userId, s);
              await queryClient.invalidateQueries({ queryKey: ["community", "poll-votes"] });
            }}
            aria-pressed={mine === s}
            className={cn(
              "scoreboard h-10 w-10 rounded-sm border text-sm font-bold transition-colors disabled:opacity-60",
              mine === s ? "border-primary bg-primary/15" : "border-border hover:border-primary/50",
            )}
          >
            {s}
          </button>
        ))}
        <span className="scoreboard ml-2 text-lg font-bold tabular-nums">
          {votes ? `${average.toFixed(1)} / 5` : "No ratings yet"}
        </span>
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {votes} rating{votes === 1 ? "" : "s"}.{" "}
        {!userId && (
          <Link to="/auth" search={{ next: signInNext }} className="font-semibold text-primary">
            Sign in to rate
          </Link>
        )}
      </p>
    </section>
  );
}
