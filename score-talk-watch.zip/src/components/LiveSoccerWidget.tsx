import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { liveSoccerQueryOptions } from "@/lib/feed";

/**
 * Compact live-score board for hub pages: ongoing matches first, with score,
 * minute and goalscorers, refreshing on its own every 30 seconds.
 */
export function LiveSoccerWidget({ limit = 8 }: { limit?: number }) {
  const { data, isFetching, refetch, dataUpdatedAt } = useQuery(liveSoccerQueryOptions());

  const all = data?.matches ?? [];
  const live = all.filter((m) => m.status === "live");
  const shown = (live.length ? live : all.filter((m) => m.status !== "final")).slice(0, limit);

  return (
    <section className="mt-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            Live right now
            {live.length > 0 && (
              <span className="ml-3 inline-block rounded bg-destructive px-2 py-0.5 align-middle text-[10px] font-bold uppercase tracking-widest text-destructive-foreground">
                {live.length} playing
              </span>
            )}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Matches under way across every competition — updates on its own every 30 seconds.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {dataUpdatedAt > 0 && (
            <span className="text-xs uppercase tracking-widest text-muted-foreground">
              {new Date(dataUpdatedAt).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          )}
          <button
            type="button"
            onClick={() => void refetch()}
            disabled={isFetching}
            className="rounded-md border border-border bg-card px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-primary transition-colors hover:border-primary disabled:opacity-60"
          >
            {isFetching ? "Refreshing…" : "Refresh"}
          </button>
          <Link
            to="/soccer-live"
            className="text-xs font-bold uppercase tracking-widest text-primary underline"
          >
            Full board
          </Link>
        </div>
      </div>

      {shown.length === 0 ? (
        <p className="mt-4 rounded-md border border-border bg-card p-4 text-sm text-muted-foreground">
          {data ? "No matches on the board right now." : "Loading today's matches…"}
        </p>
      ) : (
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {shown.map((m) => (
            <article
              key={m.id}
              className="rounded-md border border-border bg-card p-3 transition-colors hover:border-primary"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="scoreboard truncate text-[10px] uppercase tracking-widest text-muted-foreground">
                  {m.league}
                </span>
                <span
                  className={
                    m.status === "live"
                      ? "shrink-0 rounded bg-destructive px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-destructive-foreground"
                      : "shrink-0 text-[10px] font-bold uppercase tracking-widest text-muted-foreground"
                  }
                >
                  {m.status === "live"
                    ? m.clock || "Live"
                    : new Date(m.kickoff).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                </span>
              </div>
              <div className="mt-2 space-y-1 text-sm">
                {[
                  { name: m.home, score: m.homeScore },
                  { name: m.away, score: m.awayScore },
                ].map((side) => (
                  <div key={side.name} className="flex items-center justify-between gap-2">
                    <span className="truncate font-semibold">{side.name}</span>
                    <span className="scoreboard font-bold tabular-nums">{side.score || "–"}</span>
                  </div>
                ))}
              </div>
              {m.scorers.length > 0 && (
                <p className="mt-2 truncate border-t border-border pt-1.5 text-[11px] text-muted-foreground">
                  ⚽ {m.scorers.join(" · ")}
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
