import { useEffect, useRef } from "react";
import { useQueries } from "@tanstack/react-query";
import { gamesQueryOptions } from "@/lib/feed";
import { useFavorites } from "@/lib/favorites";
import type { Game, LeagueId } from "@/data/sports";

export const NOTIFY_KEY = "sideline.notifications";

/** True when the fan has switched score notifications on and the browser allows them. */
export function notificationsEnabled() {
  if (typeof window === "undefined" || typeof Notification === "undefined") return false;
  return window.localStorage.getItem(NOTIFY_KEY) === "on" && Notification.permission === "granted";
}

function matches(game: Game, names: Set<string>) {
  return names.has(game.home.name) || names.has(game.away.name);
}

/**
 * Watches the fan's favourite teams while Sideline is open and raises a browser
 * notification when one of their games kicks off or goes final.
 */
export function LiveAlerts() {
  const { favorites } = useFavorites();
  const seen = useRef(new Map<string, string>());

  const leagues = [...new Set(favorites.map((f) => f.league))] as LeagueId[];
  const names = new Set(favorites.map((f) => f.name));

  const results = useQueries({
    queries: leagues.map((league) => ({
      ...gamesQueryOptions(league),
      enabled: leagues.length > 0,
    })),
  });

  const games = results.flatMap((r) => (Array.isArray(r.data) ? (r.data as Game[]) : []));

  useEffect(() => {
    if (!notificationsEnabled()) return;
    for (const game of games) {
      if (!matches(game, names)) continue;
      const previous = seen.current.get(game.id);
      seen.current.set(game.id, game.status);
      if (!previous || previous === game.status) continue;
      const matchup = `${game.away.name} at ${game.home.name}`;
      if (game.status === "live") {
        new Notification("Kickoff on Sideline", {
          body: `${matchup} is under way${game.venue ? ` · ${game.venue}` : ""}.`,
          tag: `sideline-${game.id}-live`,
        });
      } else if (game.status === "final") {
        new Notification("Final score", {
          body: `${game.away.abbr} ${game.awayScore} — ${game.home.abbr} ${game.homeScore}`,
          tag: `sideline-${game.id}-final`,
        });
      }
    }
    // names is derived from favorites each render; games drives the effect.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [games]);

  return null;
}
