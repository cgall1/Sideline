import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import {
  markNotificationsRead,
  notificationsQueryOptions,
  relativeAge,
} from "@/lib/notifications";

function line(kind: string, actor: string, body: string): string {
  if (kind === "reply") return `${actor} replied to "${body}"`;
  if (kind === "vote") return `Someone upvoted "${body}"`;
  if (kind === "follow") return `${actor} ${body}`;
  return body;
}

export function NotificationBell() {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const { data: items = [] } = useQuery(notificationsQueryOptions(userId));

  if (!userId) return null;
  const unread = items.filter((n) => !n.read).length;

  const toggle = async () => {
    const next = !open;
    setOpen(next);
    if (next && unread > 0) {
      await markNotificationsRead(userId);
      await queryClient.invalidateQueries({ queryKey: ["notifications"] });
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={toggle}
        aria-label={unread > 0 ? `Notifications, ${unread} unread` : "Notifications"}
        aria-expanded={open}
        className="scoreboard relative border border-border px-3 py-1.5 text-[11px] font-bold uppercase text-muted-foreground transition-colors hover:border-foreground hover:text-foreground"
      >
        Alerts
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 rounded-full bg-primary px-1.5 text-[10px] font-bold text-primary-foreground">
            {unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 max-h-96 w-72 overflow-y-auto border border-border bg-background shadow-lg">
          {items.length === 0 && (
            <p className="px-4 py-3 text-xs text-muted-foreground">
              Nothing yet. Post in a space and the replies land here.
            </p>
          )}
          {items.map((n) => (
            <div key={n.id} className="border-b border-border/60 px-4 py-3 last:border-b-0">
              <p className="text-xs">{line(n.kind, n.actor, n.body)}</p>
              <p className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">
                {relativeAge(n.createdAt)}
              </p>
            </div>
          ))}
          <Link
            to="/daily"
            onClick={() => setOpen(false)}
            className="block border-t border-border px-4 py-3 text-[11px] font-bold uppercase tracking-widest text-primary"
          >
            Today's debate →
          </Link>
        </div>
      )}
    </div>
  );
}
