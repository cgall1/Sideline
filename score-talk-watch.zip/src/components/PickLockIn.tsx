import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import {
  buildStreak,
  predictionsQueryOptions,
  savePick,
} from "@/lib/predictions";
import type { Game } from "@/data/sports";

/** Lock in a winner pick for a single game, with the fan's current streak. */
export function PickLockIn({ game, signInNext }: { game: Game; signInNext: string }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { data: picks = [] } = useQuery(predictionsQueryOptions(user?.id));

  const mine = picks.find((p) => p.gameId === game.id);
  const streak = user ? buildStreak(picks, user.id) : null;
  const locked = game.status !== "scheduled";

  async function choose(team: string) {
    if (!user || locked) return;
    await savePick({
      userId: user.id,
      league: game.league,
      gameId: game.id,
      gameLabel: `${game.away.name} at ${game.home.name}`,
      pick: team,
      kickoff: game.startISO ?? null,
    });
    void queryClient.invalidateQueries({ queryKey: ["predictions"] });
  }

  return (
    <section className="mt-4 rounded-md border border-border bg-card p-5">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
        Lock in your pick
      </h2>

      {!user ? (
        <p className="mt-3 text-sm text-muted-foreground">
          <Link
            to="/auth"
            search={{ next: signInNext }}
            className="font-semibold text-primary underline"
          >
            Sign in
          </Link>{" "}
          to pick a winner before kickoff and build your streak.
        </p>
      ) : (
        <>
          <div className="mt-3 flex flex-wrap gap-2">
            {[game.away, game.home].map((team) => (
              <button
                key={team.name}
                disabled={locked}
                onClick={() => void choose(team.name)}
                className={`rounded-sm border px-3 py-2 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
                  mine?.pick === team.name
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-foreground hover:border-primary"
                }`}
              >
                {team.name}
              </button>
            ))}
          </div>

          <p className="mt-3 text-xs uppercase tracking-widest text-muted-foreground">
            {mine
              ? `Your pick: ${mine.pick}${
                  mine.resolved ? (mine.correct ? " · correct" : " · missed") : ""
                }`
              : locked
                ? "Picks closed — this game is already under way."
                : "Picks close at kickoff."}
          </p>

          {streak && (
            <p className="scoreboard mt-2 text-sm font-bold tabular-nums">
              {streak.current} in a row{" "}
              <span className="font-semibold text-muted-foreground">· best {streak.best}</span>
            </p>
          )}
        </>
      )}

      <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/predictions" className="text-primary underline">
          Full predictions board
        </Link>
        <Link to="/leaderboard" className="text-primary underline">
          Leaderboard
        </Link>
      </div>
    </section>
  );
}
