import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useFavorites } from "@/lib/favorites";
import { useAuth } from "@/hooks/useAuth";
import { NOTIFY_KEY } from "@/components/LiveAlerts";
import { pushActive, pushSupported, subscribeToPush, unsubscribeFromPush } from "@/lib/push";

/** Score notifications for followed teams, delivered even when Sideline is closed. */
export function PushToggle() {
  const { favorites } = useFavorites();
  const { user } = useAuth();
  const [supported, setSupported] = useState(true);
  const [on, setOn] = useState(false);
  const [background, setBackground] = useState(false);
  const [denied, setDenied] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (typeof Notification === "undefined") {
      setSupported(false);
      return;
    }
    setDenied(Notification.permission === "denied");
    setOn(
      window.localStorage.getItem(NOTIFY_KEY) === "on" && Notification.permission === "granted",
    );
    void pushActive().then(setBackground);
  }, [user?.id]);

  async function enable() {
    setBusy(true);
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        setDenied(permission === "denied");
        return;
      }
      window.localStorage.setItem(NOTIFY_KEY, "on");
      setOn(true);

      if (user && pushSupported()) {
        const result = await subscribeToPush(user.id);
        setBackground(result === "ok");
      }
      new Notification("Score alerts are on", {
        body: "We'll ping you when your teams kick off and when they go final.",
      });
    } finally {
      setBusy(false);
    }
  }

  async function disable() {
    setBusy(true);
    try {
      window.localStorage.setItem(NOTIFY_KEY, "off");
      setOn(false);
      await unsubscribeFromPush();
      setBackground(false);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-md border border-border bg-card p-4">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
        Instant score notifications
      </h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Get a notification the moment one of your teams kicks off and again when the game goes
        final. Signed in, these arrive even when Sideline is closed.
      </p>

      {!supported ? (
        <p className="mt-3 text-sm text-muted-foreground">
          This browser doesn&apos;t support notifications.
        </p>
      ) : denied ? (
        <p className="mt-3 text-sm text-muted-foreground">
          Notifications are blocked for this site — allow them in your browser settings, then come
          back.
        </p>
      ) : on ? (
        <button
          type="button"
          disabled={busy}
          onClick={() => void disable()}
          className="mt-3 rounded-sm border border-border px-4 py-2 text-xs font-semibold uppercase tracking-widest disabled:opacity-50"
        >
          Turn notifications off
        </button>
      ) : (
        <button
          type="button"
          disabled={busy}
          onClick={() => void enable()}
          className="mt-3 rounded-sm bg-primary px-4 py-2 text-xs font-semibold uppercase tracking-widest text-primary-foreground disabled:opacity-50"
        >
          Turn notifications on
        </button>
      )}

      {on && (
        <p className="mt-3 text-xs text-muted-foreground">
          {background
            ? "This device will be alerted even with Sideline closed."
            : user
              ? "Alerts show while Sideline is open on this device."
              : "Sign in to get alerts when Sideline is closed."}
        </p>
      )}

      <p className="mt-3 text-xs text-muted-foreground">
        {favorites.length
          ? `Watching ${favorites.length} followed team${favorites.length === 1 ? "" : "s"}.`
          : "Follow teams on any team page to choose who you get alerts about."}{" "}
        <Link to="/my-teams" className="text-primary underline">
          My teams
        </Link>
      </p>
    </div>
  );
}
