import { useQuery } from "@tanstack/react-query";
import { soccerSeasonHistoryQueryOptions } from "@/lib/feed";

const LINE_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--accent))",
  "hsl(var(--chart-3, 190 90% 55%))",
  "hsl(var(--destructive))",
  "hsl(var(--chart-5, 45 95% 58%))",
  "hsl(var(--muted-foreground))",
];

/**
 * Points per season for the current top clubs, so fans can compare this
 * campaign with the last few years side by side.
 */
export function SeasonHistoryChart({ slug, name }: { slug: string; name: string }) {
  const { data, isPending } = useQuery(soccerSeasonHistoryQueryOptions(slug));

  const seasons = data?.seasons ?? [];
  const teams = data?.teams ?? [];

  if (isPending) {
    return (
      <section className="mt-12">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season by season</h2>
        <p className="mt-3 text-sm text-muted-foreground">Loading past seasons…</p>
      </section>
    );
  }

  if (seasons.length < 2 || teams.length === 0) {
    return (
      <section className="mt-12">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season by season</h2>
        <p className="mt-3 text-sm text-muted-foreground">
          Past {name} seasons aren&apos;t published yet — this chart appears once more than one
          season of tables is available.
        </p>
      </section>
    );
  }

  const width = 760;
  const height = 300;
  const padX = 48;
  const padY = 28;
  const maxPoints = Math.max(
    ...teams.flatMap((t) => t.points.map((p) => p ?? 0)),
    10,
  );
  const x = (i: number) => padX + (i * (width - padX * 2)) / Math.max(1, seasons.length - 1);
  const y = (points: number) => height - padY - (points * (height - padY * 2)) / maxPoints;

  return (
    <section className="mt-12">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season by season</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Points won by the current top {teams.length} in each of the last {seasons.length} seasons.
      </p>

      <div className="mt-4 overflow-x-auto rounded-md border border-border bg-card p-4">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-[300px] w-full min-w-[640px]"
          role="img"
          aria-label={`${name} points by season`}
        >
          {[0, Math.round(maxPoints / 2), maxPoints].map((value) => (
            <g key={value}>
              <line
                x1={padX}
                x2={width - padX}
                y1={y(value)}
                y2={y(value)}
                stroke="hsl(var(--border))"
                strokeWidth={1}
              />
              <text
                x={padX - 8}
                y={y(value) + 4}
                textAnchor="end"
                fontSize={11}
                fill="hsl(var(--muted-foreground))"
              >
                {value}
              </text>
            </g>
          ))}

          {seasons.map((season, i) => (
            <text
              key={season}
              x={x(i)}
              y={height - 6}
              textAnchor="middle"
              fontSize={11}
              fill="hsl(var(--muted-foreground))"
            >
              {season}
            </text>
          ))}

          {teams.map((team, ti) => {
            const color = LINE_COLORS[ti % LINE_COLORS.length];
            const pts = team.points
              .map((p, i) => (p === null ? null : `${x(i)},${y(p)}`))
              .filter((p): p is string => p !== null);
            return (
              <g key={team.team}>
                <polyline points={pts.join(" ")} fill="none" stroke={color} strokeWidth={2.5} />
                {team.points.map((p, i) =>
                  p === null ? null : (
                    <circle key={i} cx={x(i)} cy={y(p)} r={3.5} fill={color} />
                  ),
                )}
              </g>
            );
          })}
        </svg>

        <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-xs">
          {teams.map((team, ti) => (
            <li key={team.team} className="flex items-center gap-2">
              <span
                className="inline-block h-2.5 w-2.5 rounded-full"
                style={{ background: LINE_COLORS[ti % LINE_COLORS.length] }}
              />
              <span className="font-semibold">{team.team}</span>
              <span className="text-muted-foreground">
                {team.points.map((p) => (p === null ? "—" : p)).join(" · ")}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
