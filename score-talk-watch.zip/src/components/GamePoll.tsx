import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { castVote, pollVotesQueryOptions } from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";

interface Props {
  gameId: string;
  home: string;
  away: string;
  signInNext: string;
}

/** Live "who wins this one?" poll attached to a single game thread. */
export function GamePoll({ gameId, home, away, signInNext }: Props) {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const queryClient = useQueryClient();
  const { data } = useQuery(pollVotesQueryOptions(userId));

  const pollId = `game:${gameId}:winner`;
  const options = [
    { id: "away", label: away },
    { id: "home", label: home },
  ];
  const tallies = data?.totals[pollId] ?? {};
  const mine = data?.mine[pollId];
  const sum = options.reduce((acc, o) => acc + (tallies[o.id] ?? 0), 0);

  return (
    <div className="mt-4 rounded-md border border-border bg-card p-4">
      <h3 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
        Live poll · who takes this one?
      </h3>
      <ul className="mt-3 space-y-2">
        {options.map((o) => {
          const votes = tallies[o.id] ?? 0;
          const pct = sum ? Math.round((votes / sum) * 100) : 0;
          return (
            <li key={o.id}>
              <button
                disabled={!userId}
                onClick={async () => {
                  if (!userId) return;
                  await castVote(pollId, userId, o.id);
                  await queryClient.invalidateQueries({ queryKey: ["community", "poll-votes"] });
                }}
                className={cn(
                  "relative w-full overflow-hidden rounded-sm border px-3 py-2 text-left text-sm transition-colors disabled:opacity-60",
                  mine === o.id ? "border-primary" : "border-border hover:border-primary/50",
                )}
              >
                <span
                  aria-hidden
                  className="absolute inset-y-0 left-0 bg-primary/15"
                  style={{ width: `${pct}%` }}
                />
                <span className="relative flex justify-between gap-3">
                  <span className="font-semibold">{o.label}</span>
                  <span className="scoreboard tabular-nums text-muted-foreground">
                    {pct}% · {votes}
                  </span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mt-2 text-xs text-muted-foreground">
        {sum} vote{sum === 1 ? "" : "s"} · results update live.{" "}
        {!userId && (
          <Link to="/auth" search={{ next: signInNext }} className="font-semibold text-primary">
            Sign in to vote
          </Link>
        )}
      </p>
    </div>
  );
}
