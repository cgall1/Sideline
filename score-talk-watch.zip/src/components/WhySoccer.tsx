import { useQuery } from "@tanstack/react-query";
import { soccerCalendarQueryOptions, soccerTableQueryOptions } from "@/lib/feed";

function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
}

function same(a: string, b: string): boolean {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  return x === y || x.includes(y) || y.includes(x);
}

/**
 * "Why it matters" for a soccer fixture: points, the race the result affects
 * and the next fixtures, computed from the live table and calendar.
 */
export function WhySoccer({
  slug,
  home,
  away,
  homeScore,
  awayScore,
  status,
}: {
  slug: string;
  home: string;
  away: string;
  homeScore: string;
  awayScore: string;
  status: "live" | "final" | "scheduled";
}) {
  const { data: table } = useQuery(soccerTableQueryOptions(slug));
  const { data: calendar } = useQuery(soccerCalendarQueryOptions(slug));

  const rows = table?.rows ?? [];
  if (!rows.length) return null;

  const hs = Number(homeScore);
  const as = Number(awayScore);
  const focus =
    status === "final" && Number.isFinite(hs) && Number.isFinite(as) && hs !== as
      ? hs > as
        ? home
        : away
      : home;

  const row = rows.find((r) => same(r.team, focus));
  const lines: string[] = [];

  if (row) {
    const leader = rows[0]!;
    lines.push(
      row.rank === 1
        ? `${row.team} lead the table on ${row.points} points from ${row.gp} games (${row.gf - row.ga >= 0 ? "+" : ""}${row.gf - row.ga} goal difference).`
        : `${row.team} are ${ordinal(row.rank)} on ${row.points} points, ${leader.points - row.points} behind ${leader.team}.`,
    );

    const above = rows[row.rank - 2];
    const below = rows[row.rank];
    if (above) lines.push(`${above.team} are one place above on ${above.points}.`);
    if (below) lines.push(`${below.team} are chasing from below on ${below.points}.`);
    if (rows.length >= 6) {
      const cutRow = rows[3];
      if (cutRow && row.rank > 4) {
        lines.push(`The top four is ${cutRow.points - row.points} points away.`);
      } else if (row.rank <= 4) {
        lines.push("That keeps them inside the top four.");
      }
    }
  }

  const upcoming = (calendar?.days ?? [])
    .flatMap((d) => d.matches)
    .filter((m) => m.status === "scheduled" && (same(m.home, focus) || same(m.away, focus)))
    .slice(0, 3);
  if (upcoming.length) {
    const names = upcoming.map((m) => (same(m.home, focus) ? m.away : m.home));
    lines.push(`Next up: ${names.join(", then ")}.`);
  }

  if (!lines.length) return null;

  return (
    <section className="mt-6 rounded-md border border-primary/40 bg-card p-5">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-primary">
        Why it matters
      </h2>
      <ul className="mt-3 space-y-2">
        {lines.map((l, i) => (
          <li key={i} className="text-sm leading-relaxed">
            {l}
          </li>
        ))}
      </ul>
    </section>
  );
}
