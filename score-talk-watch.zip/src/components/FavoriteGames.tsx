import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { gamesQueryOptions } from "@/lib/feed";
import { useFavorites } from "@/lib/favorites";

/** Games involving the fan's favourite teams, shown on the home page. */
export function FavoriteGames() {
  const { favorites } = useFavorites();
  const { data: games = [] } = useQuery(gamesQueryOptions("all"));

  if (favorites.length === 0) {
    return (
      <section className="mt-16 border-y border-foreground py-7">
        <h2 className="scoreboard text-2xl font-bold uppercase">Your teams</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Star a team on any{" "}
          <Link to="/rosters" className="font-semibold text-primary">
            roster page
          </Link>{" "}
          and its games, news and threads show up here.
        </p>
      </section>
    );
  }

  const names = favorites.map((f) => f.name.toLowerCase());
  const mine = games.filter(
    (g) => names.includes(g.home.name.toLowerCase()) || names.includes(g.away.name.toLowerCase()),
  );

  return (
    <section className="mt-16 border-t border-foreground pt-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="scoreboard text-2xl font-bold uppercase">Your teams</h2>
        <Link
          to="/my-teams"
          className="scoreboard text-xs font-bold uppercase tracking-widest text-primary underline"
        >
          Open my teams
        </Link>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {favorites.map((f) => (
          <Link
            key={`${f.league}-${f.teamId}`}
            to="/rosters/$league/$team"
            params={{ league: f.league, team: f.teamId }}
            className="scoreboard border border-border px-3 py-1 text-xs font-bold uppercase text-muted-foreground hover:border-foreground hover:text-foreground"
          >
            ★ {f.name}
          </Link>
        ))}
      </div>
      {mine.length === 0 ? (
        <p className="mt-4 border-y border-border py-4 text-sm text-muted-foreground">
          None of your teams are playing right now — their next games appear here automatically.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {mine.map((game) => (
            <article key={game.id} className="border border-border bg-card p-4">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">
                {game.startLabel} {game.venue ? `· ${game.venue}` : ""}
              </p>
              <p className="mt-2 flex justify-between text-sm font-semibold">
                <span>{game.away.name}</span>
                <span className="scoreboard">{game.awayScore}</span>
              </p>
              <p className="mt-1 flex justify-between text-sm font-semibold">
                <span>{game.home.name}</span>
                <span className="scoreboard">{game.homeScore}</span>
              </p>
              <p
                className={`mt-2 scoreboard text-xs uppercase tracking-widest ${
                  game.status === "live" ? "text-[color:var(--live)]" : "text-muted-foreground"
                }`}
              >
                {game.status === "live" ? `Live · ${game.clock}` : game.status}
              </p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
