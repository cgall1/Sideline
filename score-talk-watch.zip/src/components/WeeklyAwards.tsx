import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { fetchWeeklyAwards } from "@/lib/awards.functions";

export function WeeklyAwards() {
  const fn = useServerFn(fetchWeeklyAwards);
  const { data } = useQuery({ queryKey: ["weekly-awards"], queryFn: () => fn(), staleTime: 30 * 60_000 });
  if (!data) return null;
  const empty = !data.fanOfWeek && !data.bestPredictor && !data.hottestDebate;
  const fmt = (d: string) => new Date(`${d}T12:00:00Z`).toLocaleDateString(undefined, { month: "short", day: "numeric" });

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-baseline justify-between gap-2">
        <h2 className="font-display text-lg font-bold">🏆 Weekly fan awards</h2>
        <span className="text-xs text-muted-foreground">{fmt(data.weekStart)} – {fmt(data.weekEnd)}</span>
      </div>
      {empty ? (
        <p className="mt-2 text-sm text-muted-foreground">
          No winners last week yet — post, vote and make picks this week to be in the running on Monday.
        </p>
      ) : (
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Award label="Fan of the week">
            {data.fanOfWeek ? (
              <Link to="/post/$postId" params={{ postId: data.fanOfWeek.postId }} className="hover:underline">
                <b>@{data.fanOfWeek.name}</b> — “{data.fanOfWeek.title}” ({data.fanOfWeek.votes} upvotes)
              </Link>
            ) : "Nobody yet"}
          </Award>
          <Award label="Best predictor">
            {data.bestPredictor ? (
              <span><b>@{data.bestPredictor.name}</b> — {data.bestPredictor.correct} of {data.bestPredictor.total} picks right</span>
            ) : "Nobody yet"}
          </Award>
          <Award label="Hottest debate">
            {data.hottestDebate ? (
              <Link to="/daily" className="hover:underline">
                “{data.hottestDebate.question}” ({data.hottestDebate.votes} votes)
              </Link>
            ) : "Nothing yet"}
          </Award>
        </div>
      )}
    </section>
  );
}

function Award({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-md bg-muted/50 p-3">
      <p className="text-[11px] font-semibold uppercase tracking-wide text-primary">{label}</p>
      <p className="mt-1 text-sm">{children}</p>
    </div>
  );
}
