import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { leagueVideosQueryOptions } from "@/lib/feed";

interface VideoReelProps {
  /** Channel key from src/lib/videos.functions.ts (nfl, nba, chk, epl, ...). */
  league: string;
  /** Section heading, e.g. "NBA highlight reel". */
  heading: string;
  /** One line of context under the heading. */
  intro?: string;
}

function shortDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/** Real highlight clips pulled from a league's official video channels. */
export function VideoReel({ league, heading, intro }: VideoReelProps) {
  const { data, isLoading } = useQuery(leagueVideosQueryOptions(league));
  const [playing, setPlaying] = useState<string | null>(null);
  const clips = data?.videos ?? [];

  if (isLoading) {
    return (
      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{heading}</h2>
        <p className="mt-2 text-sm text-muted-foreground">Loading the latest clips…</p>
      </section>
    );
  }
  if (clips.length === 0) {
    return (
      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{heading}</h2>
        <p className="mt-2 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No new clips posted yet — the reel fills up as soon as the next games are played.
        </p>
      </section>
    );
  }

  const featured = clips[0]!;
  return (
    <section className="mt-8">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{heading}</h2>
      {intro && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{intro}</p>}

      <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
        <div className="aspect-video w-full bg-black">
          <iframe
            src={featured.embedUrl}
            title={featured.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
            allowFullScreen
            loading="lazy"
            className="h-full w-full"
          />
        </div>
        <div className="p-4">
          <h3 className="text-lg font-bold leading-snug">{featured.title}</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            {featured.channel} · {shortDate(featured.published)}
          </p>
        </div>
      </div>

      {clips.length > 1 && (
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {clips.slice(1).map((v) => (
            <div
              key={v.id}
              className="overflow-hidden rounded-md border border-border bg-card transition-colors hover:border-primary/50"
            >
              <div className="aspect-video w-full bg-black">
                {playing === v.id ? (
                  <iframe
                    src={`${v.embedUrl}?autoplay=1`}
                    title={v.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
                    allowFullScreen
                    loading="lazy"
                    className="h-full w-full"
                  />
                ) : (
                  <button
                    type="button"
                    onClick={() => setPlaying(v.id)}
                    className="group relative h-full w-full"
                    aria-label={`Play ${v.title}`}
                  >
                    <img
                      src={v.thumbnail}
                      alt={v.title}
                      loading="lazy"
                      className="h-full w-full object-cover opacity-90 transition-opacity group-hover:opacity-100"
                    />
                    <span className="scoreboard absolute inset-0 flex items-center justify-center text-3xl text-primary">
                      ▶
                    </span>
                  </button>
                )}
              </div>
              <div className="p-4">
                <h3 className="text-base font-bold leading-snug">{v.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  {v.channel} · {shortDate(v.published)}
                </p>
                <a
                  href={v.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
                >
                  Watch on YouTube
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
