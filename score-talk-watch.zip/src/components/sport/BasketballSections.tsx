import { Link } from "@tanstack/react-router";
import type { LeagueId } from "@/data/sports";
import {
  SportNewsSection,
  SportScoresSection,
  SportStandingsSection,
} from "@/components/sport/SportSections";

export const BASKETBALL_LEAGUES = [
  { id: "nba" as LeagueId, label: "NBA" },
  { id: "wnba" as LeagueId, label: "WNBA" },
  { id: "college-basketball" as LeagueId, label: "College" },
];

export function basketballLeague(value: unknown): LeagueId {
  const match = BASKETBALL_LEAGUES.find((l) => l.id === value);
  return (match?.id ?? "nba") as LeagueId;
}

/** NBA / WNBA / College switcher shared by the basketball pages. */
export function LeagueSwitch({
  league,
  to,
}: {
  league: LeagueId;
  to: "/basketball" | "/basketball/news" | "/basketball/scores" | "/basketball/standings";
}) {
  return (
    <div className="mx-auto flex max-w-7xl flex-wrap gap-2 px-4 pt-6">
      {BASKETBALL_LEAGUES.map((l) => (
        <Link
          key={l.id}
          to={to}
          search={{ league: l.id }}
          className={`scoreboard rounded-sm border px-3 py-2 text-xs font-bold uppercase tracking-widest transition-colors ${
            l.id === league
              ? "border-primary text-primary"
              : "border-border text-muted-foreground hover:text-foreground"
          }`}
        >
          {l.label}
        </Link>
      ))}
    </div>
  );
}

export function BasketballScores({ league }: { league: LeagueId }) {
  return (
    <>
      <LeagueSwitch league={league} to="/basketball/scores" />
      <SportScoresSection league={league} />
    </>
  );
}

export function BasketballStandings({ league }: { league: LeagueId }) {
  return (
    <>
      <LeagueSwitch league={league} to="/basketball/standings" />
      <SportStandingsSection league={league} />
    </>
  );
}

export function BasketballNews({ league }: { league: LeagueId }) {
  return (
    <>
      <LeagueSwitch league={league} to="/basketball/news" />
      <SportNewsSection league={league} />
    </>
  );
}
