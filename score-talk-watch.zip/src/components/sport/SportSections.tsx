import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { LEAGUES, type LeagueId } from "@/data/sports";
import {
  gamesQueryOptions,
  monthScheduleQueryOptions,
  newsQueryOptions,
  standingsQueryOptions,
} from "@/lib/feed";
import { ScoreCard } from "@/components/ScoreCard";
import type { ScheduleGame } from "@/lib/schedule.functions";

export function leagueName(league: LeagueId): string {
  return LEAGUES.find((l) => l.id === league)?.short ?? league.toUpperCase();
}

function Shell({
  title,
  intro,
  children,
}: {
  title: string;
  intro: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">{title}</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{intro}</p>
      {children}
    </div>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return (
    <p className="mt-6 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
      {children}
    </p>
  );
}

/** Live and recent scores for one league, refreshing on its own. */
export function SportScoresSection({ league }: { league: LeagueId }) {
  const short = leagueName(league);
  const { data: games = [], isPending } = useQuery(gamesQueryOptions(league));
  const live = games.filter((g) => g.status === "live");
  const rest = games.filter((g) => g.status !== "live");

  return (
    <Shell
      title={`${short} scores`}
      intro={`Every ${short} game under way and just finished, straight from the live feed and refreshing every 30 seconds.`}
    >
      {isPending && <Empty>Loading the live scoreboard…</Empty>}
      {!isPending && games.length === 0 && (
        <Empty>No {short} games in the live feed right now — check the schedule for the next one.</Empty>
      )}
      {live.length > 0 && (
        <section className="mt-8">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Live right now</h2>
          <div className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {live.map((game) => (
              <ScoreCard key={game.id} game={game} />
            ))}
          </div>
        </section>
      )}
      {rest.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            Recent &amp; upcoming
          </h2>
          <div className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {rest.map((game) => (
              <ScoreCard key={game.id} game={game} />
            ))}
          </div>
        </section>
      )}
    </Shell>
  );
}

/** Full league table for one league. */
export function SportStandingsSection({ league }: { league: LeagueId }) {
  const short = leagueName(league);
  const { data, isPending } = useQuery(standingsQueryOptions(league));

  return (
    <Shell
      title={`${short} standings`}
      intro={`The ${short} table with every team's record, updated as results come in.`}
    >
      {isPending && <Empty>Loading the table…</Empty>}
      {!isPending && (!data || data.rows.length === 0) && (
        <Empty>No {short} table yet — it fills in once the season&apos;s games are played.</Empty>
      )}
      {data && data.rows.length > 0 && (
        <div className="mt-8 overflow-hidden rounded-md border border-border bg-card">
          <header className="border-b border-border px-4 py-3">
            <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">
              {data.group || `${short} table`}
            </h2>
          </header>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead>
                <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                  <th className="px-4 py-2 text-left font-semibold">#</th>
                  <th className="px-2 py-2 text-left font-semibold">Team</th>
                  <th className="px-2 py-2 text-right font-semibold">W</th>
                  <th className="px-2 py-2 text-right font-semibold">L</th>
                  <th className="px-2 py-2 text-right font-semibold">OT/D</th>
                  <th className="px-4 py-2 text-right font-semibold">Pct / Pts</th>
                </tr>
              </thead>
              <tbody>
                {data.rows.map((row, i) => (
                  <tr key={row.team} className="border-b border-border/60 last:border-0">
                    <td className="scoreboard px-4 py-2 tabular-nums text-muted-foreground">
                      {i + 1}
                    </td>
                    <td className="px-2 py-2 font-semibold">{row.team}</td>
                    <td className="scoreboard px-2 py-2 text-right tabular-nums">{row.w}</td>
                    <td className="scoreboard px-2 py-2 text-right tabular-nums">{row.l}</td>
                    <td className="scoreboard px-2 py-2 text-right tabular-nums text-muted-foreground">
                      {row.otl ?? "—"}
                    </td>
                    <td className="scoreboard px-4 py-2 text-right font-bold tabular-nums">
                      {row.pct}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Shell>
  );
}

/** Latest headlines for one league. */
export function SportNewsSection({ league }: { league: LeagueId }) {
  const short = leagueName(league);
  const { data, isPending } = useQuery(newsQueryOptions(league));
  const items = data?.items ?? [];

  return (
    <Shell
      title={`${short} news`}
      intro={`The latest ${short} headlines, injuries and roster moves as they are published.`}
    >
      {isPending && <Empty>Loading headlines…</Empty>}
      {!isPending && items.length === 0 && (
        <Empty>No {short} headlines in the feed right now — try again shortly.</Empty>
      )}
      <ul className="mt-8 grid gap-4 md:grid-cols-2">
        {items.map((item) => (
          <li key={item.id} className="overflow-hidden rounded-md border border-border bg-card">
            {item.image && (
              <img
                src={item.image}
                alt=""
                loading="lazy"
                className="h-40 w-full object-cover"
              />
            )}
            <div className="p-4">
              <p className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
                {new Date(item.published).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                })}
                {item.byline ? ` · ${item.byline}` : ""}
              </p>
              <h2 className="mt-1 text-lg font-semibold">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-primary"
                >
                  {item.headline}
                </a>
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">{item.summary}</p>
            </div>
          </li>
        ))}
      </ul>
    </Shell>
  );
}

function monthLabel(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1, 1)));
}

function shift(month: string, delta: number): string {
  const [y, m] = month.split("-").map(Number);
  return new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1 + delta, 1)).toISOString().slice(0, 7);
}

/** Month-by-month schedule for one league. */
export function SportScheduleSection({ league }: { league: LeagueId }) {
  const short = leagueName(league);
  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const { data, isPending } = useQuery(monthScheduleQueryOptions(league, month));
  const games: ScheduleGame[] = data?.games ?? [];
  const days = [...new Set(games.map((g) => g.day))].sort();

  return (
    <Shell
      title={`${short} schedule`}
      intro={`Every ${short} fixture month by month with start times, venues and TV.`}
    >
      <div className="mt-6 flex items-center gap-3">
        <button
          type="button"
          onClick={() => setMonth(shift(month, -1))}
          className="scoreboard rounded-sm border border-border px-3 py-1 text-xs uppercase tracking-widest hover:border-foreground"
        >
          ← Prev
        </button>
        <span className="scoreboard text-lg font-bold uppercase tracking-wide">
          {monthLabel(month)}
        </span>
        <button
          type="button"
          onClick={() => setMonth(shift(month, 1))}
          className="scoreboard rounded-sm border border-border px-3 py-1 text-xs uppercase tracking-widest hover:border-foreground"
        >
          Next →
        </button>
      </div>

      {isPending && <Empty>Loading the calendar…</Empty>}
      {!isPending && days.length === 0 && (
        <Empty>No {short} games scheduled in {monthLabel(month)}.</Empty>
      )}

      <div className="mt-6 space-y-6">
        {days.map((day) => (
          <section key={day}>
            <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
              {new Intl.DateTimeFormat("en-US", {
                weekday: "short",
                month: "short",
                day: "numeric",
                timeZone: "UTC",
              }).format(new Date(`${day}T12:00:00Z`))}
            </h2>
            <ul className="mt-2 grid gap-2 md:grid-cols-2">
              {games
                .filter((g) => g.day === day)
                .map((game) => (
                  <li key={game.id} className="rounded-md border border-border bg-card p-4">
                    <div className="flex items-start justify-between gap-3">
                      <p className="scoreboard font-semibold uppercase tracking-wide">
                        {game.awayAbbr} @ {game.homeAbbr}
                      </p>
                      <span className="scoreboard shrink-0 text-xs uppercase tracking-widest text-muted-foreground">
                        {game.status === "scheduled"
                          ? new Intl.DateTimeFormat("en-US", {
                              hour: "numeric",
                              minute: "2-digit",
                            }).format(new Date(game.date))
                          : `${game.awayScore ?? 0}-${game.homeScore ?? 0}`}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{game.name}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {[game.venue, game.city, game.broadcast].filter(Boolean).join(" · ")}
                    </p>
                    <Link
                      to="/game/$league/$gameId"
                      params={{ league, gameId: game.id }}
                      className="mt-2 inline-block text-xs font-semibold text-primary hover:underline"
                    >
                      Match thread →
                    </Link>
                  </li>
                ))}
            </ul>
          </section>
        ))}
      </div>
    </Shell>
  );
}
