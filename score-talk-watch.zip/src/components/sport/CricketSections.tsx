import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  cricketBoardQueryOptions,
  cricketNewsQueryOptions,
  cricketSeriesQueryOptions,
  cricketStandingsQueryOptions,
} from "@/lib/feed";
import type { CricketMatch } from "@/lib/cricket.functions";
import { useTrackHubVisit } from "@/lib/visits";

function Shell({
  title,
  intro,
  children,
}: {
  title: string;
  intro: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">{title}</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{intro}</p>
      {children}
    </div>
  );
}

function MatchCard({ match }: { match: CricketMatch }) {
  return (
    <article className="rounded-md border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <p className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
          {match.series}
          {match.format ? ` · ${match.format}` : ""}
        </p>
        <span
          className={`scoreboard shrink-0 text-xs font-bold uppercase tracking-widest ${
            match.state === "in" ? "live-dot text-[color:var(--live)]" : "text-muted-foreground"
          }`}
        >
          {match.state === "in" ? "Live" : match.status}
        </span>
      </div>
      <ul className="mt-3 space-y-1 text-sm">
        {match.teams.map((t, i) => (
          <li key={`${match.id}-${i}`} className="flex items-center justify-between gap-3">
            <span className={t.winner ? "font-semibold text-foreground" : "text-foreground"}>
              {t.team}
            </span>
            <span className="scoreboard text-muted-foreground">{t.score || "—"}</span>
          </li>
        ))}
      </ul>
      {match.note && <p className="mt-2 text-xs text-muted-foreground">{match.note}</p>}
      {match.venue && <p className="mt-1 text-xs text-muted-foreground">{match.venue}</p>}
    </article>
  );
}

/** Live and upcoming cricket across every active series. */
export function CricketScoresSection() {
  const { data, isLoading, refetch, isFetching } = useQuery(cricketBoardQueryOptions());
  useTrackHubVisit("/cricket/scores", "Cricket scores");
  const matches = data?.matches ?? [];

  return (
    <Shell
      title="Cricket Scores"
      intro="Every match under way, just finished or about to start across the active international and franchise series — refreshing on its own every minute."
    >
      <button
        onClick={() => refetch()}
        className="scoreboard mt-4 rounded-sm border border-border px-3 py-2 text-xs font-bold uppercase tracking-widest hover:border-primary hover:text-primary"
      >
        {isFetching ? "Refreshing…" : "Refresh"}
      </button>
      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading matches…</p>}
      {!isLoading && matches.length === 0 && (
        <p className="mt-4 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No cricket in this window — matches appear here as soon as the next one starts.
        </p>
      )}
      <div className="mt-4 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
        {matches.map((m) => (
          <MatchCard key={m.id} match={m} />
        ))}
      </div>
    </Shell>
  );
}

/** Series tables, filling in as results are published. */
export function CricketStandingsSection() {
  const { data: series = [] } = useQuery(cricketSeriesQueryOptions());
  const withTables = series.filter((s) => s.hasStandings);
  const [selected, setSelected] = useState("");
  const seriesId = selected || withTables[0]?.id || "";
  const { data: table, isLoading } = useQuery(cricketStandingsQueryOptions(seriesId));
  useTrackHubVisit("/cricket/standings", "Cricket standings");

  return (
    <Shell
      title="Cricket Standings"
      intro="Points tables for the tournaments running right now. They re-check the results feed every 15 seconds, so a finished match shows up in the table within moments."
    >
      {withTables.length > 0 && (
        <select
          value={seriesId}
          onChange={(e) => setSelected(e.target.value)}
          aria-label="Choose a cricket series"
          className="mt-4 rounded-sm border border-border bg-card px-3 py-2 text-sm"
        >
          {withTables.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      )}
      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading the table…</p>}
      {!isLoading && (!table || table.rows.length === 0) ? (
        <p className="mt-4 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          No table published yet — it fills in automatically as soon as results arrive.
        </p>
      ) : (
        table && (
          <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
            <table className="w-full text-sm">
              <thead>
                <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                  <th className="px-4 py-2 text-left font-semibold">#</th>
                  <th className="px-2 py-2 text-left font-semibold">Team</th>
                  <th className="px-2 py-2 text-right font-semibold">P</th>
                  <th className="px-2 py-2 text-right font-semibold">W</th>
                  <th className="px-2 py-2 text-right font-semibold">L</th>
                  <th className="px-4 py-2 text-right font-semibold">Pts</th>
                </tr>
              </thead>
              <tbody>
                {table.rows.map((row) => (
                  <tr key={row.team} className="border-b border-border last:border-0">
                    <td className="px-4 py-2 text-muted-foreground">{row.rank}</td>
                    <td className="px-2 py-2 font-semibold">{row.team}</td>
                    <td className="px-2 py-2 text-right text-muted-foreground">{row.played}</td>
                    <td className="px-2 py-2 text-right text-muted-foreground">{row.won}</td>
                    <td className="px-2 py-2 text-right text-muted-foreground">{row.lost}</td>
                    <td className="scoreboard px-4 py-2 text-right font-bold">{row.points}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}
    </Shell>
  );
}

/** Cricket headlines: tours, squads, injuries and match reports. */
export function CricketNewsSection() {
  const { data: news = [], isLoading } = useQuery(cricketNewsQueryOptions());
  useTrackHubVisit("/cricket/news", "Cricket news");

  return (
    <Shell
      title="Cricket News"
      intro="Squad news, injuries, tour updates and match reports from the cricket wire, refreshed automatically."
    >
      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading headlines…</p>}
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {news.map((item) => (
          <a
            key={item.id}
            href={item.url}
            target="_blank"
            rel="noreferrer"
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary"
          >
            <h2 className="font-semibold text-foreground">{item.headline}</h2>
            {item.summary && (
              <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{item.summary}</p>
            )}
          </a>
        ))}
        {!isLoading && news.length === 0 && (
          <p className="text-sm text-muted-foreground">Headlines load as soon as the wire updates.</p>
        )}
      </div>
    </Shell>
  );
}
