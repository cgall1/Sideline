import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { tennisRankingsQueryOptions } from "@/lib/feed";
import { useTrackHubVisit } from "@/lib/visits";

/** ATP and WTA world rankings — tennis's version of a league table. */
export function TennisRankingsSection() {
  const { data = [], isLoading } = useQuery(tennisRankingsQueryOptions());
  const [tour, setTour] = useState<"atp" | "wta">("atp");
  useTrackHubVisit("/tennis/standings", "Tennis rankings");
  const board = data.find((d) => d.tour === tour);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">Tennis Rankings</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        The current ATP and WTA world rankings, with points and movement since the last update.
      </p>

      <div className="mt-4 flex gap-2">
        {(["atp", "wta"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTour(t)}
            className={`scoreboard rounded-sm border px-3 py-2 text-xs font-bold uppercase tracking-widest ${
              t === tour
                ? "border-primary text-primary"
                : "border-border text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading rankings…</p>}
      {!isLoading && (!board || board.ranks.length === 0) && (
        <p className="mt-4 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          Rankings load as soon as the tour publishes its next list.
        </p>
      )}
      {board && board.ranks.length > 0 && (
        <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-2 text-left font-semibold">#</th>
                <th className="px-2 py-2 text-left font-semibold">Player</th>
                <th className="px-2 py-2 text-right font-semibold">Prev</th>
                <th className="px-4 py-2 text-right font-semibold">Points</th>
              </tr>
            </thead>
            <tbody>
              {board.ranks.map((r) => (
                <tr key={`${r.rank}-${r.player}`} className="border-b border-border last:border-0">
                  <td className="px-4 py-2 text-muted-foreground">{r.rank}</td>
                  <td className="px-2 py-2 font-semibold">{r.player}</td>
                  <td className="px-2 py-2 text-right text-muted-foreground">{r.previous || "—"}</td>
                  <td className="scoreboard px-4 py-2 text-right font-bold">
                    {r.points.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
