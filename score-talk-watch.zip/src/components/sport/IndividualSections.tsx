import { useQuery } from "@tanstack/react-query";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";
import { INDIVIDUAL_SPORTS, type SportId } from "@/lib/individual-sports.functions";
import { useTrackHubVisit } from "@/lib/visits";
import { useFavorites } from "@/lib/favorites";

function athleteId(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

function meta(id: SportId) {
  return INDIVIDUAL_SPORTS.find((s) => s.id === id)!;
}

function when(iso: string) {
  if (!iso) return "TBD";
  return new Date(iso).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

/** What the scores tab is called for each individual sport. */
export function eventsLabel(id: SportId): string {
  if (id === "golf") return "Tournaments";
  if (id === "nascar" || id === "f1") return "Races";
  if (id === "ufc") return "Fight cards";
  if (id === "boxing") return "Fights";
  return "Matches";
}

/** Live and upcoming events for one individual sport. */
export function IndividualScoresSection({ sport }: { sport: SportId }) {
  const s = meta(sport);
  const { data: events = [], isLoading } = useQuery(sportEventsQueryOptions(sport));
  const { isFavorite, toggle } = useFavorites();
  useTrackHubVisit(`/${sport}/scores`, `${s.name} scores`);

  const live = events.filter((e) => e.state === "in");
  const rest = events.filter((e) => e.state !== "in");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">
        {s.name} {eventsLabel(sport)}
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Live results and the next events on the {s.name} schedule, straight from the official feed.
      </p>
      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading live results…</p>}
      {!isLoading && events.length === 0 && (
        <p className="mt-4 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
          Nothing on the schedule right now — results appear here as soon as the next event starts.
        </p>
      )}
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {[...live, ...rest].slice(0, 30).map((event) => (
          <article key={event.id} className="rounded-md border border-border bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <h2 className="scoreboard text-lg font-semibold uppercase tracking-wide">
                {event.name}
              </h2>
              <span
                className={`scoreboard shrink-0 text-xs font-semibold uppercase tracking-widest ${
                  event.state === "in"
                    ? "live-dot text-[color:var(--live)]"
                    : "text-muted-foreground"
                }`}
              >
                {event.status}
              </span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              {when(event.date)}
              {event.venue ? ` · ${event.venue}` : ""}
              {event.location ? ` · ${event.location}` : ""}
            </p>
            {event.competitors.length > 0 && (
              <ul className="mt-3 space-y-1 text-sm">
                {event.competitors.map((c, i) => {
                  const id = athleteId(c.name);
                  const followed = isFavorite(sport, id);
                  return (
                    <li key={`${event.id}-${i}`} className="flex items-center justify-between gap-3">
                      <span className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => toggle({ league: sport, teamId: id, name: c.name })}
                          aria-label={followed ? `Unfollow ${c.name}` : `Follow ${c.name}`}
                          className={`text-sm leading-none transition-colors ${
                            followed ? "text-primary" : "text-muted-foreground hover:text-primary"
                          }`}
                        >
                          {followed ? "\u2605" : "\u2606"}
                        </button>
                        <span
                          className={
                            c.winner ? "font-semibold text-foreground" : "text-muted-foreground"
                          }
                        >
                          {c.name}
                        </span>
                      </span>
                      <span className="scoreboard text-muted-foreground">{c.detail}</span>
                    </li>
                  );
                })}
              </ul>
            )}
            {event.note && <p className="mt-2 text-xs text-muted-foreground">{event.note}</p>}
          </article>
        ))}
      </div>
    </div>
  );
}

/** Headlines for one individual sport. */
export function IndividualNewsSection({ sport }: { sport: SportId }) {
  const s = meta(sport);
  const { data: news = [], isLoading } = useQuery(sportNewsQueryOptions(sport));
  useTrackHubVisit(`/${sport}/news`, `${s.name} news`);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-3xl font-bold uppercase tracking-wide">{s.name} News</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
        Headlines, results reports and roster news from the {s.name} wire, refreshed automatically.
      </p>
      {isLoading && <p className="mt-4 text-sm text-muted-foreground">Loading headlines…</p>}
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {news.slice(0, 24).map((item) => (
          <a
            key={item.id}
            href={item.url}
            target="_blank"
            rel="noreferrer"
            className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary"
          >
            <h2 className="font-semibold text-foreground">{item.headline}</h2>
            {item.description && (
              <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{item.description}</p>
            )}
          </a>
        ))}
        {!isLoading && news.length === 0 && (
          <p className="text-sm text-muted-foreground">
            Headlines load as soon as the wire updates.
          </p>
        )}
      </div>
    </div>
  );
}
