import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { publicCounts } from "@/lib/public-counts.functions";
import { useAuth } from "@/hooks/useAuth";
import { recordFanActivity } from "@/lib/daily";
import { cn } from "@/lib/utils";

/** "I believe / I don't" tally on rumour posts in the transfers space. */
export function RumorVote({ postId }: { postId: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const key = ["rumor", postId, user?.id ?? "anon"];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => {
      const [counts, mine] = await Promise.all([
        (publicCounts({ data: { fn: "rumor_vote_counts", args: { _post: postId } } }) as Promise<{ data: any[] | null; error: any }>),
        user
          ? supabase.from("rumor_votes").select("believe").eq("post_id", postId).eq("user_id", user.id).maybeSingle()
          : Promise.resolve({ data: null }),
      ]);
      let yes = 0;
      let no = 0;
      for (const r of counts.data ?? []) {
        if (r.believe) yes = Number(r.total);
        else no = Number(r.total);
      }
      return { yes, no, mine: (mine.data as { believe: boolean } | null)?.believe ?? null };
    },
  });

  async function vote(believe: boolean) {
    if (!user) return;
    await supabase
      .from("rumor_votes")
      .upsert({ post_id: postId, user_id: user.id, believe }, { onConflict: "post_id,user_id" });
    await recordFanActivity();
    await qc.invalidateQueries({ queryKey: key });
  }

  const yes = data?.yes ?? 0;
  const no = data?.no ?? 0;
  const total = yes + no;
  const pct = total ? Math.round((yes / total) * 100) : 0;

  return (
    <div className="mt-4 rounded-sm border border-border p-3">
      <p className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">Rumour mill</p>
      <div className="mt-2 flex gap-2">
        {[
          { v: true, label: "I believe it" },
          { v: false, label: "I don't" },
        ].map((o) => (
          <button
            key={o.label}
            type="button"
            disabled={!user}
            onClick={() => void vote(o.v)}
            aria-pressed={data?.mine === o.v}
            className={cn(
              "rounded-sm border px-3 py-1.5 text-xs font-semibold uppercase tracking-widest disabled:opacity-50",
              data?.mine === o.v ? "border-primary bg-primary/15 text-primary" : "border-border",
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-surface-2">
        <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        {total ? `${pct}% believe · ${total} vote${total === 1 ? "" : "s"}` : "No votes yet."}
        {!user && " Sign in to vote."}
      </p>
    </div>
  );
}
