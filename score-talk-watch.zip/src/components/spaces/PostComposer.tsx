import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useAuth, displayNameOf } from "@/hooks/useAuth";
import {
  createSpacePost,
  POST_KINDS,
  rateLimited,
  type PostKind,
  type Space,
} from "@/lib/spaces";
import { cn } from "@/lib/utils";

/** Start a post in a space — text, a tag, and an optional poll. */
export function PostComposer({
  spaces,
  defaultSpaceId,
  signInNext,
}: {
  spaces: Space[];
  defaultSpaceId?: string;
  signInNext: string;
}) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [spaceId, setSpaceId] = useState(defaultSpaceId ?? spaces[0]?.id ?? "");
  const [kind, setKind] = useState<PostKind>("discussion");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [options, setOptions] = useState(["", ""]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="rounded-md border border-border bg-card p-4 text-sm text-muted-foreground">
        <Link
          to="/auth"
          search={{ next: signInNext }}
          className="font-semibold text-primary underline"
        >
          Sign in
        </Link>{" "}
        to post, reply and vote. Anyone can read along.
      </div>
    );
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="w-full rounded-md border border-dashed border-border bg-card px-4 py-3 text-left text-sm text-muted-foreground hover:border-primary/60"
      >
        Start a discussion, ask a question or drop a hot take…
      </button>
    );
  }

  const isPoll = kind === "poll";

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    const t = title.trim();
    if (!t || !spaceId || busy) return;
    if (rateLimited()) {
      setError("You're posting very fast — give it a minute.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await createSpacePost({
        spaceId,
        userId: user.id,
        author: displayNameOf(user),
        title: t,
        body: body.trim(),
        kind,
        ...(isPoll ? { pollOptions: options } : {}),
      });
      setTitle("");
      setBody("");
      setOptions(["", ""]);
      setOpen(false);
      await queryClient.invalidateQueries({ queryKey: ["spaces"] });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not post.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-3 rounded-md border border-border bg-card p-4">
      <div className="flex flex-wrap gap-2">
        {POST_KINDS.map((k) => (
          <button
            key={k.id}
            type="button"
            onClick={() => setKind(k.id)}
            className={cn(
              "scoreboard rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-widest",
              kind === k.id ? "border-primary bg-primary/15 text-primary" : "border-border",
            )}
          >
            {k.label}
          </button>
        ))}
      </div>

      <label className="block text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        Community
        <select
          value={spaceId}
          onChange={(e) => setSpaceId(e.target.value)}
          className="mt-1 w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm font-normal normal-case tracking-normal text-foreground"
        >
          {spaces.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </label>

      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        maxLength={160}
        placeholder="Title"
        className="w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        maxLength={4000}
        rows={4}
        placeholder="Say more (optional)"
        className="w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
      />

      {isPoll && (
        <div className="space-y-2">
          {options.map((o, i) => (
            <input
              key={i}
              value={o}
              onChange={(e) =>
                setOptions((prev) => prev.map((v, idx) => (idx === i ? e.target.value : v)))
              }
              maxLength={80}
              placeholder={`Option ${i + 1}`}
              className="w-full rounded-sm border border-input bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
            />
          ))}
          {options.length < 4 && (
            <button
              type="button"
              onClick={() => setOptions((prev) => [...prev, ""])}
              className="text-xs font-semibold text-primary hover:underline"
            >
              + Add option
            </button>
          )}
        </div>
      )}

      {error && <p className="text-xs text-live">{error}</p>}

      <div className="flex gap-2">
        <button
          type="submit"
          disabled={busy}
          className="scoreboard rounded-sm bg-primary px-4 py-2 text-sm font-bold uppercase tracking-widest text-primary-foreground disabled:opacity-60"
        >
          {busy ? "Posting…" : "Post"}
        </button>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="rounded-sm border border-border px-4 py-2 text-sm"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
