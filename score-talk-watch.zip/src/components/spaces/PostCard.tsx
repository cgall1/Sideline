import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { kindLabel, relativeTime, type SpacePost } from "@/lib/spaces";

export function PostCard({
  post,
  onVote,
  canVote,
  showSpace = true,
}: {
  post: SpacePost;
  onVote: () => void;
  canVote: boolean;
  showSpace?: boolean;
}) {
  return (
    <article className="flex gap-3 rounded-md border border-border bg-card p-4">
      <div className="flex flex-col items-center gap-1">
        <button
          onClick={onVote}
          disabled={!canVote}
          aria-pressed={post.votedByMe}
          aria-label="Upvote"
          className={cn(
            "rounded-sm border px-2 py-1 text-sm font-bold transition-colors",
            post.votedByMe
              ? "border-primary bg-primary/15 text-primary"
              : "border-border text-muted-foreground hover:border-primary/50",
            !canVote && "opacity-60",
          )}
        >
          ▲
        </button>
        <span className="scoreboard text-sm font-bold tabular-nums">{post.votes}</span>
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <span className="scoreboard rounded-sm bg-surface-2 px-1.5 py-0.5 font-bold uppercase tracking-widest">
            {kindLabel(post.kind)}
          </span>
          {showSpace && post.spaceSlug && (
            <Link
              to="/s/$slug"
              params={{ slug: post.spaceSlug }}
              className="font-semibold text-primary hover:underline"
            >
              {post.spaceName}
            </Link>
          )}
          <span>·</span>
          <Link to="/fan/$fanId" params={{ fanId: post.userId }} className="hover:underline">
            {post.author}
          </Link>
          <span>· {relativeTime(post.createdAt)}</span>
        </div>

        <h3 className="mt-1.5 text-lg font-bold leading-snug">
          <Link to="/post/$postId" params={{ postId: post.id }} className="hover:underline">
            {post.title}
          </Link>
        </h3>
        {post.body && (
          <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{post.body}</p>
        )}

        <Link
          to="/post/$postId"
          params={{ postId: post.id }}
          className="mt-2 inline-block text-xs font-semibold text-muted-foreground hover:text-foreground"
        >
          💬 {post.replies} {post.replies === 1 ? "reply" : "replies"}
        </Link>
      </div>
    </article>
  );
}
