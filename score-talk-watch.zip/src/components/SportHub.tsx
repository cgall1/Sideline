import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { sportEventsQueryOptions, sportNewsQueryOptions } from "@/lib/feed";
import { VideoReel } from "@/components/VideoReel";
import { TeamChat } from "@/components/TeamChat";
import { SPORT_TRIVIA } from "@/data/sport-trivia";
import { historyBySlug } from "@/data/history";
import type { SportMeta } from "@/lib/individual-sports.functions";
import { useTrackHubVisit } from "@/lib/visits";

function when(iso: string) {
  if (!iso) return "TBD";
  return new Date(iso).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

/** Shared hub layout for the individual sports: tennis, UFC, golf and NASCAR. */
export function SportHub({ sport }: { sport: SportMeta }) {
  const { data: events = [], isLoading } = useQuery(sportEventsQueryOptions(sport.id));
  const { data: news = [] } = useQuery(sportNewsQueryOptions(sport.id));
  const [openQuestion, setOpenQuestion] = useState<string | null>(null);
  const history = historyBySlug(sport.id === "ufc" ? "ufc" : sport.id);
  useTrackHubVisit(`/${sport.id}`, `${sport.name} hub`);

  const live = events.filter((e) => e.state === "in");
  const rest = events.filter((e) => e.state !== "in");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="scoreboard text-4xl font-bold uppercase tracking-wide">{sport.name}</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">{sport.blurb}</p>

      <div className="mt-4 flex flex-wrap gap-3 text-sm">
        {history && (
          <Link
            to="/history/$slug"
            params={{ slug: history.slug }}
            className="scoreboard rounded-sm border border-border px-3 py-1 uppercase tracking-widest text-muted-foreground hover:text-foreground"
          >
            {sport.name} history
          </Link>
        )}
        <Link
          to="/on-this-day"
          className="scoreboard rounded-sm border border-border px-3 py-1 uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          On this day
        </Link>
        <Link
          to="/community"
          className="scoreboard rounded-sm border border-border px-3 py-1 uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          Fan community
        </Link>
        <Link
          to="/odds"
          search={{ league: "nfl" as const }}
          className="scoreboard rounded-sm border border-border px-3 py-1 uppercase tracking-widest text-muted-foreground hover:text-foreground"
        >
          Win probabilities
        </Link>
      </div>

      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
          {sport.id === "golf" ? "Tournaments" : sport.id === "nascar" || sport.id === "f1" ? "Races" : sport.id === "ufc" ? "Fight cards" : sport.id === "boxing" ? "Fights" : "Matches"}
        </h2>
        {isLoading && <p className="mt-2 text-sm text-muted-foreground">Loading live results…</p>}
        {!isLoading && events.length === 0 && (
          <p className="mt-2 rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
            {sport.id === "boxing"
              ? "No fight card in the live feed right now — the latest boxing headlines are below."
              : "Nothing on the schedule right now — results appear here as soon as the next event starts."}
          </p>
        )}
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {[...live, ...rest].slice(0, 24).map((event) => (
            <article key={event.id} className="rounded-md border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <h3 className="scoreboard text-lg font-semibold uppercase tracking-wide">{event.name}</h3>
                <span
                  className={`scoreboard shrink-0 text-xs font-semibold uppercase tracking-widest ${
                    event.state === "in" ? "live-dot text-[color:var(--live)]" : "text-muted-foreground"
                  }`}
                >
                  {event.status}
                </span>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {when(event.date)}
                {event.venue ? ` · ${event.venue}` : ""}
                {event.location ? ` · ${event.location}` : ""}
              </p>
              {event.competitors.length > 0 && (
                <ul className="mt-3 space-y-1 text-sm">
                  {event.competitors.map((c, i) => (
                    <li key={`${event.id}-${i}`} className="flex justify-between gap-3">
                      <span className={c.winner ? "font-semibold text-foreground" : "text-muted-foreground"}>
                        {c.name}
                      </span>
                      <span className="scoreboard text-muted-foreground">{c.detail}</span>
                    </li>
                  ))}
                </ul>
              )}
              {event.note && <p className="mt-2 text-xs text-muted-foreground">{event.note}</p>}
              {event.link && (
                <a
                  href={event.link}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-block text-xs font-semibold uppercase tracking-widest text-primary"
                >
                  Full detail
                </a>
              )}
            </article>
          ))}
        </div>
      </section>

      <VideoReel
        league={sport.id}
        heading={`${sport.name} highlight reel`}
        intro={`The latest clips from the official ${sport.name} video channels, refreshed automatically.`}
      />

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{sport.name} news</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {news.slice(0, 12).map((item) => (
            <a
              key={item.id}
              href={item.url}
              target="_blank"
              rel="noreferrer"
              className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary"
            >
              <h3 className="font-semibold text-foreground">{item.headline}</h3>
              {item.description && (
                <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">{item.description}</p>
              )}
            </a>
          ))}
          {news.length === 0 && (
            <p className="text-sm text-muted-foreground">Headlines load as soon as the wire updates.</p>
          )}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">{sport.name} trivia</h2>
        <div className="mt-4 space-y-2">
          {SPORT_TRIVIA[sport.id].map((q) => (
            <div key={q.id} className="rounded-md border border-border bg-card p-4">
              <button
                onClick={() => setOpenQuestion(openQuestion === q.id ? null : q.id)}
                className="w-full text-left font-semibold text-foreground"
              >
                {q.question}
              </button>
              {openQuestion === q.id && <p className="mt-2 text-sm text-muted-foreground">{q.answer}</p>}
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Fan chat</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Talk through the action with other {sport.name} fans.
        </p>
        <div className="mt-4">
          <TeamChat threadId={`sport-${sport.id}`} teamName={sport.name} signInNext={`/${sport.id}`} />
        </div>
      </section>
    </div>
  );
}
