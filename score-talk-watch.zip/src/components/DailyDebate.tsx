import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { debatesQueryOptions, voteDebate, type Debate } from "@/lib/daily";
import { cn } from "@/lib/utils";

function share(total: number, votes: number) {
  return total === 0 ? 0 : Math.round((votes / total) * 100);
}

export function DebateCard({ debate, compact = false }: { debate: Debate; compact?: boolean }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const total = debate.votesA + debate.votesB;

  const pick = async (side: "a" | "b") => {
    if (!user) return;
    await voteDebate(debate.id, user.id, side);
    await queryClient.invalidateQueries({ queryKey: ["debates"] });
    await queryClient.invalidateQueries({ queryKey: ["fan-standing"] });
  };

  return (
    <article className="rounded-md border border-border bg-card p-5">
      <p className="scoreboard text-[11px] font-bold uppercase tracking-widest text-primary">
        Daily debate · {debate.date}
        {debate.league ? ` · ${debate.league}` : ""}
      </p>
      <h3 className="mt-2 text-xl font-bold">{debate.question}</h3>
      {!compact && debate.context && (
        <p className="mt-2 text-sm text-muted-foreground">{debate.context}</p>
      )}
      {debate.suggestedBy && (
        <p className="mt-1 text-[11px] font-medium text-primary">Suggested by @{debate.suggestedBy}</p>
      )}

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {(["a", "b"] as const).map((side) => {
          const label = side === "a" ? debate.sideA : debate.sideB;
          const votes = side === "a" ? debate.votesA : debate.votesB;
          const chosen = debate.myVote === side;
          return (
            <button
              key={side}
              type="button"
              onClick={() => pick(side)}
              disabled={!user}
              className={cn(
                "relative overflow-hidden rounded-sm border px-4 py-3 text-left text-sm font-semibold transition-colors",
                chosen ? "border-primary text-foreground" : "border-border hover:border-primary/60",
                !user && "cursor-not-allowed opacity-80",
              )}
            >
              <span
                aria-hidden="true"
                className="absolute inset-y-0 left-0 bg-primary/15"
                style={{ width: `${share(total, votes)}%` }}
              />
              <span className="relative flex items-center justify-between gap-3">
                <span>{label}</span>
                <span className="text-xs text-muted-foreground">
                  {share(total, votes)}% · {votes}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
        <span>
          {total} vote{total === 1 ? "" : "s"}
        </span>
        {!user && <span>Sign in to pick a side.</span>}
        {debate.link && (
          <a href={debate.link} className="font-semibold text-primary underline">
            Read the background
          </a>
        )}
        <Link to="/daily" className="font-semibold text-primary underline">
          All debates
        </Link>
      </div>
    </article>
  );
}

/** Today's debate, ready to drop on any page. Renders nothing until one exists. */
export function TodaysDebate({ compact = false }: { compact?: boolean }) {
  const { user } = useAuth();
  const { data } = useQuery(debatesQueryOptions(user?.id ?? null));
  const debate = data?.[0];
  if (!debate) return null;
  return <DebateCard debate={debate} compact={compact} />;
}
