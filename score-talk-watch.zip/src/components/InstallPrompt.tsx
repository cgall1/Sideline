import { useEffect, useState } from "react";

interface InstallEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
}

const DISMISS_KEY = "sideline-install-dismissed";

/** Offers "add to home screen" when the browser says the app is installable. */
export function InstallPrompt() {
  const [event, setEvent] = useState<InstallEvent | null>(null);

  useEffect(() => {
    if (localStorage.getItem(DISMISS_KEY) === "1") return;
    const handler = (e: Event) => {
      e.preventDefault();
      setEvent(e as InstallEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!event) return null;

  const dismiss = () => {
    localStorage.setItem(DISMISS_KEY, "1");
    setEvent(null);
  };

  return (
    <div className="fixed inset-x-3 bottom-20 z-50 rounded-md border border-border bg-card p-4 shadow-lg md:inset-x-auto md:right-4 md:bottom-4 md:w-80">
      <p className="text-sm font-semibold">Install Sideline</p>
      <p className="mt-1 text-xs text-muted-foreground">
        Add Sideline to your home screen for instant scores.
      </p>
      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={async () => {
            await event.prompt();
            await event.userChoice;
            setEvent(null);
          }}
          className="scoreboard rounded-sm bg-primary px-3 py-1 text-xs font-bold uppercase tracking-widest text-primary-foreground"
        >
          Install
        </button>
        <button
          type="button"
          onClick={dismiss}
          className="scoreboard rounded-sm border border-border px-3 py-1 text-xs uppercase tracking-widest text-muted-foreground"
        >
          Not now
        </button>
      </div>
    </div>
  );
}
