import { LEAGUES, type LeagueId } from "@/data/sports";
import { cn } from "@/lib/utils";

export const leagueAccent: Record<LeagueId, string> = {
  nfl: "bg-league-nfl text-primary-foreground",
  nba: "bg-league-nba text-primary-foreground",
  wnba: "bg-league-wnba text-primary-foreground",
  nhl: "bg-league-nhl text-primary-foreground",
  mlb: "bg-league-mlb text-primary-foreground",
  mls: "bg-league-mls text-primary-foreground",
  intl: "bg-league-intl text-primary-foreground",
  cfb: "bg-league-cfb text-primary-foreground",
  cbb: "bg-league-cbb text-primary-foreground",
  chk: "bg-league-chk text-primary-foreground",
  cbs: "bg-league-chk text-primary-foreground",
  nwsl: "bg-league-nwsl text-primary-foreground",
  sball: "bg-league-sball text-primary-foreground",
  vball: "bg-league-vball text-primary-foreground",
};

export const leagueText: Record<LeagueId, string> = {
  nfl: "text-league-nfl",
  nba: "text-league-nba",
  wnba: "text-league-wnba",
  nhl: "text-league-nhl",
  mlb: "text-league-mlb",
  mls: "text-league-mls",
  intl: "text-league-intl",
  cfb: "text-league-cfb",
  cbb: "text-league-cbb",
  chk: "text-league-chk",
  cbs: "text-league-chk",
  nwsl: "text-league-nwsl",
  sball: "text-league-sball",
  vball: "text-league-vball",
};

export function LeagueBadge({ league }: { league: LeagueId }) {
  return (
    <span
      className={cn(
        "scoreboard rounded-sm px-1.5 py-0.5 text-[0.7rem] font-bold uppercase tracking-widest",
        leagueAccent[league],
      )}
    >
      {league === "intl" ? "Intl" : league === "cfb" ? "NCAAF" : league === "cbb" ? "NCAAM" : league === "chk" ? "NCAAH" : league === "cbs" ? "CBASE" : league}
    </span>
  );
}

export function LeagueFilter({
  value,
  onChange,
  includeAll = true,
}: {
  value: LeagueId | "all";
  onChange: (league: LeagueId | "all") => void;
  includeAll?: boolean;
}) {
  const options: (LeagueId | "all")[] = includeAll
    ? ["all", ...LEAGUES.map((l) => l.id)]
    : LEAGUES.map((l) => l.id);

  return (
    <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Filter by league">
      {options.map((id) => {
        const active = id === value;
        const label = id === "all" ? "All" : LEAGUES.find((l) => l.id === id)!.short;
        return (
          <button
            key={id}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(id)}
            className={cn(
              "scoreboard rounded-sm border px-3 py-1.5 text-sm font-semibold uppercase tracking-widest transition-colors",
              active
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-surface text-muted-foreground hover:border-primary/50 hover:text-foreground",
            )}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
