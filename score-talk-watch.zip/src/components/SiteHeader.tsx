import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { displayNameOf, useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { LANGUAGES, useI18n, type LangCode } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { NotificationBell } from "@/components/NotificationBell";

const accountClass =
  "scoreboard border border-border px-3 py-1.5 text-[11px] font-bold uppercase text-muted-foreground transition-colors hover:border-foreground hover:text-foreground";

function AccountLink() {
  const { user, loading } = useAuth();
  const { t } = useI18n();

  if (loading) return <span aria-hidden />;

  if (!user) {
    return (
      <Link to="/auth" className={accountClass}>
        {t("account.signIn")}
      </Link>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <span className="scoreboard text-sm font-semibold uppercase tracking-widest text-foreground">
        {displayNameOf(user)}
      </span>
      <button onClick={() => void supabase.auth.signOut()} className={accountClass}>
        {t("account.signOut")}
      </button>
    </div>
  );
}

function LanguagePicker() {
  const { lang, setLang, t } = useI18n();
  return (
    <label className="flex items-center gap-1">
      <span className="sr-only">{t("lang.label")}</span>
      <select
        value={lang}
        onChange={(e) => setLang(e.target.value as LangCode)}
        aria-label={t("lang.label")}
        className="scoreboard border border-border bg-background px-2 py-1.5 text-[11px] font-bold uppercase text-muted-foreground transition-colors hover:text-foreground"
      >
        {LANGUAGES.map((l) => (
          <option key={l.code} value={l.code}>
            {l.label}
          </option>
        ))}
      </select>
    </label>
  );
}

function ThemeToggle() {
  const { theme, toggle } = useTheme();
  const { t } = useI18n();
  return (
    <button onClick={toggle} className={accountClass} aria-label={t("theme.toggle")} title={t("theme.toggle")}>
      {theme === "dark" ? "☀" : "☾"}
    </button>
  );
}

type NavLink = { to: string; key: string };
type NavGroup = { key: string; to: string; children: readonly NavLink[] };
type NavItem = NavLink | NavGroup;

const isGroup = (item: NavItem): item is NavGroup => "children" in item;

const NAV: readonly NavItem[] = [
  { to: "/", key: "nav.home" },
  {
    key: "nav.sports",
    to: "/sports",
    children: [
      { to: "/nfl", key: "nav.nfl" },
      { to: "/college-football", key: "nav.collegefootball" },
      { to: "/nba", key: "nav.nba" },
      { to: "/wnba", key: "nav.wnba" },
      { to: "/college-basketball", key: "nav.collegebasketball" },
      { to: "/college-hockey", key: "nav.collegehockey" },
      { to: "/college-baseball", key: "nav.collegebaseball" },
      { to: "/mlb", key: "nav.mlb" },
      { to: "/nhl", key: "nav.nhl" },
      { to: "/world-soccer", key: "nav.soccer" },
      { to: "/mls", key: "nav.mls" },
      { to: "/nwsl", key: "nav.nwsl" },
      { to: "/cricket", key: "nav.cricket" },
      { to: "/tennis", key: "nav.tennis" },
      { to: "/golf", key: "nav.golf" },
      { to: "/f1", key: "nav.f1" },
      { to: "/nascar", key: "nav.nascar" },
      { to: "/ufc", key: "nav.ufc" },
      { to: "/boxing", key: "nav.boxing" },
    ],
  },
  {
    key: "nav.scores",
    to: "/scores",
    children: [
      { to: "/scores", key: "nav.scores" },
      { to: "/live", key: "nav.live" },
    ],
  },
  { to: "/standings", key: "nav.standings" },
  { to: "/news", key: "nav.news" },
  {
    key: "nav.watchGroup",
    to: "/watch",
    children: [
      { to: "/watch", key: "nav.watch" },
      { to: "/media", key: "nav.media" },
      { to: "/highlights", key: "nav.highlights" },
    ],
  },
  {
    key: "nav.play",
    to: "/predictions",
    children: [
      { to: "/predictions", key: "nav.predictions" },
      { to: "/fantasy", key: "nav.fantasy" },
    ],
  },
  {
    key: "nav.mine",
    to: "/my-teams",
    children: [
      { to: "/my-teams", key: "nav.myteams" },
      { to: "/community", key: "nav.community" },
      { to: "/spaces", key: "nav.spaces" },
      { to: "/daily", key: "nav.daily" },
      { to: "/throwback", key: "nav.throwback" },
      { to: "/offseason", key: "nav.offseason" },
      { to: "/fan-gallery", key: "nav.gallery" },
      { to: "/fan-card", key: "nav.fancard" },
      { to: "/fan-voice", key: "nav.fanvoice" },
      { to: "/crews", key: "nav.crews" },
      { to: "/leaderboards", key: "nav.leaderboards" },
      { to: "/fan-spots", key: "nav.fanspots" },
      { to: "/ask", key: "nav.ask" },
    ],
  },
  {
    key: "nav.knowledge",
    to: "/directory",
    children: [
      { to: "/sports", key: "nav.allsports" },
      { to: "/directory", key: "nav.directory" },
      { to: "/rosters", key: "nav.rosters" },
      { to: "/injuries", key: "nav.injuries" },
      { to: "/history", key: "nav.history" },
    ],
  },
] as const;

/** Small mark shown beside each sport in the Sports menu. */
const ESPN_LEAGUE = "https://a.espncdn.com/i/teamlogos/leagues/500";
const ESPN_MISC = "https://a.espncdn.com/i/espn/misc_logos/500";
const SPORT_LOGO: Record<string, string> = {
  "/nfl": `${ESPN_LEAGUE}/nfl.png`,
  "/nba": `${ESPN_LEAGUE}/nba.png`,
  "/wnba": `${ESPN_LEAGUE}/wnba.png`,
  "/nhl": `${ESPN_LEAGUE}/nhl.png`,
  "/mlb": `${ESPN_LEAGUE}/mlb.png`,
  "/mls": `${ESPN_LEAGUE}/mls.png`,
  "/nwsl": `${ESPN_LEAGUE}/nwsl.png`,
  "/f1": `${ESPN_LEAGUE}/f1.png`,
  "/ufc": `${ESPN_LEAGUE}/ufc.png`,
  "/college-football": `${ESPN_MISC}/ncaa.png`,
  "/college-basketball": `${ESPN_MISC}/ncaa.png`,
  "/college-hockey": `${ESPN_MISC}/ncaa.png`,
  "/college-baseball": `${ESPN_MISC}/ncaa.png`,
  "/nascar": `${ESPN_MISC}/nascar.png`,
};
const SPORT_EMOJI: Record<string, string> = {
  "/world-soccer": "\u26bd",
  "/cricket": "\u{1f3cf}",
  "/tennis": "\u{1f3be}",
  "/golf": "\u26f3",
  "/boxing": "\u{1f94a}",
};

function SportMark({ to }: { to: string }) {
  const logo = SPORT_LOGO[to];
  if (logo) {
    return <img src={logo} alt="" aria-hidden className="h-4 w-4 shrink-0 object-contain" loading="lazy" />;
  }
  const emoji = SPORT_EMOJI[to];
  if (emoji) return <span aria-hidden className="w-4 shrink-0 text-center text-sm leading-none">{emoji}</span>;
  return null;
}

const navLinkClass =
  "scoreboard shrink-0 text-[11px] font-bold uppercase text-muted-foreground transition-colors hover:text-foreground";

function NavDropdown({
  group,
  open,
  onOpen,
  onToggle,
  onHoverIntent,
}: {
  group: NavGroup;
  open: boolean;
  onOpen: () => void;
  onToggle: () => void;
  onHoverIntent: () => void;
}) {
  const { t } = useI18n();
  // When a mouse glides onto the button the menu opens on hover; the click
  // that follows should NOT immediately close what the hover just opened.
  const hoverOpenedAt = useRef(0);
  return (
    <div className="group relative shrink-0" onPointerEnter={onHoverIntent}>
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className={`${navLinkClass} h-auto rounded-none px-0 py-0 hover:bg-transparent`}
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => {
          if (Date.now() - hoverOpenedAt.current < 400) return;
          onToggle();
        }}
        onPointerEnter={(e) => {
          if (e.pointerType !== "mouse") return;
          hoverOpenedAt.current = Date.now();
          onOpen();
        }}
        onFocus={onOpen}
      >
        {t(group.key)} ▾
      </Button>
      <div
        className={`${open ? "visible opacity-100" : "invisible opacity-0"} absolute left-0 top-full z-50 max-h-[70vh] min-w-36 overflow-y-auto border border-border bg-background py-1 shadow-lg transition-opacity`}
      >
        {group.children.map((child) => (
          <Link
            key={child.to}
            to={child.to}
            activeProps={{ className: "text-primary" }}
            className="scoreboard flex items-center gap-2 px-4 py-2 text-[11px] font-bold uppercase text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            onClick={onToggle}
          >
            <SportMark to={child.to} />
            {t(child.key)}
          </Link>
        ))}
      </div>
    </div>
  );
}

function SearchBar() {
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const searchQ = useRouterState({ select: (s) => (s.location.search as { q?: string }).q ?? "" });
  const onSearchPage = pathname === "/search";
  const [value, setValue] = useState(onSearchPage ? searchQ : "");
  const timer = useRef<number | null>(null);

  // Keep the box in sync when the query changes elsewhere (e.g. back/forward).
  useEffect(() => {
    if (onSearchPage) setValue(searchQ);
  }, [onSearchPage, searchQ]);

  const go = (q: string) => {
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = null;
    void navigate({ to: "/search", search: { q } });
  };

  const onChange = (next: string) => {
    setValue(next);
    if (timer.current !== null) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => go(next), 300);
  };

  return (
    <form
      role="search"
      onSubmit={(e) => {
        e.preventDefault();
        go(value);
      }}
      className="relative"
    >
      <svg
        aria-hidden
        viewBox="0 0 24 24"
        className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.5-3.5" strokeLinecap="round" />
      </svg>
      <input
        type="search"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search teams, matches…"
        aria-label="Search Sideline"
        className="h-9 w-36 rounded-md border border-border bg-background pl-8 pr-2 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none sm:w-48 lg:w-60"
      />
    </form>
  );
}

export function SiteHeader() {
  const { t } = useI18n();
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  // Grace period so gliding the pointer across the bar doesn't slam menus shut.
  const closeTimer = useRef<number | null>(null);
  const cancelClose = () => {
    if (closeTimer.current !== null) {
      window.clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
  };
  const scheduleClose = () => {
    cancelClose();
    closeTimer.current = window.setTimeout(() => setOpenGroup(null), 250);
  };
  return (
    <header className="sticky top-0 z-50 border-b border-foreground/15 bg-background/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 lg:grid lg:grid-cols-[1fr_auto_1fr] lg:items-center lg:gap-4 lg:py-5">
        <Link to="/" className="order-1 flex items-baseline justify-center lg:order-2" aria-label="Sideline home">
          <span className="scoreboard text-3xl font-bold uppercase text-foreground sm:text-4xl">Sideline</span>
          <span className="text-3xl font-bold text-primary sm:text-4xl" aria-hidden>.</span>
        </Link>
        <div className="order-2 flex items-center justify-end gap-2 lg:order-3">
          <SearchBar />
          <NotificationBell />
          <LanguagePicker />
          <ThemeToggle />
          <AccountLink />
        </div>
        <nav
          className="order-3 flex flex-wrap items-center gap-x-5 gap-y-3 overflow-visible pb-0.5 lg:order-1 lg:flex-nowrap"
          aria-label="Main"
          onMouseLeave={scheduleClose}
        >
          {NAV.map((item) =>
            isGroup(item) ? (
              <NavDropdown
                key={item.key}
                group={item}
                open={openGroup === item.key}
                onOpen={() => {
                  cancelClose();
                  setOpenGroup(item.key);
                }}
                onToggle={() => setOpenGroup((current) => (current === item.key ? null : item.key))}
                onHoverIntent={cancelClose}
              />
            ) : (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                activeProps={{ className: "text-primary" }}
                className={navLinkClass}
                onMouseEnter={scheduleClose}
              >
                {t(item.key)}
              </Link>
            ),
          )}
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const { t } = useI18n();
  return (
    <footer className="mt-20 border-t border-foreground bg-foreground text-background">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-[1fr_auto] md:items-end">
        <div>
          <p className="scoreboard text-3xl font-bold uppercase">Sideline<span className="text-primary">.</span></p>
          <p className="mt-3 max-w-xl text-sm opacity-70">{t("footer.tagline")}</p>
          <p className="mt-4 text-[11px] font-bold uppercase opacity-50">
            <a href="/privacy" className="underline-offset-4 hover:underline">Privacy Policy</a>
          </p>
        </div>
        <p className="text-[11px] font-bold uppercase opacity-50">{t("footer.note")}</p>
      </div>
    </footer>
  );
}
