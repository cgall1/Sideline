import { Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { soccerHighlightsQueryOptions } from "@/lib/feed";
import { SOCCER_COMPETITIONS, type SoccerCompetition } from "@/data/soccer";
import type { SoccerMatch } from "@/lib/soccer.functions";
import { cn } from "@/lib/utils";
import { VideoReel } from "@/components/VideoReel";

/** Official video channel key for each competition. */
const VIDEO_KEY: Record<string, string> = {
  "premier-league-highlights": "epl",
  "laliga-highlights": "laliga",
  "bundesliga-highlights": "bundesliga",
  "serie-a-highlights": "seriea",
  "ligue-1-highlights": "ligue1",
  "champions-league-highlights": "ucl",
};

function monthLabel(key: string): string {
  const [y, m] = key.split("-");
  if (!y || !m) return "Fixtures";
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
}

function groupByMonth(matches: SoccerMatch[]): { key: string; matches: SoccerMatch[] }[] {
  const map = new Map<string, SoccerMatch[]>();
  for (const m of matches) {
    const list = map.get(m.monthKey);
    if (list) list.push(m);
    else map.set(m.monthKey, [m]);
  }
  return [...map.entries()]
    .sort((a, b) => b[0].localeCompare(a[0]))
    .map(([key, list]) => ({ key, matches: list }));
}

export function SoccerHighlights({ competition }: { competition: SoccerCompetition }) {
  const { data } = useSuspenseQuery(soccerHighlightsQueryOptions(competition.slug));
  const months = groupByMonth(data.matches);
  const others = SOCCER_COMPETITIONS.filter((c) => c.slug !== competition.slug);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        <Link to="/media" className="hover:text-foreground">
          Media
        </Link>{" "}
        / {competition.name} Highlights
      </p>
      <h1 className="scoreboard mt-1 text-4xl font-bold uppercase tracking-wide">
        {competition.name} Highlights
      </h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{competition.blurb}</p>

      <div className="mt-4 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
        <Link to="/world-soccer" className="text-primary underline">
          World soccer hub
        </Link>
        <Link to="/scores" search={{ league: "intl" }} className="text-primary underline">
          Live soccer scores
        </Link>
        <Link to="/directory/$league" params={{ league: "intl" }} className="text-primary underline">
          Every club
        </Link>
        <Link to="/soccer-chat" className="text-primary underline">
          Soccer fan chat
        </Link>
        <Link
          to="/soccer-rankings/$competition"
          params={{ competition: competition.slug.replace(/-highlights$/, "") }}
          className="text-primary underline"
        >
          {competition.short} rankings
        </Link>
      </div>

      {VIDEO_KEY[competition.slug] && (
        <VideoReel
          league={VIDEO_KEY[competition.slug]!}
          heading={`${competition.name} highlight reel`}
          intro={`Goals, saves and match recaps straight from the official ${competition.name} video channel.`}
        />
      )}

      {months.map((group) => (
        <section key={group.key} className="mt-8">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            {monthLabel(group.key)}
          </h2>
          <ul className="mt-3 space-y-2">
            {group.matches.map((m) => (
              <li
                key={m.id}
                className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/40"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-bold">
                      {m.away} at {m.home}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {m.dayLabel}
                      {m.venue ? ` · ${m.venue}` : ""}
                      {m.city ? `, ${m.city}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    {m.status !== "scheduled" && (
                      <span className="scoreboard text-xl font-bold tabular-nums">
                        {m.awayScore}–{m.homeScore}
                      </span>
                    )}
                    <span
                      className={cn(
                        "scoreboard text-xs font-bold uppercase tracking-widest",
                        m.status === "live" ? "live-dot text-live" : "text-muted-foreground",
                      )}
                    >
                      {m.detail || (m.status === "final" ? "Full time" : "Scheduled")}
                    </span>
                  </div>
                </div>
                <a
                  href={m.highlightUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-2 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
                >
                  ▶ Watch {m.away} vs {m.home} highlights
                </a>
              </li>
            ))}
          </ul>
        </section>
      ))}

      {!months.length && (
        <p className="mt-8 text-muted-foreground">
          No {competition.name} matches in the current window — check back on the next matchday.
        </p>
      )}

      {data.stories.length > 0 && (
        <section className="mt-10">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            {competition.name} video &amp; analysis
          </h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {data.stories.slice(0, 12).map((s) => (
              <a
                key={s.id}
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
              >
                <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                  {s.type}
                </span>
                <h3 className="mt-1 text-lg font-bold leading-snug">{s.headline}</h3>
                <p className="mt-1.5 flex-1 text-sm text-muted-foreground">{s.summary}</p>
              </a>
            ))}
          </div>
        </section>
      )}

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
          More competition highlights
        </h2>
        <div className="mt-3 flex flex-wrap gap-3 text-sm">
          {others.map((c) => (
            <a
              key={c.slug}
              href={`/media/${c.slug}`}
              className="rounded-md border border-border bg-card px-3 py-2 font-semibold text-primary underline"
            >
              {c.name} highlights
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
