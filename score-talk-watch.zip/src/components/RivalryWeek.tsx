import { Link } from "@tanstack/react-router";
import type { Game } from "@/data/sports";
import { RIVALRIES } from "@/data/legacy";
import { useFavorites } from "@/lib/favorites";

const norm = (s: string) => s.toLowerCase();

/** Rivalry week: upcoming/live games that are a famous rivalry or pit two of your followed teams against each other. */
export function RivalryWeek({ games }: { games: Game[] }) {
  const { favorites } = useFavorites();
  const followed = (favorites ?? []).map((f) => norm(f.name));
  const isFollowed = (n: string) => followed.some((f) => norm(n).includes(f) || f.includes(norm(n)));

  const hits = games
    .filter((g) => g.status !== "final")
    .map((g) => {
      const h = norm(g.home.name);
      const a = norm(g.away.name);
      const rivalry = RIVALRIES.find((r) => {
        const [x, y] = r.name.split(/\s+vs\.?\s+/i).map(norm);
        if (!x || !y) return false;
        return (h.includes(x) && a.includes(y)) || (h.includes(y) && a.includes(x));
      });
      const both = isFollowed(g.home.name) && isFollowed(g.away.name);
      return rivalry || both ? { g, rivalry } : null;
    })
    .filter(Boolean)
    .slice(0, 3) as { g: Game; rivalry?: (typeof RIVALRIES)[number] }[];

  if (!hits.length) return null;
  return (
    <section className="mt-4 rounded-lg border-2 border-primary bg-card p-4">
      <h2 className="font-display text-lg font-bold">🔥 Rivalry week</h2>
      <ul className="mt-2 space-y-3">
        {hits.map(({ g, rivalry }) => (
          <li key={g.id}>
            <Link to="/game/$league/$gameId" params={{ league: g.league, gameId: g.id }} className="font-semibold hover:underline">
              {g.away.name} at {g.home.name}
            </Link>
            <span className="ml-2 text-xs text-muted-foreground">{g.status === "live" ? `LIVE · ${g.clock}` : g.startLabel}</span>
            {rivalry ? (
              <p className="mt-0.5 text-sm text-muted-foreground">
                {rivalry.name}, since {rivalry.since}. {rivalry.headToHead}{" "}
                <Link to="/rivalries/$slug" params={{ slug: rivalry.slug }} className="text-primary hover:underline">History →</Link>
              </p>
            ) : (
              <p className="mt-0.5 text-sm text-muted-foreground">Two teams you follow meet — pick a side in the match thread.</p>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}
