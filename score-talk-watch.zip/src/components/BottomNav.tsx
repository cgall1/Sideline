import { Link } from "@tanstack/react-router";

const ITEMS = [
  { to: "/", label: "Home", icon: "⌂" },
  { to: "/scores", label: "Scores", icon: "◉" },
  { to: "/news", label: "News", icon: "▤" },
  { to: "/directory", label: "Sports", icon: "≡" },
  { to: "/community", label: "Chat", icon: "✦" },
] as const;

/** Native-feeling bottom navigation shown on phones only. */
export function BottomNav() {
  return (
    <nav
      aria-label="Mobile"
      className="fixed inset-x-0 bottom-0 z-50 border-t border-foreground bg-background/95 backdrop-blur md:hidden"
    >
      <ul className="grid grid-cols-5">
        {ITEMS.map((item) => (
          <li key={item.to}>
            <Link
              to={item.to}
              activeProps={{ className: "text-primary" }}
              className="flex flex-col items-center gap-1 py-2 text-[10px] font-bold uppercase text-muted-foreground"
            >
              <span aria-hidden className="text-base leading-none">
                {item.icon}
              </span>
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
