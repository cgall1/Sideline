import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import type { Game, LeagueId } from "@/data/sports";
import { raceRule } from "@/data/why";
import { gamesQueryOptions, standingsQueryOptions } from "@/lib/feed";

function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
}

function same(a: string, b: string): boolean {
  const x = a.toLowerCase();
  const y = b.toLowerCase();
  if (x === y) return true;
  const nick = y.split(" ").slice(-1)[0] ?? "";
  return nick.length > 3 && x.includes(nick);
}

function winnerOf(g: Game) {
  if (g.status !== "final" || g.homeScore === g.awayScore) return null;
  return g.homeScore > g.awayScore ? g.home : g.away;
}

/** "Why today matters": the results of the day that actually moved a race. */
export function WhyToday({ league }: { league: LeagueId }) {
  const rule = raceRule(league);
  const { data: games } = useQuery(gamesQueryOptions(league));
  const { data: standings } = useQuery(standingsQueryOptions(league));

  const rows = standings?.rows ?? [];
  if (!rows.length || !games?.length) return null;

  const items = games
    .map((g) => {
      const win = winnerOf(g);
      if (!win) return null;
      const idx = rows.findIndex((r) => same(r.team, win.name));
      if (idx < 0) return null;
      const row = rows[idx]!;
      const inRace = idx + 1 <= rule.cut;
      return {
        game: g,
        rank: idx + 1,
        text: `${win.name} win and sit ${ordinal(idx + 1)} at ${row.w}-${row.l}${
          row.otl ? `-${row.otl}` : ""
        } — ${inRace ? `inside ${rule.cutLabel}` : `chasing ${rule.cutLabel}`}.`,
      };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null)
    .sort((a, b) => a.rank - b.rank)
    .slice(0, 3);

  if (!items.length) return null;

  return (
    <section className="mt-8 rounded-md border border-primary/40 bg-card p-5">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-primary">
        Why today matters
      </h2>
      <ul className="mt-3 space-y-2">
        {items.map((i) => (
          <li key={i.game.id} className="text-sm leading-relaxed">
            {i.text}{" "}
            <Link
              to="/game/$league/$gameId"
              params={{ league, gameId: i.game.id }}
              className="font-semibold text-primary underline"
            >
              Match centre
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
