import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { publicCounts } from "@/lib/public-counts.functions";
import { cn } from "@/lib/utils";

const MOODS = [
  { id: "confident", emoji: "😎", label: "Confident" },
  { id: "hyped", emoji: "🔥", label: "Hyped" },
  { id: "nervous", emoji: "😬", label: "Nervous" },
  { id: "furious", emoji: "😤", label: "Furious" },
] as const;

/** Live "how fans feel" meter plus the latest hot takes from the match thread. */
export function FanMood({ gameId, live, signInNext }: { gameId: string; live: boolean; signInNext: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [mine, setMine] = useState<string | null>(null);
  const refresh = live ? 15000 : 60000;

  const { data: counts = {} } = useQuery({
    queryKey: ["game-mood", gameId],
    refetchInterval: refresh,
    queryFn: async () => {
      const res = await publicCounts({ data: { fn: "game_mood_counts", args: { _game: gameId } } });
      const out: Record<string, number> = {};
      for (const r of res.data ?? []) out[r.mood] = Number(r.total);
      return out;
    },
  });

  const { data: takes = [] } = useQuery({
    queryKey: ["game-takes", gameId],
    refetchInterval: refresh,
    queryFn: async () => {
      const { data } = await supabase
        .from("community_posts")
        .select("id, body, created_at")
        .eq("game_id", gameId)
        .order("created_at", { ascending: false })
        .limit(4);
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!user) return setMine(null);
    supabase
      .from("game_moods")
      .select("mood")
      .eq("game_id", gameId)
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => setMine(data?.mood ?? null));
  }, [user, gameId]);

  async function pick(mood: string) {
    if (!user) return;
    setMine(mood);
    await supabase
      .from("game_moods")
      .upsert({ game_id: gameId, user_id: user.id, mood, updated_at: new Date().toISOString() });
    qc.invalidateQueries({ queryKey: ["game-mood", gameId] });
  }

  const total = MOODS.reduce((s, m) => s + (counts[m.id] ?? 0), 0);

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center justify-between">
        <h2 className="scoreboard text-lg font-bold uppercase tracking-wide">How fans feel</h2>
        {live && (
          <span className="flex items-center gap-1 text-xs font-semibold uppercase text-primary">
            <span className="h-2 w-2 animate-pulse rounded-full bg-primary" /> Live
          </span>
        )}
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {MOODS.map((m) => {
          const n = counts[m.id] ?? 0;
          const pct = total ? Math.round((n / total) * 100) : 0;
          return (
            <button
              key={m.id}
              type="button"
              disabled={!user}
              onClick={() => pick(m.id)}
              className={cn(
                "relative overflow-hidden rounded-md border px-3 py-2 text-left text-sm transition",
                mine === m.id ? "border-primary" : "border-border hover:border-primary/60",
                !user && "cursor-default",
              )}
            >
              <span className="absolute inset-y-0 left-0 bg-primary/15" style={{ width: `${pct}%` }} />
              <span className="relative flex items-center justify-between gap-2">
                <span>
                  {m.emoji} {m.label}
                </span>
                <span className="font-semibold tabular-nums">{pct}%</span>
              </span>
            </button>
          );
        })}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        {total} {total === 1 ? "fan" : "fans"} checked in.{" "}
        {!user && (
          <>
            <Link to="/auth" search={{ next: signInNext }} className="font-semibold text-primary underline">
              Sign in
            </Link>{" "}
            to add your mood.
          </>
        )}
      </p>

      {takes.length > 0 && (
        <div className="mt-4 border-t border-border pt-3">
          <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Hot takes</h3>
          <ul className="mt-2 space-y-1.5">
            {takes.map((t) => (
              <li key={t.id} className="line-clamp-2 text-sm">
                “{t.body}”
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
