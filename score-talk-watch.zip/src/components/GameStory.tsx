import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getGameStory } from "@/lib/game-story.functions";

/** "The story of the game" — shown once a game is final. */
export function GameStory({ league, gameId, final }: { league: string; gameId: string; final: boolean }) {
  const fn = useServerFn(getGameStory);
  const { data, isLoading } = useQuery({
    queryKey: ["game-story", gameId],
    queryFn: () => fn({ data: { league, gameId } }),
    enabled: final,
    staleTime: Infinity,
    retry: false,
  });
  if (!final) return null;
  if (!isLoading && !data?.body) return null;
  return (
    <section className="mt-4 rounded-md border border-border bg-card p-4">
      <p className="text-[10px] font-bold uppercase tracking-widest text-primary">The story of the game</p>
      {isLoading ? (
        <div className="mt-2 space-y-2">
          <div className="h-3 w-full animate-pulse rounded bg-muted" />
          <div className="h-3 w-4/5 animate-pulse rounded bg-muted" />
        </div>
      ) : (
        <div className="mt-2 space-y-2 text-sm leading-relaxed">
          {data!.body!.split(/\n\n+/).map((p, i) => (
            <p key={i}>{p}</p>
          ))}
          <p className="text-[10px] text-muted-foreground">Written automatically from the official box score.</p>
        </div>
      )}
    </section>
  );
}
