import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { pulseQueryOptions, setPulse, type Stance } from "@/lib/fanvoice";

const LABELS: Record<Stance, string> = { agree: "Agree", disagree: "Disagree", unsure: "Unsure" };

export function FanPulse({ type, id, question }: { type: "news" | "game" | "why"; id: string; question: string }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const opts = pulseQueryOptions(type, id, user?.id ?? null);
  const { data } = useQuery(opts);
  const counts = data?.counts ?? { agree: 0, disagree: 0, unsure: 0 };
  const total = counts.agree + counts.disagree + counts.unsure;

  async function pick(s: Stance) {
    if (!user) return;
    await setPulse(type, id, user.id, s);
    await qc.invalidateQueries({ queryKey: opts.queryKey });
  }

  return (
    <div className="rounded-md border border-border bg-card p-3">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">Fan pulse</p>
      <p className="mt-1 text-sm font-medium">{question}</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {(Object.keys(LABELS) as Stance[]).map((s) => {
          const pct = total ? Math.round((counts[s] / total) * 100) : 0;
          return (
            <button
              key={s}
              type="button"
              disabled={!user}
              onClick={() => pick(s)}
              className={`rounded-full border px-3 py-1 text-xs ${data?.mine === s ? "border-primary bg-primary text-primary-foreground" : "border-border hover:bg-muted"} disabled:opacity-60`}
            >
              {LABELS[s]} {total > 0 && `· ${pct}%`}
            </button>
          );
        })}
      </div>
      <p className="mt-1.5 text-[11px] text-muted-foreground">
        {user ? `${total} fan${total === 1 ? "" : "s"} answered` : "Sign in to add your voice"}
      </p>
    </div>
  );
}
