import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  createPost,
  deletePost,
  relativeTime,
  threadPostsQueryOptions,
  toggleLike,
} from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";

/** A live fan thread for one team, saved under a stable team thread id. */
export function TeamChat({
  threadId,
  teamName,
  signInNext,
}: {
  threadId: string;
  teamName: string;
  signInNext: string;
}) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const { data: posts = [] } = useQuery(threadPostsQueryOptions(userId));
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  const thread = posts.filter((p) => p.gameId === threadId).slice().reverse();

  useEffect(() => {
    const channel = supabase
      .channel(`team-chat-${threadId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "community_posts" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "post_likes" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient, threadId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [thread.length]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !userId || busy) return;
    setBusy(true);
    try {
      await createPost(userId, threadId, text);
      setDraft("");
      await queryClient.invalidateQueries({ queryKey: ["community"] });
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mt-10">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
        {teamName} fan thread
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Talk lineups, trades and game nights with other {teamName} fans. Posts appear live.
      </p>

      <div className="mt-4 space-y-3">
        {thread.map((post) => (
          <article key={post.id} className="rounded-md border border-border bg-card p-4">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-semibold">
                {post.author}{" "}
                <span className="text-xs font-normal text-muted-foreground">· {post.team}</span>
              </p>
              <span className="text-xs text-muted-foreground">{relativeTime(post.createdAt)}</span>
            </div>
            <p className="mt-2 text-sm">{post.body}</p>
            <div className="mt-3 flex items-center gap-4 text-xs">
              <button
                type="button"
                disabled={!userId}
                onClick={async () => {
                  if (!userId) return;
                  await toggleLike(post.id, userId, post.likedByMe);
                  await queryClient.invalidateQueries({ queryKey: ["community"] });
                }}
                className="font-semibold uppercase tracking-widest text-primary disabled:opacity-50"
              >
                ♥ {post.likes}
              </button>
              {userId === post.userId && (
                <button
                  type="button"
                  onClick={async () => {
                    await deletePost(post.id);
                    await queryClient.invalidateQueries({ queryKey: ["community"] });
                  }}
                  className="font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
                >
                  Delete
                </button>
              )}
            </div>
          </article>
        ))}
        {!thread.length && (
          <p className="rounded-md border border-border bg-card p-6 text-sm text-muted-foreground">
            No posts yet — start the {teamName} conversation.
          </p>
        )}
        <div ref={endRef} />
      </div>

      {userId ? (
        <form onSubmit={submit} className="mt-4 flex gap-2">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={`Post to the ${teamName} thread`}
            aria-label={`Post to the ${teamName} thread`}
            className="flex-1 rounded-md border border-border bg-card px-3 py-2 text-sm outline-none focus:border-primary"
          />
          <button
            type="submit"
            disabled={busy || !draft.trim()}
            className="scoreboard rounded-md bg-primary px-4 py-2 text-xs font-bold uppercase tracking-widest text-primary-foreground disabled:opacity-50"
          >
            Post
          </button>
        </form>
      ) : (
        <p className="mt-4 text-xs text-muted-foreground">
          <Link
            to="/auth"
            search={{ next: signInNext }}
            className="font-semibold text-primary underline"
          >
            Sign in
          </Link>{" "}
          to join the {teamName} thread.
        </p>
      )}
    </section>
  );
}
