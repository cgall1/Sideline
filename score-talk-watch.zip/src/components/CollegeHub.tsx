import { Link } from "@tanstack/react-router";
import { useQuery, useSuspenseQuery } from "@tanstack/react-query";
import { ARTICLES, type LeagueId } from "@/data/sports";
import { WhyToday } from "@/components/WhyToday";
import {
  gamesQueryOptions,
  leagueInjuriesQueryOptions,
  leagueMovesQueryOptions,
  monthScheduleQueryOptions,
  newsQueryOptions,
  standingsQueryOptions,
} from "@/lib/feed";
import { LeagueBadge } from "@/components/LeagueFilter";
import type { ScheduleGame } from "@/lib/schedule.functions";
import { PredictionChatWidget } from "@/components/PredictionChatWidget";


export function thisMonth(): string {
  return new Date().toISOString().slice(0, 7);
}

/**
 * Current month when it falls inside the season, otherwise the next month that
 * does — so the calendar opens on games instead of an empty off-season month.
 */
export function seasonMonth(months: number[]): string {
  const now = new Date();
  for (let i = 0; i < 12; i += 1) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
    if (months.includes(d.getUTCMonth() + 1)) return d.toISOString().slice(0, 7);
  }
  return now.toISOString().slice(0, 7);
}

export function shiftMonth(month: string, delta: number): string {
  const [y, m] = month.split("-").map(Number);
  return new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1 + delta, 1)).toISOString().slice(0, 7);
}

export function monthLabel(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(Date.UTC(y ?? 2026, (m ?? 1) - 1, 1)));
}

function dayLabel(day: string): string {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${day}T12:00:00Z`));
}

function timeLabel(iso: string): string {
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(
    new Date(iso),
  );
}

const VIDEOS = ARTICLES.filter((a) => a.kind === "video");

function reelFor(league: LeagueId, index: number) {
  const pool = VIDEOS.filter((v) => v.league === league);
  const list = pool.length > 0 ? pool : VIDEOS;
  return list[index % list.length];
}

interface HubProps {
  league: LeagueId;
  month: string;
  heading: string;
  intro: string;
  /** Called when the visitor changes month. */
  onMonth: (month: string) => void;
  /** Months (1-12) the league actually plays in, offered as quick jumps. */
  seasonMonths?: number[];
}

export function CollegeHub({
  league,
  month,
  heading,
  intro,
  onMonth,
  seasonMonths = [],
}: HubProps) {
  const scores = useSuspenseQuery(gamesQueryOptions(league)).data;
  const standings = useSuspenseQuery(standingsQueryOptions(league)).data;
  const schedule = useSuspenseQuery(monthScheduleQueryOptions(league, month)).data;

  const days = [...new Set(schedule.games.map((g: ScheduleGame) => g.day))].sort();

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="flex items-center gap-2">
        <LeagueBadge league={league} />
        <span className="text-xs uppercase tracking-widest text-muted-foreground">
          {standings.live ? "Live feed" : "Season data"}
        </span>
      </div>
      <h1 className="scoreboard mt-2 text-4xl font-bold uppercase tracking-wide">{heading}</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{intro}</p>

      <WhyToday league={league} />


      <section className="mt-8">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Live &amp; recent scores</h2>
        {scores.length === 0 ? (
          <p className="mt-3 rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">
            Scores here come straight from the official league feed, and it isn&apos;t returning any
            games right now — nothing is scheduled in this window, or the feed is briefly
            unavailable. Check the calendar below for the next kickoff.
          </p>
        ) : (
          <ul className="mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {scores.slice(0, 12).map((game) => (
              <li key={game.id} className="rounded-md border border-border bg-card p-4">
                <div className="flex items-center justify-between text-xs uppercase tracking-widest text-muted-foreground">
                  <span>{game.status === "live" ? "Live" : game.status}</span>
                  <span>{game.clock || game.startLabel}</span>
                </div>
                <p className="scoreboard mt-2 text-lg font-bold uppercase tracking-wide">
                  {game.away.abbr} {game.status === "scheduled" ? "" : game.awayScore} @{" "}
                  {game.home.abbr} {game.status === "scheduled" ? "" : game.homeScore}
                </p>
                <p className="mt-1 truncate text-sm text-muted-foreground">
                  {game.away.name} at {game.home.name}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {game.venue}
                  {game.broadcasters?.length ? ` · ${game.broadcasters.join(", ")}` : ""}
                </p>
                <Link
                  to="/game/$league/$gameId"
                  params={{ league, gameId: game.id }}
                  className="mt-2 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
                >
                  Match thread &amp; live poll →
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <LeagueNewsStrip league={league} />

      <section className="mt-10">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
          Standings — {standings.group}
        </h2>
        {!standings.live && (
          <p className="mt-2 rounded-md border border-dashed border-border p-3 text-xs text-muted-foreground">
            The official league table isn&apos;t publishing right now — this is our season table
            until the live feed returns.
          </p>
        )}
        <div className="mt-3 overflow-x-auto rounded-md border border-border bg-card">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-widest text-muted-foreground">
              <tr>
                <th className="px-4 py-2 text-left">Team</th>
                <th className="px-4 py-2 text-right">W</th>
                <th className="px-4 py-2 text-right">L</th>
                <th className="px-4 py-2 text-right">Pct</th>
                <th className="px-4 py-2 text-right">Streak</th>
              </tr>
            </thead>
            <tbody>
              {standings.rows.map((row, ri) => (
                <tr key={`${row.team}-${ri}`} className="border-t border-border">
                  <td className="px-4 py-2 font-semibold">{row.team}</td>
                  <td className="px-4 py-2 text-right">{row.w}</td>
                  <td className="px-4 py-2 text-right">{row.l}</td>
                  <td className="px-4 py-2 text-right">{row.pct}</td>
                  <td className="px-4 py-2 text-right text-muted-foreground">{row.streak}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Link
          to="/standings-calculator"
          search={{ league }}
          className="mt-3 inline-block text-xs font-semibold uppercase tracking-widest text-primary"
        >
          Rank your own team →
        </Link>
      </section>

      <section className="mt-10">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">
            Season calendar &amp; highlights
          </h2>
          <button
            type="button"
            onClick={() => onMonth(shiftMonth(month, -1))}
            className="rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
          >
            ← {monthLabel(shiftMonth(month, -1))}
          </button>
          <span className="scoreboard text-lg font-bold uppercase tracking-wide">
            {monthLabel(month)}
          </span>
          <button
            type="button"
            onClick={() => onMonth(shiftMonth(month, 1))}
            className="rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
          >
            {monthLabel(shiftMonth(month, 1))} →
          </button>
        </div>

        {days.length === 0 && (
          <div className="mt-4 rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">
            <p>No games scheduled in {monthLabel(month)} — the season is out of play.</p>
            {seasonMonths.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {seasonMonths.map((m) => {
                  const target = seasonMonth([m]);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => onMonth(target)}
                      className="rounded-sm border border-border px-3 py-1 text-xs font-semibold uppercase tracking-widest text-muted-foreground hover:text-foreground"
                    >
                      {monthLabel(target)}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {days.map((day) => (
          <div key={day} className="mt-6">
            <h3 className="scoreboard text-lg font-bold uppercase tracking-wide text-muted-foreground">
              {dayLabel(day)}
            </h3>
            <ul className="mt-2 grid gap-3 lg:grid-cols-2">
              {schedule.games
                .filter((g: ScheduleGame) => g.day === day)
                .map((game: ScheduleGame, index: number) => {
                  const reel = reelFor(league, index);
                  return (
                    <li
                      key={game.id}
                      className="rounded-md border border-border bg-card p-4 transition-colors hover:border-primary/50"
                    >
                      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
                        <LeagueBadge league={league} />
                        <span>
                          {game.status === "scheduled" ? timeLabel(game.date) : game.statusLabel}
                        </span>
                      </div>
                      <p className="scoreboard mt-2 text-lg font-bold uppercase tracking-wide">
                        {game.away} at {game.home}
                        {game.status !== "scheduled" && game.homeScore !== null && (
                          <span className="ml-2 text-primary">
                            {game.awayScore}–{game.homeScore}
                          </span>
                        )}
                      </p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {game.venue}
                        {game.city ? ` · ${game.city}` : ""}
                        {game.broadcast ? ` · ${game.broadcast}` : ""}
                      </p>
                      {reel && (
                        <Link
                          to="/media/$slug"
                          params={{ slug: reel.slug }}
                          className="mt-3 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-primary"
                        >
                          ▶ Highlight reel: {reel.title}
                        </Link>
                      )}
                    </li>
                  );
                })}
            </ul>
          </div>
        ))}
      </section>

      <div className="mt-10 flex flex-wrap gap-3 text-sm">
        <Link to="/directory" className="font-semibold text-primary underline">
          Sports directory
        </Link>
        <Link to="/standings" search={{ league }} className="font-semibold text-primary underline">
          Full standings
        </Link>
        <Link to="/scores" search={{ league }} className="font-semibold text-primary underline">
          Live scores
        </Link>
        <Link to="/podcasts" className="font-semibold text-primary underline">
          College podcasts
        </Link>
        {league === "cbb" && (
          <Link to="/college-basketball-live" className="font-semibold text-primary underline">
            Live game feed
          </Link>
        )}
      </div>

      <PredictionChatWidget league={league} />
    </div>

  );
}

/** Headlines, roster moves and the injury report for one league. */
function LeagueNewsStrip({ league }: { league: LeagueId }) {
  const news = useQuery(newsQueryOptions(league)).data?.items ?? [];
  const moves = useQuery(leagueMovesQueryOptions(league)).data ?? [];
  const injuries = useQuery(leagueInjuriesQueryOptions(league)).data ?? [];

  if (!news.length && !moves.length && !injuries.length) return null;

  return (
    <section className="mt-10">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Latest news</h2>
      <div className="mt-3 grid gap-4 md:grid-cols-3">
        <div className="rounded-md border border-border bg-card p-4">
          <h3 className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Headlines
          </h3>
          <ul className="mt-2 space-y-2 text-sm">
            {news.slice(0, 5).map((item) => (
              <li key={item.id}>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold hover:text-primary"
                >
                  {item.headline}
                </a>
              </li>
            ))}
            {!news.length && <li className="text-muted-foreground">No headlines right now.</li>}
          </ul>
        </div>
        <div className="rounded-md border border-border bg-card p-4">
          <h3 className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Transfers &amp; roster moves
          </h3>
          <ul className="mt-2 space-y-2 text-sm">
            {moves.slice(0, 5).map((item) => (
              <li key={item.id}>
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold hover:text-primary"
                >
                  {item.headline}
                </a>
              </li>
            ))}
            {!moves.length && <li className="text-muted-foreground">No moves reported yet.</li>}
          </ul>
        </div>
        <div className="rounded-md border border-border bg-card p-4">
          <h3 className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
            Injury report
          </h3>
          <ul className="mt-2 space-y-2 text-sm">
            {injuries.slice(0, 5).map((entry, i) => (
              <li key={`${entry.playerId}-${i}`}>
                <span className="font-semibold">{entry.player}</span>{" "}
                <span className="text-muted-foreground">
                  ({entry.team}) — {entry.status}
                </span>
              </li>
            ))}
            {!injuries.length && (
              <li className="text-muted-foreground">No injuries listed right now.</li>
            )}
          </ul>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-4 text-xs font-semibold uppercase tracking-widest">
        <Link to="/news" className="text-primary underline">
          All news
        </Link>
        <Link to="/moves" className="text-primary underline">
          Roster moves
        </Link>
        <Link to="/injuries" className="text-primary underline">
          Injury report
        </Link>
      </div>
    </section>
  );
}
