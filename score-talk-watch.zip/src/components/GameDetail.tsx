import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { gameSummaryQueryOptions } from "@/lib/feed";
import type { LeagueId } from "@/data/sports";

/** Auto recap, scoring timeline, momentum graph, box score and leaders for one game. */
export function GameDetail({ league, gameId }: { league: LeagueId; gameId: string }) {
  const { data, isLoading } = useQuery(gameSummaryQueryOptions(league, gameId));

  if (isLoading) {
    return (
      <p className="mt-4 rounded-md border border-border bg-card p-5 text-sm text-muted-foreground">
        Loading recap and box score…
      </p>
    );
  }
  if (!data) return null;

  const momentum = data.winProbability;

  return (
    <div className="mt-4 space-y-4">
      {data.recap.length > 0 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Recap
          </h2>
          {data.recap.map((p, i) => (
            <p key={i} className="mt-2 text-sm leading-relaxed">
              {p}
            </p>
          ))}
        </section>
      )}

      {momentum.length > 2 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Momentum — {data.homeAbbr || data.home} win probability
          </h2>
          <div className="mt-3 flex h-24 items-end gap-[2px]">
            {momentum.map((v, i) => (
              <div
                key={i}
                className="flex-1 rounded-t-sm bg-primary/70"
                style={{ height: `${Math.max(2, v)}%` }}
                title={`${v}%`}
              />
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Each bar is one play — taller means {data.home} were more likely to win at that moment.
          </p>
        </section>
      )}

      {data.timeline.length > 0 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Scoring timeline
          </h2>
          <ol className="mt-3 space-y-2">
            {data.timeline.map((p) => (
              <li key={p.id} className="flex gap-3 border-b border-border/50 pb-2 last:border-0">
                <span className="scoreboard w-16 shrink-0 text-xs uppercase tabular-nums text-muted-foreground">
                  {p.period} {p.clock}
                </span>
                <span className="flex-1 text-sm">
                  {p.team && <span className="font-semibold">{p.team} </span>}
                  {p.text}
                </span>
                <span className="scoreboard shrink-0 text-sm font-bold tabular-nums">
                  {p.awayScore}–{p.homeScore}
                </span>
              </li>
            ))}
          </ol>
        </section>
      )}

      {data.leaders.length > 0 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Game leaders
          </h2>
          <ul className="mt-3 grid gap-2 sm:grid-cols-2">
            {data.leaders.map((l, i) => (
              <li key={`${l.playerId}-${i}`} className="text-sm">
                <span className="text-xs uppercase tracking-widest text-muted-foreground">
                  {l.category}
                </span>
                <br />
                <Link
                  to="/players/$league/$playerId"
                  params={{ league, playerId: l.playerId }}
                  className="font-semibold hover:text-primary"
                >
                  {l.name}
                </Link>{" "}
                <span className="text-muted-foreground">
                  {l.team} · {l.value}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {data.stats.length > 0 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Team stats
          </h2>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full min-w-[420px] text-sm">
              <thead>
                <tr className="scoreboard border-b border-border text-xs uppercase tracking-widest text-muted-foreground">
                  <th className="py-2 text-left font-semibold">{data.awayAbbr || "Away"}</th>
                  <th className="py-2 text-center font-semibold">Stat</th>
                  <th className="py-2 text-right font-semibold">{data.homeAbbr || "Home"}</th>
                </tr>
              </thead>
              <tbody>
                {data.stats.map((s) => (
                  <tr key={s.label} className="border-b border-border/50 last:border-0">
                    <td className="scoreboard py-2 text-left tabular-nums">{s.away}</td>
                    <td className="py-2 text-center text-xs text-muted-foreground">{s.label}</td>
                    <td className="scoreboard py-2 text-right tabular-nums">{s.home}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {data.lineups.length > 0 && (
        <section className="rounded-md border border-border bg-card p-5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
            Lineups
          </h2>
          <div className="mt-3 grid gap-5 sm:grid-cols-2">
            {data.lineups.map((side) => (
              <div key={side.team}>
                <h3 className="text-sm font-semibold">{side.team}</h3>
                <ul className="mt-2 space-y-1 text-sm">
                  {side.players.map((p) => (
                    <li key={`${side.team}-${p.name}`} className="flex justify-between gap-3">
                      <span className={p.starter ? "font-medium" : "text-muted-foreground"}>
                        {p.name}
                      </span>
                      <span className="scoreboard text-xs uppercase tracking-widest text-muted-foreground">
                        {p.starter ? p.position || "Start" : p.position || "Sub"}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
