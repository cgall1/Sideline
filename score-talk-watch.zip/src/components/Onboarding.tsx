import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { fetchLeagueTeams } from "@/lib/onboarding.functions";
import { useFavorites, type FollowId } from "@/lib/favorites";
import { Button } from "@/components/ui/button";

const KEY = "sideline.onboarded";
const LEAGUES: { id: FollowId; label: string }[] = [
  { id: "nfl", label: "NFL" },
  { id: "nba", label: "NBA" },
  { id: "wnba", label: "WNBA" },
  { id: "nhl", label: "NHL" },
  { id: "mlb", label: "MLB" },
  { id: "mls", label: "MLS" },
  { id: "nwsl", label: "NWSL" },
];

/** First-visit welcome: pick sports, then clubs — lights up For You, alerts and spaces. */
export function Onboarding() {
  const { favorites, isFavorite, toggle } = useFavorites();
  const [open, setOpen] = useState(false);
  const [league, setLeague] = useState<FollowId | null>(null);
  const fn = useServerFn(fetchLeagueTeams);

  useEffect(() => {
    try {
      if (!localStorage.getItem(KEY)) setOpen(true);
    } catch {
      /* no storage */
    }
  }, []);

  const teams = useQuery({
    queryKey: ["onboard-teams", league],
    queryFn: () => fn({ data: { league: league as string } }),
    enabled: Boolean(league),
    staleTime: 3_600_000,
  });

  const close = () => {
    try {
      localStorage.setItem(KEY, "1");
    } catch {
      /* ignore */
    }
    setOpen(false);
  };

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 p-3 backdrop-blur-sm sm:items-center" role="dialog" aria-modal="true" aria-label="Welcome to Sideline">
      <div className="flex max-h-[85vh] w-full max-w-lg flex-col rounded-lg border border-border bg-card shadow-xl">
        <div className="border-b border-border p-4">
          <p className="text-[10px] font-bold uppercase tracking-widest text-primary">Welcome to Sideline</p>
          <h2 className="mt-1 text-lg font-bold">
            {league ? `Pick your ${LEAGUES.find((l) => l.id === league)?.label} teams` : "Which sports do you follow?"}
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Your picks shape your home page, phone alerts and fan spaces. {favorites.length > 0 && `${favorites.length} followed.`}
          </p>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {!league ? (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {LEAGUES.map((l) => {
                const n = favorites.filter((f) => f.league === l.id).length;
                return (
                  <button key={l.id} onClick={() => setLeague(l.id)} className="rounded-md border border-border bg-background px-3 py-4 text-sm font-bold transition-colors hover:border-primary">
                    {l.label}
                    {n > 0 && <span className="ml-1 text-xs text-primary">· {n}</span>}
                  </button>
                );
              })}
            </div>
          ) : teams.isLoading ? (
            <p className="text-sm text-muted-foreground">Loading clubs…</p>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {(teams.data ?? []).map((t) => {
                const on = isFavorite(league, t.id);
                return (
                  <button
                    key={t.id}
                    onClick={() => toggle({ league, teamId: t.id, name: t.name, logo: t.logo })}
                    aria-pressed={on}
                    className={`flex items-center gap-2 rounded-md border px-2 py-2 text-left text-xs font-semibold transition-colors ${on ? "border-primary bg-primary/10" : "border-border bg-background hover:border-primary"}`}
                  >
                    {t.logo && <img src={t.logo} alt="" className="h-6 w-6 object-contain" loading="lazy" />}
                    <span className="flex-1">{t.name}</span>
                    {on && <span className="text-primary">✓</span>}
                  </button>
                );
              })}
            </div>
          )}
        </div>
        <div className="flex items-center justify-between gap-2 border-t border-border p-3">
          {league ? (
            <Button variant="ghost" size="sm" onClick={() => setLeague(null)}>← Sports</Button>
          ) : (
            <Button variant="ghost" size="sm" onClick={close}>Skip</Button>
          )}
          <Button size="sm" onClick={close}>{favorites.length > 0 ? "Done" : "Just browsing"}</Button>
        </div>
      </div>
    </div>
  );
}
