import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { articlesQueryOptions, gamesQueryOptions } from "@/lib/feed";
import { useFavorites } from "@/lib/favorites";
import { useAuth } from "@/hooks/useAuth";
import { myFantasyPlayers } from "@/lib/fantasy.functions";
import { predictionsQueryOptions } from "@/lib/predictions";
import type { Game } from "@/data/sports";
import { WhatItMeant } from "@/components/WhatItMeant";
import { TodaysDebate } from "@/components/DailyDebate";

/** Fantasy players of yours whose club is playing right now or next. */
function FantasyInAction({ games }: { games: Game[] }) {
  const { user } = useAuth();
  const { data: players = [] } = useQuery({
    queryKey: ["my-fantasy-players", user?.id ?? "anon"],
    queryFn: () => myFantasyPlayers(),
    enabled: !!user,
    staleTime: 120_000,
  });
  if (players.length === 0) return null;

  const rows = players
    .map((p) => {
      const club = p.teamName.toLowerCase();
      const game = games.find(
        (g) =>
          (g.home.name.toLowerCase() === club || g.away.name.toLowerCase() === club) &&
          (g.status === "live" || g.status === "scheduled"),
      );
      return game ? { ...p, game } : null;
    })
    .filter((r): r is NonNullable<typeof r> => !!r)
    .sort((a, b) => (a.game.status === "live" ? -1 : 1) - (b.game.status === "live" ? -1 : 1))
    .slice(0, 6);

  if (rows.length === 0) return null;

  return (
    <section className="mt-6 border border-border bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="scoreboard text-sm font-bold uppercase">Your fantasy players in action</h3>
        <Link to="/fantasy" className="text-[11px] font-bold uppercase text-primary hover:underline">
          Fantasy →
        </Link>
      </div>
      <ul className="mt-3 grid gap-2 sm:grid-cols-2">
        {rows.map((r) => (
          <li key={`${r.leagueId}-${r.playerName}`}>
            <Link
              to="/game/$league/$gameId"
              params={{ league: r.game.league, gameId: r.game.id }}
              className="block border border-border p-3 transition-colors hover:border-foreground"
            >
              <p className="text-sm font-bold">{r.playerName}</p>
              <p className="text-[10px] font-bold uppercase text-muted-foreground">
                {r.position ? `${r.position} · ` : ""}{r.teamName} · {r.leagueName}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                {r.game.away.name} at {r.game.home.name} ·{" "}
                {r.game.status === "live" ? (
                  <span className="font-bold text-[color:var(--live)]">Live now</span>
                ) : (
                  r.game.startLabel
                )}
              </p>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}

/** Picks the fan has made that haven't been settled yet. */
function OpenPredictions() {
  const { user } = useAuth();
  const { data: picks = [] } = useQuery(predictionsQueryOptions(user?.id));
  const open = picks.filter((p) => !p.resolved).slice(0, 6);
  if (open.length === 0) return null;

  return (
    <section className="mt-6 border border-border bg-card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="scoreboard text-sm font-bold uppercase">Your open picks</h3>
        <Link to="/predictions" className="text-[11px] font-bold uppercase text-primary hover:underline">
          All picks →
        </Link>
      </div>
      <ul className="mt-3 grid gap-2 sm:grid-cols-2">
        {open.map((p) => (
          <li key={p.id} className="border border-border p-3">
            <p className="text-sm font-semibold">{p.gameLabel}</p>
            <p className="text-[10px] font-bold uppercase text-muted-foreground">
              {p.league} · you picked {p.pick}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

/**
 * The fan's own front page: live games, what's next and news for the teams and
 * athletes they follow. Falls back to a prompt when nothing is followed yet.
 */
export function ForYou() {
  const { favorites } = useFavorites();
  const { data: games = [] } = useQuery(gamesQueryOptions("all"));
  const { data: articles = [] } = useQuery(articlesQueryOptions());

  if (favorites.length === 0) {
    return (
      <>
        <section className="border border-border bg-card px-2.5 py-1">
          <p className="text-[9px] font-bold uppercase text-primary">For you</p>
          <h2 className="scoreboard truncate text-[11px] font-bold uppercase">Build your own front page</h2>
          <p className="truncate text-[10px] leading-tight text-muted-foreground">
            Star teams and athletes anywhere on Sideline and this space becomes yours.
          </p>
          <div className="mt-0.5 flex flex-wrap gap-2 text-[9px] font-bold uppercase">
            <Link to="/sports" className="text-primary hover:underline">Browse every sport →</Link>
            <Link to="/rosters" className="text-primary hover:underline">Find your team →</Link>
          </div>
        </section>
        <div className="lg:col-span-2">
          <FantasyInAction games={games} />
          <OpenPredictions />
        </div>
      </>
    );
  }

  const names = favorites.map((f) => f.name.toLowerCase());
  const mine = games.filter(
    (g) => names.includes(g.home.name.toLowerCase()) || names.includes(g.away.name.toLowerCase()),
  );
  const live = mine.filter((g) => g.status === "live");
  const next = mine.filter((g) => g.status === "scheduled").slice(0, 4);
  const done = mine.filter((g) => g.status !== "live" && g.status !== "scheduled").slice(0, 3);
  const news = articles
    .filter((a) => {
      const hay = `${a.title} ${a.dek}`.toLowerCase();
      return names.some((n) => hay.includes(n));
    })
    .slice(0, 4);

  return (
    <div className="lg:col-span-2">
    <section className="border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-foreground px-5 py-4">
        <div>
          <p className="text-[10px] font-bold uppercase text-primary">For you</p>
          <h2 className="scoreboard text-2xl font-bold uppercase">
            {live.length > 0 ? `${live.length} of your teams are live` : "Your teams today"}
          </h2>
        </div>
        <div className="flex flex-wrap gap-4 text-[11px] font-bold uppercase">
          <Link to="/my-teams" className="text-primary hover:underline">My teams →</Link>
          <Link to="/fantasy" className="text-primary hover:underline">Fantasy →</Link>
          <Link to="/predictions" className="text-primary hover:underline">My picks →</Link>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 border-b border-border px-5 py-3">
        {favorites.map((f) => (
          <span
            key={`${f.league}-${f.teamId}`}
            className="scoreboard border border-border px-3 py-1 text-[11px] font-bold uppercase text-muted-foreground"
          >
            ★ {f.name}
          </span>
        ))}
      </div>

      <div className="grid gap-px bg-border md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
        <div className="bg-card p-5">
          {live.length === 0 && next.length === 0 && done.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Nothing on the schedule right now — their next games land here automatically.
            </p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {[...live, ...next, ...done].map((game) => (
                <Link
                  key={game.id}
                  to="/game/$league/$gameId"
                  params={{ league: game.league, gameId: game.id }}
                  className="border border-border p-4 transition-colors hover:border-foreground"
                >
                  <p className="text-[10px] font-bold uppercase text-muted-foreground">
                    {game.league} · {game.status === "live" ? game.clock : game.startLabel}
                  </p>
                  <p className="mt-2 flex justify-between text-sm font-semibold">
                    <span>{game.away.name}</span>
                    <span className="scoreboard">{game.status === "scheduled" ? "–" : game.awayScore}</span>
                  </p>
                  <p className="mt-1 flex justify-between text-sm font-semibold">
                    <span>{game.home.name}</span>
                    <span className="scoreboard">{game.status === "scheduled" ? "–" : game.homeScore}</span>
                  </p>
                  {game.status === "live" ? (
                    <p className="mt-2 scoreboard text-[11px] font-bold uppercase text-[color:var(--live)]">
                      Live now
                    </p>
                  ) : null}
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="bg-card p-5">
          <h3 className="scoreboard text-sm font-bold uppercase">Your headlines</h3>
          {news.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              No stories mention your teams yet today.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {news.map((a) => (
                <li key={a.slug}>
                  <Link
                    to="/media/$slug"
                    params={{ slug: a.slug }}
                    className="block text-sm font-bold leading-tight hover:underline"
                  >
                    {a.title}
                  </Link>
                  <span className="text-[10px] font-bold uppercase text-muted-foreground">
                    {a.league} · {a.published}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
    <div className="mt-6">
      <TodaysDebate compact />
    </div>
    <WhatItMeant games={mine} names={names} />
    <FantasyInAction games={games} />
    <OpenPredictions />
    </div>
  );
}
