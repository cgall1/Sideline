import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import type { Game, LeagueId } from "@/data/sports";
import {
  leagueInjuriesQueryOptions,
  leagueVideosQueryOptions,
  newsQueryOptions,
  seasonResultsQueryOptions,
} from "@/lib/feed";

/** Loose match: "Boston Celtics" also matches "Celtics" in a headline or clip title. */
function mentions(text: string, team: { name: string; abbr: string }): boolean {
  const haystack = text.toLowerCase();
  const nick = team.name.split(" ").slice(-1)[0]?.toLowerCase() ?? "";
  return (
    haystack.includes(team.name.toLowerCase()) || (nick.length > 3 && haystack.includes(nick))
  );
}

function spaceSlug(league: LeagueId): string {
  return league === "intl" ? "world-soccer" : league;
}

function ticketSearch(game: Game): string {
  const q = encodeURIComponent(`${game.away.name} at ${game.home.name} tickets`);
  return `https://www.google.com/search?q=${q}`;
}

function Card({
  id,
  title,
  children,
}: {
  id: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="scroll-mt-24 rounded-md border border-border bg-card p-5">
      <h2 className="scoreboard text-sm font-bold uppercase tracking-widest text-muted-foreground">
        {title}
      </h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

/**
 * Everything else about one game in one place: form, injuries, news, clips,
 * where to watch, tickets and the fan conversation.
 */
export function MatchHub({ league, game }: { league: LeagueId; game: Game }) {
  const teams = [game.away, game.home];

  const { data: injuries } = useQuery(leagueInjuriesQueryOptions(league));
  const { data: news } = useQuery(newsQueryOptions(league));
  const { data: videos } = useQuery(leagueVideosQueryOptions(league));
  const { data: results } = useQuery(seasonResultsQueryOptions(league));

  const rows = (results?.groups ?? []).flatMap((g) => g.rows);
  const formFor = (name: string) =>
    rows.find((r) => r.team.toLowerCase() === name.toLowerCase()) ??
    rows.find((r) => mentions(r.team, { name, abbr: "" }));

  const gameInjuries = (injuries ?? []).filter((i) =>
    teams.some((t) => mentions(i.team, t)),
  );

  const newsItems = news?.items ?? [];
  const teamNews = newsItems
    .filter((n) => teams.some((t) => mentions(`${n.headline} ${n.summary}`, t)))
    .slice(0, 6);
  const shownNews = teamNews.length ? teamNews : newsItems.slice(0, 4);

  const clips = videos?.videos ?? [];
  const teamClips = clips
    .filter((v) => teams.some((t) => mentions(`${v.title} ${v.description}`, t)))
    .slice(0, 4);
  const shownClips = teamClips.length ? teamClips : clips.slice(0, 3);

  return (
    <div className="mt-4 space-y-4">
      <nav
        aria-label="Jump to a section of this match"
        className="flex flex-wrap gap-2 rounded-md border border-border bg-card p-3 text-xs font-semibold uppercase tracking-widest"
      >
        {[
          ["form", "Form"],
          ["injuries", "Injuries"],
          ["news", "News"],
          ["clips", "Highlights"],
          ["watch", "Where to watch"],
          ["talk", "Fan talk"],
        ].map(([id, label]) => (
          <a
            key={id}
            href={`#${id}`}
            className="rounded-full border border-border px-3 py-1 text-muted-foreground hover:border-primary/60 hover:text-foreground"
          >
            {label}
          </a>
        ))}
      </nav>

      <Card id="form" title="Recent team form">
        <ul className="grid gap-3 sm:grid-cols-2">
          {teams.map((t) => {
            const row = formFor(t.name);
            return (
              <li key={t.abbr} className="rounded-sm border border-border bg-surface p-3">
                <p className="font-bold">{t.name}</p>
                {row ? (
                  <>
                    <p className="scoreboard mt-1 text-lg font-bold tabular-nums">
                      {row.w}-{row.l}
                      {row.t ? `-${row.t}` : ""}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {row.streak ? `Streak ${row.streak} · ` : ""}
                      {row.gp} played · {row.pointsFor} for, {row.pointsAgainst} against
                    </p>
                  </>
                ) : (
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t.record ? `Record ${t.record}` : "Season record not published yet."}
                  </p>
                )}
              </li>
            );
          })}
        </ul>
      </Card>

      <Card id="injuries" title="Injury report">
        {gameInjuries.length ? (
          <ul className="space-y-2">
            {gameInjuries.slice(0, 12).map((i, idx) => (
              <li
                key={`${i.playerId}-${idx}`}
                className="flex flex-wrap items-baseline justify-between gap-2 border-b border-border pb-2 text-sm last:border-0"
              >
                <span>
                  <span className="font-semibold">{i.player}</span>{" "}
                  <span className="text-xs text-muted-foreground">
                    {i.position} · {i.team}
                  </span>
                </span>
                <span className="scoreboard text-xs font-bold uppercase tracking-widest text-live">
                  {i.status}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">
            No injuries reported for either side right now.
          </p>
        )}
        <Link
          to="/injuries/$league"
          params={{ league }}
          className="mt-3 inline-block text-xs font-semibold text-primary hover:underline"
        >
          Full injury report →
        </Link>
      </Card>

      <Card id="news" title={teamNews.length ? "Relevant news" : "Around the league"}>
        {shownNews.length ? (
          <ul className="space-y-3">
            {shownNews.map((n) => (
              <li key={n.id}>
                <a
                  href={n.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold hover:text-primary hover:underline"
                >
                  {n.headline}
                </a>
                {n.summary && (
                  <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.summary}</p>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No stories yet.</p>
        )}
      </Card>

      <Card id="clips" title="Highlight clips">
        {shownClips.length ? (
          <ul className="grid gap-3 sm:grid-cols-2">
            {shownClips.map((v) => (
              <li key={v.id} className="overflow-hidden rounded-sm border border-border">
                <a href={v.url} target="_blank" rel="noopener noreferrer">
                  <img
                    src={v.thumbnail}
                    alt=""
                    loading="lazy"
                    className="aspect-video w-full object-cover"
                  />
                  <p className="p-2 text-xs font-semibold">{v.title}</p>
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">Clips appear once the broadcasters post them.</p>
        )}
        <Link to="/highlights" className="mt-3 inline-block text-xs font-semibold text-primary hover:underline">
          More highlights →
        </Link>
      </Card>

      <Card id="watch" title="Where to watch & tickets">
        <p className="text-sm">
          {game.broadcasters.length
            ? `On ${game.broadcasters.join(", ")}`
            : "No broadcast listing yet for this game."}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          {game.venue}
          {game.startLabel ? ` · ${game.startLabel}` : ""}
        </p>
        <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
          <Link to="/watch" search={{ league }} className="text-primary underline">
            Full TV guide
          </Link>
          <a
            href={ticketSearch(game)}
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary underline"
          >
            Find tickets
          </a>
        </div>
      </Card>

      <Card id="talk" title="Fan talk">
        <p className="text-sm text-muted-foreground">
          Keep the conversation going beyond this match thread.
        </p>
        <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold uppercase tracking-widest">
          <Link
            to="/s/$slug"
            params={{ slug: spaceSlug(league) }}
            className="text-primary underline"
          >
            Fan space
          </Link>
          <Link to="/community" className="text-primary underline">
            Community feed
          </Link>
          <Link to="/fan-gallery" className="text-primary underline">
            Fan gallery
          </Link>
        </div>
      </Card>
    </div>
  );
}
