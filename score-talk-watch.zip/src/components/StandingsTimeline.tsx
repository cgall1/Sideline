import { useQuery } from "@tanstack/react-query";
import { soccerTimelineQueryOptions } from "@/lib/feed";

const LINE_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--accent))",
  "hsl(var(--chart-3, 190 90% 55%))",
  "hsl(var(--destructive))",
  "hsl(var(--chart-5, 45 95% 58%))",
  "hsl(var(--muted-foreground))",
];

/**
 * How the table moved across the season: each club's position after every
 * matchday, drawn from results so it extends itself as matches are played.
 */
export function StandingsTimeline({ slug, name }: { slug: string; name: string }) {
  const { data, isPending } = useQuery(soccerTimelineQueryOptions(slug));

  if (isPending) {
    return (
      <section className="mt-12">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season timeline</h2>
        <p className="mt-3 text-sm text-muted-foreground">Building the season timeline…</p>
      </section>
    );
  }

  const stages = data?.stages ?? [];
  const teams = data?.teams ?? [];

  if (stages.length < 2 || teams.length === 0) {
    return (
      <section className="mt-12">
        <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season timeline</h2>
        <p className="mt-3 text-sm text-muted-foreground">
          The {name} timeline starts once a few matchdays have been played — it fills in on its own
          from the results.
        </p>
      </section>
    );
  }

  const width = 760;
  const height = 280;
  const padX = 44;
  const padY = 26;
  const maxRank = Math.max(...teams.flatMap((t) => t.ranks), 2);
  const x = (i: number) => padX + (i * (width - padX * 2)) / (stages.length - 1);
  const y = (rank: number) => padY + ((rank - 1) * (height - padY * 2)) / Math.max(1, maxRank - 1);

  return (
    <section className="mt-12">
      <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Season timeline</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Where the current top {teams.length} have sat in the table after each matchday. Higher is
        better.
      </p>

      <div className="mt-4 overflow-x-auto rounded-md border border-border bg-card p-4">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-[280px] w-full min-w-[640px]"
          role="img"
          aria-label={`${name} standings progression by matchday`}
        >
          {[1, Math.ceil(maxRank / 2), maxRank].map((rank) => (
            <g key={rank}>
              <line
                x1={padX}
                x2={width - padX}
                y1={y(rank)}
                y2={y(rank)}
                stroke="hsl(var(--border))"
                strokeDasharray="4 6"
              />
              <text
                x={padX - 10}
                y={y(rank) + 4}
                textAnchor="end"
                className="fill-muted-foreground text-[11px]"
              >
                {rank}
              </text>
            </g>
          ))}

          {stages.map((label, i) =>
            i % Math.ceil(stages.length / 7) === 0 || i === stages.length - 1 ? (
              <text
                key={label + i}
                x={x(i)}
                y={height - 4}
                textAnchor="middle"
                className="fill-muted-foreground text-[10px]"
              >
                {label}
              </text>
            ) : null,
          )}

          {teams.map((team, ti) => (
            <g key={team.team}>
              <polyline
                fill="none"
                stroke={LINE_COLORS[ti % LINE_COLORS.length]}
                strokeWidth={2.5}
                strokeLinejoin="round"
                strokeLinecap="round"
                points={team.ranks.map((rank, i) => `${x(i)},${y(rank)}`).join(" ")}
              />
              {team.ranks.map((rank, i) => (
                <circle
                  key={i}
                  cx={x(i)}
                  cy={y(rank)}
                  r={2.5}
                  fill={LINE_COLORS[ti % LINE_COLORS.length]}
                >
                  <title>{`${team.team} — ${stages[i]}: #${rank}, ${team.points[i]} pts`}</title>
                </circle>
              ))}
            </g>
          ))}
        </svg>
      </div>

      <ul className="mt-3 flex flex-wrap gap-x-5 gap-y-2 text-xs font-semibold uppercase tracking-widest">
        {teams.map((team, ti) => (
          <li key={team.team} className="flex items-center gap-2">
            <span
              aria-hidden
              className="inline-block h-2.5 w-6 rounded-full"
              style={{ background: LINE_COLORS[ti % LINE_COLORS.length] }}
            />
            {team.team}
            <span className="text-muted-foreground">
              {team.points[team.points.length - 1]} pts
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
