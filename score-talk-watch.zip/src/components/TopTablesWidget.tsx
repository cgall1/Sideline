import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { topSoccerTablesQueryOptions } from "@/lib/feed";

/**
 * Top of the table for the headline competitions, so fans can scan the
 * leaders without opening each league page. Refreshes on its own.
 */
export function TopTablesWidget() {
  const { data, isPending, isFetching, refetch } = useQuery(topSoccerTablesQueryOptions());
  const tables = data ?? [];

  return (
    <section className="mx-auto max-w-7xl px-4 pb-12">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="scoreboard text-2xl font-bold uppercase tracking-wide">Top of the tables</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Who leads the biggest leagues right now — updated as results land.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refetch()}
          className="rounded-md border border-border px-3 py-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:border-primary hover:text-primary"
        >
          {isFetching ? "Refreshing…" : "Refresh"}
        </button>
      </div>

      {isPending ? (
        <p className="mt-4 text-sm text-muted-foreground">Loading the tables…</p>
      ) : tables.length === 0 ? (
        <p className="mt-4 text-sm text-muted-foreground">
          No tables published yet — they fill in automatically as results arrive.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {tables.map((table) => (
            <div key={table.slug} className="rounded-md border border-border bg-card p-4">
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="scoreboard text-sm font-bold uppercase tracking-widest">
                  {table.name}
                </h3>
                <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                  {table.source === "results" ? "From results" : "Live table"}
                </span>
              </div>
              <ol className="mt-3 space-y-1.5">
                {table.rows.map((row, i) => (
                  <li key={row.team} className="flex items-center gap-2 text-sm">
                    <span className="w-4 text-right text-xs text-muted-foreground">{i + 1}</span>
                    {row.logo ? (
                      <img src={row.logo} alt={`${row.team} logo`} className="h-4 w-4" loading="lazy" />
                    ) : null}
                    <span className="flex-1 truncate">{row.team}</span>
                    <span className="text-xs text-muted-foreground">{row.gp} GP</span>
                    <span className="w-8 text-right font-bold">{row.points}</span>
                  </li>
                ))}
              </ol>
              <Link
                to="/soccer-rankings/$competition"
                params={{ competition: table.slug.replace(/-highlights$/, "") }}
                className="mt-3 inline-block text-xs font-semibold uppercase tracking-widest text-primary underline"
              >
                Full table
              </Link>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
