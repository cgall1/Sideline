import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { debatesQueryOptions } from "@/lib/daily";

const KEY = "sideline.lastVisit";

interface MissedPost {
  id: string;
  title: string;
  spaceName: string;
}

/** Top posts, yesterday's debate verdict and the liveliest space since your last visit. */
export function WhatYouMissed() {
  const { user } = useAuth();
  const [since, setSince] = useState<string | null>(null);

  useEffect(() => {
    const prev = window.localStorage.getItem(KEY);
    const fallback = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    setSince(prev ?? fallback);
    window.localStorage.setItem(KEY, new Date().toISOString());
  }, []);

  const { data: debates } = useQuery(debatesQueryOptions(user?.id ?? null));
  const { data: posts } = useQuery({
    queryKey: ["missed-posts", since],
    enabled: Boolean(since),
    staleTime: 60_000,
    queryFn: async () => {
      const { data } = await supabase
        .from("space_posts")
        .select("id, title, spaces(name)")
        .gte("created_at", since!)
        .order("created_at", { ascending: false })
        .limit(50);
      return (data ?? []).map(
        (p): MissedPost => ({
          id: p.id,
          title: p.title,
          spaceName: (p.spaces as { name?: string } | null)?.name ?? "Community",
        }),
      );
    },
  });

  if (!since) return null;
  const today = new Date().toISOString().slice(0, 10);
  const lastDebate = (debates ?? []).find((d) => d.date < today);
  const counts = new Map<string, number>();
  for (const p of posts ?? []) counts.set(p.spaceName, (counts.get(p.spaceName) ?? 0) + 1);
  const liveliest = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
  const top = (posts ?? []).slice(0, 3);
  if (!lastDebate && !top.length) return null;

  const total = lastDebate ? lastDebate.votesA + lastDebate.votesB : 0;
  const winner =
    lastDebate && total
      ? lastDebate.votesA === lastDebate.votesB
        ? "Dead even"
        : lastDebate.votesA > lastDebate.votesB
          ? `${lastDebate.sideA} won`
          : `${lastDebate.sideB} won`
      : null;

  return (
    <section className="border border-border bg-card px-2.5 py-1">
      <h2 className="scoreboard text-[9px] font-bold uppercase tracking-widest text-muted-foreground">
        What you missed
      </h2>
      <div className="grid gap-x-3 md:grid-cols-3">
        {lastDebate && (
          <Link to="/daily/$date" params={{ date: lastDebate.date }} className="group block">
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground">Last debate</p>
            <p className="text-xs font-semibold leading-tight group-hover:underline">{lastDebate.question}</p>
            <p className="text-[10px] leading-tight text-primary">
              {winner ? `${winner} · ${total} vote${total === 1 ? "" : "s"}` : "No votes yet — have your say"}
            </p>
          </Link>
        )}
        {top.length > 0 && (
          <div>
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground">New posts</p>
            <ul>
              {top.map((p) => (
                <li className="text-xs leading-tight">
                  <Link to="/post/$postId" params={{ postId: p.id }} className="font-semibold hover:underline">
                    {p.title}
                  </Link>
                  <span className="text-[10px] text-muted-foreground"> · {p.spaceName}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {liveliest && (
          <Link to="/community" className="group block">
            <p className="text-[9px] uppercase tracking-widest text-muted-foreground">Liveliest space</p>
            <p className="text-xs font-semibold leading-tight group-hover:underline">{liveliest[0]}</p>
            <p className="text-[10px] leading-tight text-primary">
              {liveliest[1]} new post{liveliest[1] === 1 ? "" : "s"}
            </p>
          </Link>
        )}
      </div>
    </section>
  );
}
