import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { REACTIONS } from "@/data/sports";
import {
  createPost,
  deletePost,
  reactionsQueryOptions,
  relativeTime,
  setReaction,
  threadPostsQueryOptions,
  toggleLike,
} from "@/lib/community";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { TopVoiceBadge, useTopVoices } from "@/components/TopVoiceBadge";

interface Props {
  gameId: string;
  signInNext: string;
  heading?: string;
  /** Spoiler shield: hide messages newer than this many seconds. */
  delaySec?: number;
}

/** Reusable live fan thread for one single game: reactions, chat and likes. */
export function GameThread({ gameId, signInNext, heading = "Live chat", delaySec = 0 }: Props) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const topVoices = useTopVoices();
  const { data: posts = [] } = useQuery(threadPostsQueryOptions(userId));
  const { data: reactionData } = useQuery(reactionsQueryOptions(userId));

  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [live, setLive] = useState(false);
  const endRef = useRef<HTMLDivElement | null>(null);

  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!delaySec) return;
    const i = setInterval(() => setNow(Date.now()), 2000);
    return () => clearInterval(i);
  }, [delaySec]);
  const threadPosts = posts
    .filter((p) => p.gameId === gameId)
    .filter((p) => !delaySec || p.userId === userId || new Date(p.createdAt).getTime() <= now - delaySec * 1000)
    .slice()
    .reverse();
  const refresh = () => queryClient.invalidateQueries({ queryKey: ["community"] });

  useEffect(() => {
    const channel = supabase
      .channel(`game-thread-${gameId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "community_posts" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "post_likes" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "game_reactions" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["community"] });
      })
      .subscribe((status) => setLive(status === "SUBSCRIBED"));
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [gameId, queryClient]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [threadPosts.length]);

  const myReaction = reactionData?.mine[gameId];
  const reactionTotals = reactionData?.totals[gameId] ?? {};

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text || !userId || busy) return;
    setBusy(true);
    try {
      await createPost(userId, gameId, text);
      setDraft("");
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {REACTIONS.map((emoji) => (
          <button
            key={emoji}
            onClick={async () => {
              if (!userId) return;
              await setReaction(gameId, userId, myReaction === emoji ? null : emoji);
              await refresh();
            }}
            disabled={!userId}
            aria-pressed={myReaction === emoji}
            className={cn(
              "rounded-full border px-3 py-1.5 text-sm font-semibold transition-colors",
              myReaction === emoji
                ? "border-primary bg-primary/15 text-foreground"
                : "border-border hover:border-primary/50",
              !userId && "opacity-60",
            )}
          >
            <span aria-hidden className="mr-1.5 text-base">
              {emoji}
            </span>
            <span className="scoreboard tabular-nums">{reactionTotals[emoji] ?? 0}</span>
          </button>
        ))}
      </div>

      <div className="mt-4 overflow-hidden rounded-md border border-border bg-card">
        <div className="flex items-center justify-between gap-2 border-b border-border px-4 py-2.5">
          <h2 className="scoreboard text-sm font-bold uppercase tracking-widest">{heading}</h2>
          <span
            className={cn(
              "scoreboard text-xs font-bold uppercase tracking-widest",
              live ? "live-dot text-live" : "text-muted-foreground",
            )}
          >
            {live ? "Live" : "Connecting…"}
          </span>
        </div>

        <ul className="max-h-[28rem] space-y-3 overflow-y-auto p-4">
          {threadPosts.map((p) => (
            <li key={p.id} className="rounded-md border border-border bg-surface p-3.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-bold">
                  {p.author}
                  <TopVoiceBadge userId={p.userId} voices={topVoices} />{" "}
                  <span className="scoreboard ml-1 rounded-sm bg-surface-2 px-1.5 py-0.5 text-xs font-semibold">
                    {p.team}
                  </span>
                </span>
                <span className="text-xs text-muted-foreground">{relativeTime(p.createdAt)}</span>
              </div>
              <p className="mt-1.5 text-sm">{p.body}</p>
              <div className="mt-2 flex items-center gap-3">
                <button
                  onClick={async () => {
                    if (!userId) return;
                    await toggleLike(p.id, userId, p.likedByMe);
                    await refresh();
                  }}
                  disabled={!userId}
                  aria-pressed={p.likedByMe}
                  className={cn(
                    "text-xs font-semibold",
                    p.likedByMe ? "text-primary" : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  ▲ {p.likes}
                </button>
                {p.userId === userId && (
                  <button
                    onClick={async () => {
                      await deletePost(p.id);
                      await refresh();
                    }}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Delete
                  </button>
                )}
              </div>
            </li>
          ))}
          {!threadPosts.length && (
            <li className="py-6 text-center text-sm text-muted-foreground">
              No posts yet — start the conversation.
            </li>
          )}
          <div ref={endRef} />
        </ul>

        <div className="border-t border-border p-4">
          {userId ? (
            <form onSubmit={submit} className="flex gap-2">
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Say something about this game…"
                maxLength={400}
                className="flex-1 rounded-sm border border-border bg-surface px-3 py-2 text-sm outline-none focus:border-primary"
              />
              <button
                type="submit"
                disabled={busy || !draft.trim()}
                className="rounded-sm bg-primary px-4 py-2 text-sm font-bold text-primary-foreground disabled:opacity-50"
              >
                Post
              </button>
            </form>
          ) : (
            <p className="text-xs text-muted-foreground">
              <Link
                to="/auth"
                search={{ next: signInNext }}
                className="font-semibold text-primary underline"
              >
                Sign in
              </Link>{" "}
              to post in this thread.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
