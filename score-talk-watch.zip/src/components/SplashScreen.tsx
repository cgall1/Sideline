import { useEffect, useState } from "react";

/**
 * Branded splash shown while the installed (home-screen) app boots.
 * Server-rendered so it paints instantly, then fades once the app has loaded.
 * In a regular browser tab it is hidden immediately via the inline
 * `no-splash` script in the root shell.
 */
export function SplashScreen() {
  const [phase, setPhase] = useState<"visible" | "fading" | "gone">("visible");

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (window.navigator as Navigator & { standalone?: boolean }).standalone === true;
    if (!standalone) {
      setPhase("gone");
      return;
    }
    const start = Date.now();
    let safety = 0;
    const beginFade = () => {
      const wait = Math.max(0, 1200 - (Date.now() - start));
      window.setTimeout(() => setPhase("fading"), wait);
    };
    if (document.readyState === "complete") {
      beginFade();
      return;
    }
    window.addEventListener("load", beginFade, { once: true });
    safety = window.setTimeout(beginFade, 4000);
    return () => {
      window.removeEventListener("load", beginFade);
      window.clearTimeout(safety);
    };
  }, []);

  useEffect(() => {
    if (phase !== "fading") return;
    const t = window.setTimeout(() => setPhase("gone"), 500);
    return () => window.clearTimeout(t);
  }, [phase]);

  if (phase === "gone") return null;

  return (
    <div
      className="sideline-splash fixed inset-0 z-[9999] flex flex-col items-center justify-center gap-5"
      style={{
        background: "#0c0f0a",
        opacity: phase === "fading" ? 0 : 1,
        transition: "opacity 450ms ease",
        pointerEvents: phase === "fading" ? "none" : "auto",
      }}
      aria-hidden="true"
    >
      <div className="sideline-splash-mark relative">
        <img
          src="/icons/icon-256.webp"
          alt=""
          width={128}
          height={128}
          className="h-28 w-28 rounded-2xl shadow-2xl"
        />
        <span className="sideline-splash-dot" />
      </div>
      <div className="text-center">
        <p className="text-3xl font-bold tracking-[0.18em] text-white">SIDELINE</p>
        <p className="mt-2 text-[11px] font-medium uppercase tracking-[0.3em] text-white/60">
          Live scores · Standings · Highlights
        </p>
      </div>
      <div className="sideline-splash-bar" />
    </div>
  );
}
