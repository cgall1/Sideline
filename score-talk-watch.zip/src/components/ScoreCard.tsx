import { Link } from "@tanstack/react-router";
import type { Game } from "@/data/sports";
import { LeagueBadge } from "@/components/LeagueFilter";
import { cn } from "@/lib/utils";

function StatusPill({ game }: { game: Game }) {
  if (game.status === "live") {
    return (
      <span className="live-dot scoreboard inline-flex items-center text-xs font-bold uppercase tracking-widest text-live">
        {game.clock}
      </span>
    );
  }
  if (game.status === "final") {
    return (
      <span className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
        Final
      </span>
    );
  }
  return (
    <span className="scoreboard text-xs font-bold uppercase tracking-widest text-muted-foreground">
      {game.startLabel}
    </span>
  );
}

function Row({
  abbr,
  name,
  record,
  score,
  winner,
  show,
}: {
  abbr: string;
  name: string;
  record: string;
  score: number;
  winner: boolean;
  show: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 py-2">
      <div className="flex min-w-0 items-center gap-2.5">
        <span className="scoreboard w-10 shrink-0 border-r border-border pr-2 text-center text-xs font-bold">
          {abbr}
        </span>
        <span className="min-w-0">
          <span className="block truncate text-sm font-semibold">{name}</span>
          <span className="block text-xs text-muted-foreground">{record}</span>
        </span>
      </div>
      <span
        className={cn(
          "scoreboard text-xl font-bold tabular-nums",
          !show && "text-muted-foreground",
          show && !winner && "text-muted-foreground",
        )}
      >
        {show ? score : "–"}
      </span>
    </div>
  );
}

export function ScoreCard({ game, compact = false }: { game: Game; compact?: boolean }) {
  const show = game.status !== "scheduled";
  return (
    <article
      className={cn(
        "group border border-border bg-card p-4 transition-colors hover:border-foreground",
        game.status === "live" && "border-l-4 border-l-live",
      )}
    >
      <header className="mb-2 flex items-center justify-between gap-2 border-b border-border pb-2">
        <LeagueBadge league={game.league} />
        <StatusPill game={game} />
      </header>
      <div className="divide-y divide-border/60">
        <Row
          abbr={game.away.abbr}
          name={game.away.name}
          record={game.away.record}
          score={game.awayScore}
          winner={game.awayScore >= game.homeScore}
          show={show}
        />
        <Row
          abbr={game.home.abbr}
          name={game.home.name}
          record={game.home.record}
          score={game.homeScore}
          winner={game.homeScore >= game.awayScore}
          show={show}
        />
      </div>
      {!compact && (
        <footer className="mt-2.5 space-y-1.5 border-t border-border/60 pt-2.5">
          <p className="text-xs text-muted-foreground">{game.headline}</p>
          <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span>{game.venue}</span>
            <span aria-hidden>·</span>
            <span>{game.broadcasters.join(", ")}</span>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link
              to="/game/$league/$gameId"
              params={{ league: game.league, gameId: game.id }}
              className="text-xs font-semibold text-primary hover:underline"
            >
              Match thread →
            </Link>
            <Link
              to="/community"
              search={{ game: game.id }}
              className="text-xs font-semibold text-primary hover:underline"
            >
              League chat →
            </Link>
          </div>
        </footer>
      )}
    </article>
  );
}
