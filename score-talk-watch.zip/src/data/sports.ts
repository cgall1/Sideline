export type LeagueId =
  | "nfl"
  | "nhl"
  | "nba"
  | "wnba"
  | "mlb"
  | "mls"
  | "intl"
  | "cfb"
  | "cbb"
  | "chk"
  | "cbs"
  | "nwsl"
  | "sball"
  | "vball";

export interface League {
  id: LeagueId;
  name: string;
  short: string;
  sport: string;
  accent: string; // css var name suffix
}

export const LEAGUES: League[] = [
  { id: "nfl", name: "National Football League", short: "NFL", sport: "Football", accent: "nfl" },
  { id: "nba", name: "National Basketball Association", short: "NBA", sport: "Basketball", accent: "nba" },
  { id: "wnba", name: "Women's National Basketball Association", short: "WNBA", sport: "Basketball", accent: "wnba" },
  { id: "nhl", name: "National Hockey League", short: "NHL", sport: "Hockey", accent: "nhl" },
  { id: "mlb", name: "Major League Baseball", short: "MLB", sport: "Baseball", accent: "mlb" },
  { id: "mls", name: "Major League Soccer", short: "MLS", sport: "Soccer", accent: "mls" },
  { id: "intl", name: "International Soccer", short: "INTL", sport: "Soccer", accent: "intl" },
  { id: "cfb", name: "College Football", short: "NCAAF", sport: "Football", accent: "cfb" },
  { id: "cbb", name: "College Basketball", short: "NCAAM", sport: "Basketball", accent: "cbb" },
  { id: "chk", name: "College Hockey", short: "NCAAH", sport: "Hockey", accent: "chk" },
  { id: "cbs", name: "College Baseball", short: "CBASE", sport: "Baseball", accent: "cbs" },
  { id: "nwsl", name: "National Women's Soccer League", short: "NWSL", sport: "Soccer", accent: "nwsl" },
  { id: "sball", name: "NCAA Softball", short: "NCAA SB", sport: "Softball", accent: "sball" },
  { id: "vball", name: "NCAA Women's Volleyball", short: "NCAA VB", sport: "Volleyball", accent: "vball" },
];

export const leagueById = (id: string) => LEAGUES.find((l) => l.id === id);

export type GameStatus = "live" | "scheduled" | "final";

export interface Team {
  name: string;
  abbr: string;
  record: string;
}

export interface Game {
  id: string;
  league: LeagueId;
  home: Team;
  away: Team;
  homeScore: number;
  awayScore: number;
  status: GameStatus;
  clock: string;
  venue: string;
  /** ISO-ish kickoff label, kept as a fixed string for stable rendering */
  startLabel: string;
  /** True ISO 8601 kickoff time when the live feed supplies one. */
  startISO?: string | undefined;
  broadcasters: string[];
  headline: string;
}

export const GAMES: Game[] = [
  {
    id: "nfl-1",
    league: "nfl",
    home: { name: "Kansas City Chiefs", abbr: "KC", record: "8-2" },
    away: { name: "Buffalo Bills", abbr: "BUF", record: "7-3" },
    homeScore: 24,
    awayScore: 21,
    status: "live",
    clock: "Q4 · 6:12",
    venue: "Arrowhead Stadium",
    startLabel: "Sun 4:25 PM ET",
    broadcasters: ["CBS", "Paramount+"],
    headline: "AFC heavyweights trade blows in a one-score fourth quarter.",
  },
  {
    id: "nfl-2",
    league: "nfl",
    home: { name: "Philadelphia Eagles", abbr: "PHI", record: "9-1" },
    away: { name: "Dallas Cowboys", abbr: "DAL", record: "6-4" },
    homeScore: 17,
    awayScore: 13,
    status: "live",
    clock: "Q3 · 2:40",
    venue: "Lincoln Financial Field",
    startLabel: "Sun 8:20 PM ET",
    broadcasters: ["NBC", "Peacock"],
    headline: "NFC East rivalry tightens after a defensive first half.",
  },
  {
    id: "nfl-3",
    league: "nfl",
    home: { name: "San Francisco 49ers", abbr: "SF", record: "7-3" },
    away: { name: "Seattle Seahawks", abbr: "SEA", record: "5-5" },
    homeScore: 0,
    awayScore: 0,
    status: "scheduled",
    clock: "",
    venue: "Levi's Stadium",
    startLabel: "Mon 8:15 PM ET",
    broadcasters: ["ESPN", "ABC"],
    headline: "Division rematch closes out the week.",
  },
  {
    id: "nba-1",
    league: "nba",
    home: { name: "Boston Celtics", abbr: "BOS", record: "14-4" },
    away: { name: "Denver Nuggets", abbr: "DEN", record: "12-6" },
    homeScore: 98,
    awayScore: 95,
    status: "live",
    clock: "Q4 · 4:02",
    venue: "TD Garden",
    startLabel: "Tue 7:30 PM ET",
    broadcasters: ["TNT", "Max"],
    headline: "Finals-caliber matchup goes down to the wire in Boston.",
  },
  {
    id: "nba-2",
    league: "nba",
    home: { name: "Golden State Warriors", abbr: "GSW", record: "10-8" },
    away: { name: "Los Angeles Lakers", abbr: "LAL", record: "11-7" },
    homeScore: 0,
    awayScore: 0,
    status: "scheduled",
    clock: "",
    venue: "Chase Center",
    startLabel: "Tue 10:00 PM ET",
    broadcasters: ["NBA TV", "League Pass"],
    headline: "Bay Area hosts the latest chapter of a classic rivalry.",
  },
  {
    id: "nba-3",
    league: "nba",
    home: { name: "Milwaukee Bucks", abbr: "MIL", record: "11-7" },
    away: { name: "Miami Heat", abbr: "MIA", record: "9-9" },
    homeScore: 112,
    awayScore: 104,
    status: "final",
    clock: "Final",
    venue: "Fiserv Forum",
    startLabel: "Mon 8:00 PM ET",
    broadcasters: ["Bally Sports"],
    headline: "Bucks pull away late behind a 31-point night.",
  },
  {
    id: "nhl-1",
    league: "nhl",
    home: { name: "Colorado Avalanche", abbr: "COL", record: "13-6-2" },
    away: { name: "Vegas Golden Knights", abbr: "VGK", record: "12-5-3" },
    homeScore: 3,
    awayScore: 2,
    status: "live",
    clock: "3rd · 8:44",
    venue: "Ball Arena",
    startLabel: "Tue 9:00 PM ET",
    broadcasters: ["ESPN+", "Altitude"],
    headline: "Avalanche cling to a one-goal lead in a playoff preview.",
  },
  {
    id: "nhl-2",
    league: "nhl",
    home: { name: "Toronto Maple Leafs", abbr: "TOR", record: "11-7-3" },
    away: { name: "Montreal Canadiens", abbr: "MTL", record: "8-10-2" },
    homeScore: 0,
    awayScore: 0,
    status: "scheduled",
    clock: "",
    venue: "Scotiabank Arena",
    startLabel: "Wed 7:00 PM ET",
    broadcasters: ["Sportsnet"],
    headline: "Original Six night in Toronto.",
  },
  {
    id: "mlb-1",
    league: "mlb",
    home: { name: "Los Angeles Dodgers", abbr: "LAD", record: "92-58" },
    away: { name: "Atlanta Braves", abbr: "ATL", record: "89-61" },
    homeScore: 4,
    awayScore: 4,
    status: "live",
    clock: "Bot 8th",
    venue: "Dodger Stadium",
    startLabel: "Tue 10:10 PM ET",
    broadcasters: ["FS1", "SportsNet LA"],
    headline: "Tied late with the bullpens emptied in Chavez Ravine.",
  },
  {
    id: "mlb-2",
    league: "mlb",
    home: { name: "New York Yankees", abbr: "NYY", record: "88-62" },
    away: { name: "Boston Red Sox", abbr: "BOS", record: "80-70" },
    homeScore: 6,
    awayScore: 2,
    status: "final",
    clock: "Final",
    venue: "Yankee Stadium",
    startLabel: "Mon 7:05 PM ET",
    broadcasters: ["YES Network"],
    headline: "Yankees take the series opener behind seven shutout innings.",
  },
  {
    id: "mls-1",
    league: "mls",
    home: { name: "Inter Miami CF", abbr: "MIA", record: "18-7-5" },
    away: { name: "LAFC", abbr: "LAFC", record: "16-8-6" },
    homeScore: 2,
    awayScore: 1,
    status: "live",
    clock: "72'",
    venue: "Chase Stadium",
    startLabel: "Sat 7:30 PM ET",
    broadcasters: ["MLS Season Pass"],
    headline: "Miami edge ahead in a Supporters' Shield six-pointer.",
  },
  {
    id: "mls-2",
    league: "mls",
    home: { name: "Seattle Sounders FC", abbr: "SEA", record: "14-9-8" },
    away: { name: "Portland Timbers", abbr: "POR", record: "12-11-8" },
    homeScore: 0,
    awayScore: 0,
    status: "scheduled",
    clock: "",
    venue: "Lumen Field",
    startLabel: "Sat 10:00 PM ET",
    broadcasters: ["MLS Season Pass", "FOX"],
    headline: "Cascadia Cup on the line in Seattle.",
  },
  {
    id: "intl-1",
    league: "intl",
    home: { name: "Real Madrid", abbr: "RMA", record: "1st · LaLiga" },
    away: { name: "Manchester City", abbr: "MCI", record: "2nd · Premier League" },
    homeScore: 1,
    awayScore: 1,
    status: "live",
    clock: "63'",
    venue: "Santiago Bernabéu",
    startLabel: "Wed 3:00 PM ET",
    broadcasters: ["CBS Sports Network", "Paramount+"],
    headline: "Champions League tie level on the night in Madrid.",
  },
  {
    id: "intl-2",
    league: "intl",
    home: { name: "Arsenal", abbr: "ARS", record: "2nd · Premier League" },
    away: { name: "Liverpool", abbr: "LIV", record: "1st · Premier League" },
    homeScore: 0,
    awayScore: 0,
    status: "scheduled",
    clock: "",
    venue: "Emirates Stadium",
    startLabel: "Sun 11:30 AM ET",
    broadcasters: ["NBC", "Peacock"],
    headline: "Title race renewed in north London.",
  },
  {
    id: "intl-3",
    league: "intl",
    home: { name: "Bayern München", abbr: "FCB", record: "1st · Bundesliga" },
    away: { name: "Borussia Dortmund", abbr: "BVB", record: "4th · Bundesliga" },
    homeScore: 3,
    awayScore: 0,
    status: "final",
    clock: "FT",
    venue: "Allianz Arena",
    startLabel: "Sat 12:30 PM ET",
    broadcasters: ["ESPN+"],
    headline: "Der Klassiker turns one-sided after the break.",
  },
];

export interface StandingRow {
  team: string;
  w: number;
  l: number;
  otl?: number;
  pct: string;
  streak: string;
}

export const STANDINGS: Record<LeagueId, { group: string; rows: StandingRow[] }> = {
  nwsl: {
    group: "NWSL table",
    rows: [
      { team: "Orlando Pride", w: 14, l: 4, pct: ".778", streak: "W3" },
      { team: "Washington Spirit", w: 13, l: 5, pct: ".722", streak: "W1" },
      { team: "Kansas City Current", w: 12, l: 5, pct: ".706", streak: "W2" },
      { team: "Portland Thorns FC", w: 11, l: 6, pct: ".647", streak: "L1" },
      { team: "Gotham FC", w: 10, l: 7, pct: ".588", streak: "W1" },
    ],
  },
  sball: {
    group: "NCAA softball leaders",
    rows: [
      { team: "Oklahoma Sooners", w: 45, l: 5, pct: ".900", streak: "W8" },
      { team: "Texas Longhorns", w: 43, l: 7, pct: ".860", streak: "W4" },
      { team: "Florida Gators", w: 41, l: 9, pct: ".820", streak: "W2" },
      { team: "UCLA Bruins", w: 40, l: 10, pct: ".800", streak: "L1" },
      { team: "Tennessee Lady Vols", w: 38, l: 12, pct: ".760", streak: "W3" },
    ],
  },
  vball: {
    group: "NCAA volleyball leaders",
    rows: [
      { team: "Nebraska Cornhuskers", w: 28, l: 2, pct: ".933", streak: "W10" },
      { team: "Texas Longhorns", w: 26, l: 3, pct: ".897", streak: "W5" },
      { team: "Penn State Nittany Lions", w: 26, l: 4, pct: ".867", streak: "W6" },
      { team: "Pittsburgh Panthers", w: 25, l: 4, pct: ".862", streak: "W3" },
      { team: "Stanford Cardinal", w: 24, l: 5, pct: ".828", streak: "L1" },
    ],
  },
  wnba: {
    group: "WNBA leaders",
    rows: [
      { team: "Las Vegas Aces", w: 20, l: 6, pct: ".769", streak: "W4" },
      { team: "New York Liberty", w: 19, l: 7, pct: ".731", streak: "W2" },
      { team: "Minnesota Lynx", w: 18, l: 8, pct: ".692", streak: "W1" },
      { team: "Seattle Storm", w: 16, l: 10, pct: ".615", streak: "L1" },
      { team: "Indiana Fever", w: 15, l: 11, pct: ".577", streak: "W3" },
    ],
  },
  chk: {
    group: "National leaders",
    rows: [
      { team: "Boston College Eagles", w: 14, l: 3, pct: ".824", streak: "W4" },
      { team: "Denver Pioneers", w: 13, l: 4, pct: ".765", streak: "W2" },
      { team: "Michigan State Spartans", w: 13, l: 4, pct: ".765", streak: "W3" },
      { team: "North Dakota Fighting Hawks", w: 12, l: 5, pct: ".706", streak: "L1" },
      { team: "Minnesota Golden Gophers", w: 12, l: 5, pct: ".706", streak: "W1" },
    ],
  },
  cbs: {
    group: "National leaders",
    rows: [
      { team: "LSU Tigers", w: 12, l: 3, pct: ".800", streak: "W3" },
      { team: "Tennessee Volunteers", w: 11, l: 4, pct: ".733", streak: "W1" },
      { team: "Texas A&M Aggies", w: 11, l: 4, pct: ".733", streak: "L1" },
      { team: "Arkansas Razorbacks", w: 10, l: 5, pct: ".667", streak: "W2" },
      { team: "Florida Gators", w: 10, l: 5, pct: ".667", streak: "W1" },
    ],
  },
  cbb: {
    group: "Top 25 leaders",
    rows: [
      { team: "Kansas Jayhawks", w: 12, l: 1, pct: ".923", streak: "W6" },
      { team: "Purdue Boilermakers", w: 12, l: 2, pct: ".857", streak: "W3" },
      { team: "UConn Huskies", w: 11, l: 2, pct: ".846", streak: "W4" },
      { team: "Duke Blue Devils", w: 11, l: 3, pct: ".786", streak: "W2" },
      { team: "Houston Cougars", w: 11, l: 3, pct: ".786", streak: "L1" },
    ],
  },
  cfb: {
    group: "Top 25 leaders",
    rows: [
      { team: "Georgia Bulldogs", w: 10, l: 0, pct: "1.000", streak: "W10" },
      { team: "Ohio State Buckeyes", w: 9, l: 1, pct: ".900", streak: "W4" },
      { team: "Texas Longhorns", w: 9, l: 1, pct: ".900", streak: "W6" },
      { team: "Michigan Wolverines", w: 9, l: 1, pct: ".900", streak: "W2" },
      { team: "Alabama Crimson Tide", w: 8, l: 2, pct: ".800", streak: "W3" },
    ],
  },
  nfl: {
    group: "Conference leaders",
    rows: [
      { team: "Philadelphia Eagles", w: 9, l: 1, pct: ".900", streak: "W5" },
      { team: "Kansas City Chiefs", w: 8, l: 2, pct: ".800", streak: "W2" },
      { team: "Buffalo Bills", w: 7, l: 3, pct: ".700", streak: "L1" },
      { team: "San Francisco 49ers", w: 7, l: 3, pct: ".700", streak: "W3" },
      { team: "Detroit Lions", w: 7, l: 3, pct: ".700", streak: "W1" },
    ],
  },
  nba: {
    group: "Overall",
    rows: [
      { team: "Boston Celtics", w: 14, l: 4, pct: ".778", streak: "W4" },
      { team: "Denver Nuggets", w: 12, l: 6, pct: ".667", streak: "W1" },
      { team: "Oklahoma City Thunder", w: 12, l: 6, pct: ".667", streak: "W2" },
      { team: "Milwaukee Bucks", w: 11, l: 7, pct: ".611", streak: "W1" },
      { team: "Los Angeles Lakers", w: 11, l: 7, pct: ".611", streak: "L1" },
    ],
  },
  nhl: {
    group: "Points leaders",
    rows: [
      { team: "Colorado Avalanche", w: 13, l: 6, otl: 2, pct: "28 PTS", streak: "W3" },
      { team: "Vegas Golden Knights", w: 12, l: 5, otl: 3, pct: "27 PTS", streak: "W1" },
      { team: "Toronto Maple Leafs", w: 11, l: 7, otl: 3, pct: "25 PTS", streak: "L2" },
      { team: "Florida Panthers", w: 11, l: 8, otl: 1, pct: "23 PTS", streak: "W2" },
      { team: "Boston Bruins", w: 10, l: 8, otl: 2, pct: "22 PTS", streak: "L1" },
    ],
  },
  mlb: {
    group: "Best records",
    rows: [
      { team: "Los Angeles Dodgers", w: 92, l: 58, pct: ".613", streak: "W2" },
      { team: "Atlanta Braves", w: 89, l: 61, pct: ".593", streak: "L1" },
      { team: "New York Yankees", w: 88, l: 62, pct: ".587", streak: "W3" },
      { team: "Baltimore Orioles", w: 86, l: 64, pct: ".573", streak: "W1" },
      { team: "Houston Astros", w: 84, l: 66, pct: ".560", streak: "L2" },
    ],
  },
  mls: {
    group: "Supporters' Shield race",
    rows: [
      { team: "Inter Miami CF", w: 18, l: 7, otl: 5, pct: "59 PTS", streak: "W4" },
      { team: "LAFC", w: 16, l: 8, otl: 6, pct: "54 PTS", streak: "D1" },
      { team: "FC Cincinnati", w: 16, l: 9, otl: 5, pct: "53 PTS", streak: "W1" },
      { team: "Seattle Sounders FC", w: 14, l: 9, otl: 8, pct: "50 PTS", streak: "W2" },
      { team: "Columbus Crew", w: 14, l: 10, otl: 6, pct: "48 PTS", streak: "L1" },
    ],
  },
  intl: {
    group: "Across Europe",
    rows: [
      { team: "Liverpool (PL)", w: 12, l: 1, otl: 3, pct: "39 PTS", streak: "W3" },
      { team: "Real Madrid (LaLiga)", w: 12, l: 2, otl: 2, pct: "38 PTS", streak: "W2" },
      { team: "Bayern München (BL)", w: 11, l: 1, otl: 2, pct: "35 PTS", streak: "W5" },
      { team: "Arsenal (PL)", w: 11, l: 2, otl: 3, pct: "36 PTS", streak: "D1" },
      { team: "Inter (Serie A)", w: 11, l: 2, otl: 3, pct: "36 PTS", streak: "W1" },
    ],
  },
};

export interface Leader {
  league: LeagueId;
  category: string;
  player: string;
  team: string;
  value: string;
}

export const LEADERS: Leader[] = [
  { league: "nfl", category: "Passing yards", player: "J. Allen", team: "BUF", value: "3,102" },
  { league: "nfl", category: "Rushing yards", player: "S. Barkley", team: "PHI", value: "1,244" },
  { league: "nba", category: "Points per game", player: "L. Dončić", team: "DAL", value: "33.1" },
  { league: "nba", category: "Assists per game", player: "T. Haliburton", team: "IND", value: "11.4" },
  { league: "nhl", category: "Points", player: "N. MacKinnon", team: "COL", value: "34" },
  { league: "nhl", category: "Goals", player: "A. Matthews", team: "TOR", value: "17" },
  { league: "mlb", category: "Home runs", player: "A. Judge", team: "NYY", value: "52" },
  { league: "mlb", category: "ERA", player: "T. Skubal", team: "DET", value: "2.31" },
  { league: "mls", category: "Goals", player: "L. Messi", team: "MIA", value: "23" },
  { league: "intl", category: "Goals (UCL)", player: "E. Haaland", team: "MCI", value: "9" },
];

export type MediaKind = "news" | "analysis" | "video";

export interface Article {
  slug: string;
  kind: MediaKind;
  league: LeagueId;
  title: string;
  dek: string;
  author: string;
  published: string;
  readTime: string;
  duration?: string;
  body: string[];
}

export const ARTICLES: Article[] = [
  {
    slug: "nfl-week-top-highlights",
    kind: "video",
    league: "nfl",
    title: "NFL Highlights: Every touchdown from the weekend slate",
    dek: "All 41 touchdowns, condensed — from deep bombs to goal-line trick plays.",
    author: "Network Video Desk",
    published: "3 hours ago",
    readTime: "Watch",
    duration: "8:45",
    body: [
      "Every scoring play from the weekend's fourteen games, cut together in chronological order so you can catch up in under nine minutes.",
      "Includes reverse-angle replays of the two pick-sixes and the lateral-fest final play that very nearly broke the internet.",
    ],
  },
  {
    slug: "mahomes-comeback-highlights",
    kind: "video",
    league: "nfl",
    title: "Highlights: Mahomes engineers another fourth-quarter comeback",
    dek: "Down 10 with six minutes left — see every snap of the game-winning drive.",
    author: "Network Video Desk",
    published: "8 hours ago",
    readTime: "Watch",
    duration: "5:30",
    body: [
      "The full two-minute drill, including the off-platform 34-yard strike on third-and-long that set up the winning score.",
      "Also included: the defensive stand that forced the punt and the sideline reaction to the go-ahead touchdown.",
    ],
  },
  {
    slug: "nfl-top-10-plays-week",
    kind: "video",
    league: "nfl",
    title: "Top 10 NFL plays of the week",
    dek: "One-handed grabs, a hurdling tight end, and the hit that shook the stadium.",
    author: "Network Video Desk",
    published: "Yesterday",
    readTime: "Watch",
    duration: "6:18",
    body: [
      "Counting down the ten best plays from across the league, from special-teams chaos to a toe-tap sideline catch that survived review.",
      "Analysts break down the route running on plays three and one — the two that required perfection to even have a chance.",
    ],
  },
  {
    slug: "chiefs-bills-fourth-quarter",
    kind: "analysis",
    league: "nfl",
    title: "The two-minute chess match that decided Chiefs–Bills",
    dek: "Kansas City's late-down disguise gave Buffalo nothing clean to throw into.",
    author: "Dana Whitlock",
    published: "2 hours ago",
    readTime: "6 min read",
    body: [
      "For three quarters the Bills moved the ball with the same middle-of-the-field concepts that have carried their offense all season. Then Kansas City stopped showing its hand.",
      "On six of the final eight snaps the Chiefs walked a safety down after the quarterback's second cadence, turning what looked like single-high coverage into a two-deep shell. Buffalo's route combinations were built to beat the picture they saw pre-snap, not the one they got.",
      "The result was a drive that stalled on three straight throws to the flat, and an Arrowhead crowd that never let the visiting offense communicate cleanly again.",
    ],
  },
  {
    slug: "celtics-nuggets-clutch",
    kind: "news",
    league: "nba",
    title: "Celtics survive Nuggets in a Finals-preview thriller",
    dek: "Boston closed on a 9-2 run with its starters logging heavy fourth-quarter minutes.",
    author: "Marcus Reyes",
    published: "5 hours ago",
    readTime: "4 min read",
    body: [
      "Boston needed every bit of its bench cushion to hold off Denver, who erased a 14-point deficit in just over five minutes of the third quarter.",
      "The difference came at the line and on the glass, where the Celtics grabbed five offensive rebounds in the final period.",
      "Denver's head coach called the stretch \"the best five minutes of basketball either team has played this year.\"",
    ],
  },
  {
    slug: "avalanche-third-period-highlights",
    kind: "video",
    league: "nhl",
    title: "Highlights: Avalanche hold the line in the third",
    dek: "Every save, block, and breakaway from a frantic final period in Denver.",
    author: "Network Video Desk",
    published: "1 hour ago",
    readTime: "Watch",
    duration: "4:12",
    body: [
      "Colorado's goaltender turned aside 14 of 15 shots in the third period, including a pair of point-blank chances inside the final two minutes.",
      "The package includes full-speed and reverse-angle looks at the disallowed goal that kept the score at 3-2.",
    ],
  },
  {
    slug: "messi-miami-shield-push",
    kind: "analysis",
    league: "mls",
    title: "How Inter Miami turned the Shield race into a procession",
    dek: "A midfield tweak in July unlocked the league's most efficient attack.",
    author: "Sofia Duarte",
    published: "Yesterday",
    readTime: "7 min read",
    body: [
      "Miami's shift to a single pivot freed their captain from defensive responsibility between the boxes, and the underlying numbers moved immediately.",
      "Since the change, they have produced 2.4 expected goals per match while conceding fewer shots from central areas.",
      "LAFC's visit was the first real test of whether the structure holds against a press that does not respect possession in midfield.",
    ],
  },
  {
    slug: "real-madrid-city-tactical",
    kind: "analysis",
    league: "intl",
    title: "Madrid vs City: the full-back battle that will settle it",
    dek: "Both sides are inverting their full-backs, and both are getting punished in transition.",
    author: "Owen Clarke",
    published: "3 hours ago",
    readTime: "8 min read",
    body: [
      "The Bernabéu tie has become a study in how two elite sides solve the same problem with mirrored risks.",
      "City's inverted full-backs give them a four-man build-up, but they leave the outside channels unguarded the moment the ball turns over.",
      "Madrid have scored three of their last five European goals attacking exactly that space.",
    ],
  },
  {
    slug: "judge-52-homers",
    kind: "news",
    league: "mlb",
    title: "Judge reaches 52 homers as Yankees clinch the season series",
    dek: "A 448-foot shot to dead center broke a fourth-inning tie in the Bronx.",
    author: "Priya Nair",
    published: "Yesterday",
    readTime: "3 min read",
    body: [
      "The Yankees captain now leads the majors by six home runs with twelve games remaining.",
      "New York's rotation has allowed two runs or fewer in seven of its last nine starts.",
    ],
  },
  {
    slug: "top-10-plays-week",
    kind: "video",
    league: "nba",
    title: "Top 10 plays of the week across every league",
    dek: "A buzzer-beater, an overtime winner, and a goal-line stand that ended a game.",
    author: "Network Video Desk",
    published: "Today",
    readTime: "Watch",
    duration: "6:38",
    body: [
      "Our editors ranked the week's ten best moments across the NFL, NBA, NHL, MLB, MLS, and European soccer.",
      "Number one needs no introduction if you were watching Tuesday night.",
    ],
  },
];

export interface Broadcast {
  gameId: string;
  channels: { provider: string; type: "TV" | "Stream" | "Radio" }[];
}

export const PROVIDERS = [
  "ESPN",
  "ESPN+",
  "ABC",
  "CBS",
  "Paramount+",
  "NBC",
  "Peacock",
  "FOX",
  "FS1",
  "TNT",
  "Max",
  "NBA TV",
  "League Pass",
  "MLS Season Pass",
  "Sportsnet",
  "YES Network",
  "Bally Sports",
  "Altitude",
  "SportsNet LA",
  "CBS Sports Network",
];

export interface Poll {
  id: string;
  league: LeagueId;
  question: string;
  options: { id: string; label: string; votes: number }[];
}

export const POLLS: Poll[] = [
  {
    id: "poll-1",
    league: "nfl",
    question: "Who wins the AFC this season?",
    options: [
      { id: "kc", label: "Chiefs", votes: 4820 },
      { id: "buf", label: "Bills", votes: 3910 },
      { id: "bal", label: "Ravens", votes: 2145 },
      { id: "field", label: "The field", votes: 1288 },
    ],
  },
  {
    id: "poll-2",
    league: "nba",
    question: "Celtics–Nuggets in June: who takes it?",
    options: [
      { id: "bos", label: "Celtics in 6", votes: 2980 },
      { id: "den", label: "Nuggets in 7", votes: 3240 },
      { id: "neither", label: "Neither gets there", votes: 1502 },
    ],
  },
  {
    id: "poll-3",
    league: "intl",
    question: "Best team in Europe right now?",
    options: [
      { id: "rma", label: "Real Madrid", votes: 5120 },
      { id: "mci", label: "Man City", votes: 4770 },
      { id: "liv", label: "Liverpool", votes: 4310 },
      { id: "fcb", label: "Bayern", votes: 2260 },
    ],
  },
];

export interface Post {
  id: string;
  gameId: string;
  user: string;
  team: string;
  minutesAgo: number;
  text: string;
  likes: number;
}

export const POSTS: Post[] = [
  { id: "p1", gameId: "nfl-1", user: "RedKingdom_77", team: "KC", minutesAgo: 1, text: "Defense has forced three straight three-and-outs. This is the game right here.", likes: 142 },
  { id: "p2", gameId: "nfl-1", user: "BillsMafiaJen", team: "BUF", minutesAgo: 2, text: "We need one explosive play. Stop running into the line on second and long.", likes: 98 },
  { id: "p3", gameId: "nfl-1", user: "NeutralNate", team: "—", minutesAgo: 4, text: "Best broadcast game of the year and it isn't close.", likes: 61 },
  { id: "p4", gameId: "nba-1", user: "GardenParty", team: "BOS", minutesAgo: 1, text: "Switch everything and live with the midrange. It's working.", likes: 77 },
  { id: "p5", gameId: "nba-1", user: "MileHighHoops", team: "DEN", minutesAgo: 3, text: "Give the ball to the big fella at the elbow every single possession.", likes: 120 },
  { id: "p6", gameId: "intl-1", user: "BernabeuBoy", team: "RMA", minutesAgo: 2, text: "The tempo dropped the second they went level. Need a change now.", likes: 203 },
  { id: "p7", gameId: "intl-1", user: "BlueMoonRising", team: "MCI", minutesAgo: 5, text: "Away goal energy even though away goals don't exist anymore.", likes: 155 },
  { id: "p8", gameId: "mlb-1", user: "ChavezRavine", team: "LAD", minutesAgo: 2, text: "Bullpen is cooked. Just let the position player finish it.", likes: 44 },
  { id: "p9", gameId: "mls-1", user: "Herons305", team: "MIA", minutesAgo: 1, text: "Twenty minutes to hold on for the Shield. Heart rate is unwell.", likes: 88 },
];

export const REACTIONS = ["🔥", "😤", "😱", "🙌", "🤡"] as const;
