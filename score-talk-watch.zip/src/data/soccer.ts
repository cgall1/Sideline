export interface SoccerCompetition {
  /** URL slug used for /media/<slug> */
  slug: string;
  /** ESPN competition path */
  path: string;
  name: string;
  short: string;
  country: string;
  blurb: string;
  /** Which part of the world the competition belongs to. */
  region?: "europe" | "americas" | "africa" | "asia";
}

export const SOCCER_COMPETITIONS: SoccerCompetition[] = [
  {
    slug: "premier-league-highlights",
    path: "soccer/eng.1",
    name: "Premier League",
    short: "EPL",
    country: "England",
    region: "europe",
    blurb:
      "Every Premier League goal, the best saves and full match recaps from England's top flight, updated after every matchday.",
  },
  {
    slug: "laliga-highlights",
    path: "soccer/esp.1",
    name: "LaLiga",
    short: "LaLiga",
    country: "Spain",
    region: "europe",
    blurb:
      "LaLiga highlights from Spain: goals, skills and full match recaps from Real Madrid, Barcelona, Atlético and the rest.",
  },
  {
    slug: "bundesliga-highlights",
    path: "soccer/ger.1",
    name: "Bundesliga",
    short: "BUND",
    country: "Germany",
    region: "europe",
    blurb:
      "Bundesliga highlights: goals, top plays and match recaps from Bayern, Dortmund, Leverkusen and every German top-flight club.",
  },
  {
    slug: "serie-a-highlights",
    path: "soccer/ita.1",
    name: "Serie A",
    short: "SERIE A",
    country: "Italy",
    region: "europe",
    blurb:
      "Serie A highlights from Italy: every goal, the best saves and full match recaps from Inter, Milan, Juventus, Napoli and more.",
  },
  {
    slug: "ligue-1-highlights",
    path: "soccer/fra.1",
    name: "Ligue 1",
    short: "LIGUE 1",
    country: "France",
    region: "europe",
    blurb:
      "Ligue 1 highlights: goals, top plays and match recaps from Paris Saint-Germain, Marseille, Monaco and France's top division.",
  },
  {
    slug: "champions-league-highlights",
    path: "soccer/uefa.champions",
    name: "UEFA Champions League",
    short: "UCL",
    country: "Europe",
    region: "europe",
    blurb:
      "Champions League highlights: every European night's goals, comebacks and full match recaps from the biggest clubs on earth.",
  },
  {
    slug: "championship-highlights",
    path: "soccer/eng.2",
    name: "EFL Championship",
    short: "EFL",
    country: "England",
    region: "europe",
    blurb:
      "EFL Championship highlights: goals and match recaps from England's second tier and the race for the Premier League.",
  },
  {
    slug: "fa-cup-highlights",
    path: "soccer/eng.fa",
    name: "FA Cup",
    short: "FA CUP",
    country: "England",
    region: "europe",
    blurb:
      "FA Cup highlights: giant-killings, extra time drama and full match recaps from England's oldest cup competition.",
  },
  {
    slug: "laliga-2-highlights",
    path: "soccer/esp.2",
    name: "LaLiga 2",
    short: "LALIGA 2",
    country: "Spain",
    region: "europe",
    blurb:
      "LaLiga 2 highlights and recaps from Spain's second division promotion race, updated after every matchday.",
  },
  {
    slug: "copa-del-rey-highlights",
    path: "soccer/esp.copa_del_rey",
    name: "Copa del Rey",
    short: "COPA DEL REY",
    country: "Spain",
    region: "europe",
    blurb:
      "Copa del Rey highlights: cup upsets, late winners and full match recaps from Spain's national cup.",
  },
  {
    slug: "serie-b-highlights",
    path: "soccer/ita.2",
    name: "Serie B",
    short: "SERIE B",
    country: "Italy",
    region: "europe",
    blurb:
      "Serie B highlights and recaps from Italy's second division and the fight for promotion to Serie A.",
  },
  {
    slug: "coppa-italia-highlights",
    path: "soccer/ita.coppa_italia",
    name: "Coppa Italia",
    short: "COPPA",
    country: "Italy",
    region: "europe",
    blurb:
      "Coppa Italia highlights: knockout drama and full match recaps from Italy's national cup competition.",
  },
  {
    slug: "2-bundesliga-highlights",
    path: "soccer/ger.2",
    name: "2. Bundesliga",
    short: "2. BUND",
    country: "Germany",
    region: "europe",
    blurb:
      "2. Bundesliga highlights and match recaps from Germany's second tier and the climb toward the Bundesliga.",
  },
  {
    slug: "dfb-pokal-highlights",
    path: "soccer/ger.dfb_pokal",
    name: "DFB-Pokal",
    short: "POKAL",
    country: "Germany",
    region: "europe",
    blurb:
      "DFB-Pokal highlights: cup shocks, shootouts and full match recaps from Germany's national cup.",
  },
  {
    slug: "ligue-2-highlights",
    path: "soccer/fra.2",
    name: "Ligue 2",
    short: "LIGUE 2",
    country: "France",
    region: "europe",
    blurb:
      "Ligue 2 highlights and recaps from France's second division promotion battle.",
  },
  {
    slug: "primeira-liga-highlights",
    path: "soccer/por.1",
    name: "Primeira Liga",
    short: "POR",
    country: "Portugal",
    region: "europe",
    blurb:
      "Primeira Liga highlights: goals and match recaps from Benfica, Porto, Sporting and Portugal's top flight.",
  },
  {
    slug: "eredivisie-highlights",
    path: "soccer/ned.1",
    name: "Eredivisie",
    short: "NED",
    country: "Netherlands",
    region: "europe",
    blurb:
      "Eredivisie highlights: Ajax, PSV, Feyenoord and every Dutch top-flight club, goal by goal.",
  },
  {
    slug: "belgian-pro-league-highlights",
    path: "soccer/bel.1",
    name: "Belgian Pro League",
    short: "BEL",
    country: "Belgium",
    region: "europe",
    blurb:
      "Belgian Pro League highlights and match recaps from Club Brugge, Anderlecht, Genk and the rest.",
  },
  {
    slug: "super-lig-highlights",
    path: "soccer/tur.1",
    name: "Süper Lig",
    short: "TUR",
    country: "Türkiye",
    region: "europe",
    blurb:
      "Süper Lig highlights: Galatasaray, Fenerbahçe, Beşiktaş and every club in Turkey's top division.",
  },
  {
    slug: "scottish-premiership-highlights",
    path: "soccer/sco.1",
    name: "Scottish Premiership",
    short: "SCO",
    country: "Scotland",
    region: "europe",
    blurb:
      "Scottish Premiership highlights: Celtic, Rangers and every club in Scotland's top flight.",
  },
  {
    slug: "swiss-super-league-highlights",
    path: "soccer/sui.1",
    name: "Swiss Super League",
    short: "SUI",
    country: "Switzerland",
    region: "europe",
    blurb:
      "Swiss Super League highlights and match recaps from Young Boys, Basel and Switzerland's top division.",
  },
  {
    slug: "austrian-bundesliga-highlights",
    path: "soccer/aut.1",
    name: "Austrian Bundesliga",
    short: "AUT",
    country: "Austria",
    region: "europe",
    blurb:
      "Austrian Bundesliga highlights from Salzburg, Rapid Vienna, Sturm Graz and the rest of the league.",
  },
  {
    slug: "greek-super-league-highlights",
    path: "soccer/gre.1",
    name: "Greek Super League",
    short: "GRE",
    country: "Greece",
    region: "europe",
    blurb:
      "Greek Super League highlights: Olympiacos, PAOK, AEK, Panathinaikos and every club in Greece.",
  },
  {
    slug: "russian-premier-league-highlights",
    path: "soccer/rus.1",
    name: "Russian Premier League",
    short: "RUS",
    country: "Russia",
    region: "europe",
    blurb:
      "Russian Premier League highlights and match recaps from Zenit, Spartak, CSKA and the rest.",
  },
  {
    slug: "danish-superliga-highlights",
    path: "soccer/den.1",
    name: "Danish Superliga",
    short: "DEN",
    country: "Denmark",
    region: "europe",
    blurb:
      "Danish Superliga highlights from Copenhagen, Midtjylland, Brøndby and Denmark's top flight.",
  },
  {
    slug: "eliteserien-highlights",
    path: "soccer/nor.1",
    name: "Eliteserien",
    short: "NOR",
    country: "Norway",
    region: "europe",
    blurb:
      "Eliteserien highlights: goals and match recaps from Bodø/Glimt and Norway's top division.",
  },
  {
    slug: "allsvenskan-highlights",
    path: "soccer/swe.1",
    name: "Allsvenskan",
    short: "SWE",
    country: "Sweden",
    region: "europe",
    blurb:
      "Allsvenskan highlights and recaps from Malmö, AIK, Djurgården and every Swedish top-flight club.",
  },
  {
    slug: "czech-first-league-highlights",
    path: "soccer/cze.1",
    name: "Czech First League",
    short: "CZE",
    country: "Czechia",
    region: "europe",
    blurb:
      "Czech First League highlights from Slavia Prague, Sparta Prague, Viktoria Plzeň and the rest.",
  },
  {
    slug: "liga-i-highlights",
    path: "soccer/rou.1",
    name: "Liga I",
    short: "ROU",
    country: "Romania",
    region: "europe",
    blurb:
      "Romanian Liga I highlights and match recaps from FCSB, CFR Cluj and Romania's top division.",
  },
  {
    slug: "league-of-ireland-highlights",
    path: "soccer/irl.1",
    name: "League of Ireland Premier Division",
    short: "IRL",
    country: "Ireland",
    region: "europe",
    blurb:
      "League of Ireland Premier Division highlights: Shamrock Rovers, Shelbourne and every Irish club.",
  },
  {
    slug: "ukrainian-premier-league-highlights",
    path: "soccer/ukr.1",
    name: "Ukrainian Premier League",
    short: "UPL",
    country: "Ukraine",
    region: "europe",
    blurb:
      "Ukrainian Premier League highlights and match recaps from Shakhtar Donetsk, Dynamo Kyiv and every Ukrainian club.",
  },
  {
    slug: "polish-ekstraklasa-highlights",
    path: "soccer/pol.1",
    name: "Polish Ekstraklasa",
    short: "POL",
    country: "Poland",
    region: "europe",
    blurb:
      "Polish Ekstraklasa highlights and match recaps from Legia Warsaw, Lech Poznań and every Polish club.",
  },
  {
    slug: "europa-league-highlights",
    path: "soccer/uefa.europa",
    name: "UEFA Europa League",
    short: "UEL",
    country: "Europe",
    region: "europe",
    blurb:
      "Europa League highlights: every European night's goals, comebacks and full match recaps.",
  },
  {
    slug: "conference-league-highlights",
    path: "soccer/uefa.europa.conf",
    name: "UEFA Conference League",
    short: "UECL",
    country: "Europe",
    region: "europe",
    blurb:
      "UEFA Conference League highlights and recaps from Europe's third continental club competition.",
  },
  {
    slug: "uefa-super-cup-highlights",
    path: "soccer/uefa.super_cup",
    name: "UEFA Super Cup",
    short: "SUPER CUP",
    country: "Europe",
    region: "europe",
    blurb:
      "UEFA Super Cup highlights: the Champions League and Europa League winners in one match.",
  },
  {
    slug: "uefa-nations-league-highlights",
    path: "soccer/uefa.nations",
    name: "UEFA Nations League",
    short: "UNL",
    country: "Europe",
    region: "europe",
    blurb:
      "UEFA Nations League highlights and recaps from every international window across Europe.",
  },
  {
    slug: "euros-highlights",
    path: "soccer/uefa.euro",
    name: "UEFA European Championship",
    short: "EUROS",
    country: "Europe",
    region: "europe",
    blurb:
      "UEFA European Championship highlights: goals and match recaps from the Euros.",
  },
  {
    slug: "liga-mx-highlights",
    path: "soccer/mex.1",
    name: "Liga MX",
    short: "LIGA MX",
    country: "Mexico",
    region: "americas",
    blurb:
      "Liga MX highlights, goals and full match recaps from América, Chivas, Tigres, Monterrey and every Mexican top-flight club.",
  },
  {
    slug: "liga-expansion-mx-highlights",
    path: "soccer/mex.2",
    name: "Liga de Expansión MX",
    short: "EXPANSIÓN",
    country: "Mexico",
    region: "americas",
    blurb:
      "Liga de Expansión MX highlights and match recaps from Mexico's second division, updated after every matchday.",
  },
  {
    slug: "usl-championship-highlights",
    path: "soccer/usa.usl.1",
    name: "USL Championship",
    short: "USL",
    country: "United States",
    region: "americas",
    blurb:
      "USL Championship highlights: goals, saves and match recaps from America's second-division soccer league.",
  },
  {
    slug: "usl-league-one-highlights",
    path: "soccer/usa.usl.l1",
    name: "USL League One",
    short: "USL1",
    country: "United States",
    region: "americas",
    blurb:
      "USL League One highlights and recaps from third-division soccer clubs across the United States.",
  },
  {
    slug: "us-open-cup-highlights",
    path: "soccer/usa.open",
    name: "U.S. Open Cup",
    short: "OPEN CUP",
    country: "United States",
    region: "americas",
    blurb:
      "U.S. Open Cup highlights: cup upsets, extra time drama and full match recaps from America's oldest soccer tournament.",
  },
  {
    slug: "concacaf-champions-cup-highlights",
    path: "soccer/concacaf.champions_cup",
    name: "CONCACAF Champions Cup",
    short: "CCC",
    country: "North America",
    region: "americas",
    blurb:
      "CONCACAF Champions Cup highlights: the best clubs from North America, Central America and the Caribbean, goal by goal.",
  },
  {
    slug: "concacaf-central-american-cup-highlights",
    path: "soccer/concacaf.league",
    name: "CONCACAF Central American Cup",
    short: "CAC",
    country: "Central America",
    region: "americas",
    blurb:
      "CONCACAF Central American Cup highlights and recaps from clubs across Costa Rica, Honduras, Guatemala, Panama and more.",
  },
  {
    slug: "concacaf-gold-cup-highlights",
    path: "soccer/concacaf.gold",
    name: "CONCACAF Gold Cup",
    short: "GOLD CUP",
    country: "North America",
    region: "americas",
    blurb:
      "Gold Cup highlights: goals and match recaps as the USA, Mexico, Canada and the region's national teams chase the title.",
  },
  {
    slug: "concacaf-nations-league-highlights",
    path: "soccer/concacaf.nations.league",
    name: "CONCACAF Nations League",
    short: "CNL",
    country: "North America",
    region: "americas",
    blurb:
      "CONCACAF Nations League highlights and recaps from every window of the region's national team competition.",
  },
  {
    slug: "brasileirao-highlights",
    path: "soccer/bra.1",
    name: "Brasileirão Série A",
    short: "BRA A",
    country: "Brazil",
    region: "americas",
    blurb:
      "Brasileirão Série A highlights: goals, skills and match recaps from Flamengo, Palmeiras, Corinthians and Brazil's top flight.",
  },
  {
    slug: "brasileirao-serie-b-highlights",
    path: "soccer/bra.2",
    name: "Brasileirão Série B",
    short: "BRA B",
    country: "Brazil",
    region: "americas",
    blurb:
      "Brasileirão Série B highlights and recaps from Brazil's promotion race, updated after every round.",
  },
  {
    slug: "argentine-primera-highlights",
    path: "soccer/arg.1",
    name: "Argentine Primera División",
    short: "ARG",
    country: "Argentina",
    region: "americas",
    blurb:
      "Argentine Primera División highlights: Boca, River and every club in Argentina's top flight, goal by goal.",
  },
  {
    slug: "argentine-primera-nacional-highlights",
    path: "soccer/arg.2",
    name: "Primera Nacional",
    short: "ARG B",
    country: "Argentina",
    region: "americas",
    blurb:
      "Primera Nacional highlights and recaps from Argentina's second division promotion chase.",
  },
  {
    slug: "colombia-primera-a-highlights",
    path: "soccer/col.1",
    name: "Categoría Primera A",
    short: "COL",
    country: "Colombia",
    region: "americas",
    blurb:
      "Categoría Primera A highlights: goals and match recaps from Colombia's top division.",
  },
  {
    slug: "chile-primera-highlights",
    path: "soccer/chi.1",
    name: "Primera División de Chile",
    short: "CHI",
    country: "Chile",
    region: "americas",
    blurb:
      "Chilean Primera División highlights: goals and match recaps from Colo-Colo, Universidad de Chile and the rest.",
  },
  {
    slug: "peru-liga1-highlights",
    path: "soccer/per.1",
    name: "Liga 1",
    short: "PER",
    country: "Peru",
    region: "americas",
    blurb:
      "Peruvian Liga 1 highlights and match recaps from Alianza Lima, Universitario and every club in the league.",
  },
  {
    slug: "ecuador-liga-pro-highlights",
    path: "soccer/ecu.1",
    name: "LigaPro",
    short: "ECU",
    country: "Ecuador",
    region: "americas",
    blurb:
      "Ecuadorian LigaPro highlights: goals and match recaps from Barcelona SC, LDU Quito and Ecuador's top flight.",
  },
  {
    slug: "uruguay-primera-highlights",
    path: "soccer/uru.1",
    name: "Uruguayan Primera División",
    short: "URU",
    country: "Uruguay",
    region: "americas",
    blurb:
      "Uruguayan Primera División highlights from Peñarol, Nacional and every club in the championship.",
  },
  {
    slug: "paraguay-primera-highlights",
    path: "soccer/par.1",
    name: "Paraguayan Primera División",
    short: "PAR",
    country: "Paraguay",
    region: "americas",
    blurb:
      "Paraguayan Primera División highlights: Olimpia, Cerro Porteño, Libertad and the rest of the top flight.",
  },
  {
    slug: "bolivia-primera-highlights",
    path: "soccer/bol.1",
    name: "Bolivian Primera División",
    short: "BOL",
    country: "Bolivia",
    region: "americas",
    blurb:
      "Bolivian Primera División highlights and match recaps from Bolívar, The Strongest and every club in the league.",
  },
  {
    slug: "venezuela-primera-highlights",
    path: "soccer/ven.1",
    name: "Venezuelan Primera División",
    short: "VEN",
    country: "Venezuela",
    region: "americas",
    blurb:
      "Venezuelan Primera División highlights and recaps from Caracas FC, Deportivo Táchira and the rest.",
  },
  {
    slug: "copa-libertadores-highlights",
    path: "soccer/conmebol.libertadores",
    name: "Copa Libertadores",
    short: "LIBERTADORES",
    country: "South America",
    region: "americas",
    blurb:
      "Copa Libertadores highlights: South America's biggest club nights, every goal and full match recaps.",
  },
  {
    slug: "copa-sudamericana-highlights",
    path: "soccer/conmebol.sudamericana",
    name: "Copa Sudamericana",
    short: "SUDAMERICANA",
    country: "South America",
    region: "americas",
    blurb:
      "Copa Sudamericana highlights and recaps from South America's second continental club competition.",
  },
  {
    slug: "copa-america-highlights",
    path: "soccer/conmebol.america",
    name: "Copa América",
    short: "COPA AMÉRICA",
    country: "South America",
    region: "americas",
    blurb:
      "Copa América highlights: goals and match recaps from South America's national team championship.",
  },
  {
    slug: "south-african-premiership-highlights",
    path: "soccer/rsa.1",
    name: "South African Premiership",
    short: "PSL",
    country: "South Africa",
    region: "africa",
    blurb:
      "South African Premiership highlights: every goal and match recap from the PSL.",
  },
  {
    slug: "south-african-first-division-highlights",
    path: "soccer/rsa.2",
    name: "South African First Division",
    short: "RSA 2",
    country: "South Africa",
    region: "africa",
    blurb:
      "South African First Division highlights and recaps from the country's second tier.",
  },
  {
    slug: "nigeria-premier-league-highlights",
    path: "soccer/nga.1",
    name: "Nigeria Premier League",
    short: "NPFL",
    country: "Nigeria",
    region: "africa",
    blurb:
      "Nigeria Premier League highlights: goals and match recaps from the NPFL.",
  },
  {
    slug: "ghana-premier-league-highlights",
    path: "soccer/gha.1",
    name: "Ghana Premier League",
    short: "GPL",
    country: "Ghana",
    region: "africa",
    blurb:
      "Ghana Premier League highlights and full match recaps from every matchday.",
  },
  {
    slug: "kenya-premier-league-highlights",
    path: "soccer/ken.1",
    name: "Kenya Premier League",
    short: "KPL",
    country: "Kenya",
    region: "africa",
    blurb:
      "Kenya Premier League highlights: goals and recaps from the top flight.",
  },
  {
    slug: "zimbabwe-premier-league-highlights",
    path: "soccer/zim.1",
    name: "Zimbabwe Premier Soccer League",
    short: "ZPSL",
    country: "Zimbabwe",
    region: "africa",
    blurb:
      "Zimbabwe Premier Soccer League highlights and match recaps from every round.",
  },
  {
    slug: "caf-champions-league-highlights",
    path: "soccer/caf.champions",
    name: "CAF Champions League",
    short: "CAFCL",
    country: "Africa",
    region: "africa",
    blurb:
      "CAF Champions League highlights: Africa's biggest club nights, goals and recaps.",
  },
  {
    slug: "caf-confederation-cup-highlights",
    path: "soccer/caf.confed",
    name: "CAF Confederation Cup",
    short: "CAF CC",
    country: "Africa",
    region: "africa",
    blurb:
      "CAF Confederation Cup highlights and recaps from Africa's second continental club competition.",
  },
  {
    slug: "africa-cup-of-nations-highlights",
    path: "soccer/caf.nations",
    name: "Africa Cup of Nations",
    short: "AFCON",
    country: "Africa",
    region: "africa",
    blurb:
      "Africa Cup of Nations highlights: goals and match recaps from the continental championship.",
  },
  {
    slug: "j1-league-highlights",
    path: "soccer/jpn.1",
    name: "J1 League",
    short: "J1",
    country: "Japan",
    region: "asia",
    blurb:
      "J1 League highlights: every goal and match recap from Japan's top flight.",
  },
  {
    slug: "j2-league-highlights",
    path: "soccer/jpn.2",
    name: "J2 League",
    short: "J2",
    country: "Japan",
    region: "asia",
    blurb:
      "J2 League highlights and recaps from Japan's second tier.",
  },
  {
    slug: "k-league-1-highlights",
    path: "soccer/kor.1",
    name: "K League 1",
    short: "K LEAGUE",
    country: "South Korea",
    region: "asia",
    blurb:
      "K League 1 highlights: goals and match recaps from South Korea's top flight.",
  },
  {
    slug: "chinese-super-league-highlights",
    path: "soccer/chn.1",
    name: "Chinese Super League",
    short: "CSL",
    country: "China",
    region: "asia",
    blurb:
      "Chinese Super League highlights: every goal and match recap from the CSL.",
  },
  {
    slug: "saudi-pro-league-highlights",
    path: "soccer/ksa.1",
    name: "Saudi Pro League",
    short: "SPL",
    country: "Saudi Arabia",
    region: "asia",
    blurb:
      "Saudi Pro League highlights: goals, star signings and match recaps from every round.",
  },
  {
    slug: "qatar-stars-league-highlights",
    path: "soccer/qat.1",
    name: "Qatar Stars League",
    short: "QSL",
    country: "Qatar",
    region: "asia",
    blurb:
      "Qatar Stars League highlights and match recaps from the QSL.",
  },
  {
    slug: "uae-pro-league-highlights",
    path: "soccer/uae.1",
    name: "UAE Pro League",
    short: "UAE PL",
    country: "United Arab Emirates",
    region: "asia",
    blurb:
      "UAE Pro League highlights: goals and match recaps from the Emirates' top flight.",
  },
  {
    slug: "persian-gulf-pro-league-highlights",
    path: "soccer/irn.1",
    name: "Persian Gulf Pro League",
    short: "PGPL",
    country: "Iran",
    region: "asia",
    blurb:
      "Persian Gulf Pro League highlights and match recaps from Iran's top flight.",
  },
  {
    slug: "indian-super-league-highlights",
    path: "soccer/ind.1",
    name: "Indian Super League",
    short: "ISL",
    country: "India",
    region: "asia",
    blurb:
      "Indian Super League highlights: every goal and match recap from the ISL.",
  },
  {
    slug: "thai-league-1-highlights",
    path: "soccer/tha.1",
    name: "Thai League 1",
    short: "THAI 1",
    country: "Thailand",
    region: "asia",
    blurb:
      "Thai League 1 highlights: goals and match recaps from Thailand's top flight.",
  },
  {
    slug: "vleague-1-highlights",
    path: "soccer/vie.1",
    name: "V.League 1",
    short: "V.1",
    country: "Vietnam",
    region: "asia",
    blurb:
      "V.League 1 highlights and match recaps from Vietnam's top flight.",
  },
  {
    slug: "liga-1-indonesia-highlights",
    path: "soccer/idn.1",
    name: "Liga 1",
    short: "LIGA 1",
    country: "Indonesia",
    region: "asia",
    blurb:
      "Liga 1 highlights: every goal and match recap from Indonesia's top flight.",
  },
  {
    slug: "malaysia-super-league-highlights",
    path: "soccer/mas.1",
    name: "Malaysia Super League",
    short: "MSL",
    country: "Malaysia",
    region: "asia",
    blurb:
      "Malaysia Super League highlights and match recaps from every round.",
  },
  {
    slug: "singapore-premier-league-highlights",
    path: "soccer/sgp.1",
    name: "Singapore Premier League",
    short: "SGPL",
    country: "Singapore",
    region: "asia",
    blurb:
      "Singapore Premier League highlights: goals and match recaps from every matchday.",
  },
  {
    slug: "philippines-football-league-highlights",
    path: "soccer/phl.1",
    name: "Philippines Football League",
    short: "PFL",
    country: "Philippines",
    region: "asia",
    blurb:
      "Philippines Football League highlights and match recaps.",
  },
  {
    slug: "hong-kong-premier-league-highlights",
    path: "soccer/hkg.1",
    name: "Hong Kong Premier League",
    short: "HKPL",
    country: "Hong Kong",
    region: "asia",
    blurb:
      "Hong Kong Premier League highlights: goals and match recaps from the HKPL.",
  },
  {
    slug: "a-league-highlights",
    path: "soccer/aus.1",
    name: "A-League",
    short: "A-LEAGUE",
    country: "Australia",
    region: "asia",
    blurb:
      "A-League highlights: every goal and match recap from Australia and New Zealand's top flight.",
  },
  {
    slug: "nz-national-league-highlights",
    path: "soccer/nzl.1",
    name: "New Zealand National League",
    short: "NZNL",
    country: "New Zealand",
    region: "asia",
    blurb:
      "New Zealand National League highlights and match recaps.",
  },
  {
    slug: "afc-champions-league-highlights",
    path: "soccer/afc.champions",
    name: "AFC Champions League",
    short: "ACL",
    country: "Asia",
    region: "asia",
    blurb:
      "AFC Champions League highlights: Asia's biggest club nights, every goal and full match recaps.",
  },
  {
    slug: "afc-cup-highlights",
    path: "soccer/afc.cup",
    name: "AFC Cup",
    short: "AFC CUP",
    country: "Asia",
    region: "asia",
    blurb:
      "AFC Cup highlights and recaps from Asia's second continental club competition.",
  },
  {
    slug: "afc-asian-cup-highlights",
    path: "soccer/afc.asian.cup",
    name: "AFC Asian Cup",
    short: "ASIAN CUP",
    country: "Asia",
    region: "asia",
    blurb:
      "AFC Asian Cup highlights: goals and match recaps from Asia's national team championship.",
  },
  {
    slug: "asean-championship-highlights",
    path: "soccer/aff.championship",
    name: "ASEAN Championship",
    short: "ASEAN",
    country: "Southeast Asia",
    region: "asia",
    blurb:
      "ASEAN Championship highlights: goals and recaps from Southeast Asia's national team tournament.",
  },
];

export const AMERICAS_COMPETITIONS = SOCCER_COMPETITIONS.filter(
  (c) => c.region === "americas",
);

export const EUROPE_COMPETITIONS = SOCCER_COMPETITIONS.filter(
  (c) => c.region === "europe",
);

export const AFRICA_COMPETITIONS = SOCCER_COMPETITIONS.filter(
  (c) => c.region === "africa",
);

export const ASIA_COMPETITIONS = SOCCER_COMPETITIONS.filter(
  (c) => c.region === "asia",
);

export function soccerCompetition(slug: string): SoccerCompetition | undefined {
  return SOCCER_COMPETITIONS.find((c) => c.slug === slug);
}
