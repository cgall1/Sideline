export interface HistoryMilestone {
  year: string;
  title: string;
  detail: string;
}

export interface SportHistory {
  slug: string;
  name: string;
  origin: string;
  summary: string;
  milestones: HistoryMilestone[];
  greats: { name: string; note: string }[];
  dynasties: { name: string; note: string }[];
}

export const SPORT_HISTORY: SportHistory[] = [
  {
    slug: "nfl",
    name: "NFL",
    origin: "Founded 1920 in Canton, Ohio as the American Professional Football Association",
    summary:
      "American football grew out of 19th-century college rugby, was reshaped by Walter Camp's rules, and turned professional in the industrial towns of Ohio and Pennsylvania. Television, the AFL merger and the Super Bowl made the NFL the biggest sport in the United States.",
    milestones: [
      { year: "1869", title: "First college game", detail: "Rutgers beat Princeton in a rugby-style match now counted as the first American football game." },
      { year: "1920", title: "League founded", detail: "Eleven teams met in a Hupmobile showroom in Canton and formed the APFA, renamed the NFL in 1922." },
      { year: "1958", title: "The Greatest Game Ever Played", detail: "The Colts beat the Giants in sudden-death overtime on national television and pro football's popularity exploded." },
      { year: "1967", title: "First Super Bowl", detail: "Green Bay beat Kansas City in the first AFL-NFL championship game." },
      { year: "1970", title: "AFL-NFL merger", detail: "The leagues combined into the AFC and NFC and Monday Night Football launched." },
      { year: "1993", title: "Free agency", detail: "Unrestricted free agency and the salary cap arrived, reshaping how rosters are built." },
    ],
    greats: [
      { name: "Jim Brown", note: "Led the league in rushing eight of his nine seasons." },
      { name: "Jerry Rice", note: "All-time leader in receptions, receiving yards and touchdowns." },
      { name: "Tom Brady", note: "Seven Super Bowl titles across 23 seasons." },
      { name: "Lawrence Taylor", note: "Redefined the outside linebacker position." },
    ],
    dynasties: [
      { name: "Green Bay Packers (1960s)", note: "Five titles in seven years under Vince Lombardi." },
      { name: "Pittsburgh Steelers (1970s)", note: "Four Super Bowls behind the Steel Curtain defense." },
      { name: "San Francisco 49ers (1980s)", note: "Bill Walsh's West Coast offense won four rings." },
      { name: "New England Patriots (2001-2018)", note: "Six Super Bowls with Belichick and Brady." },
    ],
  },
  {
    slug: "nba",
    name: "NBA",
    origin: "Founded 1946 as the Basketball Association of America; merged with the NBL in 1949",
    summary:
      "James Naismith invented basketball with a peach basket in 1891. The pro game consolidated after World War II, added the shot clock to save itself from stalling, integrated in 1950, absorbed the ABA's flair in 1976 and went global in the Magic-Bird-Jordan era.",
    milestones: [
      { year: "1891", title: "The game is invented", detail: "James Naismith nails peach baskets to a gym balcony in Springfield, Massachusetts." },
      { year: "1950", title: "Integration", detail: "Earl Lloyd, Chuck Cooper and Nat Clifton break the NBA's color barrier." },
      { year: "1954", title: "Shot clock", detail: "The 24-second clock ends stalling and scoring jumps overnight." },
      { year: "1976", title: "ABA merger", detail: "Four ABA teams join and the three-point line follows three years later." },
      { year: "1992", title: "The Dream Team", detail: "NBA players at the Barcelona Olympics turn basketball into a global sport." },
    ],
    greats: [
      { name: "Bill Russell", note: "Eleven championships in thirteen seasons." },
      { name: "Kareem Abdul-Jabbar", note: "Six MVPs and the unblockable skyhook." },
      { name: "Michael Jordan", note: "Six titles, six Finals MVPs, zero Finals losses." },
      { name: "LeBron James", note: "All-time leading scorer across four franchises." },
    ],
    dynasties: [
      { name: "Boston Celtics (1957-1969)", note: "Eleven titles in thirteen years." },
      { name: "Showtime Lakers (1980s)", note: "Five rings of fast-break basketball." },
      { name: "Chicago Bulls (1990s)", note: "Two three-peats in eight seasons." },
      { name: "Golden State Warriors (2015-2022)", note: "Four titles and the three-point revolution." },
    ],
  },
  {
    slug: "nhl",
    name: "NHL",
    origin: "Founded 1917 in Montreal",
    summary:
      "Hockey was codified on frozen Canadian ponds and in Montreal's indoor rinks in the 1870s. The Stanley Cup predates the NHL itself; the league grew from four Canadian clubs to the Original Six and then to a 32-team continental sport.",
    milestones: [
      { year: "1893", title: "Stanley Cup awarded", detail: "Lord Stanley's trophy goes to the Montreal Hockey Club — it is still the oldest trophy in North American pro sport." },
      { year: "1917", title: "NHL formed", detail: "Four clubs launch the league at Montreal's Windsor Hotel." },
      { year: "1942", title: "Original Six era", detail: "Twenty-five seasons of six teams create hockey's fiercest rivalries." },
      { year: "1967", title: "Expansion", detail: "The league doubles to twelve teams and moves west." },
      { year: "1980", title: "Miracle on Ice", detail: "A US college team beats the Soviet Union and the American game booms." },
    ],
    greats: [
      { name: "Wayne Gretzky", note: "2,857 career points, a record nobody has approached." },
      { name: "Gordie Howe", note: "26 NHL seasons across five decades." },
      { name: "Bobby Orr", note: "Turned the defenseman into an attacker." },
      { name: "Mario Lemieux", note: "Scored at a record clip and later saved his franchise." },
    ],
    dynasties: [
      { name: "Montreal Canadiens (1956-1979)", note: "Ten Stanley Cups, including five straight." },
      { name: "New York Islanders (1980-1983)", note: "Four consecutive Cups." },
      { name: "Edmonton Oilers (1984-1990)", note: "Five Cups with the highest-scoring team ever." },
    ],
  },
  {
    slug: "mlb",
    name: "MLB",
    origin: "National League founded 1876; American League 1901",
    summary:
      "Baseball spread from New York's amateur clubs in the 1840s to become the national pastime. Its history is one long argument between tradition and change: the dead-ball era, integration, expansion, free agency, the steroid era and the analytics revolution.",
    milestones: [
      { year: "1869", title: "First pro team", detail: "The Cincinnati Red Stockings pay every player a salary." },
      { year: "1903", title: "First World Series", detail: "Boston beats Pittsburgh in the first interleague championship." },
      { year: "1947", title: "Jackie Robinson", detail: "Robinson breaks the color line with the Brooklyn Dodgers." },
      { year: "1975", title: "Free agency", detail: "An arbitrator strikes down the reserve clause and player movement begins." },
      { year: "2016", title: "Curse broken", detail: "The Cubs win their first World Series in 108 years." },
    ],
    greats: [
      { name: "Babe Ruth", note: "Turned baseball into a power game." },
      { name: "Willie Mays", note: "The complete five-tool player." },
      { name: "Hank Aaron", note: "755 home runs against enormous pressure." },
      { name: "Shohei Ohtani", note: "The first modern two-way superstar." },
    ],
    dynasties: [
      { name: "New York Yankees (1921-1964)", note: "20 World Series titles in 44 seasons." },
      { name: "Oakland A's (1972-1974)", note: "Three straight championships." },
      { name: "San Francisco Giants (2010-2014)", note: "Three titles in five years." },
    ],
  },
  {
    slug: "soccer",
    name: "Soccer / Football",
    origin: "Rules codified in London in 1863 by the Football Association",
    summary:
      "Association football spread from British schools and factories along trade routes to every continent. FIFA arrived in 1904, the World Cup in 1930, European club competition in 1955, and the sport is now the most watched game on earth.",
    milestones: [
      { year: "1863", title: "Laws of the Game", detail: "The Football Association writes the first common rulebook." },
      { year: "1888", title: "First league", detail: "The English Football League begins organised club competition." },
      { year: "1930", title: "First World Cup", detail: "Uruguay hosts and wins the inaugural tournament." },
      { year: "1955", title: "European Cup", detail: "The competition that became the Champions League kicks off." },
      { year: "1991", title: "Women's World Cup", detail: "The first FIFA tournament for women is held in China." },
    ],
    greats: [
      { name: "Pelé", note: "Three World Cups with Brazil." },
      { name: "Diego Maradona", note: "Carried Argentina to the 1986 title." },
      { name: "Lionel Messi", note: "Eight Ballons d'Or and the 2022 World Cup." },
      { name: "Marta", note: "The all-time leading World Cup scorer." },
    ],
    dynasties: [
      { name: "Real Madrid (1956-1960)", note: "Five straight European Cups." },
      { name: "Ajax and the Netherlands (1970s)", note: "Total Football reshaped tactics." },
      { name: "Barcelona (2008-2012)", note: "Guardiola's tiki-taka won two Champions Leagues." },
    ],
  },
  {
    slug: "tennis",
    name: "Tennis",
    origin: "Lawn tennis patented 1874; Wimbledon first played 1877",
    summary:
      "Tennis grew out of French real tennis and Victorian garden parties. The Open era in 1968 let professionals into the majors, and the sport has since produced the longest-running individual rivalries in world sport.",
    milestones: [
      { year: "1877", title: "First Wimbledon", detail: "The All England Club stages the first championship." },
      { year: "1968", title: "Open era", detail: "Professionals are admitted to the Grand Slams." },
      { year: "1973", title: "Equal prize money", detail: "The US Open becomes the first major to pay men and women equally." },
      { year: "2006", title: "Hawk-Eye", detail: "Electronic line calling arrives at the majors." },
    ],
    greats: [
      { name: "Rod Laver", note: "Two calendar Grand Slams." },
      { name: "Serena Williams", note: "23 singles majors in the Open era." },
      { name: "Roger Federer", note: "Twenty majors and a record run of finals." },
      { name: "Novak Djokovic", note: "The most men's major titles in history." },
    ],
    dynasties: [
      { name: "The Big Three (2003-2023)", note: "Federer, Nadal and Djokovic won 66 majors between them." },
      { name: "Navratilova and Evert", note: "80 matches against each other across 16 years." },
    ],
  },
  {
    slug: "ufc",
    name: "UFC & MMA",
    origin: "First UFC event held in Denver in 1993",
    summary:
      "Mixed martial arts began as a no-rules style-versus-style experiment and became a regulated global sport. The Unified Rules, weight classes and The Ultimate Fighter turned a banned spectacle into a mainstream pay-per-view business.",
    milestones: [
      { year: "1993", title: "UFC 1", detail: "Royce Gracie wins a one-night tournament and shows the world jiu-jitsu." },
      { year: "2000", title: "Unified Rules", detail: "New Jersey regulators write the rules that legitimised the sport." },
      { year: "2005", title: "The Ultimate Fighter", detail: "A reality show finale saves the promotion and wins a TV deal." },
      { year: "2013", title: "Women in the UFC", detail: "Ronda Rousey headlines UFC 157 in the first women's bout." },
    ],
    greats: [
      { name: "Anderson Silva", note: "Sixteen straight wins at middleweight." },
      { name: "Georges St-Pierre", note: "Champion in two divisions and never dominated." },
      { name: "Amanda Nunes", note: "Simultaneous two-division champion." },
      { name: "Jon Jones", note: "Youngest champion in UFC history." },
    ],
    dynasties: [
      { name: "American Kickboxing Academy", note: "Produced Khabib Nurmagomedov and Daniel Cormier." },
      { name: "Team Alpha Male", note: "A generation of elite lighter-weight fighters." },
    ],
  },
  {
    slug: "golf",
    name: "Golf",
    origin: "Played at St Andrews since the 1400s; The Open first held 1860",
    summary:
      "Golf's rules were written in Scotland and its four modern majors took shape in the twentieth century. Equipment, television and a handful of transcendent players — Jones, Hogan, Palmer, Nicklaus, Woods — repeatedly grew the game.",
    milestones: [
      { year: "1860", title: "First Open Championship", detail: "Prestwick hosts eight professionals." },
      { year: "1930", title: "Bobby Jones's Grand Slam", detail: "Jones wins all four majors of his era in one year." },
      { year: "1934", title: "First Masters", detail: "Augusta National stages its inaugural invitational." },
      { year: "1997", title: "Tiger at Augusta", detail: "Woods wins the Masters by twelve shots and transforms the sport." },
    ],
    greats: [
      { name: "Jack Nicklaus", note: "Eighteen professional majors." },
      { name: "Tiger Woods", note: "Fifteen majors and 82 PGA Tour wins." },
      { name: "Annika Sörenstam", note: "Ten major titles and 72 LPGA wins." },
      { name: "Ben Hogan", note: "Won three majors in 1953." },
    ],
    dynasties: [
      { name: "The Big Three (1960s)", note: "Palmer, Nicklaus and Player dominated a decade." },
      { name: "European Ryder Cup teams (1985-2018)", note: "Turned the match into a genuine contest." },
    ],
  },
  {
    slug: "nascar",
    name: "NASCAR",
    origin: "Founded 1948 in Daytona Beach, Florida",
    summary:
      "Stock car racing grew from Prohibition-era bootleggers tuning cars to outrun the law. Bill France organised the sport in 1948, Daytona became its cathedral, and television in the 1980s and 90s carried it well beyond the South.",
    milestones: [
      { year: "1948", title: "NASCAR incorporated", detail: "Bill France Sr. formalises stock car racing." },
      { year: "1959", title: "First Daytona 500", detail: "A photo finish takes three days to settle." },
      { year: "1979", title: "Live flag-to-flag TV", detail: "A last-lap crash and fistfight in front of a snowbound national audience." },
      { year: "2001", title: "Safety overhaul", detail: "Dale Earnhardt's death leads to HANS devices and SAFER barriers." },
    ],
    greats: [
      { name: "Richard Petty", note: "200 wins and seven championships." },
      { name: "Dale Earnhardt", note: "Seven titles and the sport's defining persona." },
      { name: "Jimmie Johnson", note: "Five consecutive championships." },
      { name: "Jeff Gordon", note: "Brought a new generation to the sport." },
    ],
    dynasties: [
      { name: "Petty Enterprises", note: "Ten Cup championships." },
      { name: "Hendrick Motorsports", note: "The winningest organisation in Cup history." },
    ],
  },
  {
    slug: "college",
    name: "College Sports",
    origin: "Intercollegiate competition since the 1850s; NCAA founded 1906",
    summary:
      "American college athletics began with rowing and spread to football, basketball and hockey. The NCAA was created to make football safer, grew into a broadcasting giant, and was reshaped again by the transfer portal and name, image and likeness rights.",
    milestones: [
      { year: "1906", title: "NCAA founded", detail: "Created after a crisis over deaths in college football." },
      { year: "1939", title: "First NCAA basketball tournament", detail: "Eight teams played; March Madness grew from there." },
      { year: "1972", title: "Title IX", detail: "Federal law transforms women's college sports." },
      { year: "2021", title: "NIL rights", detail: "Athletes can earn from their name, image and likeness." },
    ],
    greats: [
      { name: "John Wooden", note: "Ten basketball titles in twelve years at UCLA." },
      { name: "Nick Saban", note: "Seven national football championships." },
      { name: "Pat Summitt", note: "Eight national titles at Tennessee." },
    ],
    dynasties: [
      { name: "UCLA basketball (1964-1975)", note: "Ten championships." },
      { name: "Alabama football (2009-2020)", note: "Six national titles." },
      { name: "UConn women's basketball", note: "Eleven national championships." },
    ],
  },
  {
    slug: "boxing",
    name: "Boxing",
    origin: "Ancient prizefighting; the modern code dates to the 1867 Queensberry rules",
    summary:
      "Boxing is one of the oldest sports on earth — fist-fighting appears in every ancient civilisation. The Queensberry rules brought gloves, rounds and weight divisions, and the heavyweight champions of the 20th century became global icons in a way few athletes ever have.",
    milestones: [
      { year: "1867", title: "Queensberry rules", detail: "Gloves, three-minute rounds and weight classes formalise the sport." },
      { year: "1892", title: "First gloved heavyweight title", detail: "\"Gentleman Jim\" Corbett beats John L. Sullivan under the new rules." },
      { year: "1971", title: "The Fight of the Century", detail: "Frazier vs Ali at Madison Square Garden becomes a global event." },
      { year: "2022", title: "Women headline the Garden", detail: "Taylor vs Serrano is the first women's main event at Madison Square Garden." },
    ],
    greats: [
      { name: "Muhammad Ali", note: "Three-time heavyweight champion and the sport's biggest voice." },
      { name: "Sugar Ray Robinson", note: "Widely called the greatest pound-for-pound boxer ever." },
      { name: "Joe Louis", note: "25 straight title defences over nearly twelve years." },
      { name: "Katie Taylor", note: "Olympic gold and undisputed champion in two weight classes." },
      { name: "Claressa Shields", note: "Undisputed in three divisions; two Olympic golds." },
      { name: "Willie Pep", note: "229 wins and legendary defensive craft at featherweight." },
    ],
    dynasties: [
      { name: "The heavyweight era (1960s-70s)", note: "Ali, Frazier and Foreman made boxing the world's centre-ring sport." },
      { name: "The Four Kings (1980s)", note: "Leonard, Hearns, Hagler and Duran traded wars across the middle divisions." },
    ],
  },
];

export function historyBySlug(slug: string): SportHistory | undefined {
  return SPORT_HISTORY.find((s) => s.slug === slug);
}
