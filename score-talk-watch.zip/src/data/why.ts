import type { LeagueId } from "@/data/sports";

/**
 * Where the meaningful cut lines sit in each league's table, so "why it matters"
 * can say whether a result moved a team in or out of a race.
 */
export interface RaceRule {
  /** Table name shown to fans. */
  table: string;
  /** Teams above this index are in the headline race (playoffs, top four…). */
  cut: number;
  cutLabel: string;
  /** Optional second line, e.g. the wild card or the relegation zone. */
  second?: { cut: number; label: string; fromBottom?: boolean };
  /** Soccer tables are points-driven, so we skip "games behind" wording. */
  soccer?: boolean;
}

export const RACE_RULES: Record<LeagueId, RaceRule> = {
  nfl: { table: "the conference standings", cut: 7, cutLabel: "the playoff places" },
  nba: { table: "the standings", cut: 6, cutLabel: "a guaranteed playoff spot", second: { cut: 10, label: "the play-in places" } },
  wnba: { table: "the standings", cut: 8, cutLabel: "the playoff places" },
  nhl: { table: "the standings", cut: 8, cutLabel: "the playoff places" },
  mlb: { table: "the standings", cut: 3, cutLabel: "a division lead", second: { cut: 6, label: "the wild card places" } },
  mls: { table: "the table", cut: 9, cutLabel: "the playoff places", soccer: true },
  nwsl: { table: "the table", cut: 8, cutLabel: "the playoff places", soccer: true },
  intl: { table: "the table", cut: 8, cutLabel: "the knockout places", soccer: true },
  cfb: { table: "the rankings", cut: 12, cutLabel: "the playoff field" },
  cbb: { table: "the rankings", cut: 25, cutLabel: "the top 25" },
  chk: { table: "the standings", cut: 16, cutLabel: "the tournament field" },
  cbs: { table: "the standings", cut: 16, cutLabel: "the tournament field" },
  sball: { table: "the standings", cut: 16, cutLabel: "the tournament field" },
  vball: { table: "the standings", cut: 16, cutLabel: "the tournament field" },
};

export function raceRule(league: LeagueId): RaceRule {
  return RACE_RULES[league] ?? { table: "the standings", cut: 8, cutLabel: "the playoff places" };
}
