import type { SportId } from "@/lib/individual-sports.functions";

export interface SportTriviaQuestion {
  id: string;
  question: string;
  answer: string;
}

export const SPORT_TRIVIA: Record<SportId, SportTriviaQuestion[]> = {
  tennis: [
    { id: "tennis-1", question: "Which tournament is the only Grand Slam played on clay?", answer: "The French Open at Roland-Garros in Paris." },
    { id: "tennis-2", question: "What is the term for a score of 40-40?", answer: "Deuce — a player must then win two straight points." },
    { id: "tennis-3", question: "Who has won the most men's singles Grand Slam titles?", answer: "Novak Djokovic, who passed Federer and Nadal in 2023." },
    { id: "tennis-4", question: "How many singles majors did Serena Williams win?", answer: "23 — the most by anyone in the Open era." },
    { id: "tennis-5", question: "What year did the Open era begin?", answer: "1968, when professionals were first allowed into the majors." },
    { id: "tennis-6", question: "Which player completed a calendar Grand Slam twice?", answer: "Rod Laver, in 1962 as an amateur and 1969 as a professional." },
    { id: "tennis-7", question: "What surface is Wimbledon played on?", answer: "Grass — the oldest surface in the sport." },
    { id: "tennis-8", question: "What is a 'bagel' in tennis slang?", answer: "Winning a set 6-0." },
  ],
  ufc: [
    { id: "ufc-1", question: "Who won the first UFC tournament in 1993?", answer: "Royce Gracie, using Brazilian jiu-jitsu." },
    { id: "ufc-2", question: "How long is a non-title UFC fight?", answer: "Three five-minute rounds; title fights are five rounds." },
    { id: "ufc-3", question: "Who was the first simultaneous two-division UFC champion?", answer: "Conor McGregor, at featherweight and lightweight in 2016." },
    { id: "ufc-4", question: "Which fighter retired 29-0?", answer: "Khabib Nurmagomedov, after defending the lightweight title in 2020." },
    { id: "ufc-5", question: "Who holds the record for most UFC title defences at middleweight?", answer: "Anderson Silva, with ten." },
    { id: "ufc-6", question: "Which show saved the UFC in 2005?", answer: "The Ultimate Fighter, whose finale drew a breakout TV audience." },
    { id: "ufc-7", question: "Who was the first woman to headline a UFC card?", answer: "Ronda Rousey at UFC 157 in 2013." },
    { id: "ufc-8", question: "What are the Unified Rules?", answer: "The 2000 regulations on rounds, fouls and weight classes that legalised MMA in the US." },
  ],
  boxing: [
    { id: "boxing-1", question: "Who is the only boxer to win world titles in eight weight classes?", answer: "Manny Pacquiao, who later added a fifth lineal title." },
    { id: "boxing-2", question: "What is the maximum weight for a heavyweight?", answer: "There is none — heavyweight is the division above the 200-pound cruiserweight limit." },
    { id: "boxing-3", question: "Which 1971 fight was billed as 'The Fight of the Century'?", answer: "Joe Frazier versus Muhammad Ali at Madison Square Garden — Frazier won on points." },
    { id: "boxing-4", question: "Who retired undefeated at 50-0?", answer: "Floyd Mayweather Jr., after beating Conor McGregor in 2017." },
    { id: "boxing-5", question: "What are the 'Marquess of Queensberry rules'?", answer: "The 1867 code that mandated gloves, three-minute rounds and the ten count." },
    { id: "boxing-6", question: "Which boxer won Olympic gold at 17 and a heavyweight world title at 20?", answer: "Mike Tyson, the youngest heavyweight champion ever." },
    { id: "boxing-7", question: "What does a 'technical knockout' mean?", answer: "The referee or a corner stops the fight because a boxer can no longer defend properly." },
    { id: "boxing-8", question: "Who was the first female boxing match headlining Las Vegas' biggest arena?", answer: "Katie Taylor versus Amanda Serrano at Madison Square Garden in 2022 — the first women's main event there." },
  ],
  golf: [
    { id: "golf-1", question: "Name golf's four majors.", answer: "The Masters, PGA Championship, US Open and The Open Championship." },
    { id: "golf-2", question: "Who has won the most professional majors?", answer: "Jack Nicklaus, with 18." },
    { id: "golf-3", question: "What is an albatross?", answer: "Three under par on a hole — also called a double eagle." },
    { id: "golf-4", question: "Which course hosts the Masters every year?", answer: "Augusta National in Georgia." },
    { id: "golf-5", question: "By how many shots did Tiger Woods win the 1997 Masters?", answer: "Twelve — a tournament record." },
    { id: "golf-6", question: "What is the Ryder Cup?", answer: "A biennial team match between the United States and Europe." },
    { id: "golf-7", question: "Where is the home of golf?", answer: "The Old Course at St Andrews, Scotland." },
    { id: "golf-8", question: "What does 'links' actually mean?", answer: "A coastal course built on sandy ground linking beach and farmland." },
  ],
  f1: [
    { id: "f1-1", question: "How many points does a race winner score?", answer: "25, with 18 for second and 15 for third." },
    { id: "f1-2", question: "Which driver has won the most world championships?", answer: "Michael Schumacher and Lewis Hamilton, with seven each." },
    { id: "f1-3", question: "What is DRS?", answer: "The Drag Reduction System — a movable rear wing flap that helps overtaking in designated zones." },
    { id: "f1-4", question: "Which circuit hosts the Monaco Grand Prix?", answer: "The Circuit de Monaco, a street track through Monte Carlo." },
    { id: "f1-5", question: "What does a black and orange flag mean?", answer: "The car has damage and must pit for repairs." },
    { id: "f1-6", question: "Which team has won the most constructors' titles?", answer: "Ferrari." },
    { id: "f1-7", question: "What is a 'grand slam' in F1?", answer: "Pole position, race win, fastest lap and leading every lap." },
    { id: "f1-8", question: "How long is a typical grand prix?", answer: "The number of laps needed to exceed 305 km, capped at two hours of racing." },
  ],
  nascar: [
    { id: "nascar-1", question: "Who founded NASCAR and when?", answer: "Bill France Sr. in 1948 in Daytona Beach, Florida." },
    { id: "nascar-2", question: "Which race is NASCAR's biggest?", answer: "The Daytona 500, which opens the Cup Series season." },
    { id: "nascar-3", question: "Who holds the record for career Cup wins?", answer: "Richard Petty, with 200." },
    { id: "nascar-4", question: "How many drivers share the record of seven Cup titles?", answer: "Three — Petty, Dale Earnhardt and Jimmie Johnson." },
    { id: "nascar-5", question: "What is drafting?", answer: "Running nose-to-tail so two cars cut through the air faster than one." },
    { id: "nascar-6", question: "What safety devices followed the 2001 Daytona 500?", answer: "The HANS device and SAFER barriers became mandatory." },
    { id: "nascar-7", question: "What does a black flag mean?", answer: "The driver must report to the pits, usually for a penalty or a problem." },
    { id: "nascar-8", question: "Which track is the shortest on the Cup schedule?", answer: "Martinsville Speedway, a 0.526-mile paperclip." },
  ],
};
