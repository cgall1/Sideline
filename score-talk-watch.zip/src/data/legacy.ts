/** Curated historical reference data: rivalries, hall of fame, championships, franchise records. */

export interface Rivalry {
  slug: string;
  name: string;
  league: string;
  since: string;
  summary: string;
  headToHead: string;
  moments: { year: string; detail: string }[];
}

export const RIVALRIES: Rivalry[] = [
  {
    slug: "packers-bears",
    name: "Packers vs Bears",
    league: "NFL",
    since: "1921",
    summary:
      "The oldest rivalry in the NFL, played more times than any other matchup in the league. Two founding franchises from small-town Wisconsin and big-city Chicago, separated by 200 miles and a century of grudges.",
    headToHead: "Bears lead the all-time series narrowly; Green Bay has dominated the modern era.",
    moments: [
      { year: "1941", detail: "The first divisional playoff in NFL history — Chicago won on the way to a title." },
      { year: "2010", detail: "Green Bay beat Chicago in the NFC Championship at Soldier Field, then won the Super Bowl." },
    ],
  },
  {
    slug: "celtics-lakers",
    name: "Celtics vs Lakers",
    league: "NBA",
    since: "1959",
    summary:
      "The defining rivalry of professional basketball. Boston's green dynasty against Los Angeles showtime, meeting in the Finals a dozen times and shaping every era of the league.",
    headToHead: "Boston leads the Finals series; the two clubs own the most championships in NBA history.",
    moments: [
      { year: "1984", detail: "Bird vs Magic went seven games in a sweltering Boston Garden." },
      { year: "2008", detail: "Boston's new big three routed the Lakers in Game 6 to win the title." },
      { year: "2010", detail: "Los Angeles answered with a Game 7 win at Staples Center." },
    ],
  },
  {
    slug: "yankees-red-sox",
    name: "Yankees vs Red Sox",
    league: "MLB",
    since: "1901",
    summary:
      "A century of pennant races, curses and October heartbreak between baseball's biggest markets in the American League East.",
    headToHead: "New York leads the all-time series; Boston ended the curse in 2004.",
    moments: [
      { year: "1978", detail: "Bucky Dent's playoff home run over the Green Monster." },
      { year: "2003", detail: "Aaron Boone walked off Game 7 of the ALCS." },
      { year: "2004", detail: "Boston became the first team to erase a 3-0 series deficit." },
    ],
  },
  {
    slug: "canadiens-bruins",
    name: "Canadiens vs Bruins",
    league: "NHL",
    since: "1924",
    summary:
      "Hockey's most-played playoff rivalry. Montreal and Boston have met in the postseason more than any pair in NHL history.",
    headToHead: "Montreal holds the edge in playoff series won.",
    moments: [
      { year: "1979", detail: "Boston's too-many-men penalty let Guy Lafleur tie Game 7; Montreal went on to the Cup." },
      { year: "2011", detail: "Boston finally broke through in overtime of Game 7 and won the Stanley Cup." },
    ],
  },
  {
    slug: "el-clasico",
    name: "El Clásico — Real Madrid vs Barcelona",
    league: "LaLiga",
    since: "1902",
    summary:
      "The most watched club fixture on earth, carrying a century of political and cultural weight between Madrid and Catalonia.",
    headToHead: "Real Madrid holds a slim edge across all competitions.",
    moments: [
      { year: "2010", detail: "Barcelona's 5-0 Guardiola masterclass at Camp Nou." },
      { year: "2017", detail: "Messi's late winner and shirt-to-the-crowd celebration at the Bernabéu." },
    ],
  },
  {
    slug: "manchester-derby",
    name: "Manchester United vs Manchester City",
    league: "Premier League",
    since: "1881",
    summary:
      "One city, two clubs, and a balance of power that flipped in the 2010s from Old Trafford to the Etihad.",
    headToHead: "United leads the all-time series; City has dominated recent seasons.",
    moments: [
      { year: "2011", detail: "City won 6-1 at Old Trafford on the way to their first Premier League title." },
      { year: "2012", detail: "Aguero's stoppage-time goal took the title from United on goal difference." },
    ],
  },
  {
    slug: "ohio-state-michigan",
    name: "Ohio State vs Michigan",
    league: "College Football",
    since: "1897",
    summary:
      "Simply called The Game. A late-November meeting that regularly decides the Big Ten and the national picture.",
    headToHead: "Michigan leads the all-time series; Ohio State dominated the 2000s and 2010s.",
    moments: [
      { year: "2006", detail: "No. 1 Ohio State beat No. 2 Michigan in the biggest edition ever played." },
      { year: "2021", detail: "Michigan snapped an eight-game losing streak in the snow at Ann Arbor." },
    ],
  },
  {
    slug: "duke-unc",
    name: "Duke vs North Carolina",
    league: "College Basketball",
    since: "1920",
    summary:
      "Eight miles of Tobacco Road separate the two blue bloods of college basketball, and every meeting feels like a national final.",
    headToHead: "North Carolina leads the all-time series by a handful of games.",
    moments: [
      { year: "1992", detail: "Duke's overtime classic run included the Laettner shot days later against Kentucky." },
      { year: "2022", detail: "The pair met in the Final Four for the first time; UNC ended Coach K's career." },
    ],
  },
  {
    slug: "lakers-warriors",
    name: "Lakers vs Warriors",
    league: "NBA",
    since: "1962",
    summary:
      "California's two crown jewels: Hollywood royalty against the Bay Area dynasty that redefined the three-point era.",
    headToHead: "Los Angeles leads the all-time series; Golden State owns recent playoff meetings.",
    moments: [
      { year: "2023", detail: "The Lakers eliminated the Warriors in six games in the conference semifinals." },
    ],
  },
  {
    slug: "cowboys-eagles",
    name: "Cowboys vs Eagles",
    league: "NFL",
    since: "1960",
    summary:
      "The NFC East's nastiest rivalry, twice a year, with the division usually on the line.",
    headToHead: "Dallas leads the all-time series.",
    moments: [
      { year: "1980", detail: "Philadelphia beat Dallas in the NFC Championship to reach their first Super Bowl." },
    ],
  },
  {
    slug: "superclasico",
    name: "Superclásico — Boca Juniors vs River Plate",
    league: "World Soccer",
    since: "1913",
    summary:
      "Buenos Aires splits in two for the Superclásico, widely called the most intense derby in world football.",
    headToHead: "Boca holds a narrow historical edge.",
    moments: [
      { year: "2018", detail: "They met in the Copa Libertadores final for the first time; River won the second leg in Madrid." },
    ],
  },
  {
    slug: "seattle-portland",
    name: "Seattle Sounders vs Portland Timbers",
    league: "MLS",
    since: "1975",
    summary:
      "Cascadia's loudest rivalry, inherited from the old NASL and carried into MLS by two of the league's best supporter cultures.",
    headToHead: "The series is close; both clubs have lifted MLS Cup in the rivalry era.",
    moments: [
      { year: "2015", detail: "Portland knocked Seattle out in the playoffs and won MLS Cup." },
    ],
  },
];

export interface HallOfFameSport {
  slug: string;
  name: string;
  hall: string;
  blurb: string;
  members: { name: string; era: string; note: string }[];
}

export const HALL_OF_FAME: HallOfFameSport[] = [
  {
    slug: "nfl",
    name: "NFL",
    hall: "Pro Football Hall of Fame — Canton, Ohio",
    blurb: "Enshrined each summer in Canton, where the league was founded in 1920.",
    members: [
      { name: "Jim Brown", era: "1957-1965", note: "Rushing champion in eight of nine seasons." },
      { name: "Jerry Rice", era: "1985-2004", note: "All-time leader in catches, yards and touchdowns." },
      { name: "Lawrence Taylor", era: "1981-1993", note: "Changed how offenses protect the quarterback." },
      { name: "Joe Montana", era: "1979-1994", note: "Four Super Bowls, never threw an interception in them." },
      { name: "Walter Payton", era: "1975-1987", note: "Sweetness — 16,726 rushing yards for Chicago." },
      { name: "Peyton Manning", era: "1998-2015", note: "Five MVP awards and two championships." },
      { name: "Deion Sanders", era: "1989-2005", note: "Shutdown corner and returner in two sports." },
      { name: "Reggie White", era: "1985-2000", note: "The Minister of Defense, 198 career sacks." },
    ],
  },
  {
    slug: "nba",
    name: "NBA",
    hall: "Naismith Memorial Basketball Hall of Fame — Springfield, Massachusetts",
    blurb: "Honors the whole sport — pro, college, international and women's basketball.",
    members: [
      { name: "Michael Jordan", era: "1984-2003", note: "Six titles, six Finals MVPs, five MVPs." },
      { name: "Bill Russell", era: "1956-1969", note: "Eleven championships in thirteen seasons." },
      { name: "Kareem Abdul-Jabbar", era: "1969-1989", note: "Six MVPs and the skyhook." },
      { name: "Magic Johnson", era: "1979-1996", note: "Point guard in a power forward's body." },
      { name: "Larry Bird", era: "1979-1992", note: "Three straight MVPs for Boston." },
      { name: "Kobe Bryant", era: "1996-2016", note: "Five titles and 81 points in a night." },
      { name: "Tim Duncan", era: "1997-2016", note: "Five rings in nineteen seasons with San Antonio." },
      { name: "Lisa Leslie", era: "1997-2009", note: "Three-time WNBA MVP and first to dunk in a WNBA game." },
    ],
  },
  {
    slug: "mlb",
    name: "MLB",
    hall: "National Baseball Hall of Fame — Cooperstown, New York",
    blurb: "Baseball's shrine since 1936, with voting by the Baseball Writers' Association.",
    members: [
      { name: "Babe Ruth", era: "1914-1935", note: "714 home runs and the modern power game." },
      { name: "Jackie Robinson", era: "1947-1956", note: "Broke the color barrier in 1947." },
      { name: "Willie Mays", era: "1951-1973", note: "The complete five-tool center fielder." },
      { name: "Hank Aaron", era: "1954-1976", note: "755 home runs and 2,297 RBIs." },
      { name: "Ted Williams", era: "1939-1960", note: "Last man to hit .400 in a season." },
      { name: "Greg Maddux", era: "1986-2008", note: "Four straight Cy Young awards." },
      { name: "Derek Jeter", era: "1995-2014", note: "Five rings and 3,465 hits for the Yankees." },
    ],
  },
  {
    slug: "nhl",
    name: "NHL",
    hall: "Hockey Hall of Fame — Toronto, Ontario",
    blurb: "Home of the Stanley Cup itself, on Yonge Street in downtown Toronto.",
    members: [
      { name: "Wayne Gretzky", era: "1979-1999", note: "2,857 points — nobody else is close." },
      { name: "Bobby Orr", era: "1966-1978", note: "Redefined what a defenseman could do." },
      { name: "Mario Lemieux", era: "1984-2006", note: "Two Cups and a comeback from cancer." },
      { name: "Gordie Howe", era: "1946-1980", note: "Mr. Hockey played across five decades." },
      { name: "Maurice Richard", era: "1942-1960", note: "First to 50 goals in 50 games." },
      { name: "Patrick Roy", era: "1984-2003", note: "Four Cups and three Conn Smythe trophies." },
    ],
  },
  {
    slug: "soccer",
    name: "Soccer",
    hall: "No single global hall — honoured by FIFA and national federations",
    blurb: "World football recognises its greats through FIFA awards, Ballon d'Or history and national halls.",
    members: [
      { name: "Pelé", era: "1956-1977", note: "Three World Cups with Brazil." },
      { name: "Diego Maradona", era: "1976-1997", note: "Carried Argentina to the 1986 World Cup." },
      { name: "Lionel Messi", era: "2004-", note: "Eight Ballons d'Or and the 2022 World Cup." },
      { name: "Cristiano Ronaldo", era: "2002-", note: "Five Champions League titles and record international goals." },
      { name: "Johan Cruyff", era: "1964-1984", note: "Total Football as player and coach." },
      { name: "Mia Hamm", era: "1987-2004", note: "Two World Cups and two Olympic golds for the USA." },
    ],
  },
  {
    slug: "tennis",
    name: "Tennis",
    hall: "International Tennis Hall of Fame — Newport, Rhode Island",
    blurb: "Housed at the Newport Casino, where the first US National Championships were played.",
    members: [
      { name: "Serena Williams", era: "1995-2022", note: "23 singles majors in the Open era." },
      { name: "Roger Federer", era: "1998-2022", note: "20 majors and eight Wimbledon titles." },
      { name: "Rafael Nadal", era: "2001-2024", note: "14 French Open championships." },
      { name: "Novak Djokovic", era: "2003-", note: "Record men's major count." },
      { name: "Billie Jean King", era: "1959-1983", note: "39 major titles and the fight for equal prize money." },
      { name: "Rod Laver", era: "1956-1979", note: "Two calendar-year Grand Slams." },
    ],
  },
  {
    slug: "ufc",
    name: "UFC",
    hall: "UFC Hall of Fame — Las Vegas, Nevada",
    blurb: "Split into pioneer, modern, fight and contributor wings.",
    members: [
      { name: "Anderson Silva", era: "2006-2020", note: "Longest title reign in UFC history." },
      { name: "Georges St-Pierre", era: "2004-2017", note: "Champion in two weight classes." },
      { name: "Ronda Rousey", era: "2013-2016", note: "First UFC women's champion." },
      { name: "Chuck Liddell", era: "1998-2010", note: "The Iceman who took the sport mainstream." },
      { name: "Amanda Nunes", era: "2013-2023", note: "Two-division champion and the women's GOAT." },
    ],
  },
  {
    slug: "golf",
    name: "Golf",
    hall: "World Golf Hall of Fame — Pinehurst, North Carolina",
    blurb: "Relocated to Pinehurst in 2024, the home of American championship golf.",
    members: [
      { name: "Jack Nicklaus", era: "1961-2005", note: "18 professional majors." },
      { name: "Tiger Woods", era: "1996-", note: "15 majors and 82 PGA Tour wins." },
      { name: "Annika Sörenstam", era: "1992-2008", note: "72 LPGA wins and 10 majors." },
      { name: "Ben Hogan", era: "1930-1971", note: "Nine majors after surviving a near-fatal crash." },
      { name: "Arnold Palmer", era: "1954-2006", note: "Brought golf to television audiences." },
    ],
  },
  {
    slug: "nascar",
    name: "NASCAR",
    hall: "NASCAR Hall of Fame — Charlotte, North Carolina",
    blurb: "Opened in 2010 in the heart of stock car country.",
    members: [
      { name: "Richard Petty", era: "1958-1992", note: "Seven titles and 200 wins." },
      { name: "Dale Earnhardt", era: "1975-2001", note: "The Intimidator, seven-time champion." },
      { name: "Jimmie Johnson", era: "2001-2020", note: "Five straight Cup titles." },
      { name: "Jeff Gordon", era: "1992-2015", note: "Four championships and 93 wins." },
      { name: "David Pearson", era: "1960-1986", note: "Won at a higher rate than anyone." },
    ],
  },
];

export interface ChampionshipLeague {
  slug: string;
  name: string;
  trophy: string;
  blurb: string;
  mostTitles: { team: string; titles: number }[];
  recent: { year: string; champion: string; note: string }[];
}

export const CHAMPIONSHIPS: ChampionshipLeague[] = [
  {
    slug: "nfl",
    name: "NFL",
    trophy: "Vince Lombardi Trophy — Super Bowl",
    blurb: "Played every February since 1967; the most-watched annual broadcast in the United States.",
    mostTitles: [
      { team: "Pittsburgh Steelers", titles: 6 },
      { team: "New England Patriots", titles: 6 },
      { team: "San Francisco 49ers", titles: 5 },
      { team: "Dallas Cowboys", titles: 5 },
      { team: "Green Bay Packers", titles: 4 },
      { team: "New York Giants", titles: 4 },
    ],
    recent: [
      { year: "2024", champion: "Kansas City Chiefs", note: "Beat San Francisco in overtime, back-to-back titles." },
      { year: "2023", champion: "Kansas City Chiefs", note: "Beat Philadelphia 38-35 in Glendale." },
      { year: "2022", champion: "Los Angeles Rams", note: "Beat Cincinnati at their own stadium." },
      { year: "2021", champion: "Tampa Bay Buccaneers", note: "Brady's seventh, at home in Tampa." },
      { year: "2020", champion: "Kansas City Chiefs", note: "First title in 50 years." },
    ],
  },
  {
    slug: "nba",
    name: "NBA",
    trophy: "Larry O'Brien Championship Trophy",
    blurb: "Decided by a best-of-seven Finals each June.",
    mostTitles: [
      { team: "Boston Celtics", titles: 18 },
      { team: "Los Angeles Lakers", titles: 17 },
      { team: "Golden State Warriors", titles: 7 },
      { team: "Chicago Bulls", titles: 6 },
      { team: "San Antonio Spurs", titles: 5 },
    ],
    recent: [
      { year: "2024", champion: "Boston Celtics", note: "Beat Dallas in five for a record 18th title." },
      { year: "2023", champion: "Denver Nuggets", note: "Jokic led Denver to a first championship." },
      { year: "2022", champion: "Golden State Warriors", note: "Curry's first Finals MVP." },
      { year: "2021", champion: "Milwaukee Bucks", note: "Antetokounmpo's 50-point closeout game." },
      { year: "2020", champion: "Los Angeles Lakers", note: "The bubble title in Orlando." },
    ],
  },
  {
    slug: "mlb",
    name: "MLB",
    trophy: "Commissioner's Trophy — World Series",
    blurb: "First played in 1903, the oldest championship series in North American pro sport.",
    mostTitles: [
      { team: "New York Yankees", titles: 27 },
      { team: "St. Louis Cardinals", titles: 11 },
      { team: "Oakland Athletics", titles: 9 },
      { team: "Boston Red Sox", titles: 9 },
      { team: "Los Angeles Dodgers", titles: 8 },
    ],
    recent: [
      { year: "2024", champion: "Los Angeles Dodgers", note: "Beat the Yankees in five games." },
      { year: "2023", champion: "Texas Rangers", note: "First title in franchise history." },
      { year: "2022", champion: "Houston Astros", note: "Beat Philadelphia in six." },
      { year: "2021", champion: "Atlanta Braves", note: "First since 1995." },
      { year: "2020", champion: "Los Angeles Dodgers", note: "The shortened-season title in Arlington." },
    ],
  },
  {
    slug: "nhl",
    name: "NHL",
    trophy: "Stanley Cup",
    blurb: "The oldest trophy competed for by professional athletes in North America, first awarded in 1893.",
    mostTitles: [
      { team: "Montreal Canadiens", titles: 24 },
      { team: "Toronto Maple Leafs", titles: 13 },
      { team: "Detroit Red Wings", titles: 11 },
      { team: "Boston Bruins", titles: 6 },
      { team: "Chicago Blackhawks", titles: 6 },
    ],
    recent: [
      { year: "2024", champion: "Florida Panthers", note: "Won Game 7 against Edmonton." },
      { year: "2023", champion: "Vegas Golden Knights", note: "Title in their sixth season." },
      { year: "2022", champion: "Colorado Avalanche", note: "Beat two-time champion Tampa Bay." },
      { year: "2021", champion: "Tampa Bay Lightning", note: "Back-to-back Cups." },
      { year: "2020", champion: "Tampa Bay Lightning", note: "The bubble Cup in Edmonton." },
    ],
  },
  {
    slug: "mls",
    name: "MLS",
    trophy: "Philip F. Anschutz Trophy — MLS Cup",
    blurb: "A single-match final at the higher seed's stadium since 2012.",
    mostTitles: [
      { team: "LA Galaxy", titles: 6 },
      { team: "D.C. United", titles: 4 },
      { team: "Sporting Kansas City", titles: 2 },
      { team: "Houston Dynamo", titles: 2 },
    ],
    recent: [
      { year: "2024", champion: "LA Galaxy", note: "A record sixth MLS Cup." },
      { year: "2023", champion: "Columbus Crew", note: "Beat LAFC at Lower.com Field." },
      { year: "2022", champion: "LAFC", note: "Won on penalties after a wild final." },
      { year: "2021", champion: "New York City FC", note: "Beat Portland on penalties." },
    ],
  },
  {
    slug: "soccer",
    name: "World Soccer",
    trophy: "FIFA World Cup and UEFA Champions League",
    blurb: "Club football's biggest night in late May, and the World Cup every four years.",
    mostTitles: [
      { team: "Real Madrid (European Cup)", titles: 15 },
      { team: "AC Milan (European Cup)", titles: 7 },
      { team: "Brazil (World Cup)", titles: 5 },
      { team: "Germany (World Cup)", titles: 4 },
      { team: "Italy (World Cup)", titles: 4 },
    ],
    recent: [
      { year: "2024", champion: "Real Madrid", note: "Champions League title number 15, beating Dortmund at Wembley." },
      { year: "2023", champion: "Manchester City", note: "Completed the treble in Istanbul." },
      { year: "2022", champion: "Argentina", note: "World Cup won on penalties against France." },
      { year: "2021", champion: "Chelsea", note: "Beat Manchester City in Porto." },
    ],
  },
  {
    slug: "college-football",
    name: "College Football",
    trophy: "College Football Playoff National Championship",
    blurb: "A 12-team playoff since the 2024 season, decided in January.",
    mostTitles: [
      { team: "Alabama (AP era)", titles: 13 },
      { team: "Notre Dame", titles: 11 },
      { team: "Ohio State", titles: 8 },
      { team: "Oklahoma", titles: 7 },
    ],
    recent: [
      { year: "2025", champion: "Ohio State", note: "Won the first expanded 12-team playoff." },
      { year: "2024", champion: "Michigan", note: "Beat Washington for a first title since 1997." },
      { year: "2023", champion: "Georgia", note: "Back-to-back championships." },
      { year: "2022", champion: "Georgia", note: "Ended a 41-year drought." },
    ],
  },
  {
    slug: "college-basketball",
    name: "College Basketball",
    trophy: "NCAA Division I Men's Basketball Championship",
    blurb: "March Madness — 68 teams, three weekends, one champion.",
    mostTitles: [
      { team: "UCLA", titles: 11 },
      { team: "Kentucky", titles: 8 },
      { team: "North Carolina", titles: 6 },
      { team: "Duke", titles: 5 },
      { team: "UConn", titles: 6 },
    ],
    recent: [
      { year: "2025", champion: "Florida", note: "Beat Houston in San Antonio." },
      { year: "2024", champion: "UConn", note: "Back-to-back titles, unbeaten in the tournament." },
      { year: "2023", champion: "UConn", note: "Won every tournament game by double digits." },
      { year: "2022", champion: "Kansas", note: "Came back from 15 down in the final." },
    ],
  },
];

export interface FranchiseRecord {
  team: string;
  league: string;
  founded: string;
  titles: string;
  retired: string[];
  records: { label: string; value: string }[];
}

export const FRANCHISE_RECORDS: FranchiseRecord[] = [
  {
    team: "Dallas Cowboys",
    league: "NFL",
    founded: "1960",
    titles: "5 Super Bowls",
    retired: ["No numbers officially retired — honoured in the Ring of Honor"],
    records: [
      { label: "Passing yards", value: "Tony Romo — 34,183" },
      { label: "Rushing yards", value: "Emmitt Smith — 17,162" },
      { label: "Receiving yards", value: "Michael Irvin — 11,904" },
    ],
  },
  {
    team: "New England Patriots",
    league: "NFL",
    founded: "1960",
    titles: "6 Super Bowls",
    retired: ["20 Gino Cappelletti", "40 Mike Haynes", "57 Steve Nelson", "73 John Hannah", "78 Bruce Armstrong", "79 Jim Lee Hunt", "89 Bob Dee"],
    records: [
      { label: "Passing yards", value: "Tom Brady — 74,571" },
      { label: "Rushing yards", value: "Sam Cunningham — 5,453" },
      { label: "Receptions", value: "Wes Welker — 672" },
    ],
  },
  {
    team: "Boston Celtics",
    league: "NBA",
    founded: "1946",
    titles: "18 NBA championships",
    retired: ["6 Bill Russell", "33 Larry Bird", "32 Kevin McHale", "00 Robert Parish", "34 Paul Pierce", "5 Kevin Garnett"],
    records: [
      { label: "Points", value: "John Havlicek — 26,395" },
      { label: "Rebounds", value: "Bill Russell — 21,620" },
      { label: "Assists", value: "Bob Cousy — 6,945" },
    ],
  },
  {
    team: "Los Angeles Lakers",
    league: "NBA",
    founded: "1947",
    titles: "17 NBA championships",
    retired: ["8 & 24 Kobe Bryant", "32 Magic Johnson", "33 Kareem Abdul-Jabbar", "34 Shaquille O'Neal", "42 James Worthy"],
    records: [
      { label: "Points", value: "Kobe Bryant — 33,643" },
      { label: "Rebounds", value: "Elgin Baylor — 11,463" },
      { label: "Assists", value: "Magic Johnson — 10,141" },
    ],
  },
  {
    team: "New York Yankees",
    league: "MLB",
    founded: "1903",
    titles: "27 World Series",
    retired: ["3 Babe Ruth", "4 Lou Gehrig", "5 Joe DiMaggio", "7 Mickey Mantle", "2 Derek Jeter", "42 Mariano Rivera"],
    records: [
      { label: "Home runs", value: "Babe Ruth — 659" },
      { label: "Hits", value: "Derek Jeter — 3,465" },
      { label: "Saves", value: "Mariano Rivera — 652" },
    ],
  },
  {
    team: "Montreal Canadiens",
    league: "NHL",
    founded: "1909",
    titles: "24 Stanley Cups",
    retired: ["9 Maurice Richard", "4 Jean Béliveau", "10 Guy Lafleur", "29 Ken Dryden", "33 Patrick Roy"],
    records: [
      { label: "Goals", value: "Maurice Richard — 544" },
      { label: "Points", value: "Guy Lafleur — 1,246" },
      { label: "Wins (goalie)", value: "Jacques Plante — 314" },
    ],
  },
  {
    team: "Chicago Bulls",
    league: "NBA",
    founded: "1966",
    titles: "6 NBA championships",
    retired: ["23 Michael Jordan", "33 Scottie Pippen", "4 Jerry Sloan", "10 Bob Love"],
    records: [
      { label: "Points", value: "Michael Jordan — 29,277" },
      { label: "Rebounds", value: "Michael Jordan — 5,836" },
      { label: "Assists", value: "Michael Jordan — 5,012" },
    ],
  },
  {
    team: "Green Bay Packers",
    league: "NFL",
    founded: "1919",
    titles: "4 Super Bowls, 13 NFL titles",
    retired: ["3 Tony Canadeo", "4 Brett Favre", "14 Don Hutson", "15 Bart Starr", "66 Ray Nitschke", "92 Reggie White"],
    records: [
      { label: "Passing yards", value: "Brett Favre — 61,655" },
      { label: "Rushing yards", value: "Ahman Green — 8,322" },
      { label: "Receiving yards", value: "Donald Driver — 10,137" },
    ],
  },
];
