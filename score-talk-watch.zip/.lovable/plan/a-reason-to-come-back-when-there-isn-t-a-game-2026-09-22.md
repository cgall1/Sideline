# A reason to come back when there isn't a game

Sideline already has the pieces: fan spaces, posts, debates, polls, replies, votes, fan profiles, the fan gallery, predictions, fantasy and history. What's missing is the *loop* — something new waiting for you on a Tuesday in July.

This plan adds five things that make the quiet days the point.

## 1. The Daily Debate

One question every day, chosen automatically from what's actually happening (or, in the off-season, from history and rivalries):

- Off a result: "Was that the best comeback of the season?"
- Off the calendar: "Ten years ago today… who was the better team?"
- Off a rivalry or hall-of-fame entry when nothing is on.
- Pure takes: "Overrated or underrated: ___".

Each debate is a real post in a space, with two sides to pick and a running tally. It appears at the top of Community, on the home page, and in its own `/daily` archive so yesterday's argument is still readable.

## 2. Streaks and a fan profile worth building

A visible reason to return:

- A **day streak** for posting, replying, voting or picking — shown in the header area of your profile.
- **Badges** earned from real activity: first post, 10 replies, a debate win, a perfect prediction week, a gallery post, following five clubs.
- Profile pages get a proper front: streak, badges, teams followed, recent posts, prediction record.

Nothing is fake — every count comes from rows that already exist.

## 3. Rumors, trades and the off-season desk

A dedicated hub at `/offseason` pulling together what fans argue about when no one is playing:

- Transfer and trade chatter (the existing moves and news feeds, sorted by team).
- Free agency and draft/transfer-window countdowns.
- "Rumor mill" posts in the transfers space, with an "I believe / I don't" vote on each.
- Next season's first fixtures per league, so there's always a date to look forward to.

## 4. Throwback and memory threads

Sports memory is the deepest well:

- **On this day** — results and moments from the same calendar day in past seasons, each with a one-tap "talk about this" that opens a thread.
- **Memory prompts** in each team space: "Your favorite match in person", "The one that still hurts", "Best shirt we ever wore".
- Rivalry and hall-of-fame pages get a discussion thread attached, so history isn't read-only.

## 5. Bring people back on purpose

The return trip has to be triggered, not hoped for:

- A **notifications bell**: replies to your posts, votes on them, new followers, and the day's debate. Reads the alerts you already have plus new community events.
- **Push for community**, reusing the existing phone alerts: an optional daily nudge ("Today's debate is up") and replies to you, respecting your quiet hours.
- **"What you missed"** strip on the home page: top posts, the day's debate result and the liveliest space since your last visit.

## Technical notes

- New tables: `daily_debates` (date, question, two sides, optional league/team context, source kind), `debate_votes` (user + side, one per debate), `fan_streaks` (user, current, longest, last active day), `fan_badges` (user, badge key, earned at), `space_notifications` (user, kind, actor, post/reply reference, read flag). All with RLS: public read where content is public, owner-only writes, counts through `SECURITY DEFINER` RPCs as with existing community tables, and explicit `GRANT`s.
- Daily debate generation runs as a cron-backed public API route (`/api/public/cron/daily-debate`) with the shared cron secret, same pattern as score alerts: pick yesterday's most-discussed result, else an "on this day" entry from `src/data/history.ts` / `legacy.ts`, else a rivalry; phrase it through the AI gateway with a template fallback so it never invents facts.
- Streaks and badges update in the existing write paths (`createSpacePost`, `addReply`, `toggleVote`, prediction save) through one `recordFanActivity` helper.
- Notifications are inserted by database triggers on `space_replies`, `space_votes` and `space_follows`, then read through the existing client.
- Off-season hub reuses `moves.functions.ts`, `news.functions.ts` and `schedule.functions.ts` — no new data source.
- New routes: `/daily`, `/daily/$date`, `/offseason`, `/on-this-day`, plus a notifications panel in the header and profile upgrades on the existing fan profile page.
- Each new page gets its own title, description and share tags, and joins the sitemap.
