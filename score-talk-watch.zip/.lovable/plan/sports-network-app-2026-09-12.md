# Sports Network App

A multi-league sports hub covering NFL, NHL, NBA, MLB, MLS, and international soccer, with scores, media, broadcast info, and fan community.

## Pages

- **Home (/)** — Live now strip, top stories, trending games, quick league switcher.
- **Scores (/scores)** — Live scores, schedules, and box-score style stats. Filter by league and by date; games auto-refresh on a short interval with a "live" pulse on in-progress games.
- **Standings & stats (/standings)** — League tables and leader boards per league.
- **Media (/media)** — News, analysis pieces, and video highlight cards; article detail page at /media/$slug.
- **Where to Watch (/watch)** — Broadcast guide: game, kickoff time in the viewer's timezone, and the networks/streamers carrying it, filterable by league and provider.
- **Community (/community)** — Live game discussion threads, fan reaction bar (emoji reactions per game), and interactive polls with instant result bars.

## Data

There is no sports data provider connected, so the first build runs on a rich built-in dataset (real teams and league structures, invented fixtures/scores) with simulated live updates so the dashboard genuinely ticks. Community posts, reactions, and poll votes are in-memory for now.

If you want real fixtures and real accounts (sign-in, persistent comments and votes), the next step is turning on Lovable Cloud plus a sports data feed — tell me and I will wire it.

## Design

Broadcast-booth energy: deep charcoal base, high-contrast scoreboard typography, one electric accent per league used for filters and live indicators. Dense score cards like a real scoreboard, not airy marketing cards. Motion is restrained — score ticks and live dots only.

## Technical notes

- TanStack Start file routes; shared header/nav in `__root.tsx`, per-route `head()` metadata.
- League/date filters live in URL search params via `validateSearch` so views are shareable.
- Mock feed module exposes query-shaped functions; polling via TanStack Query `refetchInterval` so swapping in a real API later is a single-layer change.
- Design tokens (league accents, live states) added to `src/styles.css`; no hardcoded colors in components.
