# Live sports data from API-SPORTS

Bring Sideline's scores, schedules, rosters, injuries, standings, stats, play-by-play and
history from a paid, credentialed feed (API-SPORTS), replacing today's free feeds one sport
at a time. Your key lives only on the server and is never sent to the browser.

## How it works

- Your API-SPORTS key is saved as a backend secret. Every request to the provider is made by
  Sideline's own server; the browser only ever talks to Sideline.
- A small server layer handles the provider: one host per sport (football/soccer, basketball,
  baseball, hockey, American football), shared error handling, and short-lived caching so a
  hundred visitors watching the same game cost one provider call, not a hundred.
- Live pages refresh every 30 seconds; finished games and standings refresh slowly; schedules,
  rosters and history are cached for hours.
- If the provider is unavailable or a sport isn't in your plan, the page quietly falls back to
  the feed it uses today, so nothing goes blank.

## Rollout order (sport by sport)

Each step is shipped and checked before the next one starts.

1. **Foundation** — secret, server layer, caching, health check page for you to confirm the key
   works and see which sports your plan covers.
2. **Live scores** — the scores page, homepage ticker and sport hubs, starting with soccer, then
   NBA/NFL/MLB/NHL.
3. **Standings and schedules** — league tables and calendars per sport.
4. **Rosters, player pages and injuries** — squads, player profiles, injury reports.
5. **Statistics** — team and player season stats, game leaders.
6. **Play-by-play and match centre** — timeline, events and lineups on every match page.
7. **Historical data** — past seasons for the season-by-season charts and history pages.

## What you'll need to do

- Subscribe to API-SPORTS and get your key (a free tier works for testing; live play-by-play and
  multi-sport coverage need a paid plan).
- Paste the key once into the secure form I'll open — I never see it, and it never reaches the
  browser.

## Technical detail

- Secret: `API_SPORTS_KEY`, read with `process.env` inside handlers only.
- `src/lib/apisports.server.ts` — typed fetch wrapper: per-sport base hosts
  (`v3.football.api-sports.io`, `v1.basketball`, `v1.baseball`, `v1.hockey`,
  `v1.american-football`), `x-apisports-key` header, timeout + retry, provider-error passthrough
  to the server log only, and an in-memory TTL cache keyed by sport+endpoint+params
  (live 25s, standings 5m, fixtures 1h, rosters/history 12h).
- `src/lib/apisports.functions.ts` — `createServerFn` endpoints returning plain DTOs that match
  the shapes already used by `src/lib/feed.ts` (`Game`, `StandingRow`, `ScheduleGame`,
  `GameSummary`, roster/injury/stat types), so pages swap sources without UI rewrites.
- Normalisation adapters map API-SPORTS ids to the existing `LeagueId` / `src/data/soccer.ts`
  keys, with per-league season handling.
- Query options in `src/lib/feed.ts` gain a source switch per sport: when the provider returns
  data it wins, otherwise the current ESPN-backed function is used. `refetchInterval` 30s for
  live views, existing intervals elsewhere.
- Durable pieces (score alerts cron, fantasy scoring) move to the provider in step 5-6 so their
  stat lines stay consistent with the pages.
- No new database tables; caching is request-level, plus existing Supabase tables unchanged.
