# Fans help decide what Sideline covers

Turn the audience into contributors by adding places where fans shape the site, all built into what already exists: Community, Fan Spaces, the Daily Debate, polls and the AI assistant.

## 1. "You pick today's debate"
- Fans suggest debate questions and upvote each other's ideas.
- The most-voted idea becomes tomorrow's Daily Debate, credited to the fan who suggested it ("Suggested by @name").
- If nobody suggests anything, the current automatic debate is used, so there is never a gap.
- Shows on `/daily` and the Community page.

## 2. "Deep dive requests"
- Fans vote on which topic gets a deeper breakdown this week (a player, a trade, a team's form, a rule change).
- Each week the winning topic gets a full breakdown page built only from real data (stats, standings, news, fan discussion), written by the AI assistant with a clear "based on these sources" section.
- Past deep dives stay in an archive at `/deep-dives`.

## 3. "Ask the athlete" question board
- Fans submit questions for a named athlete or coach and upvote the best ones.
- Top questions are shown as a ranked list you can share or send to a team's media contact.
- Honest labeling: answers only appear if a real answer is added later by you (admin); nothing is invented.

## 4. "Fan pulse" on every big issue
- One-tap "agree / disagree / unsure" pulse on news stories, match pages and Why It Matters cards.
- Results show as a simple bar ("68% of fans agree") plus a link to join the discussion.
- Weekly "What fans think" summary on the home page and in the For You feed.

## 5. Recognition so people feel heard
- New badges: "Debate picked", "Deep dive chosen", "Top question".
- Alerts bell notifies you when your idea is picked or your question hits the top 10.
- Phone ping (respecting quiet hours) when your suggestion goes live.

## 6. A simple admin corner
- Private page for you to approve or hide suggestions, add athlete answers, and pin topics.
- Uses a proper roles setup so only admins see it.

## Where it appears
- New "Fan Voice" hub at `/fan-voice` with tabs: Suggest a debate, Deep dives, Ask the athlete, Fan pulse.
- Added to the My Sideline menu in all five languages, plus a small card on Community.

## Technical details
- New tables (all with GRANTs + RLS, public read of visible rows, owner-only writes, counts via SECURITY DEFINER RPCs): `topic_suggestions` (kind: debate | deep_dive | athlete_question, title, body, target, status, hidden), `topic_votes`, `issue_pulse` (subject_type, subject_id, user_id, stance), `deep_dives` (topic_id, week, body, sources jsonb), `user_roles` + `app_role` enum + `has_role()` for admin.
- Daily-debate cron (`/api/public/cron/daily-debate`) first checks the top-voted approved debate suggestion from the last 24h, falls back to the current generator.
- Weekly cron `/api/public/cron/deep-dive` (Mondays) picks the winning topic and writes the breakdown via AI gateway (openai/gpt-6-astra) from existing feeds; template fallback.
- Badge rules added to `refresh_fan_badges()`; notifications via triggers into `space_notifications`; push via existing `push_alerts` + `sendTickle`.
- Rate limit and blocked-words filter reused from Fan Spaces; reports reuse `space_reports`.
- New routes with own head()/sitemap: `/fan-voice`, `/deep-dives`, `/deep-dives/$id`, `/admin/fan-voice` (noindex).
