# Make the community the heart of Sideline

Today the community is a side room: a chat attached to each live game, some polls, and the Fan Gallery. Fans can only talk when a game is on, and only about that game. The plan below turns it into a place people go to for the people.

## What fans get

**1. Fan Spaces**
Communities fans join and come back to — one per team, per league, per sport, plus open topic spaces (transfers, fantasy, betting talk, "rookie watch"). Every space has its own feed, member count and join button. Following a team automatically suggests its space.

**2. Posts, not just chat messages**
A real post: a title, text, an optional picture, and a tag — Discussion, Debate, Question, Opinion, Poll, Hot Take. Posts live in a space, get upvoted, and collect threaded replies (reply to a reply). Sort by Hot, New or Top.

**3. Debates and polls anywhere**
Any fan can attach a poll to a post (2–4 options) or start a head-to-head Debate post — two sides, pick yours, see the split live, argue it out underneath.

**4. Fan profiles**
Every fan gets a page: their teams, their badge colors, their posts, their replies, their gallery uploads and their prediction record. Fans can follow each other, and a "Fans like you" panel suggests people who follow the same teams.

**5. A community home**
`/community` becomes a feed: your spaces first, then what's hot across Sideline, with live game threads as one card among many rather than the whole page. A sidebar shows your spaces, trending spaces and top fans this week.

**6. Moderation and safety**
Report button on every post and reply; authors can delete their own; a simple blocked-words filter and a rate limit so nobody can flood a space. Signed-out visitors can read everything; posting needs an account.

## How it gets built

New tables (all with row-level rules, readable by everyone, writable by the author):
- `spaces` — slug, name, kind (team/league/sport/topic), league, team_id, description, image
- `space_members` — who joined what
- `fan_posts_v2` (name TBD to avoid clashing with the gallery table) — space_id, author, title, body, kind, image_path, pinned
- `fan_replies` — post_id, parent_reply_id (threading), body
- `fan_votes` — post/reply upvotes, one per fan
- `fan_polls` + `fan_poll_votes` — poll options and tallies
- `fan_follows` — fan follows fan
- `fan_reports` — reported content for review

Spaces get seeded from the existing league and team data, so day one has a space for every team in every league we already cover.

New pages: `/spaces` (browse and join), `/s/$slug` (one space's feed), `/post/$id` (post with threaded replies), `/fan/$id` (profile). `/community` is rebuilt as the feed. The Fan Gallery stays and its uploads start showing in the relevant team's space.

Ranking: Hot = upvotes and replies decayed by age, computed in the query — no background job needed.

## Notes

- This is a large build. Suggested order: spaces + posts + replies first (the core), then votes and sorting, then profiles and following, then polls/debates and moderation.
- Existing game threads, reactions and game polls stay exactly as they are; they get surfaced inside the matching team spaces.
- Phone alerts can later extend to "someone replied to you" — not in this plan.
