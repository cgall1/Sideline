# Roadmap

## Fan-first community (approved plan, built into the existing /community)

- [x] Database: spaces, memberships, posts, replies, votes, polls, fan follows, reports
- [x] Seed spaces from existing leagues + topics
- [x] Data layer (src/lib/spaces.ts) — feeds, hot ranking, join, post, reply, vote, poll, follow, report
- [x] /spaces browse + join
- [x] /s/$slug space feed
- [x] /post/$postId post with threaded replies
- [x] /fan/$fanId profile + follow
- [x] Rebuild /community as the feed (game threads kept below)
- [x] Nav links + typecheck + build check

## One connected match page (in progress)
- [x] MatchHub: form, injuries, relevant news, highlight clips, where to watch, tickets, fan talk
- [ ] Wire the same connected links into soccer match centre
- [x] "Why it matters" context layer — match pages, soccer match centre, sport hubs ("Why today matters"), For You ("What that meant for your teams")

## Come-back loop (plan approved 2026-09-22)
- [x] Daily debate tables, generator, /daily + /daily/$date
- [x] Streaks + badges (db functions, client)
- [x] Notifications table/triggers + header bell
- [x] /throwback (on this day + memory prompts)
- [x] /offseason desk
- [x] Profile streak/badges display
- [x] Record activity on post/reply/vote writes
- [x] Verified: typecheck clean, build OK, /daily /throwback /offseason 200
- [x] Push nudge for the daily debate (daily 15:00 UTC)
- [x] "What you missed since your last visit" strip on the home page
- [x] Rumour-mill believe/don't-believe vote on transfer posts
- [x] Privacy policy page (/privacy) + footer link
- [ ] Publish

## Firebase Cloud Messaging + app stores (requested 2026-09-24)
- [ ] Connect Firebase Cloud Messaging connector (user completes the in-chat card)
- [ ] Register devices with FCM (client tokens stored server-side)
- [ ] Route push sends through FCM HTTP v1 (APNs for iOS, device tokens for Android)
- [ ] iOS web push via installed PWA (VAPID) remains as fallback
- [ ] Store packaging for Apple App Store + Google Play (native wrapper)
- [ ] Publish

- [ ] Wrap Sideline as a native app (Capacitor) for App Store + Google Play — blocked on Firebase push connection

## Fan Voice (plan approved 2026-09-24)
- [x] Fan Voice page (suggest debate, deep-dive votes, ask the athlete), deep dives archive, fan pulse widget, menu entry
- [x] Top suggestion feeds daily debate; weekly deep-dive writer; pulse on match/news; badges; admin page
- [ ] Plan the user's next idea (waiting for them to send it)

## Next three (requested 2026-09-24)
- [x] First-visit "pick your teams" welcome
- [x] Shareable fan cards (/fan-card)
- [x] Automatic "story of the game" on finished match pages
- [ ] Publish

## Next three (requested 2026-09-24, round 2)
- [x] Weekly fan awards on Community (+ badges)
- [x] Rivalry week strip on the home page
- [x] Offline mode: last-seen scores saved on device + offline banner
